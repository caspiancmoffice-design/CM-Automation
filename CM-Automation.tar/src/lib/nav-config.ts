// nav-config.ts — Sidebar navigation config
import type { ViewKey } from "./types";
import {
  LayoutDashboard,
  FolderKanban,
  ListTodo,
  FileText,
  Mail,
  ScrollText,
  ShoppingCart,
  Truck,
  BarChart3,
  Bell,
  Search,
  Settings,
  Users,
  UserCircle,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  key: ViewKey;
  label: string;
  icon: LucideIcon;
  badge?: number;
  group?: "main" | "management" | "system";
}

export const navGroups: { title: string; items: NavItem[] }[] = [
  {
    title: "اصلی",
    items: [
      { key: "dashboard", label: "داشبورد", icon: LayoutDashboard, group: "main" },
      { key: "projects", label: "پروژه‌ها", icon: FolderKanban, group: "main" },
      { key: "tasks", label: "وظایف", icon: ListTodo, group: "main", badge: 47 },
      { key: "documents", label: "اسناد", icon: FileText, group: "main" },
      { key: "correspondence", label: "مکاتبات", icon: Mail, group: "main", badge: 3 },
      { key: "contracts", label: "قراردادها", icon: ScrollText, group: "main", badge: 6 },
      { key: "procurement", label: "تدارکات", icon: ShoppingCart, group: "main", badge: 6 },
      { key: "vendors", label: "تأمین‌کنندگان", icon: Truck, group: "main" },
      { key: "reports", label: "گزارش‌ها", icon: BarChart3, group: "main" },
    ],
  },
  {
    title: "مدیریت",
    items: [
      { key: "users", label: "کاربران و نقش‌ها", icon: Users, group: "management" },
      { key: "notifications", label: "اعلان‌ها", icon: Bell, group: "management", badge: 3 },
      { key: "search", label: "جستجو", icon: Search, group: "management" },
    ],
  },
  {
    title: "سیستم",
    items: [
      { key: "profile", label: "پروفایل کاربر", icon: UserCircle, group: "system" },
      { key: "settings", label: "تنظیمات", icon: Settings, group: "system" },
    ],
  },
];
