// types.ts — Domain types for CM Automation platform
// Based on PRD & SAPDS documents

export type ViewKey =
  | "login"
  | "dashboard"
  | "projects"
  | "project-details"
  | "tasks"
  | "task-details"
  | "documents"
  | "correspondence"
  | "contracts"
  | "contract-details"
  | "contract-new"
  | "procurement"
  | "procurement-details"
  | "procurement-new"
  | "vendors"
  | "reports"
  | "notifications"
  | "search"
  | "profile"
  | "users"
  | "settings";

export type OrganizationType =
  | "contractor" // پیمانکار
  | "consultant" // مهندس مشاور
  | "employer" // کارفرما
  | "epc"
  | "subcontractor" // پیمانکار جزء
  | "custom"; // سایر

export type ProjectRole =
  | "project_manager" // مدیر پروژه
  | "site_manager" // سرپرست کارگاه
  | "technical_office" // کارشناس دفتر فنی
  | "execution_engineer" // کارشناس اجرا
  | "electrical_engineer" // کارشناس برق
  | "mechanical_engineer" // کارشناس مکانیک
  | "custom";

export type TaskMemberRole =
  | "owner" // مسئول
  | "contributor" // همکار
  | "reviewer" // بازبین
  | "approver" // تأییدکننده
  | "observer"; // ناظر

export type TaskStatus =
  | "backlog" // عقب‌مانده
  | "todo" // در انتظار
  | "in_progress" // در حال انجام
  | "review" // در حال بازبینی
  | "done" // انجام شده
  | "blocked"; // مسدود

export type TaskPriority = "low" | "medium" | "high" | "critical";

export type ProjectStatus =
  | "planning" // برنامه‌ریزی
  | "active" // فعال
  | "on_hold" // متوقف
  | "completed" // تکمیل شده
  | "cancelled"; // لغو شده

export type DocumentCategory =
  | "drawing" // نقشه
  | "specification" // مشخصه فنی
  | "contract" // قرارداد
  | "report" // گزارش
  | "permit" // مجوز
  | "invoice" // فاکتور
  | "correspondence" // نامه
  | "other";

export type CorrespondenceDirection = "inbound" | "outbound";

export type CorrespondenceStatus =
  | "draft" // پیش‌نویس
  | "sent" // ارسال شده
  | "received" // دریافت شده
  | "in_review" // در حال بررسی
  | "answered" // پاسخ داده شده
  | "archived"; // بایگانی شده

export type NotificationType =
  | "task_assigned"
  | "task_due"
  | "doc_shared"
  | "correspondence"
  | "mention"
  | "system"
  | "approval";

export interface User {
  id: string;
  name: string; // نام و نام خانوادگی
  avatar?: string;
  email: string;
  phone?: string;
  role: ProjectRole;
  organizationId: string;
  department?: string;
  status: "active" | "inactive" | "invited";
  productivityScore: number; // 0-100
  lastSeen?: string;
}

export interface Organization {
  id: string;
  name: string;
  type: OrganizationType;
  logo?: string;
  address?: string;
  phone?: string;
  nationalId?: string;
}

export interface Project {
  id: string;
  name: string;
  code: string;
  description: string;
  status: ProjectStatus;
  organizationId: string;
  organizationName: string;
  client: string; // کارفرما
  consultant?: string; // مهندس مشاور
  contractor?: string; // پیمانکار
  startDate: string;
  endDate: string;
  progress: number; // 0-100
  budget: number; // به ریال
  spentBudget: number;
  location: string;
  managerId: string;
  managerName: string;
  teamSize: number;
  openTasks: number;
  overdueTasks: number;
  coverImage?: string;
  tags: string[];
}

export interface TaskMember {
  userId: string;
  userName: string;
  avatar?: string;
  role: TaskMemberRole;
  participationPercent: number;
  timeSpentHours: number;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  projectId: string;
  projectName: string;
  assignees: TaskMember[];
  startDate: string;
  dueDate: string;
  completedAt?: string;
  progress: number; // 0-100
  estimatedHours: number;
  spentHours: number;
  tags: string[];
  attachments: number;
  comments: number;
  subtasks: { id: string; title: string; done: boolean }[];
  workflow?: {
    currentStep: string;
    steps: { name: string; status: "done" | "current" | "pending" }[];
  };
}

export interface DocumentVersion {
  version: string;
  uploadedAt: string;
  uploadedBy: string;
  size: number;
  comment?: string;
}

export interface DocumentFile {
  id: string;
  name: string;
  category: DocumentCategory;
  projectId: string;
  projectName: string;
  mimeType: string;
  size: number;
  currentVersion: string;
  versions: DocumentVersion[];
  uploadedBy: string;
  uploadedAt: string;
  folder: string;
  sharedWith: number;
  status: "draft" | "in_review" | "approved" | "rejected";
  tags: string[];
}

export interface Correspondence {
  id: string;
  number: string; // شماره نامه
  subject: string; // موضوع
  direction: CorrespondenceDirection;
  status: CorrespondenceStatus;
  from: string;
  to: string;
  date: string;
  receivedDate?: string;
  projectId?: string;
  projectName?: string;
  priority: TaskPriority;
  attachments: number;
  body: string;
  category: string;
  responseTo?: string; // نامه والد
  // Timeline enrichment
  senderName?: string;      // نام شخص فرستنده
  senderRole?: string;      // نقش فرستنده (مدیر پروژه، کارفرما، ناظر مشاور، ...)
  receiverName?: string;    // نام شخص گیرنده
  receiverRole?: string;    // نقش گیرنده
  action?: string;          // نوع عملیات (ارسال، دریافت، پاسخ، تأیید)
}

export interface ActivityEvent {
  id: string;
  type: "task" | "document" | "correspondence" | "comment" | "approval" | "system";
  user: string;
  userAvatar?: string;
  action: string;
  target: string;
  timestamp: string;
  projectId?: string;
}

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  link?: { view: ViewKey; id?: string };
}

export interface KPI {
  label: string;
  value: number | string;
  unit?: string;
  change: number; // percent
  trend: "up" | "down" | "flat";
  sparkline?: number[];
}

export interface ChartPoint {
  label: string;
  value: number;
}
