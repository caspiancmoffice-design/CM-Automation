// jalali-utils.ts — Jalali (Persian) date utilities
// Lightweight implementation of Jalali calendar conversion
// Based on the algorithm by Kazimierz M. Borkowski

/** Gregorian date parts */
export interface DateParts {
  year: number;
  month: number; // 1-12
  day: number;   // 1-31
}

/**
 * Convert Gregorian date to Jalali (Persian) date.
 * Algorithm: based on astronomical calculations by Borkowski.
 */
export function gregorianToJalali(gy: number, gm: number, gd: number): DateParts {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy: number;
  if (gy > 1600) {
    jy = 979;
    gy -= 1600;
  } else {
    jy = 0;
    gy -= 621;
  }
  const gy2 = (gm > 2) ? (gy + 1) : gy;
  let days = (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = (days < 186) ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
  return { year: jy, month: jm, day: jd };
}

/**
 * Convert Jalali (Persian) date to Gregorian date.
 */
export function jalaliToGregorian(jy: number, jm: number, jd: number): DateParts {
  let gy: number;
  if (jy > 979) {
    gy = 1600;
    jy -= 979;
  } else {
    gy = 621;
  }
  let days = (365 * jy) + (Math.floor(jy / 33) * 8) + Math.floor(((jy % 33) + 3) / 4) + 78 + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gd = days + 1;
  const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm: number;
  for (gm = 0; gm < 13; gm++) {
    const v = sal_a[gm];
    if (gd <= v) break;
    gd -= v;
  }
  return { year: gy, month: gm, day: gd };
}

/** Check if a Jalali year is leap */
export function isJalaliLeap(jy: number): boolean {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  let jp = breaks[0];
  let jump = 0;
  for (let i = 1; i <= breaks.length; i++) {
    const jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    jp = jm;
  }
  let n = jy - jp;
  if (n < jump) {
    if (jump - n < 6) n = n - jump + Math.floor((jump + 4) / 33) * 33;
    let leap = ((n + 1) % 33 - 1) % 4;
    if (leap === -1) leap = 4;
    return leap === 0;
  }
  return false;
}

/** Number of days in a Jalali month */
export function jalaliMonthDays(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isJalaliLeap(jy) ? 30 : 29;
}

/** Format a Date object as Jalali string "YYYY/MM/DD" */
export function formatJalali(date: Date, separator: string = "/"): string {
  const parts = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  return `${parts.year}${separator}${String(parts.month).padStart(2, "0")}${separator}${String(parts.day).padStart(2, "0")}`;
}

/** Parse a Jalali date string "YYYY/MM/DD" to Date object (noon UTC to avoid TZ issues) */
export function parseJalali(dateStr: string): Date | null {
  if (!dateStr) return null;
  const parts = dateStr.split(/[\/\-\.]/).map((p) => parseInt(p.trim(), 10));
  if (parts.length !== 3 || parts.some(isNaN)) return null;
  const [jy, jm, jd] = parts;
  if (jy < 1300 || jy > 1500 || jm < 1 || jm > 12 || jd < 1 || jd > 31) return null;
  const g = jalaliToGregorian(jy, jm, jd);
  // Use noon to avoid DST/TZ edge cases
  return new Date(g.year, g.month - 1, g.day, 12, 0, 0);
}

/**
 * Add months to a Jalali date string and return new Jalali string.
 * Handles month-end edge cases (e.g., adding 1 month to 1403/12/30 → 1404/01/30 or end of next month).
 */
export function addMonthsToJalali(dateStr: string, months: number): string {
  const date = parseJalali(dateStr);
  if (!date) return "";
  const j = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  let newYear = j.year;
  let newMonth = j.month + months;
  // Normalize year/month
  while (newMonth > 12) {
    newMonth -= 12;
    newYear++;
  }
  while (newMonth < 1) {
    newMonth += 12;
    newYear--;
  }
  // Clamp day to month length
  const maxDay = jalaliMonthDays(newYear, newMonth);
  const newDay = Math.min(j.day, maxDay);
  return `${newYear}/${String(newMonth).padStart(2, "0")}/${String(newDay).padStart(2, "0")}`;
}

/** Add days to a Jalali date string */
export function addDaysToJalali(dateStr: string, days: number): string {
  const date = parseJalali(dateStr);
  if (!date) return "";
  const newDate = new Date(date);
  newDate.setDate(newDate.getDate() + days);
  return formatJalali(newDate);
}

/** Get today's Jalali date string */
export function todayJalali(): string {
  return formatJalali(new Date());
}

/** Persian month names */
export const jalaliMonthNames = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

/** Format Jalali date with month name, e.g., "۱۵ مهر ۱۴۰۳" */
export function formatJalaliLong(dateStr: string): string {
  const date = parseJalali(dateStr);
  if (!date) return dateStr;
  const j = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  return `${toPersianDigits(j.day)} ${jalaliMonthNames[j.month - 1]} ${toPersianDigits(j.year)}`;
}

/** Convert English digits to Persian digits */
export function toPersianDigits(s: string | number): string {
  const persianDigits = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
  return String(s).replace(/\d/g, (d) => persianDigits[parseInt(d, 10)]);
}

/** Convert Persian digits to English */
export function toEnglishDigits(s: string): string {
  const persianDigits = "۰۱۲۳۴۵۶۷۸۹";
  const arabicDigits = "٠١٢٣٤٥٦٧٨٩";
  return s
    .replace(/[۰-۹]/g, (d) => String(persianDigits.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String(arabicDigits.indexOf(d)));
}
