// use-crud.ts — Hook for CRUD operations with toast feedback
"use client";
import { useData } from "./data-context";
import { api } from "./api";
import { toast } from "sonner";
import { useCallback } from "react";

export function useCrud() {
  const { refresh } = useData();

  const createTask = useCallback(async (data: Record<string, unknown>) => {
    try {
      await api.tasks.create(data);
      await refresh("tasks");
      toast.success("وظیفه با موفقیت ایجاد شد");
    } catch (e: any) {
      toast.error("خطا در ایجاد وظیفه", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const createProject = useCallback(async (data: Record<string, unknown>) => {
    try {
      await api.projects.create(data);
      await refresh("projects");
      toast.success("پروژه با موفقیت ایجاد شد");
    } catch (e: any) {
      toast.error("خطا در ایجاد پروژه", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const createDocument = useCallback(async (data: Record<string, unknown>) => {
    try {
      await api.documents.create(data);
      await refresh("documents");
      toast.success("سند با موفقیت بارگذاری شد");
    } catch (e: any) {
      toast.error("خطا در بارگذاری سند", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const createCorrespondence = useCallback(async (data: Record<string, unknown>) => {
    try {
      await api.correspondence.create(data);
      await refresh("correspondence");
      toast.success("مکاتبه با موفقیت ایجاد شد");
    } catch (e: any) {
      toast.error("خطا در ایجاد مکاتبه", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const createContract = useCallback(async (data: Record<string, unknown>) => {
    try {
      await api.contracts.create(data);
      await refresh("contracts");
      toast.success("قرارداد با موفقیت ایجاد شد");
    } catch (e: any) {
      toast.error("خطا در ایجاد قرارداد", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const createVendor = useCallback(async (data: Record<string, unknown>) => {
    try {
      await api.vendors.create(data);
      await refresh("vendors");
      toast.success("وندور با موفقیت ایجاد شد");
    } catch (e: any) {
      toast.error("خطا در ایجاد وندور", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const createPurchaseRequest = useCallback(async (data: Record<string, unknown>) => {
    try {
      await api.procurement.create(data);
      await refresh("procurement");
      toast.success("درخواست خرید با موفقیت ایجاد شد");
    } catch (e: any) {
      toast.error("خطا در ایجاد درخواست خرید", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const changeTaskStatus = useCallback(async (taskId: string, status: string, comment?: string) => {
    try {
      await api.tasks.changeStatus(taskId, status, comment);
      await refresh("tasks");
      toast.success("وضعیت وظیفه تغییر کرد");
    } catch (e: any) {
      toast.error("خطا در تغییر وضعیت", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const deleteTask = useCallback(async (taskId: string) => {
    try {
      await api.tasks.delete(taskId);
      await refresh("tasks");
      toast.success("وظیفه حذف شد");
    } catch (e: any) {
      toast.error("خطا در حذف", { description: e.message });
      throw e;
    }
  }, [refresh]);

  const deleteVendor = useCallback(async (vendorId: string) => {
    try {
      await api.vendors.delete(vendorId);
      await refresh("vendors");
      toast.success("وندور حذف شد");
    } catch (e: any) {
      toast.error("خطا در حذف", { description: e.message });
      throw e;
    }
  }, [refresh]);

  return {
    createTask, createProject, createDocument, createCorrespondence,
    createContract, createVendor, createPurchaseRequest,
    changeTaskStatus, deleteTask, deleteVendor,
  };
}
