// fa-utils.ts — Persian formatting utilities

/** Format numbers with Persian thousands separator (using Persian digits) */
export function faNum(value: number | string): string {
  const num = typeof value === "string" ? parseInt(value, 10) : value;
  if (Number.isNaN(num)) return String(value);
  return num.toLocaleString("fa-IR");
}

/** Persian currency formatter (Rial -> Toman display convention) */
export function faCurrency(rial: number): string {
  const toman = Math.round(rial / 10);
  if (toman >= 1_000_000_000) {
    return `${(toman / 1_000_000_000).toLocaleString("fa-IR", { maximumFractionDigits: 2 })} میلیارد تومان`;
  }
  if (toman >= 1_000_000) {
    return `${(toman / 1_000_000).toLocaleString("fa-IR", { maximumFractionDigits: 1 })} میلیون تومان`;
  }
  return `${toman.toLocaleString("fa-IR")} تومان`;
}

/** Format file size in human-readable Persian */
export function faFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes.toLocaleString("fa-IR")} بایت`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toLocaleString("fa-IR", { maximumFractionDigits: 1 })} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toLocaleString("fa-IR", { maximumFractionDigits: 1 })} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toLocaleString("fa-IR", { maximumFractionDigits: 2 })} GB`;
}

/** Get Persian label for enum values */
export const faLabels = {
  // Organization types
  contractor: "پیمانکار",
  consultant: "مهندس مشاور",
  employer: "کارفرما",
  epc: "EPC",
  subcontractor: "پیمانکار جزء",
  custom: "سایر",
  // Project roles
  project_manager: "مدیر پروژه",
  site_manager: "سرپرست کارگاه",
  technical_office: "کارشناس دفتر فنی",
  execution_engineer: "کارشناس اجرا",
  electrical_engineer: "کارشناس برق",
  mechanical_engineer: "کارشناس مکانیک",
  // Task member roles
  owner: "مسئول",
  contributor: "همکار",
  reviewer: "بازبین",
  approver: "تأییدکننده",
  observer: "ناظر",
  // Task status
  backlog: "عقب‌مانده",
  todo: "در انتظار",
  in_progress: "در حال انجام",
  review: "در حال بازبینی",
  done: "انجام شده",
  blocked: "مسدود",
  // Priority
  low: "کم",
  medium: "متوسط",
  high: "بالا",
  critical: "بحرانی",
  // Project status
  planning: "برنامه‌ریزی",
  active: "فعال",
  on_hold: "متوقف",
  completed: "تکمیل شده",
  cancelled: "لغو شده",
  // Document categories
  drawing: "نقشه",
  specification: "مشخصه فنی",
  contract: "قرارداد",
  report: "گزارش",
  permit: "مجوز",
  invoice: "فاکتور",
  correspondence: "نامه",
  other: "سایر",
  // Correspondence status
  draft: "پیش‌نویس",
  sent: "ارسال شده",
  received: "دریافت شده",
  in_review: "در حال بررسی",
  answered: "پاسخ داده شده",
  archived: "بایگانی شده",
  // Document status
  approved: "تأیید شده",
  rejected: "رد شده",
  // Direction
  inbound: "وارده",
  outbound: "صادره",
  // Contract status (extended)
  suspended: "معلق",
  terminated: "فسخ شده",
  expired: "منقضی",
  // Contract categories
  execution: "اجرایی",
  supply: "تأمین",
  service: "خدماتی",
  // Guarantee types
  safteh: "سفته",
  bank_guarantee: "ضمانت بانکی",
  check: "چک",
  none: "بدون تضمین",
  // Procurement statuses
  submitted: "ارسال شده",
  under_review: "در حال بررسی",
  in_order: "در حال سفارش",
  partial_received: "دریافت جزئی",
  // received and cancelled already defined above (correspondence/project)
  // Item categories
  material: "مصالح",
  equipment: "تجهیزات",
  tool: "ابزار",
  consumable: "مصرفی",
  spare_part: "قطعه یدکی",
  // Workflow step types
  technical_review: "بازبینی فنی",
  manager_approval: "تأیید مدیر",
  financial_review: "بازبینی مالی",
  order: "صدور سفارش",
  delivery: "تحویل",
  close: "خاتمه",
} as const;

/** Get initials from Persian full name */
export function initials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 0) return "؟";
  if (parts.length === 1) return parts[0].slice(0, 2);
  // First letters of first two words
  return (parts[0][0] || "") + (parts[1][0] || "");
}

/** Status color classes */
export const statusColors: Record<string, string> = {
  // Task status
  backlog: "bg-muted text-muted-foreground",
  todo: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  in_progress: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  review: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  done: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",
  blocked: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  // Project status
  planning: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  active: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  on_hold: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  completed: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",
  cancelled: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  // Priority
  low: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  medium: "bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300",
  high: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  critical: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  // Correspondence status
  draft: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  sent: "bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300",
  received: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  in_review: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  answered: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",
  archived: "bg-muted text-muted-foreground",
  // Document status
  approved: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",
  rejected: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  // Contract status (extended)
  // draft, in_review, approved, active, suspended, terminated, completed, expired
  // (draft, in_review, approved, completed already covered above)
  suspended: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",
  terminated: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  expired: "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
  // Procurement statuses
  submitted: "bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300",
  under_review: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  in_order: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
  partial_received: "bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300",
  // received and cancelled already defined above
};
