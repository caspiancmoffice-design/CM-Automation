// procurement-types.ts — Procurement (تدارکات) data model
// Purchase requests with workflow tracking

export type PRStatus =
  | "draft"             // پیش‌نویس
  | "submitted"         // ارسال شده (در انتظار تأیید)
  | "under_review"      // در حال بررسی
  | "approved"          // تأیید شده
  | "rejected"          // رد شده
  | "in_order"          // در حال سفارش
  | "partial_received"  // دریافت جزئی
  | "received"          // دریافت کامل
  | "cancelled";        // لغو شده

export type PRPriority = "low" | "medium" | "high" | "critical" | "urgent";

export type ItemCategory =
  | "material"          // مصالح
  | "equipment"         // تجهیزات
  | "tool"              // ابزار
  | "consumable"        // مصرفی
  | "spare_part"        // قطعه یدکی
  | "service"           // خدمات
  | "other";

export type WFStepStatus = "done" | "current" | "pending" | "rejected" | "skipped";

export type WFStepType =
  | "submit"            // ارسال درخواست
  | "technical_review"  // بازبینی فنی
  | "manager_approval"  // تأیید مدیر
  | "financial_review"  // بازبینی مالی
  | "order"             // صدور سفارش
  | "delivery"          // تحویل
  | "close";            // خاتمه

export interface WorkflowStep {
  id: string;
  type: WFStepType;
  title: string;        // عنوان مرحله
  description?: string;
  status: WFStepStatus;
  assignedTo?: string;  // نام مسئول
  assignedRole?: string;
  startedAt?: string;   // تاریخ شروع
  completedAt?: string; // تاریخ تکمیل
  comment?: string;     // نظر مسئول
  orderPercent?: number; // درصد سفارش (برای مرحله order)
}

export interface Vendor {
  id: string;
  name: string;          // نام وندور/تأمین‌کننده
  type: "person" | "company";
  nationalId?: string;
  phone?: string;
  email?: string;
  address?: string;
  contactPerson?: string;
  iban?: string;
  rating?: number;       // 1-5
  tags?: string[];       // تگ‌ها (مثال: تأمین‌کننده اصلی، بتن، فولاد)
  previousOrders?: number; // تعداد سفارش‌های قبلی
}

export interface PurchaseRequestItem {
  id: string;
  row: number;            // ردیف
  name: string;           // شرح دقیق مصالح/تجهیزات
  category: ItemCategory;
  quantity: number;       // مقدار
  unit: string;           // واحد
  unitPriceEstimate?: number; // تخمین بهای واحد (ریال)
  totalPriceEstimate?: number; // تخمین مبلغ کل
  consumptionLocation: string; // محل مصرف (مثال: طبقه ۱۸، موتورخانه، کارگاه)
  technicalSpec: string;  // مشخصات فنی
  vendorId?: string;      // وندور پیشنهادی
  vendorName?: string;
  orderPercent: number;   // درصد سفارش (0-100)
  notes?: string;         // توضیحات تکمیلی
  // وضعیت تأمین
  orderedQuantity?: number;   // مقدار سفارش داده شده
  receivedQuantity?: number;  // مقدار دریافت شده
}

export interface WorkflowHistoryEntry {
  id: string;
  stepType: WFStepType;
  stepTitle: string;
  fromStatus: PRStatus;
  toStatus: PRStatus;
  actor: string;          // نام کاربر انجام‌دهنده
  actorRole?: string;
  timestamp: string;
  comment?: string;
  attachmentCount?: number;
}

export interface PurchaseRequest {
  id: string;
  number: string;         // شماره درخواست (مثال: PR-1403-001)
  title: string;          // عنوان درخواست
  status: PRStatus;
  priority: PRPriority;

  // اتصال به پروژه
  projectId: string;
  projectName: string;

  // درخواست‌کننده
  requesterId: string;
  requesterName: string;
  requesterRole?: string;
  department?: string;

  // تاریخ‌های کلیدی
  createdAt: string;
  neededByDate: string;     // تاریخ نیاز

  // اقلام
  items: PurchaseRequestItem[];

  // گردش کار
  workflow: WorkflowStep[];
  history: WorkflowHistoryEntry[];

  // مالی
  totalEstimate: number;    // تخمین کل (ریال) — محاسبه خودکار از items

  // وندورهای مرتبط
  vendors: Vendor[];

  // توضیحات
  description?: string;
  justification?: string;   // توجیه نیاز

  // فراداده
  tags?: string[];
  attachmentsCount?: number;
  commentsCount?: number;
}

export const prStatusLabels: Record<PRStatus, string> = {
  draft: "پیش‌نویس",
  submitted: "ارسال شده",
  under_review: "در حال بررسی",
  approved: "تأیید شده",
  rejected: "رد شده",
  in_order: "در حال سفارش",
  partial_received: "دریافت جزئی",
  received: "دریافت کامل",
  cancelled: "لغو شده",
};

export const prPriorityLabels: Record<PRPriority, string> = {
  low: "کم",
  medium: "متوسط",
  high: "بالا",
  critical: "بحرانی",
  urgent: "فوری",
};

export const itemCategoryLabels: Record<ItemCategory, string> = {
  material: "مصالح",
  equipment: "تجهیزات",
  tool: "ابزار",
  consumable: "مصرفی",
  spare_part: "قطعه یدکی",
  service: "خدمات",
  other: "سایر",
};

export const wfStepTypeLabels: Record<WFStepType, string> = {
  submit: "ارسال درخواست",
  technical_review: "بازبینی فنی",
  manager_approval: "تأیید مدیر",
  financial_review: "بازبینی مالی",
  order: "صدور سفارش",
  delivery: "تحویل",
  close: "خاتمه",
};

export const wfStepStatusLabels: Record<WFStepStatus, string> = {
  done: "انجام شده",
  current: "در حال انجام",
  pending: "در انتظار",
  rejected: "رد شده",
  skipped: "نادیده گرفته شد",
};

export const defaultWorkflowSteps: Omit<WorkflowStep, "id" | "status" | "startedAt" | "completedAt">[] = [
  {
    type: "submit",
    title: "ارسال درخواست",
    description: "درخواست توسط درخواست‌کننده ارسال می‌شود",
    assignedRole: "درخواست‌کننده",
  },
  {
    type: "technical_review",
    title: "بازبینی فنی",
    description: "بررسی مشخصات فنی و ضرورت توسط کارشناس فنی",
    assignedRole: "کارشناس فنی",
  },
  {
    type: "manager_approval",
    title: "تأیید مدیر پروژه",
    description: "تأیید نهایی توسط مدیر پروژه",
    assignedRole: "مدیر پروژه",
  },
  {
    type: "financial_review",
    title: "بازبینی مالی",
    description: "بررسی بودجه و تأیید مالی توسط امور مالی",
    assignedRole: "امور مالی",
  },
  {
    type: "order",
    title: "صدور سفارش",
    description: "صدور سفارش خرید به وندور و ثبت درصد سفارش",
    assignedRole: "واحد خرید",
  },
  {
    type: "delivery",
    title: "تحویل",
    description: "دریافت کالا و تطبیق با سفارش",
    assignedRole: "انبار",
  },
  {
    type: "close",
    title: "خاتمه",
    description: "بستن درخواست و بایگانی",
    assignedRole: "سیستم",
  },
];
