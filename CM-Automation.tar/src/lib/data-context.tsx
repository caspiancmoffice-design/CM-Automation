// data-context.tsx — Global data context that loads from real API
"use client";
import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";

interface DataContextType {
  // Data
  tasks: any[];
  projects: any[];
  users: any[];
  organizations: any[];
  documents: any[];
  correspondences: any[];
  contracts: any[];
  vendors: any[];
  purchaseRequests: any[];
  notifications: any[];
  // Loading
  loading: Record<string, boolean>;
  // Refresh
  refresh: (module: string) => Promise<void>;
  refreshAll: () => Promise<void>;
}

const DataContext = createContext<DataContextType | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<any[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [organizations, setOrganizations] = useState<any[]>([]);
  const [documents, setDocuments] = useState<any[]>([]);
  const [correspondences, setCorrespondences] = useState<any[]>([]);
  const [contracts, setContracts] = useState<any[]>([]);
  const [vendors, setVendors] = useState<any[]>([]);
  const [purchaseRequests, setPurchaseRequests] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState<Record<string, boolean>>({});

  const refresh = useCallback(async (module: string) => {
    setLoading((prev) => ({ ...prev, [module]: true }));
    try {
      const api = (await import("@/lib/api")).api;
      switch (module) {
        case "tasks": { const r = await api.tasks.list(); setTasks(r.data || []); break; }
        case "projects": { const r = await api.projects.list(); setProjects(r.data || []); break; }
        case "users": { const r = await api.users.list(); setUsers(r.data || []); break; }
        case "organizations": { const r = await api.organizations.list(); setOrganizations(r.data || []); break; }
        case "documents": { const r = await api.documents.list(); setDocuments(r.data || []); break; }
        case "correspondence": { const r = await api.correspondence.list(); setCorrespondences(r.data || []); break; }
        case "contracts": { const r = await api.contracts.list(); setContracts(r.data || []); break; }
        case "vendors": { const r = await api.vendors.list(); setVendors(r.data || []); break; }
        case "procurement": { const r = await api.procurement.list(); setPurchaseRequests(r.data || []); break; }
        case "notifications": { const r = await api.notifications.list(); setNotifications(r.data || []); break; }
      }
    } catch (e) {
      console.error(`Failed to load ${module}:`, e);
    } finally {
      setLoading((prev) => ({ ...prev, [module]: false }));
    }
  }, []);

  const refreshAll = useCallback(async () => {
    await Promise.all([
      refresh("tasks"), refresh("projects"), refresh("users"),
      refresh("organizations"), refresh("documents"), refresh("correspondence"),
      refresh("contracts"), refresh("vendors"), refresh("procurement"), refresh("notifications"),
    ]);
  }, [refresh]);

  useEffect(() => { refreshAll(); }, [refreshAll]);

  return (
    <DataContext.Provider value={{
      tasks, projects, users, organizations, documents, correspondences, contracts, vendors, purchaseRequests, notifications,
      loading, refresh, refreshAll,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used inside DataProvider");
  return ctx;
}
