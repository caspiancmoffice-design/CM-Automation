// contract-types.ts — Parametric Contract data model
// Based on analysis of 6 sample contractor contracts (gypsum, concrete,
// plywood doors, elevator, fan-coil, mechanical room, electrical panels)

export type ContractType =
  | "gypsum"          // گچ و خاک و سفیدکاری
  | "concrete"        // بتن آماده
  | "plywood_door"    // درب پلی‌وود
  | "elevator"        // اسانسور
  | "fan_coil"        // فن‌کویل (تأمین)
  | "mechanical"      // موتورخانه
  | "electrical_panel" // تابلو برق
  | "rebar"           // آرماتوربندی
  | "brickwork"       // بنایی
  | "plumbing"        // تأسیسات لوله‌کشی
  | "wiring"          // سیم‌کشی برق
  | "painting"        // نقاشی
  | "tile"            // سرامیک و کاشی
  | "roofing"         // سقف
  | "demolition"      // تخریب
  | "other";          // سایر

export type ContractCategory = "execution" | "supply" | "service";
// execution = مقاطعه کاری اجرا
// supply = تأمین مصالح/تجهیزات
// service = خدمات

export type ContractStatus =
  | "draft"           // پیش‌نویس
  | "in_review"       // در حال بررسی
  | "approved"        // تأیید شده
  | "active"          // فعال (ابلاغ شده)
  | "suspended"       // تعلیق
  | "terminated"      // فسخ شده
  | "completed"       // تکمیل شده
  | "expired";        // منقضی

export type PaymentMethod =
  | "monthly_statement"   // صورت‌وضعیت ماهانه
  | "milestone"           // مرحله‌ای
  | "lump_sum"            // مقطوع
  | "advance_balance";    // پیش‌پرداخت + تسویه

/** Party (طرف قرارداد - کارفرما یا پیمانکار) */
export interface ContractParty {
  type: "employer" | "contractor";
  name: string;          // نام شخص/شرکت
  legalType: "person" | "company"; // حقیقی / حقوقی
  nationalId?: string;   // کدملی / شناسه ملی
  registrationNumber?: string; // شماره ثبت (شرکت)
  representative?: string; // نماینده
  representativeNationalId?: string;
  address: string;
  phone?: string;
  email?: string;
  iban?: string;         // شماره شبا
}

/** Pricing item row (ردیف بهای پیمان) */
export interface PriceItem {
  id: string;
  code: string;          // کد ردیف
  description: string;   // شرح
  unit: string;          // واحد (دستگاه، مترمربع، عدد، ...)
  quantity: number;      // مقدار (می‌تواند اعشاری باشد)
  unitPrice: number;     // بهای واحد (ریال)
  totalPrice: number;    // مبلغ کل (ریال) — محاسبه خودکار
}

/** Default unit options for pricing items */
export const DEFAULT_UNITS: string[] = [
  "دستگاه",
  "عدد",
  "مترمربع",
  "مترطول",
  "مترمکعب",
  "مترخطی",
  "کیلوگرم",
  "تن",
  "لیتر",
  "خودرو",
  "خودکاره",
  "ساعت",
  "روز",
  "ماه",
  "متری",
  "جعبه",
  "بشکه",
  "رول",
  "شاخه",
  "قطعه",
];

/** Payment milestone (مرحله پرداخت) */
export interface PaymentMilestone {
  id: string;
  title: string;         // عنوان مرحله
  percent: number;       // درصد از مبلغ کل
  condition: string;     // شرط تحقق
  dueOn: string;         // زمان/شرط پرداخت
}

/** Financial terms (ماده ۶: مسائل مالی) */
export interface FinancialTerms {
  totalAmount: number;            // مبلغ کل قرارداد (ریال)
  totalAmountWords?: string;      // مبلغ به حروف
  prepaymentPercent: number;      // درصد پیش‌پرداخت (۰-۱۰۰)
  prepaymentConditions?: string;  // شرایط پیش‌پرداخت
  guaranteeType: "safteh" | "bank_guarantee" | "check" | "none"; // نوع تضمین
  guaranteeAmount: number;        // مبلغ تضمین (ریال)
  guaranteeDetails?: string;      // جزئیات (شماره سفته و ...)
  retentionPercent: number;       // درصد سپرده حسن انجام کار
  retentionReleaseMonths: number; // مدت آزادسازی سپرده (ماه)
  paymentMethod: PaymentMethod;
  paymentSchedule: string;        // توضیح نحوه پرداخت (مثلاً ۱۳ و ۲۷ هر ماه)
  milestones: PaymentMilestone[]; // مراحل پرداخت (در صورت مرحله‌ای بودن)
  taxPercent: number;             // درصد مالیات
  insurancePercent: number;       // درصد بیمه
}

/** Obligation item (تعهد) */
export interface Obligation {
  id: string;
  code: string;          // شماره بند (مثلاً ۸-۱)
  text: string;          // متن تعهد
  category: "general" | "technical" | "safety" | "hse" | "personnel" | "tools" | "materials" | "reporting";
}

/** Duration (ماده ۵: مدت قرارداد) */
export interface ContractDuration {
  totalMonths: number;          // مدت کل (ماه)
  totalDays?: number;           // یا مدت کل (روز)
  calendarType: "jalali_workday" | "jalali_calendar"; // روز کاری یا روز تقویمی
  startDate: string;            // تاریخ شروع (پس از ابلاغ)
  endDate: string;              // تاریخ پایان
  extensionConditions?: string; // شرایط تمدید
  phases?: { name: string; durationDays: number; description?: string }[];
}

/** Document attachment (ضمیمه قرارداد) */
export interface ContractAttachment {
  id: string;
  title: string;         // عنوان ضمیمه
  type: "general_spec" | "price_list" | "obligations" | "drawings" | "work_order" | "safety_regulation" | "addendum" | "other";
  fileName?: string;     // نام فایل پیوست
  uploadedAt?: string;
  required: boolean;
}

/** Penalties & termination (مواد ۱۳، ۱۴) */
export interface PenaltyTerms {
  delayPenaltyPerDay: number;    // جریمه تأخیر روزانه (ریال)
  delayPenaltyMaxDays?: number;  // حداکثر روز جریمه
  delayPenaltyAfterMax?: number; // جریمه پس از حداکثر (ریال)
  terminationConditions: string[]; // شرایط فسخ
  delayMaxPercent: number;       // حداکثر تأخیر مجاز (٪)
}

export interface Contract {
  id: string;
  number: string;                // شماره قرارداد
  title: string;                 // عنوان قرارداد
  type: ContractType;
  category: ContractCategory;
  status: ContractStatus;

  // ماده ۱: موضوع
  subject: string;

  // ماده ۲: محل اجرا
  projectName: string;
  projectAddress: string;
  projectId?: string;            // اتصال به پروژه سامانه

  // طرفین
  employer: ContractParty;
  contractor: ContractParty;

  // ماده ۳: مبلغ و ماده ۶: مالی
  financial: FinancialTerms;

  // ماده ۴: ضمائم
  attachments: ContractAttachment[];

  // ماده ۵: مدت
  duration: ContractDuration;

  // ماده ۷: كسورات (داخل financial.retention)

  // ماده ۸: تعهدات پیمانکار (پارامتریک بر اساس نوع)
  contractorObligations: Obligation[];

  // ماده ۹: تعهدات کارفرما
  employerObligations: Obligation[];

  // ماده ۱۰: شرایط خصوصی
  specialConditions: string[];

  // ماده ۱۴: جرایم
  penalties: PenaltyTerms;

  // ماده ۱۲: حل اختلاف
  disputeResolution: string;

  // فراداده
  createdAt: string;
  createdBy: string;
  approvedAt?: string;
  approvedBy?: string;
  issuedAt?: string;            // تاریخ ابلاغ
  tags: string[];
  notes?: string;
}

/** Template for creating contracts parametrically */
export interface ContractTemplate {
  type: ContractType;
  title: string;                  // عنوان پیش‌فرض
  category: ContractCategory;
  defaultSubject: string;         // موضوع پیش‌فرض
  iconKey: string;                // نام آیکون (lucide)
  description: string;            // توضیح قالب
  recommendedDurationMonths: number;
  defaultPrepaymentPercent: number;
  defaultRetentionPercent: number;
  defaultPaymentMethod: PaymentMethod;
  defaultUnit: string;            // واحد اصلی کار
  defaultObligations: Obligation[]; // تعهدات پیش‌فرض
  defaultEmployerObligations: Obligation[];
  defaultSpecialConditions: string[];
  defaultAttachments: ContractAttachment[];
  defaultPriceItems?: PriceItem[]; // ردیف‌های بهای پیش‌فرض
  sampleQuantity?: number;        // مقدار نمونه
}
