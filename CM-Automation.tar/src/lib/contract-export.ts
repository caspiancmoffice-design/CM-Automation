// contract-export.ts — Export contract to Word (.docx) and PDF formats
"use client";
import {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
  type ISectionOptions,
} from "docx";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import type { Contract } from "./contract-types";
import {
  contractTypeLabels,
  contractCategoryLabels,
  paymentMethodLabels,
  guaranteeTypeLabels,
  obligationCategoryLabels,
} from "./contract-templates";
import { faCurrency } from "./fa-utils";

/** Persian text helper - reverses for proper RTL display in docx */
function rtlText(text: string): TextRun {
  return new TextRun({
    text,
    rightToLeft: true,
    font: "Vazirmatn",
    size: 22, // 11pt
  });
}

function rtlHeading(text: string, level: (typeof HeadingLevel)[keyof typeof HeadingLevel] = HeadingLevel.HEADING_2): Paragraph {
  return new Paragraph({
    heading: level,
    bidirectional: true,
    alignment: AlignmentType.RIGHT,
    children: [rtlText(text)],
    spacing: { before: 240, after: 120 },
  });
}

function rtlParagraph(text: string, options: { bold?: boolean; size?: number } = {}): Paragraph {
  return new Paragraph({
    bidirectional: true,
    alignment: AlignmentType.RIGHT,
    spacing: { after: 120, line: 360 },
    children: [
      new TextRun({
        text,
        rightToLeft: true,
        font: "Vazirmatn",
        size: options.size ?? 22,
        bold: options.bold,
      }),
    ],
  });
}

function articleBlock(number: string, title: string, paragraphs: (Paragraph | Table)[]): (Paragraph | Table)[] {
  const result: (Paragraph | Table)[] = [];
  result.push(new Paragraph({
    heading: HeadingLevel.HEADING_3,
    bidirectional: true,
    alignment: AlignmentType.RIGHT,
    spacing: { before: 240, after: 120 },
    shading: { type: ShadingType.SOLID, color: "F0F0F0", fill: "F0F0F0" },
    children: [rtlText(`ماده ${number} – ${title}`)],
  }));
  result.push(...paragraphs);
  return result;
}

function cell(text: string, opts: { bold?: boolean; width?: number } = {}): TableCell {
  return new TableCell({
    width: { size: opts.width ?? 25, type: WidthType.PERCENTAGE },
    children: [
      new Paragraph({
        bidirectional: true,
        alignment: AlignmentType.RIGHT,
        children: [
          new TextRun({
            text,
            rightToLeft: true,
            font: "Vazirmatn",
            size: 20,
            bold: opts.bold,
          }),
        ],
      }),
    ],
  });
}

/** Build the contract document for docx export */
function buildDocxSections(contract: Contract): ISectionOptions[] {
  const children: (Paragraph | Table)[] = [];

  // Header
  children.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    bidirectional: true,
    spacing: { after: 80 },
    children: [new TextRun({ text: "به نام خدا", rightToLeft: true, font: "Vazirmatn", size: 22 })],
  }));
  children.push(new Paragraph({
    heading: HeadingLevel.HEADING_1,
    alignment: AlignmentType.CENTER,
    bidirectional: true,
    spacing: { after: 80 },
    children: [rtlText("قرارداد مقاطعه‌کاری")],
  }));
  children.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    bidirectional: true,
    spacing: { after: 200 },
    children: [rtlText(contractTypeLabels[contract.type])],
  }));
  children.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    bidirectional: true,
    spacing: { after: 200 },
    children: [rtlText(`شماره قرارداد: ${contract.number}`)],
  }));

  // Preamble
  children.push(rtlHeading("موافقت‌نامه", HeadingLevel.HEADING_2));
  children.push(rtlParagraph(
    `موافقت‌نامه حاضر، همراه با اسناد و مدارک موضوع ماده ۱ آن، که مجموعه‌ای غیرقابل تفکیک است و از این پس قرارداد نامیده می‌شود، که بر اساس ماده ۱۰ قانون مدنی جمهوری اسلامی ایران نیز می‌باشد؛ در تاریخ ${contract.issuedAt ?? contract.createdAt} بین ${contract.employer.name}${contract.employer.representative ? ` به نمایندگی ${contract.employer.representative}` : ""} به نشانی: ${contract.employer.address} که از این پس کارفرما نامیده می‌شود و ${contract.contractor.name}${contract.contractor.representative ? ` به نمایندگی ${contract.contractor.representative}` : ""} به نشانی: ${contract.contractor.address} از طرف دیگر که پیمانکار نامیده می‌شود، مطابق با شرایط و مشخصات ذیل منعقد می‌گردد.`
  ));

  // Article 1: Subject
  children.push(...articleBlock("۱", "موضوع قرارداد", [
    rtlParagraph(contract.subject),
  ]));

  // Article 2: Location
  children.push(...articleBlock("۲", "محل اجرا", [
    rtlParagraph(`پروژه ${contract.projectName} واقع در ${contract.projectAddress}`),
  ]));

  // Article 3: Amount
  children.push(...articleBlock("۳", "مبلغ قرارداد", [
    rtlParagraph(`مبلغ کل: ${contract.financial.totalAmount.toLocaleString("fa-IR")} ریال معادل ${contract.financial.totalAmountWords ?? ""}`),
  ]));

  // Article 4: Attachments
  const attRows: TableRow[] = [
    new TableRow({
      children: [
        cell("ردیف", { bold: true, width: 15 }),
        cell("عنوان ضمیمه", { bold: true, width: 60 }),
        cell("الزامی", { bold: true, width: 25 }),
      ],
      tableHeader: true,
    }),
  ];
  contract.attachments.forEach((att, idx) => {
    attRows.push(new TableRow({
      children: [
        cell((idx + 1).toLocaleString("fa-IR")),
        cell(att.title),
        cell(att.required ? "بله" : "خیر"),
      ],
    }));
  });
  children.push(...articleBlock("۴", "ضمائم قرارداد", [
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: attRows,
    }),
  ]));

  // Article 5: Duration
  const durParas: Paragraph[] = [
    rtlParagraph(`مدت زمان کل اجرای عملیات موضوع قرارداد ${contract.duration.totalMonths.toLocaleString("fa-IR")} ماه از تاریخ ابلاغ قرارداد می‌باشد.`),
    rtlParagraph(`تاریخ شروع: ${contract.duration.startDate}`),
    rtlParagraph(`تاریخ پایان: ${contract.duration.endDate}`),
  ];
  if (contract.duration.extensionConditions) {
    durParas.push(rtlParagraph(contract.duration.extensionConditions));
  }
  if (contract.duration.phases && contract.duration.phases.length > 0) {
    durParas.push(rtlParagraph("مراحل اجرا:"));
    contract.duration.phases.forEach((p, idx) => {
      durParas.push(rtlParagraph(`${(idx + 1).toLocaleString("fa-IR")}- ${p.name}: ${p.durationDays.toLocaleString("fa-IR")} روز${p.description ? ` (${p.description})` : ""}`));
    });
  }
  children.push(...articleBlock("۵", "مدت قرارداد", durParas));

  // Article 6: Financial
  const finParas: Paragraph[] = [
    rtlParagraph(`۱- پیش‌پرداخت: ${contract.financial.prepaymentPercent.toLocaleString("fa-IR")}٪ از مبلغ قرارداد${contract.financial.prepaymentConditions ? ` (${contract.financial.prepaymentConditions})` : ""}`, { bold: true }),
    rtlParagraph(`۲- تضمین انجام تعهدات: ${guaranteeTypeLabels[contract.financial.guaranteeType]} به مبلغ ${faCurrency(contract.financial.guaranteeAmount)}${contract.financial.guaranteeDetails ? ` (${contract.financial.guaranteeDetails})` : ""}`, { bold: true }),
    rtlParagraph(`۳- نحوه پرداخت: ${paymentMethodLabels[contract.financial.paymentMethod]} - ${contract.financial.paymentSchedule}`, { bold: true }),
  ];
  if (contract.financial.milestones.length > 0) {
    finParas.push(rtlParagraph("مراحل پرداخت:"));
    contract.financial.milestones.forEach((m, idx) => {
      finParas.push(rtlParagraph(`${(idx + 1).toLocaleString("fa-IR")}- ${m.title}: ${m.percent.toLocaleString("fa-IR")}٪ - ${m.condition}`));
    });
  }
  children.push(...articleBlock("۶", "مسائل مالی", finParas));

  // Article 7: Retention
  children.push(...articleBlock("۷", "کسورات", [
    rtlParagraph(`صورت‌وضعیت کارکرد پیمانکار پس از کسر ${contract.financial.retentionPercent.toLocaleString("fa-IR")}٪ بابت سپرده حسن انجام کار قابل پرداخت می‌باشد. سپرده حسن انجام کار نزد کارفرما باقی خواهد ماند و پس از گذشت ${contract.financial.retentionReleaseMonths.toLocaleString("fa-IR")} ماه از تاریخ ارسال صورت‌وضعیت قطعی به پیمانکار قابل پرداخت خواهد بود.`),
  ]));

  // Article 8: Contractor obligations
  const obRows: TableRow[] = [
    new TableRow({
      children: [
        cell("بند", { bold: true, width: 12 }),
        cell("متن تعهد", { bold: true, width: 70 }),
        cell("دسته", { bold: true, width: 18 }),
      ],
      tableHeader: true,
    }),
  ];
  contract.contractorObligations.forEach((ob) => {
    obRows.push(new TableRow({
      children: [
        cell(ob.code),
        cell(ob.text),
        cell(obligationCategoryLabels[ob.category] ?? ob.category),
      ],
    }));
  });
  children.push(...articleBlock("۸", "تعهدات پیمانکار", [
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: obRows,
    }),
  ]));

  // Article 9: Employer obligations
  const eoRows: TableRow[] = [
    new TableRow({
      children: [
        cell("بند", { bold: true, width: 12 }),
        cell("متن تعهد", { bold: true, width: 88 }),
      ],
      tableHeader: true,
    }),
  ];
  contract.employerObligations.forEach((ob) => {
    eoRows.push(new TableRow({
      children: [cell(ob.code), cell(ob.text)],
    }));
  });
  children.push(...articleBlock("۹", "تعهدات کارفرما", [
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: eoRows,
    }),
  ]));

  // Article 10: Special conditions
  const scParas: Paragraph[] = [];
  contract.specialConditions.forEach((cond, idx) => {
    scParas.push(rtlParagraph(`${(idx + 1).toLocaleString("fa-IR")}- ${cond}`));
  });
  children.push(...articleBlock("۱۰", "شرایط خصوصی", scParas));

  // Article 11: Delivery
  children.push(...articleBlock("۱۱", "تحویل موقت و قطعی", [
    rtlParagraph("در پایان کار و پس از تقاضای پیمانکار مراحل تحویل موقت انجام می‌شود و کارفرما پس از بازدید کارها، هرگاه عیب و نقصی که ناشی از کار پیمانکار باشد مشاهده ننماید کار را به صورت قطعی تحویل گرفته و طی صورتجلسه‌ای به پیمانکار ابلاغ می‌نماید."),
  ]));

  // Article 12: Dispute
  children.push(...articleBlock("۱۲", "حل اختلاف", [
    rtlParagraph(contract.disputeResolution),
  ]));

  // Article 13: Termination
  const termParas: Paragraph[] = [
    rtlParagraph("کارفرما می‌تواند در موارد ذیل قرارداد را بصورت یک‌طرفه فسخ نماید:"),
  ];
  contract.penalties.terminationConditions.forEach((cond, idx) => {
    termParas.push(rtlParagraph(`${(idx + 1).toLocaleString("fa-IR")}- ${cond}`));
  });
  children.push(...articleBlock("۱۳", "فسخ قرارداد", termParas));

  // Article 14: Penalties
  children.push(...articleBlock("۱۴", "تأخیرات", [
    rtlParagraph(`چنانچه پیمانکار ظرف مدت مقرر در ماده ۵ پیمان عملیات به تعهدات خود عمل ننماید، به ازای هر یک روز تأخیر مبلغ ${contract.penalties.delayPenaltyPerDay.toLocaleString("fa-IR")} ریال به عنوان جریمه به حساب بدهکاری ایشان منظور و از مبلغ کل کارکرد پیمانکار کسر خواهد گردید.`),
  ]));

  // Article 15: Addresses
  children.push(...articleBlock("۱۵", "نشانی طرفین", [
    rtlParagraph(`کارفرما: ${contract.employer.name} - ${contract.employer.address}`),
    rtlParagraph(`پیمانکار: ${contract.contractor.name} - ${contract.contractor.address}`),
  ]));

  // Article 16: Force Majeure
  children.push(...articleBlock("۱۶", "حوادث قهری", [
    rtlParagraph("حوادث قهری و غیرمترقبه (جنگ اعم از اعلام شده یا نشده، انقلابات و اعتصابات عمومی، زلزله، سیل، طغیان‌های غیرعادی کار، بیماری‌های واگیردار و آتش‌سوزی‌های دامنه‌دار که ناشی از قصور پیمانکار نباشد) جزء حوادث قهری محسوب شده و به عنوان تأخیرات مجاز پیمانکار تلقی می‌گردد."),
  ]));

  // Signatures
  children.push(new Paragraph({
    bidirectional: true,
    alignment: AlignmentType.RIGHT,
    spacing: { before: 480, after: 120 },
    children: [rtlText("مهر و امضای طرفین:")],
  }));

  const sigTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: 50, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [rtlText("کارفرما")] }),
              new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, spacing: { before: 240 }, children: [rtlText(contract.employer.name)] }),
              new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, spacing: { before: 120 }, children: [rtlText("_________________________")] }),
            ],
          }),
          new TableCell({
            width: { size: 50, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [rtlText("پیمانکار")] }),
              new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, spacing: { before: 240 }, children: [rtlText(contract.contractor.name)] }),
              new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, spacing: { before: 120 }, children: [rtlText("_________________________")] }),
            ],
          }),
        ],
      }),
    ],
  });
  children.push(sigTable);

  return [{
    properties: {
      page: {
        margin: { top: 1000, right: 1000, bottom: 1000, left: 1000 },
      },
    },
    children,
  }];
}

/** Export contract as Word (.docx) file */
export async function exportContractToWord(contract: Contract): Promise<void> {
  const sections = buildDocxSections(contract);
  const doc = new Document({
    creator: "CM Automation",
    title: contract.title,
    description: `قرارداد ${contract.number}`,
    styles: {
      default: {
        document: {
          run: { font: "Vazirmatn", size: 22 },
        },
      },
    },
    sections,
  });

  const blob = await Packer.toBlob(doc);
  const safeName = contract.title.replace(/[\/\\:*?"<>|]/g, "_").slice(0, 80);
  saveAs(blob, `قرارداد-${safeName}.docx`);
}

/**
 * Export contract as PDF using jsPDF with proper Persian text rendering.
 * Note: jsPDF doesn't support RTL Persian out-of-the-box well, so we use
 * an HTML-to-canvas approach via a temporary DOM element with proper RTL.
 */
export async function exportContractToPdf(contract: Contract): Promise<void> {
  // Build HTML content with proper RTL Persian
  const html = buildContractHtml(contract);

  // Create a hidden container, render, then capture via iframe print
  return new Promise<void>((resolve, reject) => {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.position = "fixed";
      iframe.style.right = "-10000px";
      iframe.style.top = "0";
      iframe.style.width = "794px"; // A4 width at 96dpi
      iframe.style.height = "1123px";
      iframe.style.border = "none";
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document;
      if (!doc) {
        reject(new Error("iframe contentWindow not available"));
        return;
      }

      doc.open();
      doc.write(html);
      doc.close();

      // Wait for fonts to load, then print
      iframe.onload = () => {
        setTimeout(() => {
          try {
            iframe.contentWindow?.focus();
            iframe.contentWindow?.print();
            // Cleanup after print dialog
            setTimeout(() => {
              document.body.removeChild(iframe);
              resolve();
            }, 1000);
          } catch (e) {
            reject(e);
          }
        }, 500);
      };

      // Some browsers don't fire onload for srcdoc-style writes; trigger manually
      setTimeout(() => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
          setTimeout(() => {
            if (iframe.parentNode) document.body.removeChild(iframe);
            resolve();
          }, 1000);
        } catch (e) {
          reject(e);
        }
      }, 1000);
    } catch (e) {
      reject(e);
    }
  });
}

/** Build printable HTML for the contract (used for PDF + browser print) */
export function buildContractHtml(contract: Contract): string {
  const articleRows = (rows: string[][]) =>
    rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join("")}</tr>`).join("");

  const obligationsTable = `
    <table class="data-table">
      <thead><tr><th style="width:10%">بند</th><th>متن تعهد</th><th style="width:15%">دسته</th></tr></thead>
      <tbody>
        ${articleRows(
          contract.contractorObligations.map((o) => [
            o.code,
            o.text,
            obligationCategoryLabels[o.category] ?? o.category,
          ])
        )}
      </tbody>
    </table>
  `;

  const employerObligationsTable = `
    <table class="data-table">
      <thead><tr><th style="width:10%">بند</th><th>متن تعهد</th></tr></thead>
      <tbody>
        ${articleRows(
          contract.employerObligations.map((o) => [o.code, o.text])
        )}
      </tbody>
    </table>
  `;

  const priceItemsTable = contract.financial.milestones.length > 0
    ? `
      <table class="data-table">
        <thead><tr><th>ردیف</th><th>مرحله</th><th>درصد</th><th>شرط تحقق</th></tr></thead>
        <tbody>
          ${articleRows(
            contract.financial.milestones.map((m, i) => [
              (i + 1).toLocaleString("fa-IR"),
              m.title,
              `${m.percent.toLocaleString("fa-IR")}٪`,
              m.condition,
            ])
          )}
        </tbody>
      </table>
    `
    : "";

  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>قرارداد ${contract.number}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  * { box-sizing: border-box; }
  body {
    font-family: 'Vazirmatn', 'Tahoma', sans-serif;
    line-height: 1.8;
    color: #1a1a1a;
    padding: 30px 40px;
    font-size: 12pt;
    direction: rtl;
    text-align: right;
  }
  .header { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #1a5f4a; }
  .header h1 { font-size: 22pt; margin: 5px 0; color: #1a5f4a; }
  .header .contract-number { color: #666; font-size: 11pt; margin-top: 8px; }
  h2 {
    font-size: 14pt;
    color: #1a5f4a;
    margin-top: 24px;
    margin-bottom: 12px;
    padding: 6px 10px;
    background: #f0f5f3;
    border-right: 4px solid #1a5f4a;
  }
  h3 {
    font-size: 12pt;
    margin-top: 18px;
    margin-bottom: 10px;
    color: #333;
  }
  p { margin: 8px 0; text-align: justify; }
  .data-table {
    width: 100%;
    border-collapse: collapse;
    margin: 10px 0 16px;
    font-size: 10.5pt;
  }
  .data-table th, .data-table td {
    border: 1px solid #ccc;
    padding: 6px 10px;
    text-align: right;
  }
  .data-table th { background: #e8efe d; font-weight: 600; }
  .data-table tr:nth-child(even) { background: #fafafa; }
  .signatures {
    margin-top: 60px;
    display: flex;
    justify-content: space-between;
    gap: 40px;
    page-break-inside: avoid;
  }
  .sign-box {
    flex: 1;
    text-align: center;
    border: 1px dashed #999;
    padding: 30px 10px;
    border-radius: 6px;
  }
  .sign-box h4 { margin: 0 0 30px; font-size: 11pt; color: #1a5f4a; }
  .summary-box {
    background: #f8f9fa;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    padding: 14px 18px;
    margin: 12px 0;
    font-size: 11pt;
  }
  .summary-box strong { color: #1a5f4a; }
  ul, ol { padding-right: 24px; }
  @media print {
    body { padding: 15px 20px; }
    @page { margin: 1.5cm; size: A4; }
    h2 { page-break-after: avoid; }
    .data-table { page-break-inside: avoid; }
  }
</style>
</head>
<body>
  <div class="header">
    <p style="font-size: 11pt; color: #666;">به نام خدا</p>
    <h1>قرارداد ${contractTypeLabels[contract.type]}</h1>
    <p style="font-size: 12pt;">${contract.title}</p>
    <p class="contract-number">شماره قرارداد: <strong>${contract.number}</strong></p>
  </div>

  <h2>موافقت‌نامه</h2>
  <p>
    موافقت‌نامه حاضر، همراه با اسناد و مدارک موضوع ماده ۱ آن، که مجموعه‌ای غیرقابل تفکیک است و از این پس قرارداد نامیده می‌شود، که بر اساس ماده ۱۰ قانون مدنی جمهوری اسلامی ایران نیز می‌باشد؛ در تاریخ
    <strong>${contract.issuedAt ?? contract.createdAt}</strong>
    بین <strong>${contract.employer.name}</strong>
    ${contract.employer.representative ? `به نمایندگی ${contract.employer.representative}` : ""}
    به نشانی: ${contract.employer.address}
    که از این پس <strong>کارفرما</strong> نامیده می‌شود و
    <strong>${contract.contractor.name}</strong>
    ${contract.contractor.representative ? `به نمایندگی ${contract.contractor.representative}` : ""}
    به نشانی: ${contract.contractor.address}
    از طرف دیگر که <strong>پیمانکار</strong> نامیده می‌شود، مطابق با شرایط و مشخصات ذیل منعقد می‌گردد.
  </p>

  <h2>ماده ۱ – موضوع قرارداد</h2>
  <p>${contract.subject}</p>

  <h2>ماده ۲ – محل اجرا</h2>
  <p>پروژه ${contract.projectName} واقع در ${contract.projectAddress}</p>

  <h2>ماده ۳ – مبلغ قرارداد</h2>
  <div class="summary-box">
    <p>مبلغ کل: <strong>${contract.financial.totalAmount.toLocaleString("fa-IR")} ریال</strong></p>
    ${contract.financial.totalAmountWords ? `<p>معادل: ${contract.financial.totalAmountWords}</p>` : ""}
  </div>

  <h2>ماده ۴ – ضمائم قرارداد</h2>
  <table class="data-table">
    <thead><tr><th style="width:10%">ردیف</th><th>عنوان ضمیمه</th><th style="width:15%">الزامی</th></tr></thead>
    <tbody>
      ${articleRows(
        contract.attachments.map((a, i) => [
          (i + 1).toLocaleString("fa-IR"),
          a.title,
          a.required ? "بله" : "خیر",
        ])
      )}
    </tbody>
  </table>

  <h2>ماده ۵ – مدت قرارداد</h2>
  <div class="summary-box">
    <p>مدت کل: <strong>${contract.duration.totalMonths.toLocaleString("fa-IR")} ماه</strong></p>
    <p>تاریخ شروع: <strong>${contract.duration.startDate}</strong></p>
    <p>تاریخ پایان: <strong>${contract.duration.endDate}</strong></p>
    ${contract.duration.extensionConditions ? `<p><small>${contract.duration.extensionConditions}</small></p>` : ""}
  </div>
  ${contract.duration.phases && contract.duration.phases.length > 0 ? `
    <h3>مراحل اجرا</h3>
    <ol>
      ${contract.duration.phases.map((p) => `<li><strong>${p.name}:</strong> ${p.durationDays.toLocaleString("fa-IR")} روز${p.description ? ` - ${p.description}` : ""}</li>`).join("")}
    </ol>
  ` : ""}

  <h2>ماده ۶ – مسائل مالی</h2>
  <div class="summary-box">
    <p><strong>۱- پیش‌پرداخت:</strong> ${contract.financial.prepaymentPercent.toLocaleString("fa-IR")}٪ از مبلغ قرارداد
    ${contract.financial.prepaymentConditions ? `(${contract.financial.prepaymentConditions})` : ""}</p>
    <p><strong>۲- تضمین انجام تعهدات:</strong> ${guaranteeTypeLabels[contract.financial.guaranteeType]} به مبلغ ${faCurrency(contract.financial.guaranteeAmount)}
    ${contract.financial.guaranteeDetails ? `(${contract.financial.guaranteeDetails})` : ""}</p>
    <p><strong>۳- نحوه پرداخت:</strong> ${paymentMethodLabels[contract.financial.paymentMethod]} - ${contract.financial.paymentSchedule}</p>
  </div>
  ${priceItemsTable}

  <h2>ماده ۷ – کسورات</h2>
  <p>صورت‌وضعیت کارکرد پیمانکار پس از کسر <strong>${contract.financial.retentionPercent.toLocaleString("fa-IR")}٪</strong> بابت سپرده حسن انجام کار قابل پرداخت می‌باشد. سپرده حسن انجام کار نزد کارفرما باقی خواهد ماند و پس از گذشت <strong>${contract.financial.retentionReleaseMonths.toLocaleString("fa-IR")} ماه</strong> از تاریخ ارسال صورت‌وضعیت قطعی به پیمانکار قابل پرداخت خواهد بود.</p>

  <h2>ماده ۸ – تعهدات پیمانکار</h2>
  ${obligationsTable}

  <h2>ماده ۹ – تعهدات کارفرما</h2>
  ${employerObligationsTable}

  <h2>ماده ۱۰ – شرایط خصوصی</h2>
  <ol>
    ${contract.specialConditions.map((c) => `<li>${c}</li>`).join("")}
  </ol>

  <h2>ماده ۱۱ – تحویل موقت و قطعی</h2>
  <p>در پایان کار و پس از تقاضای پیمانکار مراحل تحویل موقت انجام می‌شود و کارفرما پس از بازدید کارها، هرگاه عیب و نقصی که ناشی از کار پیمانکار باشد مشاهده ننماید کار را به صورت قطعی تحویل گرفته و طی صورتجلسه‌ای به پیمانکار ابلاغ می‌نماید.</p>

  <h2>ماده ۱۲ – حل اختلاف</h2>
  <p>${contract.disputeResolution}</p>

  <h2>ماده ۱۳ – فسخ قرارداد</h2>
  <p>کارفرما می‌تواند در موارد ذیل قرارداد را بصورت یک‌طرفه فسخ نماید:</p>
  <ol>
    ${contract.penalties.terminationConditions.map((c) => `<li>${c}</li>`).join("")}
  </ol>

  <h2>ماده ۱۴ – تأخیرات</h2>
  <p>چنانچه پیمانکار ظرف مدت مقرر در ماده ۵ پیمان عملیات به تعهدات خود عمل ننماید، به ازای هر یک روز تأخیر مبلغ <strong>${contract.penalties.delayPenaltyPerDay.toLocaleString("fa-IR")} ریال</strong> به عنوان جریمه به حساب بدهکاری ایشان منظور و از مبلغ کل کارکرد پیمانکار کسر خواهد گردید.
  ${contract.penalties.delayPenaltyMaxDays ? ` (حداکثر ${contract.penalties.delayPenaltyMaxDays.toLocaleString("fa-IR")} روز با این نرخ و پس از آن به ازای هر روز ${contract.penalties.delayPenaltyAfterMax?.toLocaleString("fa-IR") ?? ""} ریال)` : ""}</p>

  <h2>ماده ۱۵ – نشانی طرفین</h2>
  <div class="summary-box">
    <p><strong>کارفرما:</strong> ${contract.employer.name} - ${contract.employer.address}</p>
    <p><strong>پیمانکار:</strong> ${contract.contractor.name} - ${contract.contractor.address}</p>
  </div>

  <h2>ماده ۱۶ – حوادث قهری</h2>
  <p>حوادث قهری و غیرمترقبه (جنگ اعم از اعلام شده یا نشده، انقلابات و اعتصابات عمومی، زلزله، سیل، طغیان‌های غیرعادی کار، بیماری‌های واگیردار و آتش‌سوزی‌های دامنه‌دار که ناشی از قصور پیمانکار نباشد) جزء حوادث قهری محسوب شده و به عنوان تأخیرات مجاز پیمانکار تلقی می‌گردد.</p>

  <div class="signatures">
    <div class="sign-box">
      <h4>مهر و امضای کارفرما</h4>
      <p>${contract.employer.name}</p>
    </div>
    <div class="sign-box">
      <h4>مهر و امضای پیمانکار</h4>
      <p>${contract.contractor.name}</p>
    </div>
  </div>
</body>
</html>`;
}

/** Open print dialog for the contract (browser native print, can save as PDF) */
export function printContract(contract: Contract): void {
  const html = buildContractHtml(contract);
  const iframe = document.createElement("iframe");
  iframe.style.position = "fixed";
  iframe.style.right = "-10000px";
  iframe.style.top = "0";
  iframe.style.width = "794px";
  iframe.style.height = "1123px";
  iframe.style.border = "none";
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  doc.open();
  doc.write(html);
  doc.close();

  // Wait a bit for fonts to load
  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      // Cleanup after a delay
      setTimeout(() => {
        if (iframe.parentNode) document.body.removeChild(iframe);
      }, 2000);
    } catch (e) {
      console.error("Print failed:", e);
      if (iframe.parentNode) document.body.removeChild(iframe);
    }
  }, 800);
}
