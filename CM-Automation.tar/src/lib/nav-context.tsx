// nav-context.tsx — Navigation state management
"use client";
import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import type { ViewKey } from "./types";

interface NavState {
  view: ViewKey;
  // Optional context id (project id, task id, etc.)
  contextId?: string;
  // Global search query (for search view)
  searchQuery?: string;
}

interface NavContextValue extends NavState {
  navigate: (view: ViewKey, contextId?: string) => void;
  navigateWithSearch: (query: string) => void;
  // Track previous view for back navigation
  history: NavState[];
  goBack: () => void;
  canGoBack: boolean;
}

const NavContext = createContext<NavContextValue | null>(null);

export function NavProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<NavState>({ view: "dashboard" });
  const [history, setHistory] = useState<NavState[]>([]);

  const navigate = useCallback((view: ViewKey, contextId?: string) => {
    setState((prev) => {
      setHistory((h) => [...h, prev].slice(-20));
      return { view, contextId };
    });
    // Scroll to top on navigation
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, []);

  const navigateWithSearch = useCallback((query: string) => {
    setState((prev) => {
      setHistory((h) => [...h, prev].slice(-20));
      return { view: "search", searchQuery: query };
    });
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, []);

  const goBack = useCallback(() => {
    setHistory((h) => {
      if (h.length === 0) return h;
      const prev = h[h.length - 1];
      setState(prev);
      return h.slice(0, -1);
    });
  }, []);

  return (
    <NavContext.Provider
      value={{
        ...state,
        navigate,
        navigateWithSearch,
        history,
        goBack,
        canGoBack: history.length > 0,
      }}
    >
      {children}
    </NavContext.Provider>
  );
}

export function useNav() {
  const ctx = useContext(NavContext);
  if (!ctx) throw new Error("useNav must be used inside NavProvider");
  return ctx;
}
