// api.ts — Complete API client for all modules
const API_BASE = "/api/v1";

async function apiFetch<T = unknown>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...options?.headers },
    ...options,
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ error: "خطای ناشناخته" }));
    throw new Error(error.error || `HTTP ${res.status}`);
  }
  return res.json();
}

// Default user ID (will be replaced by auth context)
const DEFAULT_USER_ID = "user-001";

export const api = {
  tasks: {
    list: (params?: Record<string, string>) => {
      const qs = new URLSearchParams(params || {});
      return apiFetch<{ data: any[] }>(`/tasks?${qs}`);
    },
    get: (id: string) => apiFetch(`/tasks/${id}`),
    create: (data: any) => apiFetch("/tasks", { method: "POST", body: JSON.stringify({ ...data, createdBy: data.createdBy || DEFAULT_USER_ID }) }),
    update: (id: string, data: any) => apiFetch(`/tasks/${id}`, { method: "PUT", body: JSON.stringify(data) }),
    delete: (id: string) => apiFetch(`/tasks/${id}`, { method: "DELETE" }),
    changeStatus: (id: string, status: string, comment?: string) => apiFetch(`/tasks/${id}/status`, { method: "PATCH", body: JSON.stringify({ status, comment, actorId: DEFAULT_USER_ID }) }),
    addComment: (taskId: string, body: string) => apiFetch(`/tasks/${taskId}/comments`, { method: "POST", body: JSON.stringify({ userId: DEFAULT_USER_ID, body }) }),
    logTime: (taskId: string, hours: number, description?: string) => apiFetch(`/tasks/${taskId}/time-logs`, { method: "POST", body: JSON.stringify({ userId: DEFAULT_USER_ID, hours, description }) }),
  },
  projects: {
    list: (params?: Record<string, string>) => {
      const qs = new URLSearchParams(params || {});
      return apiFetch<{ data: any[] }>(`/projects?${qs}`);
    },
    create: (data: any) => apiFetch("/projects", { method: "POST", body: JSON.stringify(data) }),
  },
  users: {
    list: (params?: Record<string, string>) => {
      const qs = new URLSearchParams(params || {});
      return apiFetch<{ data: any[] }>(`/users?${qs}`);
    },
  },
  organizations: {
    list: () => apiFetch<{ data: any[] }>("/organizations"),
  },
  documents: {
    list: (params?: Record<string, string>) => {
      const qs = new URLSearchParams(params || {});
      return apiFetch<{ data: any[] }>(`/documents?${qs}`);
    },
    create: (data: any) => apiFetch("/documents", { method: "POST", body: JSON.stringify(data) }),
  },
  correspondence: {
    list: (params?: Record<string, string>) => {
      const qs = new URLSearchParams(params || {});
      return apiFetch<{ data: any[] }>(`/correspondence?${qs}`);
    },
    create: (data: any) => apiFetch("/correspondence", { method: "POST", body: JSON.stringify(data) }),
  },
  contracts: {
    list: (params?: Record<string, string>) => {
      const qs = new URLSearchParams(params || {});
      return apiFetch<{ data: any[] }>(`/contracts?${qs}`);
    },
    create: (data: any) => apiFetch("/contracts", { method: "POST", body: JSON.stringify(data) }),
  },
  vendors: {
    list: (params?: Record<string, string>) => {
      const qs = new URLSearchParams(params || {});
      return apiFetch<{ data: any[] }>(`/vendors?${qs}`);
    },
    create: (data: any) => apiFetch("/vendors", { method: "POST", body: JSON.stringify(data) }),
    delete: (id: string) => apiFetch(`/vendors?id=${id}`, { method: "DELETE" }),
  },
  procurement: {
    list: (params?: Record<string, string>) => {
      const qs = new URLSearchParams(params || {});
      return apiFetch<{ data: any[] }>(`/procurement?${qs}`);
    },
    create: (data: any) => apiFetch("/procurement", { method: "POST", body: JSON.stringify(data) }),
  },
  notifications: {
    list: (userId?: string) => apiFetch<{ data: any[] }>(`/notifications?userId=${userId || DEFAULT_USER_ID}`),
    markRead: (id: string) => apiFetch("/notifications", { method: "PUT", body: JSON.stringify({ id }) }),
    markAllRead: (userId?: string) => apiFetch("/notifications", { method: "PUT", body: JSON.stringify({ markAllRead: true, userId: userId || DEFAULT_USER_ID }) }),
  },
};
