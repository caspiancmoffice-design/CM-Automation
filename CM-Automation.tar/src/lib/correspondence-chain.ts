// correspondence-chain.ts — Helper to extract full correspondence chain
import type { Correspondence } from "./types";

/**
 * Get the full chain of correspondences for a given letter.
 * Traverses up to find all parents (via responseTo) and down to find all children.
 * Returns the chain sorted by date (oldest first).
 */
export function getCorrespondenceChain(
  allCorrespondences: Correspondence[],
  currentId: string
): Correspondence[] {
  const current = allCorrespondences.find((c) => c.id === currentId);
  if (!current) return [];

  // Build a map for quick lookup
  const byId = new Map(allCorrespondences.map((c) => [c.id, c]));

  // Collect all ancestors (walk up via responseTo)
  const ancestors: Correspondence[] = [];
  let node = current;
  while (node.responseTo) {
    const parent = byId.get(node.responseTo);
    if (!parent) break;
    ancestors.unshift(parent); // prepend
    node = parent;
  }

  // Collect all descendants (walk down - find letters that have responseTo pointing to our chain)
  const descendants: Correspondence[] = [];
  const collectChildren = (parentId: string) => {
    const children = allCorrespondences.filter((c) => c.responseTo === parentId);
    for (const child of children) {
      descendants.push(child);
      collectChildren(child.id); // recursively find grandchildren
    }
  };
  collectChildren(currentId);

  // Full chain: ancestors + current + descendants (already sorted by date due to chronological nature)
  const chain = [...ancestors, current, ...descendants];

  // Sort by date to ensure chronological order
  chain.sort((a, b) => {
    const dateA = a.date.replace(/\//g, "");
    const dateB = b.date.replace(/\//g, "");
    return dateA.localeCompare(dateB);
  });

  return chain;
}

/**
 * Get the position of current letter in the chain.
 * Returns { index, total, prevId, nextId }.
 */
export function getChainPosition(
  chain: Correspondence[],
  currentId: string
): {
  index: number;
  total: number;
  prevId?: string;
  nextId?: string;
  isFirst: boolean;
  isLast: boolean;
} {
  const index = chain.findIndex((c) => c.id === currentId);
  if (index === -1) {
    return { index: -1, total: 0, isFirst: true, isLast: true };
  }
  return {
    index,
    total: chain.length,
    prevId: index > 0 ? chain[index - 1].id : undefined,
    nextId: index < chain.length - 1 ? chain[index + 1].id : undefined,
    isFirst: index === 0,
    isLast: index === chain.length - 1,
  };
}
