'use client';

import { NavProvider, useNav } from "@/lib/nav-context";
import { DataProvider } from "@/lib/data-context";
import { AppShell } from "@/components/cm/app-shell";
import { LoginView } from "@/components/cm/views/login-view";

function AppContent() {
  const { view } = useNav();
  if (view === "login") {
    return <LoginView />;
  }
  return <AppShell />;
}

export default function Home() {
  return (
    <NavProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </NavProvider>
  );
}
