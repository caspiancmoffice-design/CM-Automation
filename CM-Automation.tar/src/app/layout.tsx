import type { Metadata } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: "CM Automation | سامانه مدیریت هوشمند ساخت",
  description:
    "پلتفرم یکپارچه، هوشمند و ماژولار برای مدیریت پروژه‌ها، اسناد، مکاتبات، قراردادها، بهره‌وری منابع انسانی و دانش سازمانی در صنعت ساخت.",
  keywords: [
    "مدیریت پروژه",
    "صنعت ساخت",
    "CM Automation",
    "پیمانکار",
    "مهندس مشاور",
    "کارفرما",
  ],
  authors: [{ name: "CM Automation Team" }],
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body
        className={`${vazirmatn.variable} font-sans antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <SonnerToaster position="top-center" dir="rtl" />
      </body>
    </html>
  );
}
