// GET /api/v1/users - List users
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const role = searchParams.get("role");

    const where: Record<string, unknown> = { deletedAt: null };
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { email: { contains: search } },
      ];
    }
    if (role && role !== "all") {
      where.defaultRole = role;
    }

    const users = await db.user.findMany({
      where,
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        avatarUrl: true,
        defaultRole: true,
        organizationId: true,
        department: true,
        status: true,
        productivityScore: true,
        lastSeenAt: true,
      },
      orderBy: { name: "asc" },
    });

    return NextResponse.json({ data: users });
  } catch (error) {
    console.error("GET users error:", error);
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}
