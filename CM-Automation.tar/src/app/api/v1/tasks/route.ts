// GET /api/v1/tasks - List tasks with filtering
// POST /api/v1/tasks - Create new task
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get("projectId");
    const status = searchParams.get("status");
    const priority = searchParams.get("priority");
    const search = searchParams.get("search") || "";
    const limit = parseInt(searchParams.get("limit") || "50");
    const offset = parseInt(searchParams.get("offset") || "0");

    const where: Record<string, unknown> = {
      deletedAt: null,
    };

    if (projectId) where.projectId = projectId;
    if (status && status !== "all") where.status = status;
    if (priority && priority !== "all") where.priority = priority;
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }

    const tasks = await db.task.findMany({
      where,
      include: {
        project: { select: { id: true, name: true } },
        members: {
          where: { isActive: true },
          include: {
            user: { select: { id: true, name: true, avatarUrl: true, defaultRole: true } },
          },
        },
        subtasks: { where: { deletedAt: null } },
        _count: {
          select: {
            comments: { where: { isDeleted: false } },
            timeLogs: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
      take: limit,
      skip: offset,
    });

    const total = await db.task.count({ where });

    // Transform for API response
    const transformed = tasks.map((task) => ({
      ...task,
      tags: JSON.parse(task.tags || "[]"),
      memberCount: task.members.length,
      subtaskCount: task.subtasks.length,
      subtaskDoneCount: task.subtasks.filter((s) => s.isDone).length,
      commentCount: task._count.comments,
      attachmentCount: 0, // TODO: when attachments module is ready
    }));

    return NextResponse.json({
      data: transformed,
      meta: { total, limit, offset },
    });
  } catch (error) {
    console.error("GET /api/v1/tasks error:", error);
    return NextResponse.json(
      { error: "خطا در دریافت وظایف" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validate required fields
    if (!body.title?.trim()) {
      return NextResponse.json(
        { error: "عنوان وظیفه الزامی است" },
        { status: 400 }
      );
    }
    if (!body.projectId) {
      return NextResponse.json(
        { error: "پروژه الزامی است" },
        { status: 400 }
      );
    }
    if (!body.dueDate) {
      return NextResponse.json(
        { error: "تاریخ سررسید الزامی است" },
        { status: 400 }
      );
    }

    // Create task
    const task = await db.task.create({
      data: {
        title: body.title.trim(),
        description: body.description || "",
        status: "todo",
        priority: body.priority || "medium",
        projectId: body.projectId,
        startDate: body.startDate || new Date().toISOString().split("T")[0].replace(/-/g, "/"),
        dueDate: body.dueDate,
        estimatedHours: parseFloat(body.estimatedHours) || 0,
        tags: JSON.stringify(body.tags || []),
        createdBy: body.createdBy || "unknown", // TODO: get from auth
      },
    });

    // Add members if provided (assignees is comma-separated)
    if (body.assignees) {
      const userIds = String(body.assignees).split(",").filter(Boolean);
      for (const userId of userIds) {
        // Handle "self" - skip for now, will be resolved with auth
        if (userId === "self") continue;

        await db.taskMember.create({
          data: {
            taskId: task.id,
            userId,
            role: "contributor",
            participationPercent: Math.floor(100 / userIds.length),
          },
        });
      }
    }

    // Log activity
    await db.taskActivityLog.create({
      data: {
        taskId: task.id,
        activityType: "created",
        actorId: body.createdBy || "unknown",
        description: "وظیفه ایجاد شد",
      },
    });

    // Fetch created task with relations
    const created = await db.task.findUnique({
      where: { id: task.id },
      include: {
        project: { select: { id: true, name: true } },
        members: {
          where: { isActive: true },
          include: { user: { select: { id: true, name: true } } },
        },
      },
    });

    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("POST /api/v1/tasks error:", error);
    return NextResponse.json(
      { error: "خطا در ایجاد وظیفه" },
      { status: 500 }
    );
  }
}
