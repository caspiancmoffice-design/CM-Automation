// POST /api/v1/tasks/[id]/comments - Add comment
// GET /api/v1/tasks/[id]/comments - List comments
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const comments = await db.taskComment.findMany({
      where: { taskId: params.id, isDeleted: false },
      include: { user: { select: { id: true, name: true, avatarUrl: true } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(comments);
  } catch (error) {
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { userId, body: commentBody, type = "comment" } = body;

    if (!commentBody?.trim()) {
      return NextResponse.json({ error: "متن نظر الزامی است" }, { status: 400 });
    }

    const comment = await db.taskComment.create({
      data: {
        taskId: params.id,
        userId,
        body: commentBody.trim(),
        type,
      },
      include: { user: { select: { id: true, name: true, avatarUrl: true } } },
    });

    await db.taskActivityLog.create({
      data: {
        taskId: params.id,
        activityType: "commented",
        actorId: userId,
        description: "نظر جدید ثبت شد",
      },
    });

    return NextResponse.json(comment, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}
