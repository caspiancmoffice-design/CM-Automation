// GET /api/v1/tasks/[id] - Get task details
// PUT /api/v1/tasks/[id] - Update task
// DELETE /api/v1/tasks/[id] - Soft delete task
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const task = await db.task.findUnique({
      where: { id: params.id, deletedAt: null },
      include: {
        project: { select: { id: true, name: true, code: true } },
        members: {
          where: { isActive: true },
          include: {
            user: { select: { id: true, name: true, avatarUrl: true, defaultRole: true } },
          },
        },
        subtasks: {
          where: { deletedAt: null },
          orderBy: { displayOrder: "asc" },
        },
        comments: {
          where: { isDeleted: false },
          include: { user: { select: { id: true, name: true, avatarUrl: true } } },
          orderBy: { createdAt: "desc" },
        },
        timeLogs: {
          include: { user: { select: { id: true, name: true } } },
          orderBy: { logDate: "desc" },
        },
        activities: {
          include: {
            actor: { select: { id: true, name: true } },
          },
          orderBy: { createdAt: "desc" },
          take: 20,
        },
      },
    });

    if (!task) {
      return NextResponse.json(
        { error: "وظیفه یافت نشد" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      ...task,
      tags: JSON.parse(task.tags || "[]"),
    });
  } catch (error) {
    console.error("GET /api/v1/tasks/[id] error:", error);
    return NextResponse.json(
      { error: "خطا در دریافت وظیفه" },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const task = await db.task.findUnique({
      where: { id: params.id, deletedAt: null },
    });

    if (!task) {
      return NextResponse.json(
        { error: "وظیفه یافت نشد" },
        { status: 404 }
      );
    }

    // Track changes for activity log
    const changes: string[] = [];
    const updateData: Record<string, unknown> = { updatedBy: body.updatedBy || task.createdBy };

    if (body.title && body.title !== task.title) {
      updateData.title = body.title;
      changes.push("title");
    }
    if (body.description !== undefined && body.description !== task.description) {
      updateData.description = body.description;
      changes.push("description");
    }
    if (body.priority && body.priority !== task.priority) {
      updateData.priority = body.priority;
      changes.push("priority");
    }
    if (body.dueDate && body.dueDate !== task.dueDate) {
      updateData.dueDate = body.dueDate;
      changes.push("dueDate");
    }
    if (body.estimatedHours !== undefined) {
      updateData.estimatedHours = parseFloat(body.estimatedHours);
      changes.push("estimatedHours");
    }
    if (body.tags) {
      updateData.tags = JSON.stringify(body.tags);
      changes.push("tags");
    }

    const updated = await db.task.update({
      where: { id: params.id },
      data: updateData,
    });

    // Log activity if changed
    if (changes.length > 0) {
      await db.taskActivityLog.create({
        data: {
          taskId: params.id,
          activityType: "updated",
          actorId: body.updatedBy || task.createdBy,
          description: `فیلدهای ${changes.join("، ")} به‌روزرسانی شد`,
          metadata: JSON.stringify({ fields: changes }),
        },
      });
    }

    return NextResponse.json(updated);
  } catch (error) {
    console.error("PUT /api/v1/tasks/[id] error:", error);
    return NextResponse.json(
      { error: "خطا در ویرایش وظیفه" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const task = await db.task.findUnique({
      where: { id: params.id, deletedAt: null },
    });

    if (!task) {
      return NextResponse.json(
        { error: "وظیفه یافت نشد" },
        { status: 404 }
      );
    }

    // Soft delete
    await db.task.update({
      where: { id: params.id },
      data: { deletedAt: new Date() },
    });

    await db.taskActivityLog.create({
      data: {
        taskId: params.id,
        activityType: "deleted",
        actorId: task.createdBy,
        description: "وظیفه حذف شد",
      },
    });

    return NextResponse.json({ deleted: true });
  } catch (error) {
    console.error("DELETE /api/v1/tasks/[id] error:", error);
    return NextResponse.json(
      { error: "خطا در حذف وظیفه" },
      { status: 500 }
    );
  }
}
