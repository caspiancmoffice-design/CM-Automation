// PATCH /api/v1/tasks/[id]/status - Change task status
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Valid status transitions
const validTransitions: Record<string, string[]> = {
  backlog: ["todo"],
  todo: ["in_progress", "blocked"],
  in_progress: ["review", "blocked", "todo"],
  review: ["done", "in_progress"],
  done: [],
  blocked: ["todo", "in_progress"],
};

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { status, comment, actorId } = body;

    const task = await db.task.findUnique({
      where: { id: params.id, deletedAt: null },
    });

    if (!task) {
      return NextResponse.json({ error: "وظیفه یافت نشد" }, { status: 404 });
    }

    // Validate transition
    if (!validTransitions[task.status]?.includes(status)) {
      return NextResponse.json(
        { error: `انتقال از ${task.status} به ${status} مجاز نیست` },
        { status: 400 }
      );
    }

    const updateData: Record<string, unknown> = { status, updatedBy: actorId || task.createdBy };

    // Set completedAt when status is 'done'
    if (status === "done" && task.status !== "done") {
      updateData.completedAt = new Date();
      updateData.progress = 100;
    }
    // Clear completedAt when reopening
    if (status !== "done" && task.status === "done") {
      updateData.completedAt = null;
    }

    const updated = await db.task.update({
      where: { id: params.id },
      data: updateData,
    });

    // Log activity
    await db.taskActivityLog.create({
      data: {
        taskId: params.id,
        activityType: status === "done" ? "completed" : "status_changed",
        actorId: actorId || task.createdBy,
        fieldName: "status",
        oldValue: task.status,
        newValue: status,
        description: `وضعیت از ${task.status} به ${status} تغییر کرد`,
      },
    });

    // Add comment if provided
    if (comment) {
      await db.taskComment.create({
        data: {
          taskId: params.id,
          userId: actorId || task.createdBy,
          body: comment,
          type: "system",
        },
      });
    }

    return NextResponse.json(updated);
  } catch (error) {
    console.error("PATCH status error:", error);
    return NextResponse.json({ error: "خطا در تغییر وضعیت" }, { status: 500 });
  }
}
