// POST /api/v1/tasks/[id]/time-logs - Log time
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { userId, hours, description, source = "manual" } = body;

    if (!hours || hours <= 0 || hours > 24) {
      return NextResponse.json({ error: "ساعت باید بین ۰ و ۲۴ باشد" }, { status: 400 });
    }

    const log = await db.taskTimeLog.create({
      data: {
        taskId: params.id,
        userId,
        hours: parseFloat(hours),
        description,
        source,
      },
    });

    // Auto-update task and member spent hours
    const totalHours = await db.taskTimeLog.aggregate({
      where: { taskId: params.id },
      _sum: { hours: true },
    });

    await db.task.update({
      where: { id: params.id },
      data: { spentHours: totalHours._sum.hours || 0 },
    });

    const memberHours = await db.taskTimeLog.aggregate({
      where: { taskId: params.id, userId },
      _sum: { hours: true },
    });

    await db.taskMember.update({
      where: { taskId_userId: { taskId: params.id, userId } },
      data: { timeSpentHours: memberHours._sum.hours || 0 },
    });

    await db.taskActivityLog.create({
      data: {
        taskId: params.id,
        activityType: "time_logged",
        actorId: userId,
        description: `${hours} ساعت زمان ثبت شد`,
        metadata: JSON.stringify({ hours, source }),
      },
    });

    return NextResponse.json(log, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}
