// POST /api/v1/tasks/[id]/members - Add member to task
// GET /api/v1/tasks/[id]/members - List members
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const members = await db.taskMember.findMany({
      where: { taskId: params.id, isActive: true },
      include: {
        user: { select: { id: true, name: true, avatarUrl: true, defaultRole: true } },
      },
    });
    return NextResponse.json(members);
  } catch (error) {
    console.error("GET members error:", error);
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { userId, role = "contributor", participationPercent = 0, actorId } = body;

    // Check if already a member
    const existing = await db.taskMember.findUnique({
      where: { taskId_userId: { taskId: params.id, userId } },
    });

    if (existing && existing.isActive) {
      return NextResponse.json(
        { error: "این کاربر قبلاً عضو وظیفه است" },
        { status: 409 }
      );
    }

    // Create or reactivate membership
    const member = await db.taskMember.upsert({
      where: { taskId_userId: { taskId: params.id, userId } },
      update: { isActive: true, role, participationPercent, unassignedAt: null },
      create: { taskId: params.id, userId, role, participationPercent },
    });

    // Log activity
    await db.taskActivityLog.create({
      data: {
        taskId: params.id,
        activityType: "assigned",
        actorId: actorId || "system",
        targetUserId: userId,
        description: `عضو جدید با نقش ${role} تخصیص داده شد`,
      },
    });

    return NextResponse.json(member, { status: 201 });
  } catch (error) {
    console.error("POST members error:", error);
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}

// DELETE - Remove member
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json({ error: "userId الزامی است" }, { status: 400 });
    }

    await db.taskMember.update({
      where: { taskId_userId: { taskId: params.id, userId } },
      data: { isActive: false, unassignedAt: new Date() },
    });

    await db.taskActivityLog.create({
      data: {
        taskId: params.id,
        activityType: "unassigned",
        actorId: userId,
        targetUserId: userId,
        description: "عضو از وظیفه حذف شد",
      },
    });

    return NextResponse.json({ removed: true });
  } catch (error) {
    console.error("DELETE members error:", error);
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}
