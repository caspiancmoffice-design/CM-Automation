// GET /api/v1/projects - List projects
// POST /api/v1/projects - Create project
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const search = searchParams.get("search") || "";

    const where: Record<string, unknown> = { deletedAt: null };
    if (status && status !== "all") where.status = status;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { code: { contains: search } },
        { client: { contains: search } },
      ];
    }

    const projects = await db.project.findMany({
      where,
      include: {
        members: { where: { isActive: true }, include: { user: { select: { id: true, name: true } } } },
        _count: { select: { tasks: { where: { deletedAt: null, status: { not: "done" } } } } },
      },
      orderBy: { updatedAt: "desc" },
    });

    const transformed = projects.map((p) => ({
      ...p,
      budget: p.budget?.toString(),
      spentBudget: p.spentBudget?.toString(),
      tags: JSON.parse(p.tags || "[]"),
      teamSize: p.members.length,
      openTasks: p._count.tasks,
    }));

    return NextResponse.json({ data: transformed });
  } catch (error) {
    console.error("GET projects error:", error);
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body.name?.trim() || !body.code?.trim()) {
      return NextResponse.json({ error: "نام و کد پروژه الزامی است" }, { status: 400 });
    }

    const project = await db.project.create({
      data: {
        name: body.name.trim(),
        code: body.code.trim(),
        description: body.description || "",
        status: "planning",
        organizationId: body.organizationId,
        client: body.client || "",
        consultant: body.consultant,
        contractor: body.contractor,
        startDate: body.startDate,
        endDate: body.endDate,
        budget: BigInt(body.budget || 0),
        location: body.location,
        managerId: body.managerId,
        tags: JSON.stringify(body.tags || []),
        createdBy: body.createdBy,
      },
    });

    return NextResponse.json({
      ...project,
      budget: project.budget?.toString(),
      spentBudget: project.spentBudget?.toString(),
    }, { status: 201 });
  } catch (error) {
    console.error("POST projects error:", error);
    return NextResponse.json({ error: "خطا در ایجاد پروژه" }, { status: 500 });
  }
}
