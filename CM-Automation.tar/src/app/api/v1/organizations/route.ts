// GET /api/v1/organizations - List organizations
import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const orgs = await db.organization.findMany({
      where: { deletedAt: null, isActive: true },
      select: {
        id: true,
        name: true,
        type: true,
        address: true,
        phone: true,
        email: true,
        nationalId: true,
      },
      orderBy: { name: "asc" },
    });

    return NextResponse.json({ data: orgs });
  } catch (error) {
    console.error("GET organizations error:", error);
    return NextResponse.json({ error: "خطا" }, { status: 500 });
  }
}
