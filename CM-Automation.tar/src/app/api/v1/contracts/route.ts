// GET / POST /api/v1/contracts
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");
    const status = searchParams.get("status");
    const search = searchParams.get("search") || "";
    const where: Record<string, unknown> = {};
    if (type && type !== "all") where.type = type;
    if (status && status !== "all") where.status = status;
    if (search) { where.OR = [{ title: { contains: search } }, { number: { contains: search } }]; }

    const contracts = await db.contract.findMany({ where, include: { obligations: true, priceItems: true, project: { select: { name: true } } }, orderBy: { createdAt: "desc" } });
    const transformed = contracts.map(c => ({ ...c, totalAmount: c.totalAmount?.toString(), guaranteeAmount: c.guaranteeAmount?.toString(), delayPenalty: c.delayPenalty?.toString(), specialConditions: JSON.parse(c.specialConditions || "[]"), priceItems: c.priceItems.map(pi => ({ ...pi, unitPrice: pi.unitPrice?.toString(), totalPrice: pi.totalPrice?.toString() })) }));
    return NextResponse.json({ data: transformed });
  } catch (e) { console.error(e); return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    if (!body.title?.trim()) return NextResponse.json({ error: "عنوان قرارداد الزامی است" }, { status: 400 });
    if (!body.number?.trim()) return NextResponse.json({ error: "شماره قرارداد الزامی است" }, { status: 400 });

    const contract = await db.contract.create({
      data: {
        number: body.number.trim(),
        title: body.title.trim(),
        type: body.type || "other",
        category: body.category || "execution",
        status: "draft",
        subject: body.subject || "",
        projectId: body.projectId || null,
        projectName: body.projectName || "",
        projectAddress: body.projectAddress || "",
        employer: body.employer || "",
        contractor: body.contractor || "",
        totalAmount: BigInt(body.totalAmount || 0),
        prepaymentPercent: body.prepaymentPercent || 0,
        guaranteeType: body.guaranteeType || "none",
        guaranteeAmount: BigInt(body.guaranteeAmount || 0),
        retentionPercent: body.retentionPercent || 10,
        paymentMethod: body.paymentMethod || "monthly_statement",
        durationMonths: body.durationMonths || 3,
        startDate: body.startDate || null,
        endDate: body.endDate || null,
        delayPenalty: BigInt(body.delayPenalty || 0),
        disputeResolution: body.disputeResolution || "داوری",
        createdBy: body.createdBy || "system",
      },
    });
    return NextResponse.json({ ...contract, totalAmount: contract.totalAmount?.toString() }, { status: 201 });
  } catch (e) { console.error(e); return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}
