// GET /api/v1/notifications
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId") || "user-001";
    const filter = searchParams.get("filter"); // "all" or "unread"

    const where: Record<string, unknown> = { userId };
    if (filter === "unread") where.read = false;

    const notifs = await db.notification.findMany({ where, orderBy: { createdAt: "desc" } });
    return NextResponse.json({ data: notifs });
  } catch (e) { return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, markAllRead, userId } = body;

    if (markAllRead && userId) {
      await db.notification.updateMany({ where: { userId, read: false }, data: { read: true } });
      return NextResponse.json({ updated: true });
    }

    if (id) {
      await db.notification.update({ where: { id }, data: { read: true } });
      return NextResponse.json({ updated: true });
    }

    return NextResponse.json({ error: "id یا markAllRead الزامی است" }, { status: 400 });
  } catch (e) { return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}
