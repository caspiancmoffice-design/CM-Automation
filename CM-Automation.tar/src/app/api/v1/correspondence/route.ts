// GET / POST /api/v1/correspondence
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const direction = searchParams.get("direction");
    const search = searchParams.get("search") || "";
    const where: Record<string, unknown> = {};
    if (direction && direction !== "all") where.direction = direction;
    if (search) { where.OR = [{ subject: { contains: search } }, { number: { contains: search } }, { from: { contains: search } }, { to: { contains: search } }]; }

    const corrs = await db.correspondence.findMany({ where, orderBy: { date: "desc" } });
    return NextResponse.json({ data: corrs });
  } catch (e) { console.error(e); return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    if (!body.subject?.trim()) return NextResponse.json({ error: "موضوع الزامی است" }, { status: 400 });

    // Auto-generate number
    const count = await db.correspondence.count();
    const number = `PA-1403/${1000 + count + 27}`;

    const corr = await db.correspondence.create({
      data: {
        number,
        subject: body.subject.trim(),
        direction: body.direction || "outbound",
        status: "sent",
        from: body.from || "شرکت ساختمانی پارس آرین",
        to: body.to || "",
        date: body.date || new Date().toISOString().split("T")[0].replace(/-/g, "/"),
        projectId: body.project || null,
        priority: body.priority || "medium",
        body: body.body || "",
        category: body.category || "فنی",
        senderName: body.senderName || null,
        senderRole: body.senderRole || null,
        receiverName: body.receiverName || null,
        receiverRole: body.receiverRole || null,
        action: body.action || "ارسال نامه",
        createdBy: body.createdBy || U.u1,
      },
    });
    return NextResponse.json(corr, { status: 201 });
  } catch (e) { console.error(e); return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}

const U = { u1: "user-001" };
