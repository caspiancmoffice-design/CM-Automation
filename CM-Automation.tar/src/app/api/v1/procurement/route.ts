// GET / POST /api/v1/procurement
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const priority = searchParams.get("priority");
    const search = searchParams.get("search") || "";
    const where: Record<string, unknown> = {};
    if (status && status !== "all") where.status = status;
    if (priority && priority !== "all") where.priority = priority;
    if (search) { where.OR = [{ title: { contains: search } }, { number: { contains: search } }, { requesterName: { contains: search } }]; }

    const prs = await db.purchaseRequest.findMany({ where, include: { items: true, workflowSteps: { orderBy: { createdAt: "asc" } }, project: { select: { name: true } } }, orderBy: { createdAt: "desc" } });
    const transformed = prs.map(pr => ({ ...pr, totalEstimate: pr.totalEstimate?.toString(), items: pr.items.map(it => ({ ...it, unitPriceEstimate: it.unitPriceEstimate?.toString(), totalPriceEstimate: it.totalPriceEstimate?.toString() })) }));
    return NextResponse.json({ data: transformed });
  } catch (e) { return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    if (!body.title?.trim()) return NextResponse.json({ error: "عنوان الزامی است" }, { status: 400 });

    const count = await db.purchaseRequest.count();
    const number = `PR-1403-${String(count + 24).padStart(3, "0")}`;

    let totalEstimate = BigInt(0);
    if (body.items) {
      for (const item of body.items) {
        if (item.quantity && item.unitPriceEstimate) {
          totalEstimate += BigInt(Math.floor(item.quantity * item.unitPriceEstimate));
        }
      }
    }

    const pr = await prisma.purchaseRequest.create({
      data: {
        number,
        title: body.title.trim(),
        status: body.submitMode === "submit" ? "submitted" : "draft",
        priority: body.priority || "medium",
        projectId: body.projectId || null,
        requesterId: body.requesterId || "user-001",
        requesterName: body.requesterName || "مهندس رضا کریمی",
        neededByDate: body.neededByDate || "",
        totalEstimate,
        description: body.description || "",
        justification: body.justification || "",
      },
    });

    // Create items
    if (body.items && Array.isArray(body.items)) {
      for (let i = 0; i < body.items.length; i++) {
        const item = body.items[i];
        if (!item.name?.trim()) continue;
        await prisma.purchaseRequestItem.create({
          data: {
            purchaseRequestId: pr.id,
            row: i + 1,
            name: item.name.trim(),
            category: item.category || "material",
            quantity: parseFloat(item.quantity) || 0,
            unit: item.unit || "عدد",
            consumptionLocation: item.consumptionLocation || "",
            technicalSpec: item.technicalSpec || "",
            vendorId: item.vendorId || null,
            vendorName: item.vendorName || null,
            orderPercent: parseInt(item.orderPercent) || 0,
            unitPriceEstimate: BigInt(Math.floor(parseFloat(item.unitPriceEstimate) || 0)),
            totalPriceEstimate: BigInt(Math.floor(parseFloat(item.unitPriceEstimate || 0) * parseFloat(item.quantity || 0))),
          },
        });
      }
    }

    // Create default workflow steps
    const steps = [
      ["submit", "ارسال درخواست"],
      ["technical_review", "بازبینی فنی"],
      ["manager_approval", "تأیید مدیر پروژه"],
      ["financial_review", "بازبینی مالی"],
      ["order", "صدور سفارش"],
      ["delivery", "تحویل"],
      ["close", "خاتمه"],
    ];
    for (let i = 0; i < steps.length; i++) {
      await prisma.workflowStep.create({
        data: {
          purchaseRequestId: pr.id,
          type: steps[i][0],
          title: steps[i][1],
          status: i === 0 && body.submitMode === "submit" ? "current" : "pending",
        },
      });
    }

    return NextResponse.json(pr, { status: 201 });
  } catch (e) { console.error(e); return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}

import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
