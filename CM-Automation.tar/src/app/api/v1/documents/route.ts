// GET / POST /api/v1/documents
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get("projectId");
    const category = searchParams.get("category");
    const search = searchParams.get("search") || "";

    const where: Record<string, unknown> = { deletedAt: null };
    if (projectId) where.projectId = projectId;
    if (category && category !== "all") where.category = category;
    if (search) where.name = { contains: search };

    const docs = await db.document.findMany({ where, include: { versions: true, project: { select: { name: true } } }, orderBy: { createdAt: "desc" } });
    const transformed = docs.map(d => ({ ...d, tags: JSON.parse(d.tags || "[]") }));
    return NextResponse.json({ data: transformed });
  } catch (e) { console.error(e); return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    if (!body.name?.trim()) return NextResponse.json({ error: "نام سند الزامی است" }, { status: 400 });

    const doc = await db.document.create({
      data: {
        name: body.name.trim(),
        category: body.category || "other",
        projectId: body.projectId || null,
        mimeType: body.mimeType || "application/octet-stream",
        size: body.size || 0,
        currentVersion: "v1.0",
        status: "draft",
        tags: JSON.stringify(body.tags || []),
        uploadedBy: body.uploadedBy || "system",
        description: body.description || "",
      },
      include: { versions: true, project: { select: { name: true } } },
    });

    // Create initial version
    await db.documentVersion.create({
      data: { documentId: doc.id, version: "v1.0", uploadedBy: body.uploadedBy || "system", comment: "نسخه اولیه" },
    });

    return NextResponse.json({ ...doc, tags: JSON.parse(doc.tags || "[]") }, { status: 201 });
  } catch (e) { console.error(e); return NextResponse.json({ error: "خطا" }, { status: 500 }); }
}
