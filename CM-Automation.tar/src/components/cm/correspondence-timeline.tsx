// correspondence-timeline.tsx — Visual timeline for correspondence chains
"use client";
import { useMemo } from "react";
import { useNav } from "@/lib/nav-context";
import { UserAvatar } from "./user-avatar";
import { StatusBadge } from "./status-badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ArrowDownLeft,
  ArrowUpRight,
  ArrowRight,
  ArrowLeft,
  Mail,
  Paperclip,
  ChevronLeft,
  ChevronRight,
  GitBranch,
  Clock,
  User as UserIcon,
  Building2,
} from "lucide-react";
import { getCorrespondenceChain, getChainPosition } from "@/lib/correspondence-chain";
import { toPersianDigits } from "@/lib/jalali-utils";
import { faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import type { Correspondence } from "@/lib/types";

interface CorrespondenceTimelineProps {
  correspondences: Correspondence[];
  currentId: string;
  onSelect?: (id: string) => void;
}

export function CorrespondenceTimeline({
  correspondences,
  currentId,
  onSelect,
}: CorrespondenceTimelineProps) {
  const { navigate } = useNav();

  const chain = useMemo(
    () => getCorrespondenceChain(correspondences, currentId),
    [correspondences, currentId]
  );
  const position = useMemo(
    () => getChainPosition(chain, currentId),
    [chain, currentId]
  );

  if (chain.length <= 1) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          <GitBranch className="size-10 mx-auto mb-2 opacity-30" />
          <p className="text-sm">این مکاتبه بخشی از زنجیره‌ای نیست.</p>
          <p className="text-xs mt-1">این نامه پاسخی به نامه دیگری نیست و پاسخی نیز دریافت نکرده است.</p>
        </CardContent>
      </Card>
    );
  }

  const handleSelect = (id: string) => {
    if (onSelect) {
      onSelect(id);
    } else {
      // Navigate to correspondence view and set context
      navigate("correspondence", id);
    }
  };

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <GitBranch className="size-4 text-primary" />
          زنجیره مکاتبات
          <span className="text-xs text-muted-foreground font-normal">
            ({toPersianDigits(chain.length)} نامه)
          </span>
        </CardTitle>
        <div className="flex items-center gap-1">
          <Button
            variant="outline"
            size="sm"
            disabled={position.isFirst}
            onClick={() => position.prevId && handleSelect(position.prevId)}
          >
            <ChevronRight className="size-4" />
            <span className="hidden sm:inline">نامه قبلی</span>
          </Button>
          <span className="text-xs text-muted-foreground px-2">
            {toPersianDigits(position.index + 1)} از {toPersianDigits(position.total)}
          </span>
          <Button
            variant="outline"
            size="sm"
            disabled={position.isLast}
            onClick={() => position.nextId && handleSelect(position.nextId)}
          >
            <span className="hidden sm:inline">نامه بعدی</span>
            <ChevronLeft className="size-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Horizontal scrollable timeline */}
        <div className="overflow-x-auto pb-2">
          <div className="flex items-stretch gap-0 min-w-max">
            {chain.map((letter, idx) => {
              const isCurrent = letter.id === currentId;
              const isInbound = letter.direction === "inbound";
              const Icon = isInbound ? ArrowDownLeft : ArrowUpRight;

              return (
                <div key={letter.id} className="flex items-stretch">
                  {/* Timeline node */}
                  <button
                    onClick={() => handleSelect(letter.id)}
                    className={cn(
                      "flex flex-col items-center min-w-[200px] max-w-[240px] p-3 rounded-lg border-2 transition-all group text-right",
                      isCurrent
                        ? "border-primary bg-primary/5 shadow-md"
                        : "border-border hover:border-primary/40 hover:bg-accent/30"
                    )}
                  >
                    {/* Direction + date */}
                    <div className="flex items-center justify-between w-full mb-2">
                      <div className={cn(
                        "size-8 rounded-full flex items-center justify-center shrink-0",
                        isInbound
                          ? "bg-success/10 text-success"
                          : "bg-info/10 text-info"
                      )}>
                        <Icon className="size-4" />
                      </div>
                      <span className={cn(
                        "text-[10px] font-mono px-1.5 py-0.5 rounded",
                        isCurrent ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                      )}>
                        {toPersianDigits(idx + 1)}
                      </span>
                    </div>

                    {/* Date */}
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground mb-2 w-full">
                      <Clock className="size-2.5 shrink-0" />
                      <span>{toPersianDigits(letter.date)}</span>
                    </div>

                    {/* Subject */}
                    <p className={cn(
                      "text-xs font-medium leading-snug line-clamp-2 w-full mb-2",
                      isCurrent ? "text-primary" : "text-foreground"
                    )}>
                      {letter.subject}
                    </p>

                    {/* Sender info */}
                    <div className="flex items-center gap-1.5 w-full mb-1">
                      <UserAvatar name={letter.senderName || letter.from} size="sm" />
                      <div className="flex-1 min-w-0 text-right">
                        <p className="text-[10px] font-medium truncate">
                          {letter.senderName || letter.from}
                        </p>
                        {letter.senderRole && (
                          <p className="text-[9px] text-muted-foreground truncate">
                            {letter.senderRole}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Arrow down */}
                    <ArrowLeft className="size-3 text-muted-foreground rotate-90 my-0.5" />

                    {/* Receiver info */}
                    <div className="flex items-center gap-1.5 w-full">
                      <UserAvatar name={letter.receiverName || letter.to} size="sm" />
                      <div className="flex-1 min-w-0 text-right">
                        <p className="text-[10px] font-medium truncate">
                          {letter.receiverName || letter.to}
                        </p>
                        {letter.receiverRole && (
                          <p className="text-[9px] text-muted-foreground truncate">
                            {letter.receiverRole}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Action badge */}
                    {letter.action && (
                      <span className="mt-2 text-[9px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground w-full text-center">
                        {letter.action}
                      </span>
                    )}

                    {/* Number */}
                    <p className="text-[9px] text-muted-foreground font-mono mt-1.5 w-full text-center">
                      {letter.number}
                    </p>

                    {/* Current indicator */}
                    {isCurrent && (
                      <div className="mt-2 px-2 py-0.5 rounded-full bg-primary text-primary-foreground text-[9px] font-bold w-full text-center">
                        مکاتبه فعلی
                      </div>
                    )}
                  </button>

                  {/* Connector arrow between nodes */}
                  {idx < chain.length - 1 && (
                    <div className="flex items-center px-1">
                      <div className="flex flex-col items-center">
                        <div className={cn(
                          "h-0.5 w-8",
                          isCurrent ? "bg-primary" : "bg-border"
                        )} />
                        <ChevronLeft className="size-3 text-muted-foreground -mt-1.5" />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Summary bar */}
        <div className="mt-4 pt-3 border-t flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-muted-foreground">
              <ArrowUpRight className="size-3 text-info" />
              صادره: {toPersianDigits(chain.filter((c) => c.direction === "outbound").length)}
            </span>
            <span className="flex items-center gap-1 text-muted-foreground">
              <ArrowDownLeft className="size-3 text-success" />
              وارده: {toPersianDigits(chain.filter((c) => c.direction === "inbound").length)}
            </span>
          </div>
          <div className="flex items-center gap-1 text-muted-foreground">
            <Clock className="size-3" />
            <span>
              از {toPersianDigits(chain[0].date)} تا {toPersianDigits(chain[chain.length - 1].date)}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
