// user-avatar.tsx — Avatar with Persian initials fallback
"use client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { initials } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";

const palette = [
  "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
  "bg-amber-500/15 text-amber-700 dark:text-amber-300",
  "bg-rose-500/15 text-rose-700 dark:text-rose-300",
  "bg-teal-500/15 text-teal-700 dark:text-teal-300",
  "bg-orange-500/15 text-orange-700 dark:text-orange-300",
  "bg-lime-500/15 text-lime-700 dark:text-lime-300",
];

function pickColor(seed: string) {
  let sum = 0;
  for (let i = 0; i < seed.length; i++) sum += seed.charCodeAt(i);
  return palette[sum % palette.length];
}

export function UserAvatar({
  name,
  src,
  size = "default",
  className,
}: {
  name: string;
  src?: string;
  size?: "sm" | "default" | "lg" | "xl";
  className?: string;
}) {
  const sizeClass = {
    sm: "size-7 text-[10px]",
    default: "size-9 text-xs",
    lg: "size-11 text-sm",
    xl: "size-16 text-lg",
  }[size];

  return (
    <Avatar className={cn(sizeClass, className)}>
      {src && <AvatarImage src={src} alt={name} />}
      <AvatarFallback className={cn("font-semibold", pickColor(name))}>
        {initials(name)}
      </AvatarFallback>
    </Avatar>
  );
}

/** Stacked avatar group (for showing multiple assignees) */
export function AvatarGroup({
  users,
  max = 3,
  size = "sm",
}: {
  users: { userName: string; avatar?: string }[];
  max?: number;
  size?: "sm" | "default";
}) {
  const visible = users.slice(0, max);
  const overflow = users.length - max;
  const sizePx = size === "sm" ? 28 : 36;

  return (
    <div className="flex items-center -space-x-2 space-x-reverse">
      {visible.map((u, i) => (
        <div
          key={i}
          style={{ zIndex: visible.length - i }}
          className="ring-2 ring-background rounded-full"
        >
          <UserAvatar name={u.userName} src={u.avatar} size={size} />
        </div>
      ))}
      {overflow > 0 && (
        <div
          className="ring-2 ring-background rounded-full bg-muted text-muted-foreground flex items-center justify-center font-medium"
          style={{ width: sizePx, height: sizePx, fontSize: size === "sm" ? 10 : 12 }}
        >
          +{overflow.toLocaleString("fa-IR")}
        </div>
      )}
    </div>
  );
}
