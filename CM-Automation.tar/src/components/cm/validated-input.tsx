// validated-input.tsx — Input with format + validation for Iranian IDs
"use client";
import { useState, useEffect, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { toEnglishDigits } from "@/lib/jalali-utils";

type ValidatorType = "nationalId" | "phone" | "iban" | "postalCode" | "companyNationalId" | "number";

interface ValidatedInputProps {
  type: ValidatorType;
  value: string;
  onChange: (value: string) => void;
  label?: string;
  placeholder?: string;
  className?: string;
  dir?: "rtl" | "ltr";
  disabled?: boolean;
  required?: boolean;
  showError?: boolean; // show error message below input (default true)
}

/** Validate Iranian National ID (کدملی) - 10 digits with check digit */
export function validateNationalId(value: string): { valid: boolean; error?: string } {
  const v = toEnglishDigits(value).replace(/[\s\-]/g, "");
  if (!v) return { valid: false, error: "کدملی الزامی است" };
  if (!/^\d{10}$/.test(v)) {
    if (v.length < 10) return { valid: false, error: "کدملی باید ۱۰ رقم باشد" };
    return { valid: false, error: "کدملی فقط باید شامل ارقام باشد" };
  }
  // Check digit algorithm
  const digits = v.split("").map(Number);
  const check = digits[9];
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += digits[i] * (10 - i);
  }
  const remainder = sum % 11;
  const isValid = remainder < 2
    ? check === remainder
    : check === 11 - remainder;
  if (!isValid) return { valid: false, error: "کدملی نامعتبر است" };
  return { valid: true };
}

/** Validate Iranian company National ID (شناسه ملی) - 11 digits with check digit */
export function validateCompanyNationalId(value: string): { valid: boolean; error?: string } {
  const v = toEnglishDigits(value).replace(/[\s\-]/g, "");
  if (!v) return { valid: false, error: "شناسه ملی الزامی است" };
  if (!/^\d{11}$/.test(v)) {
    if (v.length < 11) return { valid: false, error: "شناسه ملی باید ۱۱ رقم باشد" };
    return { valid: false, error: "شناسه ملی فقط باید شامل ارقام باشد" };
  }
  // Company national ID check algorithm
  const digits = v.split("").map(Number);
  const check = digits[10];
  let sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += digits[i] * (11 - i);
  }
  const remainder = sum % 11;
  const computed = (remainder === 0) ? 0 : (11 - remainder);
  if (check !== computed && (remainder < 2 ? check !== remainder : check !== 11 - remainder)) {
    return { valid: false, error: "شناسه ملی نامعتبر است" };
  }
  return { valid: true };
}

/** Validate Iranian mobile phone (09123456789) */
export function validatePhone(value: string): { valid: boolean; error?: string } {
  const v = toEnglishDigits(value).replace(/[\s\-()]/g, "");
  if (!v) return { valid: false, error: "شماره تلفن الزامی است" };
  if (!/^09\d{9}$/.test(v)) {
    if (v.length < 11) return { valid: false, error: "شماره موبایل باید ۱۱ رقم باشد" };
    if (!v.startsWith("09")) return { valid: false, error: "شماره موبایل باید با ۰۹ شروع شود" };
    return { valid: false, error: "فرمت شماره موبایل صحیح نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹)" };
  }
  return { valid: true };
}

/** Validate landline phone (021-12345678) - more lenient */
export function validateLandline(value: string): { valid: boolean; error?: string } {
  const v = toEnglishDigits(value).replace(/[\s\-()]/g, "");
  if (!v) return { valid: false, error: "شماره تلفن الزامی است" };
  if (!/^0\d{10}$/.test(v)) {
    if (v.length < 11) return { valid: false, error: "شماره تلفن باید ۱۱ رقم باشد" };
    if (!v.startsWith("0")) return { valid: false, error: "شماره تلفن باید با ۰ شروع شود" };
    return { valid: false, error: "فرمت شماره تلفن صحیح نیست" };
  }
  return { valid: true };
}

/** Validate Iranian IBAN (شماره شبا) - IR + 24 digits */
export function validateIban(value: string): { valid: boolean; error?: string } {
  const v = toEnglishDigits(value).replace(/[\s\-]/g, "").toUpperCase();
  if (!v) return { valid: true }; // optional
  if (!/^IR\d{24}$/.test(v)) {
    if (!v.startsWith("IR")) return { valid: false, error: "شماره شبا باید با IR شروع شود" };
    if (v.length < 26) return { valid: false, error: `شماره شبا باید ۲۴ رقم پس از IR داشته باشد (الان ${v.length - 2} رقم)` };
    return { valid: false, error: "فرمت شماره شبا صحیح نیست" };
  }
  return { valid: true };
}

/** Validate Iranian postal code - 10 digits */
export function validatePostalCode(value: string): { valid: boolean; error?: string } {
  const v = toEnglishDigits(value).replace(/[\s\-]/g, "");
  if (!v) return { valid: true }; // optional
  if (!/^\d{10}$/.test(v)) {
    if (v.length < 10) return { valid: false, error: "کد پستی باید ۱۰ رقم باشد" };
    return { valid: false, error: "کد پستی فقط باید شامل ارقام باشد" };
  }
  return { valid: true };
}

function getValidator(type: ValidatorType) {
  switch (type) {
    case "nationalId": return validateNationalId;
    case "companyNationalId": return validateCompanyNationalId;
    case "phone": return validatePhone;
    case "iban": return validateIban;
    case "postalCode": return validatePostalCode;
    case "number": return (v: string) => ({ valid: true, error: undefined });
  }
}

function getMaxLength(type: ValidatorType): number | undefined {
  switch (type) {
    case "nationalId": return 10;
    case "companyNationalId": return 11;
    case "phone": return 11;
    case "iban": return 26;
    case "postalCode": return 10;
    case "number": return undefined;
  }
}

function getPlaceholder(type: ValidatorType): string {
  switch (type) {
    case "nationalId": return "۰۰۱۲۳۴۵۶۷۸";
    case "companyNationalId": return "۱۴۰۰۱۲۳۴۵۶۷";
    case "phone": return "۰۹۱۲۳۴۵۶۷۸۹";
    case "iban": return "IR۸۲۰۱۷۰۰۰۰۰۰۰۰۰۱۱۲۳۴۵۶۷۸۹";
    case "postalCode": return "۱۲۳۴۵۶۷۸۹۰";
    case "number": return "";
  }
}

export function ValidatedInput({
  type,
  value,
  onChange,
  label,
  placeholder,
  className,
  dir = "ltr",
  disabled,
  required,
  showError = true,
}: ValidatedInputProps) {
  const [touched, setTouched] = useState(false);
  const [inputValue, setInputValue] = useState(value);

  // Sync external value changes
  useEffect(() => {
    setInputValue(value);
  }, [value]);

  const validator = getValidator(type);
  const maxLength = getMaxLength(type);
  const defaultPlaceholder = placeholder ?? getPlaceholder(type);

  const validation = useMemo(() => validator(inputValue), [inputValue, validator]);
  const showValidation = touched && inputValue.length > 0;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let v = e.target.value;
    // Convert Persian/Arabic digits to English for validation
    v = toEnglishDigits(v);
    // Remove non-digit chars for digit-only fields (except IBAN which can have IR prefix)
    if (type === "iban") {
      v = v.toUpperCase().replace(/[^0-9A-Z]/g, "");
    } else {
      v = v.replace(/[^\d]/g, "");
    }
    // Enforce max length
    if (maxLength && v.length > maxLength) {
      v = v.slice(0, maxLength);
    }
    setInputValue(v);
    onChange(v);
  };

  const handleBlur = () => {
    setTouched(true);
  };

  return (
    <div className="space-y-1">
      {label && (
        <Label className="text-xs flex items-center gap-1">
          {label}
          {required && <span className="text-destructive">*</span>}
        </Label>
      )}
      <div className="relative">
        <Input
          value={inputValue}
          onChange={handleChange}
          onBlur={handleBlur}
          placeholder={defaultPlaceholder}
          className={cn(
            "font-mono",
            type === "iban" && "text-xs",
            showValidation && !validation.valid && "border-destructive focus-visible:border-destructive",
            showValidation && validation.valid && "border-success focus-visible:border-success",
            className
          )}
          dir={dir}
          disabled={disabled}
          inputMode={type === "iban" ? "text" : "numeric"}
          autoComplete="off"
        />
        {showValidation && (
          <div className="absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none">
            {validation.valid ? (
              <CheckCircle2 className="size-4 text-success" />
            ) : (
              <AlertCircle className="size-4 text-destructive" />
            )}
          </div>
        )}
      </div>
      {showError && showValidation && !validation.valid && (
        <p className="text-[11px] text-destructive flex items-center gap-1">
          <AlertCircle className="size-3" />
          {validation.error}
        </p>
      )}
      {showError && (!touched || inputValue.length === 0) && (
        <p className="text-[10px] text-muted-foreground">
          {type === "nationalId" && "کدملی ۱۰ رقمی"}
          {type === "companyNationalId" && "شناسه ملی شرکت ۱۱ رقمی"}
          {type === "phone" && "موبایل با ۰۹ شروع می‌شود"}
          {type === "iban" && "با IR شروع و ۲۴ رقم"}
          {type === "postalCode" && "کد پستی ۱۰ رقمی"}
          {maxLength && ` (حداکثر ${maxLength.toLocaleString("fa-IR")} رقم)`}
        </p>
      )}
    </div>
  );
}

/** Hook for bulk validation of multiple fields */
export function useFieldValidation() {
  return {
    validateNationalId,
    validateCompanyNationalId,
    validatePhone,
    validateLandline,
    validateIban,
    validatePostalCode,
  };
}
