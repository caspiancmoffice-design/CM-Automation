// app-shell.tsx — Main application shell
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { Sidebar } from "./sidebar";
import { Header } from "./header";
import { DashboardView } from "./views/dashboard-view";
import { ProjectsView } from "./views/projects-view";
import { ProjectDetailsView } from "./views/project-details-view";
import { TasksView } from "./views/tasks-view";
import { TaskDetailsView } from "./views/task-details-view";
import { DocumentsView } from "./views/documents-view";
import { CorrespondenceView } from "./views/correspondence-view";
import { ContractsView } from "./views/contracts-view";
import { ContractDetailsView } from "./views/contract-details-view";
import { ContractNewView } from "./views/contract-new-view";
import { ProcurementView } from "./views/procurement-view";
import { ProcurementDetailsView } from "./views/procurement-details-view";
import { ProcurementNewView } from "./views/procurement-new-view";
import { VendorsView } from "./views/vendors-view";
import { ReportsView } from "./views/reports-view";
import { ProfileView } from "./views/profile-view";
import { UsersView } from "./views/users-view";
import { NotificationsView } from "./views/notifications-view";
import { SearchView } from "./views/search-view";
import { SettingsView } from "./views/settings-view";
import { cn } from "@/lib/utils";

export function AppShell() {
  const { view } = useNav();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:block w-64 shrink-0">
        <Sidebar />
      </div>

      {/* Mobile sidebar overlay */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <div className="absolute top-0 right-0 bottom-0 w-72 max-w-[85vw] shadow-2xl">
            <Sidebar onItemClick={() => setMobileSidebarOpen(false)} />
          </div>
        </div>
      )}

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header onMenuClick={() => setMobileSidebarOpen(true)} />
        <main
          className={cn(
            "flex-1 overflow-y-auto",
            "px-4 py-6 lg:px-8 lg:py-8"
          )}
        >
          <div className="mx-auto max-w-7xl">
            {view === "dashboard" && <DashboardView />}
            {view === "projects" && <ProjectsView />}
            {view === "project-details" && <ProjectDetailsView />}
            {view === "tasks" && <TasksView />}
            {view === "task-details" && <TaskDetailsView />}
            {view === "documents" && <DocumentsView />}
            {view === "correspondence" && <CorrespondenceView />}
            {view === "contracts" && <ContractsView />}
            {view === "contract-details" && <ContractDetailsView />}
            {view === "contract-new" && <ContractNewView />}
            {view === "procurement" && <ProcurementView />}
            {view === "procurement-details" && <ProcurementDetailsView />}
            {view === "procurement-new" && <ProcurementNewView />}
            {view === "vendors" && <VendorsView />}
            {view === "reports" && <ReportsView />}
            {view === "profile" && <ProfileView />}
            {view === "users" && <UsersView />}
            {view === "notifications" && <NotificationsView />}
            {view === "search" && <SearchView />}
            {view === "settings" && <SettingsView />}
          </div>
        </main>
      </div>
    </div>
  );
}
