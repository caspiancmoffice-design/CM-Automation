// header.tsx — Top bar with search, notifications, theme toggle, profile
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Bell,
  Search,
  Menu,
  Sun,
  Moon,
  ChevronLeft,
  HelpCircle,
} from "lucide-react";
import { UserAvatar } from "./user-avatar";
import { currentUser, notifications as allNotifications } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";

// Page title mapping
const viewTitles: Record<string, string> = {
  dashboard: "داشبورد",
  projects: "پروژه‌ها",
  "project-details": "جزئیات پروژه",
  tasks: "مدیریت وظایف",
  "task-details": "جزئیات وظیفه",
  documents: "مدیریت اسناد",
  correspondence: "مکاتبات",
  contracts: "مدیریت قراردادها",
  "contract-details": "جزئیات قرارداد",
  "contract-new": "ایجاد قرارداد جدید",
  procurement: "مدیریت تدارکات",
  "procurement-details": "جزئیات درخواست خرید",
  "procurement-new": "درخواست خرید جدید",
  vendors: "تأمین‌کنندگان",
  reports: "گزارش‌ها",
  notifications: "اعلان‌ها",
  search: "جستجو",
  profile: "پروفایل کاربر",
  users: "کاربران و نقش‌ها",
  settings: "تنظیمات",
};

function getInitialDarkMode(): boolean {
  if (typeof document === "undefined") return false;
  return document.documentElement.classList.contains("dark");
}

export function Header({ onMenuClick }: { onMenuClick?: () => void }) {
  const { view, navigate, goBack, canGoBack } = useNav();
  const [searchValue, setSearchValue] = useState("");
  // Initialize from DOM at first render (avoids setState-in-effect lint)
  const [isDark, setIsDark] = useState(getInitialDarkMode);

  const toggleTheme = () => {
    const newIsDark = !isDark;
    setIsDark(newIsDark);
    if (typeof document !== "undefined") {
      document.documentElement.classList.toggle("dark", newIsDark);
    }
  };

  const onSubmitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchValue.trim()) {
      navigate("search");
    }
  };

  const unreadCount = allNotifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-30 glass border-b border-border/60">
      <div className="flex h-16 items-center gap-3 px-4 lg:px-6">
        {/* Mobile menu */}
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden"
          onClick={onMenuClick}
        >
          <Menu className="size-5" />
        </Button>

        {/* Back button */}
        {canGoBack && (
          <Button
            variant="ghost"
            size="icon"
            onClick={goBack}
            className="text-muted-foreground hover:text-foreground"
            title="بازگشت"
          >
            <ChevronLeft className="size-5 rotate-180" />
          </Button>
        )}

        {/* Page title */}
        <div className="hidden sm:block min-w-0">
          <h2 className="text-base font-semibold truncate">
            {viewTitles[view] ?? "صفحه"}
          </h2>
        </div>

        {/* Search */}
        <form
          onSubmit={onSubmitSearch}
          className="flex-1 max-w-md mx-auto sm:mx-4"
        >
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
            <Input
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="جستجو در پروژه‌ها، وظایف، اسناد..."
              className="pr-9 pl-3 h-9 bg-muted/50 border-transparent focus-visible:bg-background focus-visible:border-input"
            />
          </div>
        </form>

        <div className="flex items-center gap-1">
          {/* Theme toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            title={isDark ? "حالت روشن" : "حالت تاریک"}
            className="text-muted-foreground"
          >
            {isDark ? <Sun className="size-5" /> : <Moon className="size-5" />}
          </Button>

          {/* Help */}
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hidden sm:inline-flex"
            title="راهنما"
          >
            <HelpCircle className="size-5" />
          </Button>

          {/* Notifications */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative text-muted-foreground"
                title="اعلان‌ها"
              >
                <Bell className="size-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 size-2 rounded-full bg-destructive ring-2 ring-background" />
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent
              align="end"
              className="w-80 p-0"
              sideOffset={8}
            >
              <div className="flex items-center justify-between px-4 py-3 border-b">
                <p className="font-semibold text-sm">اعلان‌های اخیر</p>
                <button
                  className="text-xs text-primary hover:underline"
                  onClick={() => navigate("notifications")}
                >
                  مشاهده همه
                </button>
              </div>
              <ScrollArea className="max-h-80">
                <ul className="divide-y">
                  {allNotifications.slice(0, 5).map((n) => (
                    <li key={n.id}>
                      <button
                        onClick={() => n.link && navigate(n.link.view, n.link.id)}
                        className={cn(
                          "w-full text-right p-3 hover:bg-accent/50 transition-colors flex gap-3",
                          !n.read && "bg-primary/5"
                        )}
                      >
                        <span
                          className={cn(
                            "size-2 rounded-full mt-1.5 shrink-0",
                            n.read ? "bg-muted-foreground/30" : "bg-primary"
                          )}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold truncate">{n.title}</p>
                          <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                            {n.message}
                          </p>
                          <p className="text-[10px] text-muted-foreground/70 mt-1">
                            {n.timestamp}
                          </p>
                        </div>
                      </button>
                    </li>
                  ))}
                </ul>
              </ScrollArea>
            </PopoverContent>
          </Popover>

          {/* Profile dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 rounded-full p-1 pr-2 hover:bg-accent transition-colors">
                <UserAvatar name={currentUser.name} size="sm" />
                <div className="hidden md:block text-right leading-tight">
                  <p className="text-xs font-semibold max-w-32 truncate">{currentUser.name}</p>
                  <p className="text-[10px] text-muted-foreground">مدیر پروژه</p>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="text-xs text-muted-foreground">
                <div className="flex flex-col gap-0.5">
                  <span className="font-semibold text-foreground text-sm">{currentUser.name}</span>
                  <span className="text-[11px]">{currentUser.email}</span>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate("profile")}>
                پروفایل من
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate("settings")}>
                تنظیمات حساب
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => navigate("login")}
                className="text-destructive focus:text-destructive"
              >
                خروج از حساب
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
