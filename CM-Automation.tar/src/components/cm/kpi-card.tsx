// kpi-card.tsx — KPI card for dashboard
"use client";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowUpRight, ArrowDownRight, Minus } from "lucide-react";
import { cn } from "@/lib/utils";
import { faNum } from "@/lib/fa-utils";

export interface KPICardProps {
  label: string;
  value: number | string;
  unit?: string;
  change?: number;
  trend?: "up" | "down" | "flat";
  icon?: React.ComponentType<{ className?: string }>;
  accent?: "primary" | "success" | "warning" | "info" | "destructive";
  formatNumber?: boolean;
}

const accentClasses = {
  primary: "bg-primary/10 text-primary",
  success: "bg-success/15 text-success",
  warning: "bg-warning/15 text-warning-foreground",
  info: "bg-info/15 text-info",
  destructive: "bg-destructive/10 text-destructive",
};

export function KPICard({
  label,
  value,
  unit,
  change,
  trend,
  icon: Icon,
  accent = "primary",
  formatNumber = false,
}: KPICardProps) {
  const displayValue = formatNumber && typeof value === "number" ? faNum(value) : value;
  const TrendIcon = trend === "up" ? ArrowUpRight : trend === "down" ? ArrowDownRight : Minus;
  const trendColor =
    trend === "up"
      ? "text-success"
      : trend === "down"
      ? "text-destructive"
      : "text-muted-foreground";

  return (
    <Card className="overflow-hidden border-border/60 hover:shadow-md transition-shadow">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1 min-w-0">
            <p className="text-sm text-muted-foreground truncate">{label}</p>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-bold tracking-tight">{displayValue}</span>
              {unit && <span className="text-xs text-muted-foreground">{unit}</span>}
            </div>
          </div>
          {Icon && (
            <div className={cn("size-10 rounded-lg flex items-center justify-center shrink-0", accentClasses[accent])}>
              <Icon className="size-5" />
            </div>
          )}
        </div>
        {typeof change === "number" && (
          <div className="flex items-center gap-1.5 mt-3 text-xs">
            <span className={cn("flex items-center gap-0.5 font-medium", trendColor)}>
              <TrendIcon className="size-3" />
              {Math.abs(change).toLocaleString("fa-IR")}٪
            </span>
            <span className="text-muted-foreground">نسبت به ماه قبل</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
