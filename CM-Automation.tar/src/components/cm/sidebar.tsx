// sidebar.tsx — Main app sidebar (RTL: positioned on right)
"use client";
import { navGroups } from "@/lib/nav-config";
import { useNav } from "@/lib/nav-context";
import { cn } from "@/lib/utils";
import { Building2, LogOut, ChevronLeft } from "lucide-react";
import { faNum } from "@/lib/fa-utils";
import { Button } from "@/components/ui/button";

export function Sidebar({ onItemClick }: { onItemClick?: () => void }) {
  const { view, navigate } = useNav();

  return (
    <aside className="flex h-full flex-col bg-sidebar text-sidebar-foreground overflow-hidden">
      {/* Brand */}
      <div className="flex items-center gap-3 px-5 h-16 border-b border-sidebar-border shrink-0">
        <div className="size-10 rounded-lg bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-md">
          <Building2 className="size-5 text-primary-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-sm font-bold tracking-tight leading-tight">CM Automation</h1>
          <p className="text-[10px] text-sidebar-foreground/60 leading-tight">سامانه مدیریت ساخت</p>
        </div>
      </div>

      {/* Navigation - scrollable */}
      <nav className="flex-1 overflow-y-auto overflow-x-hidden px-3 py-4">
        <div className="space-y-6">
          {navGroups.map((group) => (
            <div key={group.title}>
              <p className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/40">
                {group.title}
              </p>
              <ul className="space-y-1">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const active = view === item.key;
                  return (
                    <li key={item.key}>
                      <button
                        onClick={() => {
                          navigate(item.key);
                          onItemClick?.();
                        }}
                        className={cn(
                          "group w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                          "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                          active
                            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
                            : "text-sidebar-foreground/80"
                        )}
                      >
                        <Icon className={cn("size-4.5 shrink-0", active ? "" : "opacity-80 group-hover:opacity-100")} />
                        <span className="flex-1 text-right truncate">{item.label}</span>
                        {item.badge ? (
                          <span
                            className={cn(
                              "min-w-5 h-5 px-1.5 inline-flex items-center justify-center rounded-full text-[10px] font-bold",
                              active
                                ? "bg-sidebar-primary-foreground/20 text-sidebar-primary-foreground"
                                : "bg-sidebar-accent text-sidebar-accent-foreground"
                            )}
                          >
                            {faNum(item.badge)}
                          </span>
                        ) : null}
                        {active && (
                          <ChevronLeft className="size-3.5 text-sidebar-primary-foreground/70" />
                        )}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </div>
      </nav>

      {/* Footer */}
      <div className="border-t border-sidebar-border p-3 shrink-0">
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
          onClick={() => navigate("login")}
        >
          <LogOut className="size-4" />
          <span>خروج از حساب</span>
        </Button>
      </div>
    </aside>
  );
}
