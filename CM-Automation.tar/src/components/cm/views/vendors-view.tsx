// vendors-view.tsx — Vendors/suppliers directory
"use client";
import { useState, useMemo } from "react";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { EntityFormModal, type FormField } from "../entity-form-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Truck,
  Plus,
  Search,
  Phone,
  Mail,
  MapPin,
  User,
  Star,
  Package,
  CreditCard,
} from "lucide-react";
import { vendors as allVendors } from "@/lib/procurement-mock-data";
import { faNum, faCurrency } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";

export function VendorsView() {
  const [search, setSearch] = useState("");
  const [tagFilter, setTagFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);

  const allTags = useMemo(() => {
    const tags = new Set<string>();
    allVendors.forEach((v) => v.tags?.forEach((t) => tags.add(t)));
    return Array.from(tags);
  }, []);

  const filtered = useMemo(() => {
    return allVendors.filter((v) => {
      const matchSearch =
        !search ||
        v.name.includes(search) ||
        v.contactPerson?.includes(search) ||
        v.phone?.includes(search);
      const matchTag = tagFilter === "all" || v.tags?.includes(tagFilter);
      return matchSearch && matchTag;
    });
  }, [search, tagFilter]);

  const vendorFormFields: FormField[] = [
    { name: "name", label: "نام وندور", type: "text", placeholder: "مثال: شرکت تأمین فولاد", required: true, colSpan: 2 },
    {
      name: "type",
      label: "نوع شخص",
      type: "select",
      required: true,
      defaultValue: "company",
      options: [
        { value: "company", label: "حقوقی" },
        { value: "person", label: "حقیقی" },
      ],
    },
    {
      name: "rating",
      label: "امتیاز",
      type: "select",
      defaultValue: "4",
      options: [
        { value: "5", label: "★★★★★ عالی" },
        { value: "4", label: "★★★★☆ خوب" },
        { value: "3", label: "★★★☆☆ متوسط" },
        { value: "2", label: "★★☆☆☆ ضعیف" },
        { value: "1", label: "★☆☆☆☆ بد" },
      ],
    },
    { name: "nationalId", label: "شناسه ملی / کدملی", type: "text", placeholder: "۱۴۰۰..." },
    { name: "phone", label: "تلفن", type: "text", placeholder: "021-..." },
    { name: "contactPerson", label: "نماینده", type: "text", placeholder: "نام شخص رابط" },
    { name: "email", label: "ایمیل", type: "text", placeholder: "info@..." },
    { name: "iban", label: "شماره شبا", type: "text", placeholder: "IR..." },
    { name: "address", label: "نشانی", type: "textarea", placeholder: "آدرس کامل...", colSpan: 2 },
    { name: "tags", label: "تگ‌ها (با کام جدا کنید)", type: "text", placeholder: "فولاد، میلگرد، ورق", colSpan: 2 },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="تأمین‌کنندگان (وندورها)"
        subtitle={`${faNum(allVendors.length)} وندور ثبت‌شده`}
        icon={Truck}
        actions={
          <Button size="sm" onClick={() => setModalOpen(true)}>
            <Plus className="size-4" />
            وندور جدید
          </Button>
        }
      />

      <EntityFormModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        title="افزودن وندور جدید"
        description="وندور/تأمین‌کننده جدید را ثبت کنید"
        icon={<Truck className="size-5 text-primary" />}
        fields={vendorFormFields}
        submitLabel="افزودن وندور"
        size="lg"
        onSubmit={async (data) => {
          console.log("New vendor:", data);
        }}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "کل وندورها", value: faNum(allVendors.length), icon: Truck, color: "text-primary" },
          { label: "حقوقی", value: faNum(allVendors.filter(v => v.type === "company").length), icon: Truck, color: "text-info" },
          { label: "حقیقی", value: faNum(allVendors.filter(v => v.type === "person").length), icon: User, color: "text-success" },
          { label: "میانگین امتیاز", value: `${faNum(Math.round((allVendors.reduce((a, v) => a + (v.rating ?? 0), 0) / allVendors.length) * 10) / 10)} ★`, icon: Star, color: "text-amber-500" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-bold mt-1">{stat.value}</p>
                </div>
                <stat.icon className={cn("size-5", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجوی وندور..."
                className="pr-9"
              />
            </div>
            <Select value={tagFilter} onValueChange={setTagFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="تگ" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه تگ‌ها</SelectItem>
                {allTags.map((t) => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Vendors grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((vendor) => (
          <Card key={vendor.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-5 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <div className="size-11 rounded-lg bg-info/10 text-info flex items-center justify-center shrink-0">
                    <Truck className="size-5" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-sm truncate">{vendor.name}</h3>
                    <p className="text-[11px] text-muted-foreground">
                      {vendor.type === "company" ? "شخص حقوقی" : "شخص حقیقی"}
                    </p>
                  </div>
                </div>
                {vendor.rating && (
                  <div className="flex items-center gap-0.5 shrink-0">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={cn(
                          "size-3",
                          i < vendor.rating! ? "fill-amber-500 text-amber-500" : "text-muted-foreground/30"
                        )}
                      />
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2 text-xs">
                {vendor.contactPerson && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <User className="size-3 shrink-0" />
                    <span className="truncate">{vendor.contactPerson}</span>
                  </div>
                )}
                {vendor.phone && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="size-3 shrink-0" />
                    <span className="font-mono" dir="ltr">{vendor.phone}</span>
                  </div>
                )}
                {vendor.email && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="size-3 shrink-0" />
                    <span className="font-mono truncate text-[10px]" dir="ltr">{vendor.email}</span>
                  </div>
                )}
                {vendor.address && (
                  <div className="flex items-start gap-2 text-muted-foreground">
                    <MapPin className="size-3 shrink-0 mt-0.5" />
                    <span className="leading-snug line-clamp-2">{vendor.address}</span>
                  </div>
                )}
              </div>

              {vendor.tags && vendor.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 pt-2 border-t border-border/60">
                  {vendor.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}

              <div className="flex items-center justify-between pt-2 border-t border-border/60 text-xs">
                <div className="flex items-center gap-1">
                  <Package className="size-3 text-muted-foreground" />
                  <span className="text-muted-foreground">سفارش‌های قبلی:</span>
                  <span className="font-semibold">{faNum(vendor.previousOrders ?? 0)}</span>
                </div>
                {vendor.iban && (
                  <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                    <CreditCard className="size-3" />
                    <span className="font-mono">IBAN</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <Truck className="size-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">وندوری مطابق با جستجو یافت نشد.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
