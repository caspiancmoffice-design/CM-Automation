// contracts-view.tsx — Contracts list with filters and card/table toggle
"use client";
import { useState, useMemo } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { getContractIcon, getContractColor } from "../contract-icon";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ScrollText,
  Plus,
  LayoutGrid,
  List,
  Search,
  Calendar,
  Wallet,
  Building2,
  User as UserIcon,
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileText,
} from "lucide-react";
import { mockContracts } from "@/lib/contract-mock-data";
import { contractTemplates, contractTypeLabels, contractStatusLabels, contractCategoryLabels } from "@/lib/contract-templates";
import { faNum, faCurrency } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";

export function ContractsView() {
  const { navigate } = useNav();
  const [view, setView] = useState<"grid" | "table">("grid");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const filtered = useMemo(() => {
    return mockContracts.filter((c) => {
      const matchSearch =
        !search ||
        c.title.includes(search) ||
        c.number.includes(search) ||
        c.contractor.name.includes(search) ||
        c.projectName.includes(search);
      const matchStatus = statusFilter === "all" || c.status === statusFilter;
      const matchType = typeFilter === "all" || c.type === typeFilter;
      return matchSearch && matchStatus && matchType;
    });
  }, [search, statusFilter, typeFilter]);

  // Stats
  const totalValue = mockContracts.reduce((acc, c) => acc + c.financial.totalAmount, 0);
  const activeCount = mockContracts.filter((c) => c.status === "active").length;
  const draftCount = mockContracts.filter((c) => c.status === "draft" || c.status === "in_review").length;
  const completedCount = mockContracts.filter((c) => c.status === "completed").length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="مدیریت قراردادها"
        subtitle={`${faNum(mockContracts.length)} قرارداد پیمانکاری • ارزش کل: ${faCurrency(totalValue)}`}
        icon={ScrollText}
        actions={
          <Button size="sm" onClick={() => navigate("contract-new")}>
            <Plus className="size-4" />
            قرارداد جدید
          </Button>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "کل قراردادها", value: faNum(mockContracts.length), icon: ScrollText, color: "text-primary" },
          { label: "قراردادهای فعال", value: faNum(activeCount), icon: CheckCircle2, color: "text-success" },
          { label: "در حال بررسی/پیش‌نویس", value: faNum(draftCount), icon: Clock, color: "text-warning-foreground" },
          { label: "تکمیل شده", value: faNum(completedCount), icon: FileText, color: "text-info" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-bold mt-1">{stat.value}</p>
                </div>
                <stat.icon className={cn("size-5", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجو بر اساس عنوان، شماره، پیمانکار یا پروژه..."
                className="pr-9"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full lg:w-52">
                <SelectValue placeholder="نوع پیمانکار" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه انواع</SelectItem>
                {Object.entries(contractTypeLabels).map(([key, label]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full lg:w-40">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                {Object.entries(contractStatusLabels).map(([key, label]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Tabs value={view} onValueChange={(v) => setView(v as "grid" | "table")}>
              <TabsList className="grid grid-cols-2 w-full lg:w-auto">
                <TabsTrigger value="grid" className="gap-1.5">
                  <LayoutGrid className="size-3.5" />
                  <span className="hidden sm:inline">کارت</span>
                </TabsTrigger>
                <TabsTrigger value="table" className="gap-1.5">
                  <List className="size-3.5" />
                  <span className="hidden sm:inline">جدول</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      {/* Grid view */}
      {view === "grid" && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((contract) => {
            const Icon = getContractIcon(contractTemplates[contract.type].iconKey);
            return (
              <Card
                key={contract.id}
                className="overflow-hidden hover:shadow-lg hover:border-primary/30 transition-all cursor-pointer group"
                onClick={() => navigate("contract-details", contract.id)}
              >
                <div className="h-1.5 bg-gradient-to-l from-primary via-primary/70 to-chart-2" />
                <CardContent className="p-5 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <div className={cn("size-11 rounded-lg flex items-center justify-center shrink-0", getContractColor(contract.type))}>
                        <Icon className="size-5" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-semibold text-sm truncate group-hover:text-primary transition-colors">
                          {contract.title}
                        </h3>
                        <p className="text-[11px] text-muted-foreground font-mono">
                          {contract.number}
                        </p>
                      </div>
                    </div>
                    <StatusBadge status={contract.status} />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Building2 className="size-3 shrink-0" />
                      <span className="truncate">{contract.projectName}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <UserIcon className="size-3 shrink-0" />
                      <span className="truncate">{contract.contractor.name}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-border/60">
                    <div>
                      <p className="text-muted-foreground mb-0.5">مبلغ قرارداد</p>
                      <p className="font-bold text-primary">{faCurrency(contract.financial.totalAmount)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-0.5">مدت قرارداد</p>
                      <p className="font-medium flex items-center gap-1">
                        <Calendar className="size-3" />
                        {faNum(contract.duration.totalMonths)} ماه
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-0.5">پیش‌پرداخت</p>
                      <p className="font-medium">{faNum(contract.financial.prepaymentPercent)}٪</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-0.5">حسن انجام کار</p>
                      <p className="font-medium">{faNum(contract.financial.retentionPercent)}٪</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-border/60">
                    <div className="flex items-center gap-2">
                      <StatusBadge status={contract.category} label={contractCategoryLabels[contract.category]} />
                      <span className="text-[11px] text-muted-foreground">
                        {contractTypeLabels[contract.type]}
                      </span>
                    </div>
                    {contract.status === "active" && (
                      <span className="flex items-center gap-1 text-[11px] text-success">
                        <CheckCircle2 className="size-3" />
                        ابلاغ‌شده
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Table view */}
      {view === "table" && (
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs">
                  <tr className="text-right">
                    <th className="px-4 py-3 font-semibold text-muted-foreground">عنوان</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">شماره</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">پیمانکار</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">نوع</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">مبلغ</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">مدت</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">وضعیت</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">ابلاغ</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filtered.map((c) => {
                    const Icon = getContractIcon(contractTemplates[c.type].iconKey);
                    return (
                      <tr
                        key={c.id}
                        className="hover:bg-accent/30 cursor-pointer transition-colors"
                        onClick={() => navigate("contract-details", c.id)}
                      >
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className={cn("size-8 rounded-md flex items-center justify-center shrink-0", getContractColor(c.type))}>
                              <Icon className="size-4" />
                            </div>
                            <span className="font-medium truncate max-w-48">{c.title}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-xs text-muted-foreground font-mono">{c.number}</td>
                        <td className="px-4 py-3 text-xs">{c.contractor.name}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{contractTypeLabels[c.type]}</td>
                        <td className="px-4 py-3 text-xs font-medium">{faCurrency(c.financial.totalAmount)}</td>
                        <td className="px-4 py-3 text-xs">{faNum(c.duration.totalMonths)} ماه</td>
                        <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{c.issuedAt ?? "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <ScrollText className="size-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">قراردادی مطابق با فیلترهای انتخاب‌شده یافت نشد.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
