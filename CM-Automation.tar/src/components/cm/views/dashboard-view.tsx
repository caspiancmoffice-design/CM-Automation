// dashboard-view.tsx — Role-based dashboard with KPIs and charts
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { KPICard } from "../kpi-card";
import { UserAvatar } from "../user-avatar";
import { StatusBadge } from "../status-badge";
import { EntityFormModal, type FormField } from "../entity-form-modal";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  FolderKanban,
  ListTodo,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Plus,
  ArrowLeft,
  Clock,
  FileText,
  Mail,
  MessageSquare,
  CheckCheck,
  Settings as SettingsIcon,
} from "lucide-react";
import {
  activities,
  projects,
  tasks,
  productivityTrend,
  taskDistributionByStatus,
  taskDistributionByPriority,
  budgetUsageData,
  currentUser,
} from "@/lib/mock-data";
import { faNum, faCurrency, faLabels } from "@/lib/fa-utils";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts";

const taskFormFields: FormField[] = [
  { name: "title", label: "عنوان وظیفه", type: "text", placeholder: "مثال: بازبینی نقشه‌های فاز ۲", required: true, colSpan: 2 },
  {
    name: "project",
    label: "پروژه",
    type: "select",
    required: true,
    options: [
      { value: "p-1001", label: "برج مسکونی آرین" },
      { value: "p-1002", label: "مجتمع تجاری-اداری پاسارگاد" },
      { value: "p-1003", label: "بیمارستان تخصصی شفا" },
      { value: "p-1004", label: "ویلاهای لوکس هشتگرد" },
    ],
  },
  {
    name: "priority",
    label: "اولویت",
    type: "select",
    required: true,
    defaultValue: "medium",
    options: [
      { value: "low", label: "کم" },
      { value: "medium", label: "متوسط" },
      { value: "high", label: "بالا" },
      { value: "critical", label: "بحرانی" },
    ],
  },
  { name: "dueDate", label: "تاریخ سررسید", type: "date", required: true },
  {
    name: "assignees",
    label: "مسئولین وظیفه",
    type: "multiselect",
    required: true,
    colSpan: 2,
    helperText: "می‌توانید چند نفر را هم‌زمان انتخاب کنید. ایجادکننده وظیفه به‌صورت خودکار دسترسی مشاهده خواهد داشت.",
    options: [
      { value: "self", label: "خودم (ایجادکننده)" },
      { value: "u-002", label: "مهندس مریم احمدی - کارشناس دفتر فنی" },
      { value: "u-003", label: "مهندس علی محمودی - کارشناس اجرا" },
      { value: "u-004", label: "مهندس زهرا حسینی - کارشناس برق" },
      { value: "u-005", label: "مهندس حسین رضایی - کارشناس مکانیک" },
      { value: "u-006", label: "امیر صادقی - سرپرست کارگاه" },
    ],
  },
  { name: "description", label: "شرح وظیفه", type: "textarea", placeholder: "توضیحات کامل وظیفه...", colSpan: 2 },
];

const projectFormFields: FormField[] = [
  { name: "name", label: "نام پروژه", type: "text", placeholder: "مثال: برج مسکونی آرین", required: true, colSpan: 2 },
  { name: "code", label: "کد پروژه", type: "text", placeholder: "PA-1403-01", required: true },
  { name: "client", label: "کارفرما", type: "text", placeholder: "نام کارفرما", required: true },
  { name: "startDate", label: "تاریخ شروع", type: "date", placeholder: "1403/01/01", required: true },
  { name: "endDate", label: "تاریخ پایان", type: "date", placeholder: "1405/01/01", required: true },
  { name: "location", label: "محل پروژه", type: "text", placeholder: "آدرس پروژه", colSpan: 2 },
  { name: "description", label: "شرح پروژه", type: "textarea", placeholder: "توضیحات پروژه...", colSpan: 2 },
];

export function DashboardView() {
  const { navigate } = useNav();
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [projectModalOpen, setProjectModalOpen] = useState(false);

  // KPI calculations
  const activeProjects = projects.filter((p) => p.status === "active").length;
  const myOpenTasks = tasks.filter(
    (t) => t.status !== "done" && t.assignees.some((a) => a.userId === currentUser.id)
  ).length;
  const completedThisMonth = tasks.filter((t) => t.status === "done").length;
  const overdueTasks = tasks.filter(
    (t) => t.status !== "done" && t.assignees.some((a) => a.userId === currentUser.id)
  ).length; // mocked

  return (
    <div className="space-y-6">
      <PageHeader
        title={`خوش آمدید، ${currentUser.name}`}
        subtitle="نمای کلی فعالیت‌ها و عملکرد شما در سامانه CM Automation"
        icon={TrendingUp}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => setProjectModalOpen(true)}>
              <Plus className="size-4" />
              <span className="hidden sm:inline">پروژه جدید</span>
            </Button>
            <Button size="sm" onClick={() => setTaskModalOpen(true)}>
              <Plus className="size-4" />
              <span className="hidden sm:inline">وظیفه جدید</span>
            </Button>
          </>
        }
      />

      <EntityFormModal
        open={taskModalOpen}
        onOpenChange={setTaskModalOpen}
        title="ایجاد وظیفه جدید"
        description="فرم زیر را برای ایجاد وظیفه جدید تکمیل کنید"
        icon={<ListTodo className="size-5 text-primary" />}
        fields={taskFormFields}
        submitLabel="ایجاد وظیفه"
        size="lg"
        onSubmit={async (data) => {
          console.log("New task:", data);
        }}
      />

      <EntityFormModal
        open={projectModalOpen}
        onOpenChange={setProjectModalOpen}
        title="ایجاد پروژه جدید"
        description="فرم زیر را برای ایجاد پروژه جدید تکمیل کنید"
        icon={<FolderKanban className="size-5 text-primary" />}
        fields={projectFormFields}
        submitLabel="ایجاد پروژه"
        size="lg"
        onSubmit={async (data) => {
          console.log("New project:", data);
        }}
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          label="پروژه‌های فعال"
          value={faNum(activeProjects)}
          unit="پروژه"
          change={12}
          trend="up"
          icon={FolderKanban}
          accent="primary"
        />
        <KPICard
          label="وظایف باز من"
          value={faNum(myOpenTasks)}
          unit="وظیفه"
          change={-5}
          trend="down"
          icon={ListTodo}
          accent="info"
        />
        <KPICard
          label="انجام‌شده این ماه"
          value={faNum(completedThisMonth)}
          unit="وظیفه"
          change={18}
          trend="up"
          icon={CheckCircle2}
          accent="success"
        />
        <KPICard
          label="وظایف تأخیری"
          value={faNum(overdueTasks)}
          unit="وظیفه"
          change={-2}
          trend="down"
          icon={AlertTriangle}
          accent="destructive"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Productivity Trend */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-4">
            <div>
              <CardTitle className="text-base">روند بهره‌وری</CardTitle>
              <CardDescription className="text-xs mt-1">
                شاخص بهره‌وری ۷ ماه گذشته (درصد)
              </CardDescription>
            </div>
            <div className="text-left">
              <p className="text-2xl font-bold text-success">{faNum(87)}٪</p>
              <p className="text-[11px] text-muted-foreground">امتیاز فعلی</p>
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={productivityTrend} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="prodGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  reversed
                />
                <YAxis
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  orientation="right"
                  domain={[60, 100]}
                  tickFormatter={(v) => `${faNum(v)}٪`}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    direction: "rtl",
                  }}
                  formatter={(v: number) => [`${faNum(v)}٪`, "بهره‌وری"]}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="var(--chart-1)"
                  strokeWidth={2.5}
                  fill="url(#prodGrad)"
                  dot={{ r: 3, fill: "var(--chart-1)" }}
                  activeDot={{ r: 5 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Task distribution by status */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">توزیع وظایف</CardTitle>
            <CardDescription className="text-xs">بر اساس وضعیت</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie
                  data={taskDistributionByStatus}
                  dataKey="value"
                  nameKey="label"
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={75}
                  paddingAngle={2}
                  stroke="none"
                >
                  {taskDistributionByStatus.map((entry, idx) => (
                    <Cell key={idx} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    direction: "rtl",
                  }}
                  formatter={(v: number) => faNum(v)}
                />
              </PieChart>
            </ResponsiveContainer>
            <ul className="space-y-1.5 mt-2">
              {taskDistributionByStatus.map((item) => (
                <li
                  key={item.label}
                  className="flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="size-2.5 rounded-sm"
                      style={{ background: item.color }}
                    />
                    <span className="text-muted-foreground">{item.label}</span>
                  </div>
                  <span className="font-semibold">{faNum(item.value)}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Projects + Activity Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active projects */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle className="text-base">پروژه‌های فعال</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-primary"
              onClick={() => navigate("projects")}
            >
              مشاهده همه
              <ArrowLeft className="size-3.5 rotate-180" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {projects
              .filter((p) => p.status === "active" || p.status === "on_hold")
              .slice(0, 3)
              .map((project) => (
                <button
                  key={project.id}
                  onClick={() => navigate("project-details", project.id)}
                  className="w-full text-right p-4 rounded-lg border border-border/60 hover:border-primary/40 hover:bg-accent/30 transition-all group"
                >
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-sm truncate group-hover:text-primary transition-colors">
                          {project.name}
                        </h3>
                        <StatusBadge status={project.status} />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {project.code} • {project.client}
                      </p>
                    </div>
                    <span className="text-lg font-bold text-primary shrink-0">
                      {faNum(project.progress)}٪
                    </span>
                  </div>
                  <Progress value={project.progress} className="h-1.5 mb-3" />
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <Clock className="size-3" />
                        سررسید: {project.endDate}
                      </span>
                      <span className="flex items-center gap-1">
                        <ListTodo className="size-3" />
                        {faNum(project.openTasks)} وظیفه باز
                      </span>
                      {project.overdueTasks > 0 && (
                        <span className="flex items-center gap-1 text-destructive">
                          <AlertTriangle className="size-3" />
                          {faNum(project.overdueTasks)} تأخیر
                        </span>
                      )}
                    </div>
                    <span>{faCurrency(project.budget)}</span>
                  </div>
                </button>
              ))}
          </CardContent>
        </Card>

        {/* Recent activity */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">فعالیت‌های اخیر</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[340px]">
              <ul className="px-6 pb-6 space-y-4">
                {activities.map((a) => {
                  const Icon =
                    a.type === "task"
                      ? ListTodo
                      : a.type === "document"
                      ? FileText
                      : a.type === "correspondence"
                      ? Mail
                      : a.type === "comment"
                      ? MessageSquare
                      : a.type === "approval"
                      ? CheckCheck
                      : SettingsIcon;
                  return (
                    <li key={a.id} className="flex gap-3">
                      <div className="relative shrink-0">
                        <UserAvatar name={a.user} size="sm" />
                        <span className="absolute -bottom-1 -left-1 size-4 rounded-full bg-background flex items-center justify-center">
                          <Icon className="size-2.5 text-primary" />
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs leading-relaxed">
                          <span className="font-semibold">{a.user}</span>{" "}
                          <span className="text-muted-foreground">{a.action}</span>
                        </p>
                        <p className="text-[10px] text-muted-foreground/70 mt-0.5">
                          {a.timestamp}
                        </p>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Tasks + Priority Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* My tasks */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle className="text-base">وظایف من</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-primary"
              onClick={() => navigate("tasks")}
            >
              مشاهده همه
              <ArrowLeft className="size-3.5 rotate-180" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-2">
            {tasks
              .filter((t) => t.assignees.some((a) => a.userId === currentUser.id))
              .slice(0, 5)
              .map((task) => (
                <button
                  key={task.id}
                  onClick={() => navigate("task-details", task.id)}
                  className="w-full text-right p-3 rounded-lg border border-border/60 hover:border-primary/40 hover:bg-accent/30 transition-all group flex items-center gap-3"
                >
                  <div className="size-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <ListTodo className="size-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">
                      {task.title}
                    </p>
                    <p className="text-[11px] text-muted-foreground">
                      {task.projectName} • سررسید: {task.dueDate}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <StatusBadge status={task.priority} />
                    <StatusBadge status={task.status} />
                  </div>
                </button>
              ))}
          </CardContent>
        </Card>

        {/* Priority distribution */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">اولویت وظایف</CardTitle>
            <CardDescription className="text-xs">توزیع بر اساس اولویت</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart
                data={taskDistributionByPriority}
                layout="vertical"
                margin={{ top: 8, right: 8, left: 0, bottom: 8 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                <XAxis
                  type="number"
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => faNum(v)}
                  reversed
                />
                <YAxis
                  type="category"
                  dataKey="label"
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  width={50}
                  orientation="right"
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    direction: "rtl",
                  }}
                  formatter={(v: number) => faNum(v)}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {taskDistributionByPriority.map((entry, idx) => (
                    <Cell key={idx} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
