// correspondence-view.tsx — Correspondence management with timeline
"use client";
import { useState, useMemo } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { EntityFormModal, type FormField } from "../entity-form-modal";
import { CorrespondenceChainModal } from "../correspondence-chain-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Mail,
  Plus,
  Search,
  Inbox,
  Send,
  ArrowDownLeft,
  ArrowUpRight,
  Paperclip,
  Clock,
  Calendar,
  Building,
  Reply,
  Forward,
  Eye,
  GitBranch,
} from "lucide-react";
import { correspondences } from "@/lib/mock-data";
import { faNum, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Correspondence } from "@/lib/types";

export function CorrespondenceView() {
  const { navigate } = useNav();
  const [tab, setTab] = useState<"all" | "inbound" | "outbound">("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Correspondence | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [chainModalOpen, setChainModalOpen] = useState(false);
  const [attachmentModalOpen, setAttachmentModalOpen] = useState(false);
  const [forwardModalOpen, setForwardModalOpen] = useState(false);
  const [replyModalOpen, setReplyModalOpen] = useState(false);

  const letterFormFields: FormField[] = [
    { name: "subject", label: "موضوع نامه", type: "text", placeholder: "مثال: درخواست تأیید نقشه‌ها", required: true, colSpan: 2 },
    {
      name: "direction",
      label: "نوع نامه",
      type: "select",
      required: true,
      defaultValue: "outbound",
      options: [
        { value: "outbound", label: "صادره (ارسالی)" },
        { value: "inbound", label: "وارده (دریافتی)" },
      ],
    },
    {
      name: "project",
      label: "پروژه مربوطه",
      type: "select",
      options: [
        { value: "p-1001", label: "برج مسکونی آرین" },
        { value: "p-1002", label: "مجتمع تجاری-اداری پاسارگاد" },
        { value: "p-1003", label: "بیمارستان تخصصی شفا" },
        { value: "none", label: "بدون پروژه" },
      ],
    },
    { name: "from", label: "فرستنده", type: "text", placeholder: "نام فرستنده", required: true },
    { name: "to", label: "گیرنده", type: "text", placeholder: "نام گیرنده", required: true },
    { name: "date", label: "تاریخ", type: "date", placeholder: "1403/10/01", required: true },
    {
      name: "priority",
      label: "اولویت",
      type: "select",
      defaultValue: "medium",
      options: [
        { value: "low", label: "کم" },
        { value: "medium", label: "متوسط" },
        { value: "high", label: "بالا" },
        { value: "critical", label: "بحرانی" },
      ],
    },
    { name: "body", label: "متن نامه", type: "textarea", placeholder: "متن کامل نامه...", colSpan: 2 },
  ];

  const filtered = useMemo(() => {
    return correspondences.filter((c) => {
      const matchTab = tab === "all" || c.direction === tab;
      const matchSearch =
        !search ||
        c.subject.includes(search) ||
        c.number.includes(search) ||
        c.from.includes(search) ||
        c.to.includes(search);
      return matchTab && matchSearch;
    });
  }, [tab, search]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="مکاتبات"
        subtitle={`${faNum(correspondences.length)} نامه • مدیریت مکاتبات وارده و صادره`}
        icon={Mail}
        actions={
          <Button size="sm" onClick={() => setModalOpen(true)}>
            <Plus className="size-4" />
            نامه جدید
          </Button>
        }
      />

      <EntityFormModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        title="ایجاد نامه جدید"
        description="فرم زیر را برای ثبت نامه جدید تکمیل کنید"
        icon={<Mail className="size-5 text-primary" />}
        fields={letterFormFields}
        submitLabel="ثبت نامه"
        size="lg"
        onSubmit={async (data) => {
          console.log("New letter:", data);
        }}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "وارده", value: faNum(correspondences.filter(c => c.direction === "inbound").length), icon: Inbox, color: "text-success" },
          { label: "صادره", value: faNum(correspondences.filter(c => c.direction === "outbound").length), icon: Send, color: "text-info" },
          { label: "پاسخ داده شده", value: faNum(correspondences.filter(c => c.status === "answered").length), icon: Reply, color: "text-primary" },
          { label: "در انتظار", value: faNum(correspondences.filter(c => c.status === "in_review" || c.status === "sent").length), icon: Clock, color: "text-warning-foreground" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-bold mt-1">{stat.value}</p>
                </div>
                <stat.icon className={cn("size-5", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs + Search */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
              <TabsList className="grid grid-cols-3 w-full sm:w-auto">
                <TabsTrigger value="all" className="gap-1.5">
                  <Mail className="size-3.5" />
                  همه
                </TabsTrigger>
                <TabsTrigger value="inbound" className="gap-1.5">
                  <Inbox className="size-3.5" />
                  وارده
                </TabsTrigger>
                <TabsTrigger value="outbound" className="gap-1.5">
                  <Send className="size-3.5" />
                  صادره
                </TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجو در موضوع، شماره یا طرف..."
                className="pr-9"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Correspondence list */}
      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <ul className="divide-y">
            {filtered.map((c) => (
              <li key={c.id}>
                <button
                  onClick={() => setSelected(c)}
                  className="w-full text-right p-4 hover:bg-accent/30 transition-colors flex items-start gap-3"
                >
                  <div className={cn(
                    "size-10 rounded-lg flex items-center justify-center shrink-0",
                    c.direction === "inbound" ? "bg-success/10 text-success" : "bg-info/10 text-info"
                  )}>
                    {c.direction === "inbound" ? <ArrowDownLeft className="size-5" /> : <ArrowUpRight className="size-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <p className="text-sm font-semibold truncate">{c.subject}</p>
                      <span className="text-[11px] text-muted-foreground shrink-0">{c.date}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-muted-foreground mb-2">
                      <span className="font-mono">{c.number}</span>
                      <span>•</span>
                      <span>{c.from} ← {c.to}</span>
                      {c.attachments > 0 && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-0.5">
                            <Paperclip className="size-3" />
                            {faNum(c.attachments)}
                          </span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge status={c.direction} />
                      <StatusBadge status={c.status} />
                      <StatusBadge status={c.priority} />
                      {c.projectName && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate("project-details", c.projectId);
                          }}
                          className="text-[11px] text-primary hover:underline truncate"
                        >
                          {c.projectName}
                        </button>
                      )}
                    </div>
                  </div>
                </button>
              </li>
            ))}
            {filtered.length === 0 && (
              <li className="text-center py-12 text-muted-foreground text-sm">
                <Mail className="size-10 mx-auto mb-2 opacity-30" />
                مکاتبه‌ای یافت نشد.
              </li>
            )}
          </ul>
        </CardContent>
      </Card>

      {/* Detail dialog */}
      {selected && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelected(null)}
        >
          <Card
            className="w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <CardContent className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-start justify-between gap-3 p-5 border-b">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <div className={cn(
                    "size-10 rounded-lg flex items-center justify-center shrink-0",
                    selected.direction === "inbound" ? "bg-success/10 text-success" : "bg-info/10 text-info"
                  )}>
                    {selected.direction === "inbound" ? <ArrowDownLeft className="size-5" /> : <ArrowUpRight className="size-5" />}
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-sm">{selected.subject}</h3>
                    <p className="text-[11px] text-muted-foreground font-mono mt-0.5">{selected.number}</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setSelected(null)} className="size-7 shrink-0">
                  ✕
                </Button>
              </div>

              {/* Metadata */}
              <div className="grid grid-cols-2 gap-3 p-5 border-b text-sm">
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">{selected.direction === "inbound" ? "فرستنده" : "گیرنده"}</p>
                  <p className="font-medium flex items-center gap-1.5">
                    <Building className="size-3.5 text-muted-foreground" />
                    {selected.direction === "inbound" ? selected.from : selected.to}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">تاریخ</p>
                  <p className="font-medium flex items-center gap-1.5">
                    <Calendar className="size-3.5 text-muted-foreground" />
                    {selected.date}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">دسته</p>
                  <p className="font-medium">{selected.category}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">پیوست‌ها</p>
                  <p className="font-medium">{faNum(selected.attachments)} فایل</p>
                </div>
              </div>

              {/* Body */}
              <div className="flex-1 overflow-y-auto p-5">
                <p className="text-sm leading-loose whitespace-pre-line text-foreground/90">{selected.body}</p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 p-4 border-t flex-wrap">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    if (selected.attachments === 0) {
                      toast.info("این مکاتبه پیوست ندارد");
                    } else {
                      setAttachmentModalOpen(true);
                    }
                  }}
                >
                  <Eye className="size-4" />
                  مشاهده پیوست
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setForwardModalOpen(true)}
                >
                  <Forward className="size-4" />
                  ارجاع
                </Button>
                <Button size="sm" variant="outline" onClick={() => setChainModalOpen(true)}>
                  <GitBranch className="size-4" />
                  زنجیره مکاتبات
                </Button>
                <Button
                  size="sm"
                  className="mr-auto"
                  onClick={() => setReplyModalOpen(true)}
                >
                  <Reply className="size-4" />
                  پاسخ
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Attachment modal */}
      {selected && (
        <EntityFormModal
          open={attachmentModalOpen}
          onOpenChange={setAttachmentModalOpen}
          title="پیوست‌های مکاتبه"
          description={`${selected.number} - ${selected.subject}`}
          icon={<Eye className="size-5 text-primary" />}
          fields={[
            { name: "attachment", label: "انتخاب فایل پیوست", type: "text", placeholder: "فایل‌های پیوست این مکاتبه در اینجا نمایش داده می‌شوند", colSpan: 2 },
          ]}
          submitLabel="دانلود پیوست"
          onSubmit={async () => {
            toast.success("دانلود پیوست شروع شد");
          }}
        />
      )}

      {/* Forward modal */}
      {selected && (
        <EntityFormModal
          open={forwardModalOpen}
          onOpenChange={setForwardModalOpen}
          title="ارجاع مکاتبه"
          description={`${selected.number} - ${selected.subject}`}
          icon={<Forward className="size-5 text-primary" />}
          fields={[
            {
              name: "recipient",
              label: "گیرنده ارجاع",
              type: "select",
              required: true,
              options: [
                { value: "u-002", label: "مهندس مریم احمدی - کارشناس دفتر فنی" },
                { value: "u-003", label: "مهندس علی محمودی - کارشناس اجرا" },
                { value: "u-004", label: "مهندس زهرا حسینی - کارشناس برق" },
                { value: "u-005", label: "مهندس حسین رضایی - کارشناس مکانیک" },
                { value: "u-006", label: "امیر صادقی - سرپرست کارگاه" },
              ],
            },
            { name: "comment", label: "توضیحات ارجاع", type: "textarea", placeholder: "دلیل ارجاع و دستورالعمل...", colSpan: 2 },
          ]}
          submitLabel="ارجاع"
          onSubmit={async (data) => {
            toast.success("مکاتبه ارجاع داده شد", {
              description: `به ${data.recipient}`,
            });
          }}
        />
      )}

      {/* Reply modal */}
      {selected && (
        <EntityFormModal
          open={replyModalOpen}
          onOpenChange={setReplyModalOpen}
          title="پاسخ به مکاتبه"
          description={`${selected.number} - ${selected.subject}`}
          icon={<Reply className="size-5 text-primary" />}
          fields={[
            { name: "subject", label: "موضوع پاسخ", type: "text", placeholder: `پاسخ: ${selected.subject}`, required: true, colSpan: 2 },
            {
              name: "direction",
              label: "نوع نامه",
              type: "select",
              required: true,
              defaultValue: "outbound",
              options: [
                { value: "outbound", label: "صادره (ارسالی)" },
                { value: "inbound", label: "وارده (دریافتی)" },
              ],
            },
            { name: "date", label: "تاریخ", type: "date", placeholder: "1403/10/01", required: true },
            { name: "body", label: "متن پاسخ", type: "textarea", placeholder: "متن کامل پاسخ...", colSpan: 2 },
          ]}
          submitLabel="ارسال پاسخ"
          size="lg"
          onSubmit={async () => {
            toast.success("پاسخ ثبت شد", {
              description: "پاسخ به زنجیره مکاتبات اضافه شد",
            });
          }}
        />
      )}

      {/* Chain modal */}
      {selected && (
        <CorrespondenceChainModal
          open={chainModalOpen}
          onOpenChange={setChainModalOpen}
          correspondences={correspondences}
          currentId={selected.id}
          onSelect={(id) => {
            const next = correspondences.find((c) => c.id === id);
            if (next) setSelected(next);
          }}
        />
      )}
    </div>
  );
}
