// settings-view.tsx — Application settings
"use client";
import { useState } from "react";
import { PageHeader } from "../page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Settings as SettingsIcon,
  User,
  Bell,
  Palette,
  Globe,
  Shield,
  Database,
  Save,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function SettingsView() {
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    desktop: false,
    taskAssigned: true,
    taskDue: true,
    correspondence: true,
    mentions: true,
    weekly: false,
  });

  const [appearance, setAppearance] = useState({
    theme: "system",
    language: "fa",
    timezone: "asia-tehran",
    rtl: true,
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="تنظیمات"
        subtitle="پیکربندی حساب کاربری و سامانه"
        icon={SettingsIcon}
        actions={
          <Button size="sm">
            <Save className="size-4" />
            ذخیره تغییرات
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sidebar nav */}
        <Card className="lg:col-span-1 h-fit">
          <CardContent className="p-3">
            <nav className="space-y-1">
              {[
                { id: "account", label: "حساب کاربری", icon: User },
                { id: "notifications", label: "اعلان‌ها", icon: Bell },
                { id: "appearance", label: "ظاهر", icon: Palette },
                { id: "language", label: "زبان و منطقه", icon: Globe },
                { id: "security", label: "امنیت", icon: Shield },
                { id: "data", label: "داده‌ها", icon: Database },
              ].map((item, idx) => (
                <button
                  key={item.id}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors text-right",
                    idx === 0
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-accent text-foreground"
                  )}
                >
                  <item.icon className="size-4" />
                  <span className="flex-1">{item.label}</span>
                </button>
              ))}
            </nav>
          </CardContent>
        </Card>

        {/* Settings content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Account */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <User className="size-4 text-primary" />
                حساب کاربری
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs">نام و نام خانوادگی</Label>
                  <Input defaultValue="مهندس رضا کریمی" className="mt-1" />
                </div>
                <div>
                  <Label className="text-xs">ایمیل</Label>
                  <Input defaultValue="r.karimi@parsarian.ir" className="mt-1" dir="ltr" />
                </div>
                <div>
                  <Label className="text-xs">تلفن همراه</Label>
                  <Input defaultValue="0912-345-6789" className="mt-1" dir="ltr" />
                </div>
                <div>
                  <Label className="text-xs">سمت</Label>
                  <Input defaultValue="مدیر پروژه" className="mt-1" readOnly />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Bell className="size-4 text-primary" />
                تنظیمات اعلان‌ها
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              <SettingRow
                label="اعلان ایمیلی"
                desc="دریافت اعلان‌ها از طریق ایمیل"
                checked={notifications.email}
                onChange={(v) => setNotifications((n) => ({ ...n, email: v }))}
              />
              <Separator />
              <SettingRow
                label="اعلان Push"
                desc="اعلان‌های مرورگر در دستگاه‌های مختلف"
                checked={notifications.push}
                onChange={(v) => setNotifications((n) => ({ ...n, push: v }))}
              />
              <Separator />
              <SettingRow
                label="اعلان دسکتاپ"
                desc="نمایش اعلان‌ها در دسکتاپ سیستم"
                checked={notifications.desktop}
                onChange={(v) => setNotifications((n) => ({ ...n, desktop: v }))}
              />
              <Separator />
              <SettingRow
                label="محول‌شدن وظیفه جدید"
                desc="هنگام تخصیص وظیفه جدید اطلاع بده"
                checked={notifications.taskAssigned}
                onChange={(v) => setNotifications((n) => ({ ...n, taskAssigned: v }))}
              />
              <Separator />
              <SettingRow
                label="نزدیک سررسید"
                desc="یادآوری وظایف با سررسید نزدیک"
                checked={notifications.taskDue}
                onChange={(v) => setNotifications((n) => ({ ...n, taskDue: v }))}
              />
              <Separator />
              <SettingRow
                label="مکاتبات جدید"
                desc="اعلان دریافت نامه‌های جدید"
                checked={notifications.correspondence}
                onChange={(v) => setNotifications((n) => ({ ...n, correspondence: v }))}
              />
              <Separator />
              <SettingRow
                label="اشاره به شما"
                desc="هنگامی که کسی در نظری به شما اشاره کرد"
                checked={notifications.mentions}
                onChange={(v) => setNotifications((n) => ({ ...n, mentions: v }))}
              />
              <Separator />
              <SettingRow
                label="گزارش هفتگی"
                desc="دریافت خلاصه عملکرد هفتگی"
                checked={notifications.weekly}
                onChange={(v) => setNotifications((n) => ({ ...n, weekly: v }))}
              />
            </CardContent>
          </Card>

          {/* Appearance */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Palette className="size-4 text-primary" />
                ظاهر و نمایش
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-xs mb-2 block">تم سامانه</Label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: "light", label: "روشن" },
                    { value: "dark", label: "تاریک" },
                    { value: "system", label: "سیستم" },
                  ].map((t) => (
                    <button
                      key={t.value}
                      className={cn(
                        "p-3 rounded-lg border-2 text-sm transition-colors",
                        appearance.theme === t.value
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/40"
                      )}
                      onClick={() => setAppearance((a) => ({ ...a, theme: t.value }))}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
              <Separator />
              <SettingRow
                label="چیدمان راست‌چین (RTL)"
                desc="نمایش محتوا از راست به چپ (پیش‌فرض فارسی)"
                checked={appearance.rtl}
                onChange={(v) => setAppearance((a) => ({ ...a, rtl: v }))}
              />
            </CardContent>
          </Card>

          {/* Security */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="size-4 text-primary" />
                امنیت
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs">رمز عبور فعلی</Label>
                  <Input type="password" placeholder="••••••••" className="mt-1" dir="ltr" />
                </div>
                <div>
                  <Label className="text-xs">رمز عبور جدید</Label>
                  <Input type="password" placeholder="••••••••" className="mt-1" dir="ltr" />
                </div>
              </div>
              <Separator />
              <SettingRow
                label="احراز هویت دو مرحله‌ای"
                desc="افزایش امنیت با تأیید پیامکی هنگام ورود"
                checked={false}
                onChange={() => {}}
              />
              <Separator />
              <SettingRow
                label="نشست‌های فعال"
                desc="مدیریت دستگاه‌های واردشده به حساب"
                checked={true}
                onChange={() => {}}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function SettingRow({
  label,
  desc,
  checked,
  onChange,
}: {
  label: string;
  desc: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <div className="min-w-0">
        <p className="text-sm font-medium">{label}</p>
        <p className="text-[11px] text-muted-foreground">{desc}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
