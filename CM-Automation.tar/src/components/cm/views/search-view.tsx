// search-view.tsx — Global search results
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { UserAvatar } from "../user-avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Search as SearchIcon,
  FolderKanban,
  ListTodo,
  FileText,
  Mail,
  Users,
  ArrowLeft,
} from "lucide-react";
import { projects, tasks, documents, correspondences, users } from "@/lib/mock-data";
import { faNum } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";

export function SearchView() {
  const { navigate } = useNav();
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<"all" | "projects" | "tasks" | "documents" | "correspondence" | "users">("all");

  const q = query.trim();
  const match = (text: string) => !q || text.includes(q);

  const projectResults = projects.filter((p) => match(p.name) || match(p.code) || match(p.client));
  const taskResults = tasks.filter((t) => match(t.title) || match(t.description));
  const docResults = documents.filter((d) => match(d.name));
  const corrResults = correspondences.filter((c) => match(c.subject) || match(c.number));
  const userResults = users.filter((u) => match(u.name) || match(u.email));

  const total = projectResults.length + taskResults.length + docResults.length + corrResults.length + userResults.length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="جستجو در سامانه"
        subtitle={query ? `${faNum(total)} نتیجه برای «${query}»` : "جستجوی پروژه‌ها، وظایف، اسناد، مکاتبات و کاربران"}
        icon={SearchIcon}
      />

      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <SearchIcon className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="عبارت مورد نظر را وارد کنید..."
              className="pr-9 h-11"
              autoFocus
            />
          </div>
        </CardContent>
      </Card>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="all">همه ({faNum(total)})</TabsTrigger>
          <TabsTrigger value="projects">پروژه‌ها ({faNum(projectResults.length)})</TabsTrigger>
          <TabsTrigger value="tasks">وظایف ({faNum(taskResults.length)})</TabsTrigger>
          <TabsTrigger value="documents">اسناد ({faNum(docResults.length)})</TabsTrigger>
          <TabsTrigger value="correspondence">مکاتبات ({faNum(corrResults.length)})</TabsTrigger>
          <TabsTrigger value="users">کاربران ({faNum(userResults.length)})</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="space-y-6">
        {/* Projects */}
        {(tab === "all" || tab === "projects") && projectResults.length > 0 && (
          <section>
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <FolderKanban className="size-4 text-primary" />
              پروژه‌ها
              <span className="text-xs text-muted-foreground">({faNum(projectResults.length)})</span>
            </h3>
            <div className="space-y-2">
              {projectResults.map((p) => (
                <button
                  key={p.id}
                  onClick={() => navigate("project-details", p.id)}
                  className="w-full text-right p-3 rounded-lg border border-border/60 hover:border-primary/40 hover:bg-accent/30 transition-all flex items-center gap-3"
                >
                  <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <FolderKanban className="size-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{p.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {p.code} • {p.client}
                    </p>
                  </div>
                  <StatusBadge status={p.status} />
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Tasks */}
        {(tab === "all" || tab === "tasks") && taskResults.length > 0 && (
          <section>
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <ListTodo className="size-4 text-primary" />
              وظایف
              <span className="text-xs text-muted-foreground">({faNum(taskResults.length)})</span>
            </h3>
            <div className="space-y-2">
              {taskResults.map((t) => (
                <button
                  key={t.id}
                  onClick={() => navigate("task-details", t.id)}
                  className="w-full text-right p-3 rounded-lg border border-border/60 hover:border-primary/40 hover:bg-accent/30 transition-all flex items-center gap-3"
                >
                  <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <ListTodo className="size-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{t.title}</p>
                    <p className="text-[11px] text-muted-foreground">{t.projectName}</p>
                  </div>
                  <StatusBadge status={t.status} />
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Documents */}
        {(tab === "all" || tab === "documents") && docResults.length > 0 && (
          <section>
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <FileText className="size-4 text-primary" />
              اسناد
              <span className="text-xs text-muted-foreground">({faNum(docResults.length)})</span>
            </h3>
            <div className="space-y-2">
              {docResults.map((d) => (
                <button
                  key={d.id}
                  onClick={() => navigate("documents")}
                  className="w-full text-right p-3 rounded-lg border border-border/60 hover:border-primary/40 hover:bg-accent/30 transition-all flex items-center gap-3"
                >
                  <div className="size-10 rounded-lg bg-info/10 text-info flex items-center justify-center shrink-0">
                    <FileText className="size-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{d.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {d.projectName} • نسخه {d.currentVersion}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Correspondence */}
        {(tab === "all" || tab === "correspondence") && corrResults.length > 0 && (
          <section>
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Mail className="size-4 text-primary" />
              مکاتبات
              <span className="text-xs text-muted-foreground">({faNum(corrResults.length)})</span>
            </h3>
            <div className="space-y-2">
              {corrResults.map((c) => (
                <button
                  key={c.id}
                  onClick={() => navigate("correspondence")}
                  className="w-full text-right p-3 rounded-lg border border-border/60 hover:border-primary/40 hover:bg-accent/30 transition-all flex items-center gap-3"
                >
                  <div className="size-10 rounded-lg bg-success/10 text-success flex items-center justify-center shrink-0">
                    <Mail className="size-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{c.subject}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {c.number} • {c.from}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Users */}
        {(tab === "all" || tab === "users") && userResults.length > 0 && (
          <section>
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Users className="size-4 text-primary" />
              کاربران
              <span className="text-xs text-muted-foreground">({faNum(userResults.length)})</span>
            </h3>
            <div className="space-y-2">
              {userResults.map((u) => (
                <button
                  key={u.id}
                  onClick={() => navigate("users")}
                  className="w-full text-right p-3 rounded-lg border border-border/60 hover:border-primary/40 hover:bg-accent/30 transition-all flex items-center gap-3"
                >
                  <UserAvatar name={u.name} size="sm" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{u.name}</p>
                    <p className="text-[11px] text-muted-foreground">{u.email}</p>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Empty state */}
        {total === 0 && (
          <Card>
            <CardContent className="py-16 text-center text-muted-foreground">
              <SearchIcon className="size-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">
                {query ? `نتیجه‌ای برای «${query}» یافت نشد.` : "برای شروع جستجو عبارتی وارد کنید."}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
