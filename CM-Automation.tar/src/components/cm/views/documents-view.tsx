// documents-view.tsx — Documents with version history and upload
"use client";
import { useState, useMemo } from "react";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { EntityFormModal } from "../entity-form-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  FileText,
  Upload,
  Search,
  Folder,
  FileSpreadsheet,
  FileImage,
  Download,
  Eye,
  History,
  Share2,
  MoreHorizontal,
  HardDrive,
  Calendar,
  User as UserIcon,
  Tag,
} from "lucide-react";
import { documents } from "@/lib/mock-data";
import { faNum, faFileSize, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import type { DocumentFile } from "@/lib/types";

const categoryColors: Record<string, string> = {
  drawing: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  specification: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
  contract: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  report: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  permit: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
  invoice: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300",
  correspondence: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  other: "bg-muted text-muted-foreground",
};

function getIcon(mime: string) {
  if (mime.includes("spreadsheet")) return FileSpreadsheet;
  if (mime.includes("image")) return FileImage;
  return FileText;
}

export function DocumentsView() {
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [selectedDoc, setSelectedDoc] = useState<DocumentFile | null>(null);
  const [folderModalOpen, setFolderModalOpen] = useState(false);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const filtered = useMemo(() => {
    return documents.filter((d) => {
      const matchSearch = !search || d.name.includes(search);
      const matchCat = categoryFilter === "all" || d.category === categoryFilter;
      return matchSearch && matchCat;
    });
  }, [search, categoryFilter]);

  const totalSize = documents.reduce((acc, d) => acc + d.size, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="مدیریت اسناد"
        subtitle={`${faNum(documents.length)} سند • ${faFileSize(totalSize)} فضای استفاده‌شده`}
        icon={FileText}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => setFolderModalOpen(true)}>
              <Folder className="size-4" />
              پوشه جدید
            </Button>
            <Button size="sm" onClick={() => setUploadModalOpen(true)}>
              <Upload className="size-4" />
              بارگذاری سند
            </Button>
          </>
        }
      />

      <EntityFormModal
        open={folderModalOpen}
        onOpenChange={setFolderModalOpen}
        title="ایجاد پوشه جدید"
        description="یک پوشه جدید برای سازمان‌دهی اسناد ایجاد کنید"
        icon={<Folder className="size-5 text-primary" />}
        fields={[
          { name: "name", label: "نام پوشه", type: "text", placeholder: "مثال: نقشه‌های فاز ۲", required: true, colSpan: 2 },
          {
            name: "project",
            label: "پروژه",
            type: "select",
            options: [
              { value: "p-1001", label: "برج مسکونی آرین" },
              { value: "p-1002", label: "مجتمع تجاری-اداری پاسارگاد" },
              { value: "p-1003", label: "بیمارستان تخصصی شفا" },
              { value: "none", label: "مشترک" },
            ],
          },
          {
            name: "parent",
            label: "پوشه والد",
            type: "select",
            options: [
              { value: "root", label: "ریشه" },
              { value: "drawings", label: "نقشه‌ها" },
              { value: "contracts", label: "قراردادها" },
              { value: "reports", label: "گزارش‌ها" },
            ],
          },
        ]}
        submitLabel="ایجاد پوشه"
        onSubmit={async (data) => {
          console.log("New folder:", data);
        }}
      />

      <EntityFormModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        title="بارگذاری سند جدید"
        description="سند جدید را در سامانه بارگذاری کنید"
        icon={<Upload className="size-5 text-primary" />}
        fields={[
          { name: "name", label: "نام سند", type: "text", placeholder: "مثال: نقشه‌های فاز ۲ اسکلت.pdf", required: true, colSpan: 2 },
          {
            name: "category",
            label: "دسته‌بندی",
            type: "select",
            required: true,
            options: [
              { value: "drawing", label: "نقشه" },
              { value: "specification", label: "مشخصه فنی" },
              { value: "contract", label: "قرارداد" },
              { value: "report", label: "گزارش" },
              { value: "permit", label: "مجوز" },
              { value: "invoice", label: "فاکتور" },
              { value: "other", label: "سایر" },
            ],
          },
          {
            name: "project",
            label: "پروژه",
            type: "select",
            required: true,
            options: [
              { value: "p-1001", label: "برج مسکونی آرین" },
              { value: "p-1002", label: "مجتمع تجاری-اداری پاسارگاد" },
              { value: "p-1003", label: "بیمارستان تخصصی شفا" },
              { value: "p-1004", label: "ویلاهای لوکس هشتگرد" },
            ],
          },
          { name: "description", label: "توضیحات", type: "textarea", placeholder: "توضیحات سند...", colSpan: 2 },
        ]}
        submitLabel="بارگذاری سند"
        size="lg"
        onSubmit={async (data) => {
          console.log("New document:", data);
        }}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "کل اسناد", value: faNum(documents.length), icon: FileText, color: "text-primary" },
          { label: "در انتظار بازبینی", value: faNum(documents.filter(d => d.status === "in_review").length), icon: History, color: "text-warning-foreground" },
          { label: "تأیید شده", value: faNum(documents.filter(d => d.status === "approved").length), icon: FileText, color: "text-success" },
          { label: "فضای استفاده", value: faFileSize(totalSize), icon: HardDrive, color: "text-info" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-bold mt-1">{stat.value}</p>
                </div>
                <stat.icon className={cn("size-5", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجوی سند..."
                className="pr-9"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="دسته‌بندی" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه دسته‌ها</SelectItem>
                <SelectItem value="drawing">نقشه</SelectItem>
                <SelectItem value="specification">مشخصه فنی</SelectItem>
                <SelectItem value="contract">قرارداد</SelectItem>
                <SelectItem value="report">گزارش</SelectItem>
                <SelectItem value="permit">مجوز</SelectItem>
                <SelectItem value="invoice">فاکتور</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Documents grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((doc) => {
          const Icon = getIcon(doc.mimeType);
          return (
            <Card
              key={doc.id}
              className="hover:shadow-md hover:border-primary/30 transition-all cursor-pointer group"
              onClick={() => setSelectedDoc(doc)}
            >
              <CardContent className="p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <div className={cn("size-11 rounded-lg flex items-center justify-center shrink-0", categoryColors[doc.category])}>
                    <Icon className="size-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium leading-snug line-clamp-2 group-hover:text-primary transition-colors">
                      {doc.name}
                    </p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{doc.projectName}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-7 shrink-0"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <MoreHorizontal className="size-4" />
                  </Button>
                </div>

                <div className="flex items-center gap-2 text-[11px]">
                  <StatusBadge status={doc.category} label={faLabels[doc.category as keyof typeof faLabels]} />
                  <StatusBadge status={doc.status} />
                  <span className="text-muted-foreground mr-auto">{faFileSize(doc.size)}</span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-border/60 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <UserIcon className="size-3" />
                    {doc.uploadedBy}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="size-3" />
                    {doc.uploadedAt}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-muted-foreground">نسخه فعلی</span>
                  <span className="text-xs font-bold text-primary">{doc.currentVersion}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Document detail dialog */}
      <Dialog open={!!selectedDoc} onOpenChange={(open) => !open && setSelectedDoc(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          {selectedDoc && (
            <>
              <DialogHeader>
                <DialogTitle className="text-right flex items-center gap-2">
                  {(() => {
                    const Icon = getIcon(selectedDoc.mimeType);
                    return <Icon className="size-5 text-primary" />;
                  })()}
                  {selectedDoc.name}
                </DialogTitle>
                <DialogDescription className="text-right">
                  {selectedDoc.folder} • نسخه {selectedDoc.currentVersion}
                </DialogDescription>
              </DialogHeader>

              <div className="flex items-center gap-2 pb-3 border-b">
                <Button size="sm" variant="outline">
                  <Eye className="size-4" />
                  مشاهده
                </Button>
                <Button size="sm" variant="outline">
                  <Download className="size-4" />
                  دانلود
                </Button>
                <Button size="sm" variant="outline">
                  <Share2 className="size-4" />
                  اشتراک‌گذاری
                </Button>
                <Button size="sm" variant="outline">
                  <Upload className="size-4" />
                  نسخه جدید
                </Button>
              </div>

              {/* Document preview placeholder */}
              <div className="bg-muted/40 rounded-lg p-12 flex flex-col items-center justify-center text-center">
                {(() => {
                  const Icon = getIcon(selectedDoc.mimeType);
                  return <Icon className="size-20 text-muted-foreground/40 mb-3" />;
                })()}
                <p className="text-sm text-muted-foreground">
                  پیش‌نمایش سند در اینجا نمایش داده می‌شود
                </p>
                <p className="text-xs text-muted-foreground/70 mt-1">
                  {faFileSize(selectedDoc.size)} • {selectedDoc.mimeType}
                </p>
              </div>

              {/* Metadata */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">پروژه</p>
                  <p className="font-medium">{selectedDoc.projectName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">بارگذارنده</p>
                  <p className="font-medium">{selectedDoc.uploadedBy}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">تاریخ بارگذاری</p>
                  <p className="font-medium">{selectedDoc.uploadedAt}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">اشتراک با</p>
                  <p className="font-medium">{faNum(selectedDoc.sharedWith)} نفر</p>
                </div>
              </div>

              {/* Tags */}
              {selectedDoc.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {selectedDoc.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[11px] px-2 py-1 rounded-md bg-muted text-muted-foreground flex items-center gap-1"
                    >
                      <Tag className="size-2.5" />
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Version history */}
              <div className="border-t pt-3">
                <p className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <History className="size-4 text-primary" />
                  تاریخچه نسخه‌ها
                </p>
                <ul className="space-y-2 max-h-48 overflow-y-auto">
                  {[...selectedDoc.versions].reverse().map((v, idx) => (
                    <li
                      key={v.version}
                      className={cn(
                        "flex items-center gap-3 p-2 rounded-lg",
                        idx === 0 ? "bg-primary/5" : "hover:bg-accent/40"
                      )}
                    >
                      <div className={cn(
                        "size-8 rounded-md flex items-center justify-center text-[11px] font-bold shrink-0",
                        idx === 0 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                      )}>
                        {v.version}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium">
                          {v.uploadedBy}
                          {idx === 0 && <span className="text-primary mr-2">• نسخه فعلی</span>}
                        </p>
                        <p className="text-[11px] text-muted-foreground">
                          {v.uploadedAt} • {faFileSize(v.size)}
                          {v.comment && ` • ${v.comment}`}
                        </p>
                      </div>
                      {idx > 0 && (
                        <Button variant="ghost" size="icon" className="size-7">
                          <Download className="size-3.5" />
                        </Button>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
