// procurement-view.tsx — Procurement list with filters and workflow status
"use client";
import { useState, useMemo } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ShoppingCart,
  Plus,
  Search,
  Calendar,
  Wallet,
  Building2,
  Package,
  CheckCircle2,
  Clock,
  Truck,
  AlertTriangle,
  TrendingUp,
  LayoutGrid,
  List,
} from "lucide-react";
import { purchaseRequests } from "@/lib/procurement-mock-data";
import {
  prStatusLabels,
  prPriorityLabels,
  itemCategoryLabels,
} from "@/lib/procurement-types";
import { faNum, faCurrency } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";

export function ProcurementView() {
  const { navigate } = useNav();
  const [view, setView] = useState<"grid" | "table">("grid");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");

  const filtered = useMemo(() => {
    return purchaseRequests.filter((pr) => {
      const matchSearch =
        !search ||
        pr.title.includes(search) ||
        pr.number.includes(search) ||
        pr.requesterName.includes(search) ||
        pr.projectName.includes(search);
      const matchStatus = statusFilter === "all" || pr.status === statusFilter;
      const matchPriority = priorityFilter === "all" || pr.priority === priorityFilter;
      return matchSearch && matchStatus && matchPriority;
    });
  }, [search, statusFilter, priorityFilter]);

  // Stats
  const totalValue = purchaseRequests.reduce((acc, pr) => acc + pr.totalEstimate, 0);
  const pendingCount = purchaseRequests.filter(
    (pr) => pr.status === "submitted" || pr.status === "under_review" || pr.status === "approved"
  ).length;
  const inOrderCount = purchaseRequests.filter((pr) => pr.status === "in_order").length;
  const receivedCount = purchaseRequests.filter(
    (pr) => pr.status === "received" || pr.status === "partial_received"
  ).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="مدیریت تدارکات"
        subtitle={`${faNum(purchaseRequests.length)} درخواست خرید • ارزش کل: ${faCurrency(totalValue)}`}
        icon={ShoppingCart}
        actions={
          <Button size="sm" onClick={() => navigate("procurement-new")}>
            <Plus className="size-4" />
            درخواست خرید جدید
          </Button>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "کل درخواست‌ها", value: faNum(purchaseRequests.length), icon: ShoppingCart, color: "text-primary" },
          { label: "در انتظار بررسی", value: faNum(pendingCount), icon: Clock, color: "text-warning-foreground" },
          { label: "در حال سفارش", value: faNum(inOrderCount), icon: Truck, color: "text-info" },
          { label: "دریافت شده", value: faNum(receivedCount), icon: CheckCircle2, color: "text-success" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-bold mt-1">{stat.value}</p>
                </div>
                <stat.icon className={cn("size-5", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجو بر اساس عنوان، شماره، درخواست‌کننده یا پروژه..."
                className="pr-9"
              />
            </div>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-full lg:w-40">
                <SelectValue placeholder="اولویت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه اولویت‌ها</SelectItem>
                {Object.entries(prPriorityLabels).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full lg:w-44">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                {Object.entries(prStatusLabels).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Tabs value={view} onValueChange={(v) => setView(v as "grid" | "table")}>
              <TabsList className="grid grid-cols-2 w-full lg:w-auto">
                <TabsTrigger value="grid" className="gap-1.5">
                  <LayoutGrid className="size-3.5" />
                  <span className="hidden sm:inline">کارت</span>
                </TabsTrigger>
                <TabsTrigger value="table" className="gap-1.5">
                  <List className="size-3.5" />
                  <span className="hidden sm:inline">جدول</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      {/* Grid view */}
      {view === "grid" && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((pr) => {
            const workflowProgress = (pr.workflow.filter((w) => w.status === "done").length / pr.workflow.length) * 100;
            const itemsCount = pr.items.length;
            const totalOrdered = pr.items.reduce((acc, it) => acc + (it.orderedQuantity ?? 0), 0);
            const totalNeeded = pr.items.reduce((acc, it) => acc + it.quantity, 0);
            const orderPercent = totalNeeded > 0 ? Math.round((totalOrdered / totalNeeded) * 100) : 0;

            return (
              <Card
                key={pr.id}
                className="overflow-hidden hover:shadow-lg hover:border-primary/30 transition-all cursor-pointer group"
                onClick={() => navigate("procurement-details", pr.id)}
              >
                <div className="h-1.5 bg-gradient-to-l from-primary via-primary/70 to-chart-2" />
                <CardContent className="p-5 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <div className="size-11 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <ShoppingCart className="size-5" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-semibold text-sm truncate group-hover:text-primary transition-colors">
                          {pr.title}
                        </h3>
                        <p className="text-[11px] text-muted-foreground font-mono">
                          {pr.number}
                        </p>
                      </div>
                    </div>
                    <StatusBadge status={pr.status} />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Building2 className="size-3 shrink-0" />
                      <span className="truncate">{pr.projectName}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Package className="size-3 shrink-0" />
                      <span className="truncate">{pr.requesterName} ({pr.department})</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-border/60">
                    <div>
                      <p className="text-muted-foreground mb-0.5">تخمین کل</p>
                      <p className="font-bold text-primary">{faCurrency(pr.totalEstimate)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-0.5">تعداد اقلام</p>
                      <p className="font-medium">{faNum(itemsCount)} قلم</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-0.5">تاریخ نیاز</p>
                      <p className="font-medium flex items-center gap-1">
                        <Calendar className="size-3" />
                        {pr.neededByDate}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-0.5">اولویت</p>
                      <StatusBadge status={pr.priority} />
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">پیشرفت گردش کار</span>
                      <span className="font-semibold">{faNum(Math.round(workflowProgress))}٪</span>
                    </div>
                    <Progress value={workflowProgress} className="h-1.5" />
                  </div>

                  {pr.status === "in_order" || pr.status === "partial_received" || pr.status === "received" ? (
                    <div className="space-y-1.5 pt-2 border-t border-border/60">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-muted-foreground">درصد سفارش</span>
                        <span className="font-semibold text-info">{faNum(orderPercent)}٪</span>
                      </div>
                      <Progress value={orderPercent} className="h-1.5" />
                    </div>
                  ) : null}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Table view */}
      {view === "table" && (
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs">
                  <tr className="text-right">
                    <th className="px-4 py-3 font-semibold text-muted-foreground">عنوان</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">شماره</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">پروژه</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">درخواست‌کننده</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">تخمین</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">اولویت</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">وضعیت</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">تاریخ نیاز</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filtered.map((pr) => (
                    <tr
                      key={pr.id}
                      className="hover:bg-accent/30 cursor-pointer transition-colors"
                      onClick={() => navigate("procurement-details", pr.id)}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="size-8 rounded-md bg-primary/10 text-primary flex items-center justify-center shrink-0">
                            <ShoppingCart className="size-4" />
                          </div>
                          <span className="font-medium truncate max-w-48">{pr.title}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground font-mono">{pr.number}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground truncate max-w-32">{pr.projectName}</td>
                      <td className="px-4 py-3 text-xs">{pr.requesterName}</td>
                      <td className="px-4 py-3 text-xs font-medium">{faCurrency(pr.totalEstimate)}</td>
                      <td className="px-4 py-3"><StatusBadge status={pr.priority} /></td>
                      <td className="px-4 py-3"><StatusBadge status={pr.status} /></td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{pr.neededByDate}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <ShoppingCart className="size-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">درخواست خرید مطابق با فیلترهای انتخاب‌شده یافت نشد.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
