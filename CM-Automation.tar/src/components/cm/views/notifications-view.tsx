// notifications-view.tsx — Notifications center
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bell,
  CheckCheck,
  Trash2,
  ListTodo,
  FileText,
  Mail,
  MessageSquare,
  CheckCheck as ApproveIcon,
  Settings as SysIcon,
  AlertTriangle,
  Clock,
} from "lucide-react";
import { notifications as allNotifs } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import type { NotificationType } from "@/lib/types";

const typeIcon: Record<NotificationType, typeof Bell> = {
  task_assigned: ListTodo,
  task_due: Clock,
  doc_shared: FileText,
  correspondence: Mail,
  mention: MessageSquare,
  approval: ApproveIcon,
  system: SysIcon,
};

const typeColor: Record<NotificationType, string> = {
  task_assigned: "bg-primary/10 text-primary",
  task_due: "bg-warning/15 text-warning-foreground",
  doc_shared: "bg-info/10 text-info",
  correspondence: "bg-success/10 text-success",
  mention: "bg-chart-2/15 text-chart-2",
  approval: "bg-primary/10 text-primary",
  system: "bg-muted text-muted-foreground",
};

export function NotificationsView() {
  const { navigate } = useNav();
  const [tab, setTab] = useState<"all" | "unread">("all");
  const [notifs, setNotifs] = useState(allNotifs);

  const filtered = notifs.filter((n) => tab === "all" || !n.read);
  const unreadCount = notifs.filter((n) => !n.read).length;

  const markAllRead = () => {
    setNotifs((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const markRead = (id: string) => {
    setNotifs((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="اعلان‌ها"
        subtitle={`${unreadCount.toString().padStart(2, "۰").replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[parseInt(d)])} اعلان خوانده‌نشده`}
        icon={Bell}
        actions={
          <Button size="sm" variant="outline" onClick={markAllRead} disabled={unreadCount === 0}>
            <CheckCheck className="size-4" />
            <span className="hidden sm:inline">علامت‌گذاری همه به عنوان خوانده‌شده</span>
            <span className="sm:hidden">خوانده‌شده</span>
          </Button>
        }
      />

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="all">همه ({notifs.length.toLocaleString("fa-IR")})</TabsTrigger>
          <TabsTrigger value="unread">خوانده‌نشده ({unreadCount.toLocaleString("fa-IR")})</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <ul className="divide-y">
            {filtered.length === 0 ? (
              <li className="text-center py-16 text-muted-foreground">
                <Bell className="size-12 mx-auto mb-3 opacity-30" />
                <p className="text-sm">اعلانی برای نمایش وجود ندارد.</p>
              </li>
            ) : (
              filtered.map((n) => {
                const Icon = typeIcon[n.type];
                return (
                  <li
                    key={n.id}
                    className={cn(
                      "flex items-start gap-3 p-4 hover:bg-accent/30 transition-colors",
                      !n.read && "bg-primary/5"
                    )}
                  >
                    <div className={cn("size-10 rounded-lg flex items-center justify-center shrink-0", typeColor[n.type])}>
                      <Icon className="size-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <p className="text-sm font-semibold">{n.title}</p>
                        <span className="text-[11px] text-muted-foreground shrink-0">{n.timestamp}</span>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">{n.message}</p>
                      <div className="flex items-center gap-3 mt-2">
                        {n.link && (
                          <Button
                            variant="link"
                            size="sm"
                            className="h-auto p-0 text-xs text-primary"
                            onClick={() => navigate(n.link!.view, n.link!.id)}
                          >
                            مشاهده جزئیات
                          </Button>
                        )}
                        {!n.read && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-auto p-0 text-xs text-muted-foreground"
                            onClick={() => markRead(n.id)}
                          >
                            علامت‌گذاری به عنوان خوانده‌شده
                          </Button>
                        )}
                      </div>
                    </div>
                    {!n.read && <span className="size-2 rounded-full bg-primary mt-2 shrink-0" />}
                  </li>
                );
              })
            )}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
