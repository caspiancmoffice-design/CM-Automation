// users-view.tsx — User & role management
"use client";
import { useState, useMemo } from "react";
import { PageHeader } from "../page-header";
import { UserAvatar } from "../user-avatar";
import { StatusBadge } from "../status-badge";
import { EntityFormModal } from "../entity-form-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users as UsersIcon,
  Plus,
  Search,
  Mail,
  Phone,
  MoreHorizontal,
  Shield,
  UserCog,
} from "lucide-react";
import { users } from "@/lib/mock-data";
import { faNum, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";

const rolePermissions = [
  { role: "project_manager", label: "مدیر پروژه", permissions: 24, users: 1 },
  { role: "site_manager", label: "سرپرست کارگاه", permissions: 18, users: 1 },
  { role: "technical_office", label: "کارشناس دفتر فنی", permissions: 15, users: 2 },
  { role: "execution_engineer", label: "کارشناس اجرا", permissions: 14, users: 1 },
  { role: "electrical_engineer", label: "کارشناس برق", permissions: 14, users: 1 },
  { role: "mechanical_engineer", label: "کارشناس مکانیک", permissions: 14, users: 1 },
];

export function UsersView() {
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [roleModalOpen, setRoleModalOpen] = useState(false);

  const filtered = useMemo(() => {
    return users.filter((u) => {
      const matchSearch = !search || u.name.includes(search) || u.email.includes(search);
      const matchRole = roleFilter === "all" || u.role === roleFilter;
      return matchSearch && matchRole;
    });
  }, [search, roleFilter]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="کاربران و نقش‌ها"
        subtitle={`مدیریت ${faNum(users.length)} کاربر و ${faNum(rolePermissions.length)} نقش در سامانه`}
        icon={UsersIcon}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => setRoleModalOpen(true)}>
              <Shield className="size-4" />
              تعریف نقش
            </Button>
            <Button size="sm" onClick={() => setUserModalOpen(true)}>
              <Plus className="size-4" />
              کاربر جدید
            </Button>
          </>
        }
      />

      <EntityFormModal
        open={userModalOpen}
        onOpenChange={setUserModalOpen}
        title="افزودن کاربر جدید"
        description="کاربر جدید را به سامانه اضافه کنید"
        icon={<UsersIcon className="size-5 text-primary" />}
        fields={[
          { name: "name", label: "نام و نام خانوادگی", type: "text", placeholder: "مثال: مهندس علی رضایی", required: true, colSpan: 2 },
          { name: "email", label: "ایمیل", type: "text", placeholder: "user@example.com", required: true, colSpan: 2 },
          { name: "phone", label: "شماره موبایل", type: "text", placeholder: "09123456789", required: true },
          {
            name: "role",
            label: "نقش",
            type: "select",
            required: true,
            options: [
              { value: "project_manager", label: "مدیر پروژه" },
              { value: "site_manager", label: "سرپرست کارگاه" },
              { value: "technical_office", label: "کارشناس دفتر فنی" },
              { value: "execution_engineer", label: "کارشناس اجرا" },
              { value: "electrical_engineer", label: "کارشناس برق" },
              { value: "mechanical_engineer", label: "کارشناس مکانیک" },
            ],
          },
          { name: "department", label: "دپارتمان", type: "text", placeholder: "مثال: دفتر فنی" },
          {
            name: "status",
            label: "وضعیت",
            type: "select",
            defaultValue: "invited",
            options: [
              { value: "active", label: "فعال" },
              { value: "invited", label: "دعوت‌شده" },
              { value: "inactive", label: "غیرفعال" },
            ],
          },
        ]}
        submitLabel="افزودن کاربر"
        size="lg"
        onSubmit={async (data) => {
          console.log("New user:", data);
        }}
      />

      <EntityFormModal
        open={roleModalOpen}
        onOpenChange={setRoleModalOpen}
        title="تعریف نقش جدید"
        description="نقش جدید با دسترسی‌های مشخص تعریف کنید"
        icon={<Shield className="size-5 text-primary" />}
        fields={[
          { name: "name", label: "نام نقش", type: "text", placeholder: "مثال: ناظر کیفیت", required: true, colSpan: 2 },
          { name: "description", label: "توضیحات", type: "textarea", placeholder: "شرح وظایف نقش...", colSpan: 2 },
          {
            name: "permissions",
            label: "سطح دسترسی",
            type: "select",
            required: true,
            options: [
              { value: "full", label: "کامل (مدیر سیستم)" },
              { value: "project", label: "سطح پروژه" },
              { value: "department", label: "سطح دپارتمان" },
              { value: "view", label: "فقط مشاهده" },
            ],
          },
        ]}
        submitLabel="تعریف نقش"
        onSubmit={async (data) => {
          console.log("New role:", data);
        }}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "کل کاربران", value: faNum(users.length), icon: UsersIcon, color: "text-primary" },
          { label: "فعال", value: faNum(users.filter(u => u.status === "active").length), icon: UserCog, color: "text-success" },
          { label: "دعوت‌شده", value: faNum(users.filter(u => u.status === "invited").length), icon: Mail, color: "text-warning-foreground" },
          { label: "نقش‌ها", value: faNum(rolePermissions.length), icon: Shield, color: "text-info" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-bold mt-1">{stat.value}</p>
                </div>
                <stat.icon className={cn("size-5", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Roles overview */}
      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-semibold mb-4">نقش‌های تعریف‌شده</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {rolePermissions.map((role) => (
              <div
                key={role.role}
                className="flex items-center gap-3 p-3 rounded-lg border border-border/60 hover:border-primary/30 transition-colors"
              >
                <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <Shield className="size-4.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{role.label}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {faNum(role.permissions)} دسترسی • {faNum(role.users)} کاربر
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجوی کاربر..."
                className="pr-9"
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="نقش" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه نقش‌ها</SelectItem>
                <SelectItem value="project_manager">مدیر پروژه</SelectItem>
                <SelectItem value="site_manager">سرپرست کارگاه</SelectItem>
                <SelectItem value="technical_office">کارشناس دفتر فنی</SelectItem>
                <SelectItem value="execution_engineer">کارشناس اجرا</SelectItem>
                <SelectItem value="electrical_engineer">کارشناس برق</SelectItem>
                <SelectItem value="mechanical_engineer">کارشناس مکانیک</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Users table */}
      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs">
                <tr className="text-right">
                  <th className="px-4 py-3 font-semibold text-muted-foreground">کاربر</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">نقش</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">دپارتمان</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">تماس</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">بهره‌وری</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">وضعیت</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">آخرین بازدید</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground"></th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filtered.map((user) => (
                  <tr key={user.id} className="hover:bg-accent/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <UserAvatar name={user.name} size="sm" />
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-[11px] text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs">{faLabels[user.role as keyof typeof faLabels]}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{user.department ?? "—"}</td>
                    <td className="px-4 py-3">
                      <div className="text-[11px] text-muted-foreground">
                        <p className="flex items-center gap-1">
                          <Phone className="size-2.5" />
                          {user.phone}
                        </p>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {user.productivityScore > 0 ? (
                        <span className={cn(
                          "font-bold text-xs",
                          user.productivityScore >= 85 ? "text-success" :
                          user.productivityScore >= 75 ? "text-warning-foreground" : "text-destructive"
                        )}>
                          {faNum(user.productivityScore)}٪
                        </span>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge
                        status={user.status}
                        label={user.status === "active" ? "فعال" : user.status === "invited" ? "دعوت‌شده" : "غیرفعال"}
                      />
                    </td>
                    <td className="px-4 py-3 text-[11px] text-muted-foreground">{user.lastSeen}</td>
                    <td className="px-4 py-3">
                      <Button variant="ghost" size="icon" className="size-7">
                        <MoreHorizontal className="size-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
