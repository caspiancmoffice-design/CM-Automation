// projects-view.tsx — Projects list (card grid + table view toggle)
"use client";
import { useState, useMemo } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { EntityFormModal } from "../entity-form-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  FolderKanban,
  Plus,
  LayoutGrid,
  List,
  Search,
  MapPin,
  Calendar,
  Users,
  ListTodo,
  AlertTriangle,
  Wallet,
} from "lucide-react";
import { projects } from "@/lib/mock-data";
import { faNum, faCurrency, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function ProjectsView() {
  const { navigate } = useNav();
  const [view, setView] = useState<"grid" | "table">("grid");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [modalOpen, setModalOpen] = useState(false);

  const filtered = useMemo(() => {
    return projects.filter((p) => {
      const matchSearch =
        !search ||
        p.name.includes(search) ||
        p.code.toLowerCase().includes(search.toLowerCase()) ||
        p.client.includes(search);
      const matchStatus = statusFilter === "all" || p.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [search, statusFilter]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="پروژه‌ها"
        subtitle={`مدیریت ${faNum(projects.length)} پروژه فعال و تکمیل‌شده`}
        icon={FolderKanban}
        actions={
          <Button size="sm" onClick={() => setModalOpen(true)}>
            <Plus className="size-4" />
            پروژه جدید
          </Button>
        }
      />

      <EntityFormModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        title="ایجاد پروژه جدید"
        description="فرم زیر را برای ایجاد پروژه جدید تکمیل کنید"
        icon={<FolderKanban className="size-5 text-primary" />}
        fields={[
          { name: "name", label: "نام پروژه", type: "text", placeholder: "مثال: برج مسکونی آرین", required: true, colSpan: 2 },
          { name: "code", label: "کد پروژه", type: "text", placeholder: "PA-1403-01", required: true },
          { name: "client", label: "کارفرما", type: "text", placeholder: "نام کارفرما", required: true },
          { name: "startDate", label: "تاریخ شروع", type: "date", placeholder: "1403/01/01", required: true },
          { name: "endDate", label: "تاریخ پایان", type: "date", placeholder: "1405/01/01", required: true },
          { name: "location", label: "محل پروژه", type: "text", placeholder: "آدرس پروژه", colSpan: 2 },
          { name: "description", label: "شرح پروژه", type: "textarea", placeholder: "توضیحات پروژه...", colSpan: 2 },
        ]}
        submitLabel="ایجاد پروژه"
        size="lg"
        onSubmit={async (data) => {
          console.log("New project:", data);
        }}
      />

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجو بر اساس نام، کد یا کارفرما..."
                className="pr-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                <SelectItem value="planning">برنامه‌ریزی</SelectItem>
                <SelectItem value="active">فعال</SelectItem>
                <SelectItem value="on_hold">متوقف</SelectItem>
                <SelectItem value="completed">تکمیل شده</SelectItem>
              </SelectContent>
            </Select>
            <Tabs value={view} onValueChange={(v) => setView(v as "grid" | "table")}>
              <TabsList className="grid grid-cols-2 w-full lg:w-auto">
                <TabsTrigger value="grid" className="gap-1.5">
                  <LayoutGrid className="size-3.5" />
                  <span className="hidden sm:inline">کارت</span>
                </TabsTrigger>
                <TabsTrigger value="table" className="gap-1.5">
                  <List className="size-3.5" />
                  <span className="hidden sm:inline">جدول</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      {/* Grid view */}
      {view === "grid" && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((project) => (
            <Card
              key={project.id}
              className="overflow-hidden hover:shadow-lg hover:border-primary/30 transition-all cursor-pointer group"
              onClick={() => navigate("project-details", project.id)}
            >
              <div className="h-1.5 bg-gradient-to-l from-primary via-primary/70 to-chart-2" />
              <CardContent className="p-5 space-y-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-sm truncate group-hover:text-primary transition-colors">
                        {project.name}
                      </h3>
                    </div>
                    <p className="text-[11px] text-muted-foreground">
                      {project.code} • {project.organizationName}
                    </p>
                  </div>
                  <StatusBadge status={project.status} />
                </div>

                <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed min-h-[2.5rem]">
                  {project.description}
                </p>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">پیشرفت کلی</span>
                    <span className="font-bold text-primary">{faNum(project.progress)}٪</span>
                  </div>
                  <Progress value={project.progress} className="h-1.5" />
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Calendar className="size-3" />
                      <span>شروع</span>
                    </div>
                    <p className="font-medium">{project.startDate}</p>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Calendar className="size-3" />
                      <span>پایان</span>
                    </div>
                    <p className="font-medium">{project.endDate}</p>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Users className="size-3" />
                      <span>تیم</span>
                    </div>
                    <p className="font-medium">{faNum(project.teamSize)} نفر</p>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <ListTodo className="size-3" />
                      <span>وظایف باز</span>
                    </div>
                    <p className="font-medium">{faNum(project.openTasks)} مورد</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-border/60">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground min-w-0">
                    <MapPin className="size-3 shrink-0" />
                    <span className="truncate">{project.location}</span>
                  </div>
                  {project.overdueTasks > 0 && (
                    <span className="flex items-center gap-1 text-xs text-destructive shrink-0">
                      <AlertTriangle className="size-3" />
                      {faNum(project.overdueTasks)} تأخیر
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-border/60">
                  <div className="flex items-center gap-1.5 text-xs">
                    <Wallet className="size-3 text-muted-foreground" />
                    <span className="text-muted-foreground">بودجه:</span>
                    <span className="font-semibold">{faCurrency(project.budget)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Table view */}
      {view === "table" && (
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs">
                  <tr className="text-right">
                    <th className="px-4 py-3 font-semibold text-muted-foreground">نام پروژه</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">کد</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">کارفرما</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">مدیر پروژه</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">پیشرفت</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">وضعیت</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">سررسید</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filtered.map((p) => (
                    <tr
                      key={p.id}
                      className="hover:bg-accent/30 cursor-pointer transition-colors"
                      onClick={() => navigate("project-details", p.id)}
                    >
                      <td className="px-4 py-3">
                        <div className="font-medium text-foreground">{p.name}</div>
                        <div className="text-[11px] text-muted-foreground">{p.organizationName}</div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{p.code}</td>
                      <td className="px-4 py-3 text-muted-foreground">{p.client}</td>
                      <td className="px-4 py-3">{p.managerName}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Progress value={p.progress} className="h-1.5 w-16" />
                          <span className="text-xs font-semibold">{faNum(p.progress)}٪</span>
                        </div>
                      </td>
                      <td className="px-4 py-3"><StatusBadge status={p.status} /></td>
                      <td className="px-4 py-3 text-muted-foreground">{p.endDate}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <FolderKanban className="size-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">پروژه‌ای مطابق با فیلترهای انتخاب‌شده یافت نشد.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
