// profile-view.tsx — User profile
"use client";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { UserAvatar } from "../user-avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  UserCircle,
  Mail,
  Phone,
  Building,
  Briefcase,
  Calendar,
  MapPin,
  Edit,
  Award,
  TrendingUp,
  CheckCircle2,
  Clock,
} from "lucide-react";
import { currentUser, tasks } from "@/lib/mock-data";
import { faNum, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
} from "recharts";

const productivityHistory = [
  { month: "فروردین", score: 72 },
  { month: "اردیبهشت", score: 75 },
  { month: "خرداد", score: 78 },
  { month: "تیر", score: 81 },
  { month: "مرداد", score: 79 },
  { month: "شهریور", score: 84 },
  { month: "مهر", score: 87 },
];

const skills = [
  { subject: "اجرای پروژه", A: 90 },
  { subject: "بازبینی فنی", A: 85 },
  { subject: "هماهنگی تیم", A: 88 },
  { subject: "مکاتبات", A: 78 },
  { subject: "گزارش‌گیری", A: 92 },
  { subject: "مدیریت زمان", A: 82 },
];

export function ProfileView() {
  const { navigate } = useNav();
  const myTasks = tasks.filter((t) => t.assignees.some((a) => a.userId === currentUser.id));
  const doneTasks = myTasks.filter((t) => t.status === "done").length;
  const openTasks = myTasks.filter((t) => t.status !== "done").length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="پروفایل کاربر"
        subtitle="مشاهده و ویرایش اطلاعات حساب کاربری"
        icon={UserCircle}
        actions={
          <Button size="sm" variant="outline">
            <Edit className="size-4" />
            ویرایش پروفایل
          </Button>
        }
      />

      {/* Profile header card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <UserAvatar name={currentUser.name} size="xl" className="size-20" />
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-bold">{currentUser.name}</h2>
              <p className="text-sm text-muted-foreground mt-0.5">
                {faLabels[currentUser.role as keyof typeof faLabels]} • {currentUser.department}
              </p>
              <div className="flex flex-wrap items-center gap-3 mt-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Mail className="size-3.5" />
                  {currentUser.email}
                </span>
                <span className="flex items-center gap-1">
                  <Phone className="size-3.5" />
                  {currentUser.phone}
                </span>
                <span className="flex items-center gap-1">
                  <Building className="size-3.5" />
                  شرکت ساختمانی پارس آرین
                </span>
              </div>
            </div>
            <div className="flex flex-col items-center gap-1 shrink-0">
              <div className="text-center">
                <p className="text-3xl font-bold text-success">{faNum(currentUser.productivityScore)}٪</p>
                <p className="text-[11px] text-muted-foreground">امتیاز بهره‌وری</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "وظایف انجام‌شده", value: faNum(doneTasks), icon: CheckCircle2, color: "text-success" },
          { label: "وظایف باز", value: faNum(openTasks), icon: Clock, color: "text-warning-foreground" },
          { label: "پروژه‌های فعال", value: "۴", icon: Briefcase, color: "text-primary" },
          { label: "ساعت کاری ماه", value: faNum(168), icon: TrendingUp, color: "text-info" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-bold mt-1">{stat.value}</p>
                </div>
                <stat.icon className={cn("size-5", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="info" className="space-y-6">
        <TabsList>
          <TabsTrigger value="info">اطلاعات شخصی</TabsTrigger>
          <TabsTrigger value="performance">عملکرد</TabsTrigger>
          <TabsTrigger value="activity">فعالیت‌ها</TabsTrigger>
        </TabsList>

        {/* Personal info */}
        <TabsContent value="info" className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">اطلاعات تماس</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs text-muted-foreground">نام و نام خانوادگی</Label>
                  <Input value={currentUser.name} readOnly className="mt-1 bg-muted/30" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">ایمیل</Label>
                  <Input value={currentUser.email} readOnly className="mt-1 bg-muted/30" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">تلفن همراه</Label>
                  <Input value={currentUser.phone} readOnly className="mt-1 bg-muted/30" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">نقش</Label>
                  <Input value={faLabels[currentUser.role as keyof typeof faLabels]} readOnly className="mt-1 bg-muted/30" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">دپارتمان</Label>
                  <Input value={currentUser.department ?? "—"} readOnly className="mt-1 bg-muted/30" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">وضعیت</Label>
                  <Input value="فعال" readOnly className="mt-1 bg-muted/30" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance */}
        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">روند بهره‌وری</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={240}>
                  <RadarChart data={skills}>
                    <PolarGrid stroke="var(--border)" />
                    <PolarAngleAxis
                      dataKey="subject"
                      tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                    />
                    <PolarRadiusAxis
                      angle={90}
                      domain={[0, 100]}
                      tick={{ fontSize: 10, fill: "var(--muted-foreground)" }}
                      tickFormatter={(v) => faNum(v)}
                    />
                    <Radar
                      name="مهارت"
                      dataKey="A"
                      stroke="var(--chart-1)"
                      fill="var(--chart-1)"
                      fillOpacity={0.4}
                      strokeWidth={2}
                    />
                    <Tooltip
                      contentStyle={{
                        background: "var(--popover)",
                        border: "1px solid var(--border)",
                        borderRadius: 8,
                        fontSize: 12,
                        direction: "rtl",
                      }}
                      formatter={(v: number) => faNum(v)}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">دستاوردها</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { icon: Award, title: "بهترین کارمند ماه", desc: "مهر ۱۴۰۳", color: "bg-amber-100 text-amber-700" },
                  { icon: CheckCircle2, title: "تکمیل ۱۰۰ وظیفه", desc: "در یک فصل", color: "bg-success/10 text-success" },
                  { icon: TrendingUp, title: "بهره‌وری بالای ۸۵٪", desc: "۳ ماه متوالی", color: "bg-primary/10 text-primary" },
                  { icon: Briefcase, title: "مدیر ۵ پروژه", desc: "با موفقیت", color: "bg-info/10 text-info" },
                ].map((ach) => (
                  <div key={ach.title} className="flex items-center gap-3 p-3 rounded-lg border border-border/60">
                    <div className={cn("size-10 rounded-lg flex items-center justify-center shrink-0", ach.color)}>
                      <ach.icon className="size-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{ach.title}</p>
                      <p className="text-[11px] text-muted-foreground">{ach.desc}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Activity */}
        <TabsContent value="activity">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">وظایف اخیر من</CardTitle>
            </CardHeader>
            <CardContent className="divide-y">
              {myTasks.slice(0, 5).map((task) => (
                <button
                  key={task.id}
                  onClick={() => navigate("task-details", task.id)}
                  className="w-full text-right py-3 flex items-center gap-3 hover:bg-accent/30 -mx-2 px-2 rounded-lg transition-colors"
                >
                  <Briefcase className="size-4 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{task.title}</p>
                    <p className="text-[11px] text-muted-foreground">{task.projectName} • سررسید: {task.dueDate}</p>
                  </div>
                  <span className="text-xs text-muted-foreground shrink-0">{faNum(task.progress)}٪</span>
                </button>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
