// tasks-view.tsx — Task management (Kanban + List)
"use client";
import { useState, useMemo } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge, PriorityBadge } from "../status-badge";
import { UserAvatar, AvatarGroup } from "../user-avatar";
import { EntityFormModal, type FormField } from "../entity-form-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ListTodo,
  Plus,
  LayoutGrid,
  List,
  Search,
  Calendar,
  Paperclip,
  MessageSquare,
  Clock,
  KanbanSquare,
} from "lucide-react";
import { tasks } from "@/lib/mock-data";
import { faNum, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import type { Task, TaskStatus } from "@/lib/types";

const columns: { key: TaskStatus; title: string; accent: string }[] = [
  { key: "backlog", title: "عقب‌مانده", accent: "bg-slate-400" },
  { key: "todo", title: "در انتظار", accent: "bg-blue-400" },
  { key: "in_progress", title: "در حال انجام", accent: "bg-emerald-400" },
  { key: "review", title: "بازبینی", accent: "bg-amber-400" },
  { key: "done", title: "انجام شده", accent: "bg-green-500" },
];

export function TasksView() {
  const { navigate } = useNav();
  const [view, setView] = useState<"kanban" | "list">("kanban");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [projectFilter, setProjectFilter] = useState<string>("all");
  const [modalOpen, setModalOpen] = useState(false);

  const taskFormFields: FormField[] = [
    { name: "title", label: "عنوان وظیفه", type: "text", placeholder: "مثال: بازبینی نقشه‌های فاز ۲", required: true, colSpan: 2 },
    {
      name: "project",
      label: "پروژه",
      type: "select",
      required: true,
      options: [
        { value: "p-1001", label: "برج مسکونی آرین" },
        { value: "p-1002", label: "مجتمع تجاری-اداری پاسارگاد" },
        { value: "p-1003", label: "بیمارستان تخصصی شفا" },
        { value: "p-1004", label: "ویلاهای لوکس هشتگرد" },
      ],
    },
    {
      name: "priority",
      label: "اولویت",
      type: "select",
      required: true,
      defaultValue: "medium",
      options: [
        { value: "low", label: "کم" },
        { value: "medium", label: "متوسط" },
        { value: "high", label: "بالا" },
        { value: "critical", label: "بحرانی" },
      ],
    },
    { name: "dueDate", label: "تاریخ سررسید", type: "date", required: true },
    {
      name: "assignees",
      label: "مسئولین وظیفه",
      type: "multiselect",
      required: true,
      colSpan: 2,
      helperText: "می‌توانید چند نفر را هم‌زمان انتخاب کنید. ایجادکننده وظیفه به‌صورت خودکار دسترسی مشاهده خواهد داشت.",
      options: [
        { value: "self", label: "خودم (ایجادکننده)" },
        { value: "u-002", label: "مهندس مریم احمدی - کارشناس دفتر فنی" },
        { value: "u-003", label: "مهندس علی محمودی - کارشناس اجرا" },
        { value: "u-004", label: "مهندس زهرا حسینی - کارشناس برق" },
        { value: "u-005", label: "مهندس حسین رضایی - کارشناس مکانیک" },
        { value: "u-006", label: "امیر صادقی - سرپرست کارگاه" },
      ],
    },
    { name: "description", label: "شرح وظیفه", type: "textarea", placeholder: "توضیحات کامل وظیفه...", colSpan: 2 },
  ];

  const filtered = useMemo(() => {
    return tasks.filter((t) => {
      const matchSearch =
        !search || t.title.includes(search) || t.projectName.includes(search);
      const matchStatus = statusFilter === "all" || t.status === statusFilter;
      const matchProject = projectFilter === "all" || t.projectId === projectFilter;
      return matchSearch && matchStatus && matchProject;
    });
  }, [search, statusFilter, projectFilter]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="مدیریت وظایف"
        subtitle={`${faNum(tasks.length)} وظیفه در سامانه`}
        icon={ListTodo}
        actions={
          <Button size="sm" onClick={() => setModalOpen(true)}>
            <Plus className="size-4" />
            وظیفه جدید
          </Button>
        }
      />

      <EntityFormModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        title="ایجاد وظیفه جدید"
        description="فرم زیر را برای ایجاد وظیفه جدید تکمیل کنید"
        icon={<ListTodo className="size-5 text-primary" />}
        fields={taskFormFields}
        submitLabel="ایجاد وظیفه"
        size="lg"
        onSubmit={async (data) => {
          console.log("New task:", data);
        }}
      />

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجوی وظیفه..."
                className="pr-9"
              />
            </div>
            <Select value={projectFilter} onValueChange={setProjectFilter}>
              <SelectTrigger className="w-full lg:w-56">
                <SelectValue placeholder="پروژه" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه پروژه‌ها</SelectItem>
                <SelectItem value="p-1001">برج مسکونی آرین</SelectItem>
                <SelectItem value="p-1002">مجتمع تجاری-اداری پاسارگاد</SelectItem>
                <SelectItem value="p-1003">بیمارستان تخصصی شفا</SelectItem>
                <SelectItem value="p-1004">ویلاهای لوکس هشتگرد</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full lg:w-40">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                <SelectItem value="todo">در انتظار</SelectItem>
                <SelectItem value="in_progress">در حال انجام</SelectItem>
                <SelectItem value="review">بازبینی</SelectItem>
                <SelectItem value="done">انجام شده</SelectItem>
                <SelectItem value="blocked">مسدود</SelectItem>
                <SelectItem value="backlog">عقب‌مانده</SelectItem>
              </SelectContent>
            </Select>
            <Tabs value={view} onValueChange={(v) => setView(v as "kanban" | "list")}>
              <TabsList className="grid grid-cols-2 w-full lg:w-auto">
                <TabsTrigger value="kanban" className="gap-1.5">
                  <KanbanSquare className="size-3.5" />
                  <span className="hidden sm:inline">تابلو</span>
                </TabsTrigger>
                <TabsTrigger value="list" className="gap-1.5">
                  <List className="size-3.5" />
                  <span className="hidden sm:inline">فهرست</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      {/* Kanban view */}
      {view === "kanban" && (
        <div className="overflow-x-auto pb-4">
          <div className="flex gap-4 min-w-max">
            {columns.map((col) => {
              const colTasks = filtered.filter((t) => t.status === col.key);
              return (
                <div key={col.key} className="w-72 shrink-0">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className={cn("size-2.5 rounded-full", col.accent)} />
                      <h3 className="text-sm font-semibold">{col.title}</h3>
                      <span className="text-[11px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                        {faNum(colTasks.length)}
                      </span>
                    </div>
                    <Button variant="ghost" size="icon" className="size-7 text-muted-foreground">
                      <Plus className="size-3.5" />
                    </Button>
                  </div>
                  <div className="space-y-2.5">
                    {colTasks.map((task) => (
                      <TaskCard key={task.id} task={task} onClick={() => navigate("task-details", task.id)} />
                    ))}
                    {colTasks.length === 0 && (
                      <div className="text-center py-8 text-xs text-muted-foreground border border-dashed rounded-lg">
                        وظیفه‌ای در این ستون نیست
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* List view */}
      {view === "list" && (
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs">
                  <tr className="text-right">
                    <th className="px-4 py-3 font-semibold text-muted-foreground">عنوان وظیفه</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">پروژه</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">مسئولین</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">اولویت</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">سررسید</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">پیشرفت</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">وضعیت</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filtered.map((task) => (
                    <tr
                      key={task.id}
                      className="hover:bg-accent/30 cursor-pointer transition-colors"
                      onClick={() => navigate("task-details", task.id)}
                    >
                      <td className="px-4 py-3">
                        <div className="font-medium">{task.title}</div>
                        {task.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {task.tags.slice(0, 2).map((tag) => (
                              <span key={tag} className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                                #{tag}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground text-xs">{task.projectName}</td>
                      <td className="px-4 py-3">
                        <AvatarGroup users={task.assignees.map((a) => ({ userName: a.userName }))} max={3} size="sm" />
                      </td>
                      <td className="px-4 py-3"><PriorityBadge priority={task.priority} /></td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{task.dueDate}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Progress value={task.progress} className="h-1.5 w-14" />
                          <span className="text-xs font-semibold">{faNum(task.progress)}٪</span>
                        </div>
                      </td>
                      <td className="px-4 py-3"><StatusBadge status={task.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function TaskCard({ task, onClick }: { task: Task; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full text-right p-3.5 rounded-lg bg-card border border-border/60 hover:border-primary/40 hover:shadow-md transition-all group"
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <h4 className="text-sm font-medium leading-snug group-hover:text-primary transition-colors line-clamp-2">
          {task.title}
        </h4>
        <PriorityBadge priority={task.priority} />
      </div>

      <p className="text-[11px] text-muted-foreground mb-3 line-clamp-2">
        {task.description.slice(0, 100)}
      </p>

      {task.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {task.tags.slice(0, 3).map((tag) => (
            <span key={tag} className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
              #{tag}
            </span>
          ))}
        </div>
      )}

      {task.subtasks.length > 0 && (
        <div className="mb-3">
          <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
            <span>زیروظایف</span>
            <span>
              {faNum(task.subtasks.filter((s) => s.done).length)}/{faNum(task.subtasks.length)}
            </span>
          </div>
          <Progress
            value={(task.subtasks.filter((s) => s.done).length / task.subtasks.length) * 100}
            className="h-1"
          />
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AvatarGroup users={task.assignees.map((a) => ({ userName: a.userName }))} max={3} size="sm" />
        </div>
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
          {task.attachments > 0 && (
            <span className="flex items-center gap-0.5">
              <Paperclip className="size-3" />
              {faNum(task.attachments)}
            </span>
          )}
          {task.comments > 0 && (
            <span className="flex items-center gap-0.5">
              <MessageSquare className="size-3" />
              {faNum(task.comments)}
            </span>
          )}
          <span className="flex items-center gap-0.5">
            <Calendar className="size-3" />
            {task.dueDate}
          </span>
        </div>
      </div>
    </button>
  );
}
