// procurement-details-view.tsx — Purchase request details with workflow tracking
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  ArrowRight,
  ShoppingCart,
  Building2,
  Calendar,
  Wallet,
  Clock,
  Package,
  Truck,
  CheckCircle2,
  AlertTriangle,
  MapPin,
  User,
  FileText,
  MessageSquare,
  GitBranch,
  Circle,
  Check,
  CheckCheck,
  X,
  Plus,
  History,
  Send,
} from "lucide-react";
import { purchaseRequests } from "@/lib/procurement-mock-data";
import {
  prStatusLabels,
  prPriorityLabels,
  itemCategoryLabels,
  wfStepStatusLabels,
  type WFStepStatus,
} from "@/lib/procurement-types";
import { faNum, faCurrency, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function ProcurementDetailsView() {
  const { contextId, navigate } = useNav();
  const [activeTab, setActiveTab] = useState("overview");
  const pr = purchaseRequests.find((p) => p.id === contextId) ?? purchaseRequests[0];

  const workflowProgress = (pr.workflow.filter((w) => w.status === "done").length / pr.workflow.length) * 100;
  const totalOrdered = pr.items.reduce((acc, it) => acc + (it.orderedQuantity ?? 0), 0);
  const totalReceived = pr.items.reduce((acc, it) => acc + (it.receivedQuantity ?? 0), 0);
  const totalNeeded = pr.items.reduce((acc, it) => acc + it.quantity, 0);
  const orderPercent = totalNeeded > 0 ? Math.round((totalOrdered / totalNeeded) * 100) : 0;
  const receivePercent = totalNeeded > 0 ? Math.round((totalReceived / totalNeeded) * 100) : 0;

  return (
    <div className="space-y-6">
      <button
        onClick={() => navigate("procurement")}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowRight className="size-4 rotate-180" />
        بازگشت به فهرست درخواست‌های خرید
      </button>

      <PageHeader
        title={pr.title}
        subtitle={`${pr.number} • ${pr.projectName}`}
        icon={ShoppingCart}
        actions={
          <>
            <StatusBadge status={pr.priority} />
            <StatusBadge status={pr.status} />
          </>
        }
      />

      {/* Top info cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Wallet className="size-3.5" />
              تخمین کل
            </div>
            <p className="font-bold text-primary">{faCurrency(pr.totalEstimate)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Package className="size-3.5" />
              تعداد اقلام
            </div>
            <p className="font-bold">{faNum(pr.items.length)} قلم</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Clock className="size-3.5" />
              تاریخ نیاز
            </div>
            <p className="font-bold text-sm">{pr.neededByDate}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <GitBranch className="size-3.5" />
              پیشرفت گردش کار
            </div>
            <p className="font-bold">{faNum(Math.round(workflowProgress))}٪</p>
            <Progress value={workflowProgress} className="h-1.5 mt-1" />
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="w-full justify-start overflow-x-auto">
          <TabsTrigger value="overview">نمای کلی</TabsTrigger>
          <TabsTrigger value="items">اقلام ({faNum(pr.items.length)})</TabsTrigger>
          <TabsTrigger value="workflow">گردش کار</TabsTrigger>
          <TabsTrigger value="history">تاریخچه</TabsTrigger>
          <TabsTrigger value="vendors">وندورها</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Description */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">شرح درخواست</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm leading-relaxed text-foreground/90">
                  {pr.description ?? "بدون توضیحات"}
                </p>
                <Separator />
                <div>
                  <p className="text-xs text-muted-foreground mb-1">توجیه نیاز</p>
                  <p className="text-sm leading-relaxed">{pr.justification ?? "—"}</p>
                </div>
                {pr.tags && pr.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-2 border-t">
                    {pr.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-[11px] px-2 py-1 rounded-md bg-muted text-muted-foreground"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Metadata */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">مشخصات درخواست</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">شماره درخواست</p>
                  <p className="font-mono text-xs">{pr.number}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5 flex items-center gap-1">
                    <Building2 className="size-3" />
                    پروژه
                  </p>
                  <p className="font-medium">{pr.projectName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5 flex items-center gap-1">
                    <User className="size-3" />
                    درخواست‌کننده
                  </p>
                  <p className="font-medium">{pr.requesterName}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {pr.requesterRole} • {pr.department}
                  </p>
                </div>
                <Separator />
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">تاریخ ایجاد</p>
                  <p className="font-medium">{pr.createdAt}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">تاریخ نیاز</p>
                  <p className="font-medium text-warning-foreground">{pr.neededByDate}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order progress */}
          {(pr.status === "in_order" || pr.status === "partial_received" || pr.status === "received") && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Truck className="size-4 text-info" />
                  پیشرفت سفارش و تحویل
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">درصد سفارش</span>
                      <span className="text-xl font-bold text-info">{faNum(orderPercent)}٪</span>
                    </div>
                    <Progress value={orderPercent} className="h-2.5" />
                    <p className="text-[11px] text-muted-foreground mt-2">
                      {faNum(totalOrdered)} از {faNum(totalNeeded)} {pr.items[0]?.unit ?? ""} سفارش داده شده
                    </p>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">درصد دریافت</span>
                      <span className="text-xl font-bold text-success">{faNum(receivePercent)}٪</span>
                    </div>
                    <Progress value={receivePercent} className="h-2.5" />
                    <p className="text-[11px] text-muted-foreground mt-2">
                      {faNum(totalReceived)} از {faNum(totalNeeded)} {pr.items[0]?.unit ?? ""} دریافت شده
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Items tab */}
        <TabsContent value="items" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Package className="size-4 text-primary" />
                اقلام درخواست خرید
                <span className="text-xs text-muted-foreground font-normal">({faNum(pr.items.length)} قلم)</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="bg-muted/50">
                    <tr className="text-right">
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">ردیف</th>
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">شرح مصالح/تجهیزات</th>
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">دسته</th>
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">مقدار</th>
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">محل مصرف</th>
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">مشخصات فنی</th>
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">وندور</th>
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">٪ سفارش</th>
                      <th className="px-3 py-2.5 font-semibold text-muted-foreground">تخمین قیمت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {pr.items.map((item) => (
                      <tr key={item.id} className="hover:bg-accent/20 align-top">
                        <td className="px-3 py-3 font-mono text-muted-foreground">{faNum(item.row)}</td>
                        <td className="px-3 py-3">
                          <p className="font-medium text-foreground">{item.name}</p>
                          {item.notes && (
                            <p className="text-[10px] text-muted-foreground mt-0.5">{item.notes}</p>
                          )}
                        </td>
                        <td className="px-3 py-3">
                          <StatusBadge status={item.category} label={itemCategoryLabels[item.category]} />
                        </td>
                        <td className="px-3 py-3 whitespace-nowrap">
                          <p className="font-bold">{faNum(item.quantity)}</p>
                          <p className="text-[10px] text-muted-foreground">{item.unit}</p>
                        </td>
                        <td className="px-3 py-3">
                          <p className="flex items-start gap-1 text-foreground/80">
                            <MapPin className="size-3 shrink-0 mt-0.5 text-muted-foreground" />
                            <span className="leading-snug">{item.consumptionLocation}</span>
                          </p>
                        </td>
                        <td className="px-3 py-3 max-w-64">
                          <p className="text-foreground/80 leading-relaxed text-[11px]">{item.technicalSpec}</p>
                        </td>
                        <td className="px-3 py-3 text-xs">
                          {item.vendorName ?? "—"}
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-2">
                            <span className={cn(
                              "font-bold",
                              item.orderPercent === 100 ? "text-success" :
                              item.orderPercent > 0 ? "text-info" : "text-muted-foreground"
                            )}>
                              {faNum(item.orderPercent)}٪
                            </span>
                          </div>
                          {item.orderedQuantity !== undefined && item.orderedQuantity > 0 && (
                            <p className="text-[10px] text-muted-foreground mt-0.5">
                              {faNum(item.orderedQuantity)} از {faNum(item.quantity)} سفارش
                            </p>
                          )}
                        </td>
                        <td className="px-3 py-3 whitespace-nowrap">
                          <p className="font-bold text-primary text-xs">{faCurrency(item.totalPriceEstimate ?? 0)}</p>
                          <p className="text-[10px] text-muted-foreground">
                            {faNum(item.unitPriceEstimate ?? 0)} × {faNum(item.quantity)}
                          </p>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-muted/30">
                    <tr>
                      <td colSpan={8} className="px-3 py-3 text-left text-sm font-bold">جمع کل تخمینی:</td>
                      <td className="px-3 py-3 text-sm font-bold text-primary whitespace-nowrap">
                        {faCurrency(pr.totalEstimate)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Workflow tab */}
        <TabsContent value="workflow" className="space-y-6">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <GitBranch className="size-4 text-primary" />
                گردش کار درخواست
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => toast.info("افزودن نظر در حال توسعه")}
                >
                  <MessageSquare className="size-4" />
                  افزودن نظر
                </Button>
                <Button
                  size="sm"
                  onClick={() => toast.success("مرحله بعدی فعال شد")}
                >
                  <CheckCheck className="size-4" />
                  تأیید و ادامه
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ol className="relative space-y-4 pr-6">
                {/* Vertical line */}
                <div className="absolute right-2.5 top-2 bottom-2 w-0.5 bg-border" />

                {pr.workflow.map((step, idx) => {
                  const isLast = idx === pr.workflow.length - 1;
                  return (
                    <li key={step.id} className="relative">
                      {/* Step indicator */}
                      <div className={cn(
                        "absolute -right-6 top-0.5 size-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ring-4 ring-background",
                        step.status === "done" && "bg-success text-success-foreground",
                        step.status === "current" && "bg-primary text-primary-foreground",
                        step.status === "pending" && "bg-muted text-muted-foreground",
                        step.status === "rejected" && "bg-destructive text-white",
                        step.status === "skipped" && "bg-muted-foreground/30 text-muted-foreground"
                      )}>
                        {step.status === "done" ? (
                          <Check className="size-3" />
                        ) : step.status === "rejected" ? (
                          <X className="size-3" />
                        ) : (
                          faNum(idx + 1)
                        )}
                      </div>

                      <div className={cn(
                        "p-3 rounded-lg border",
                        step.status === "current"
                          ? "border-primary/40 bg-primary/5"
                          : step.status === "done"
                          ? "border-success/30 bg-success/5"
                          : step.status === "rejected"
                          ? "border-destructive/30 bg-destructive/5"
                          : "border-border/60"
                      )}>
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <div>
                            <p className={cn(
                              "text-sm font-semibold",
                              step.status === "current" && "text-primary",
                              step.status === "done" && "text-foreground",
                              step.status === "pending" && "text-muted-foreground"
                            )}>
                              {step.title}
                            </p>
                            {step.description && (
                              <p className="text-[11px] text-muted-foreground mt-0.5">{step.description}</p>
                            )}
                          </div>
                          <StatusBadge status={step.status} label={wfStepStatusLabels[step.status]} />
                        </div>

                        <div className="flex flex-wrap items-center gap-3 mt-2 text-[11px] text-muted-foreground">
                          {step.assignedTo && (
                            <span className="flex items-center gap-1">
                              <User className="size-2.5" />
                              {step.assignedTo}
                            </span>
                          )}
                          {!step.assignedTo && step.assignedRole && (
                            <span className="flex items-center gap-1">
                              <User className="size-2.5" />
                              {step.assignedRole}
                            </span>
                          )}
                          {step.startedAt && (
                            <span className="flex items-center gap-1">
                              <Clock className="size-2.5" />
                              شروع: {step.startedAt}
                            </span>
                          )}
                          {step.completedAt && (
                            <span className="flex items-center gap-1">
                              <CheckCircle2 className="size-2.5 text-success" />
                              تکمیل: {step.completedAt}
                            </span>
                          )}
                          {step.orderPercent !== undefined && (
                            <span className="flex items-center gap-1">
                              <Truck className="size-2.5 text-info" />
                              سفارش: {faNum(step.orderPercent)}٪
                            </span>
                          )}
                        </div>

                        {step.comment && (
                          <div className="mt-2 p-2 rounded bg-background/50 text-[11px] text-foreground/80 leading-relaxed">
                            <span className="text-muted-foreground">نظر: </span>
                            {step.comment}
                          </div>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ol>
            </CardContent>
          </Card>
        </TabsContent>

        {/* History tab */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <History className="size-4 text-primary" />
                تاریخچه تغییرات
                <span className="text-xs text-muted-foreground font-normal">({faNum(pr.history.length)} رخداد)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {pr.history.map((entry) => (
                  <li
                    key={entry.id}
                    className="flex gap-3 p-3 rounded-lg border border-border/60 hover:bg-accent/20 transition-colors"
                  >
                    <div className="size-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <Send className="size-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <p className="text-sm font-medium">{entry.stepTitle}</p>
                        <span className="text-[11px] text-muted-foreground shrink-0">{entry.timestamp}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] mb-1">
                        <span className="text-muted-foreground">توسط:</span>
                        <span className="font-medium">{entry.actor}</span>
                        {entry.actorRole && (
                          <span className="text-muted-foreground">({entry.actorRole})</span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-[11px]">
                        <StatusBadge status={entry.fromStatus} />
                        <span className="text-muted-foreground">→</span>
                        <StatusBadge status={entry.toStatus} />
                      </div>
                      {entry.comment && (
                        <p className="text-[11px] text-foreground/80 mt-1.5 leading-relaxed bg-muted/40 p-2 rounded">
                          {entry.comment}
                        </p>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Vendors tab */}
        <TabsContent value="vendors" className="space-y-4">
          {pr.vendors.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <Truck className="size-12 mx-auto mb-3 opacity-30" />
                <p className="text-sm">هیچ وندوری برای این درخواست ثبت نشده است.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pr.vendors.map((vendor) => (
                <Card key={vendor.id}>
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <div className="size-11 rounded-lg bg-info/10 text-info flex items-center justify-center shrink-0">
                          <Truck className="size-5" />
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-semibold text-sm truncate">{vendor.name}</h3>
                          <p className="text-[11px] text-muted-foreground">
                            {vendor.type === "company" ? "شخص حقوقی" : "شخص حقیقی"}
                          </p>
                        </div>
                      </div>
                      {vendor.rating && (
                        <div className="flex items-center gap-0.5 shrink-0">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <span
                              key={i}
                              className={cn(
                                "text-xs",
                                i < vendor.rating! ? "text-amber-500" : "text-muted-foreground/30"
                              )}
                            >
                              ★
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t">
                      {vendor.contactPerson && (
                        <div>
                          <p className="text-muted-foreground">نماینده</p>
                          <p className="font-medium">{vendor.contactPerson}</p>
                        </div>
                      )}
                      {vendor.phone && (
                        <div>
                          <p className="text-muted-foreground">تلفن</p>
                          <p className="font-medium font-mono" dir="ltr">{vendor.phone}</p>
                        </div>
                      )}
                      {vendor.previousOrders !== undefined && (
                        <div>
                          <p className="text-muted-foreground">سفارش‌های قبلی</p>
                          <p className="font-medium">{faNum(vendor.previousOrders)} سفارش</p>
                        </div>
                      )}
                    </div>

                    {vendor.tags && vendor.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-2 border-t">
                        {vendor.tags.map((tag) => (
                          <span
                            key={tag}
                            className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
