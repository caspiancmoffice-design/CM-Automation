// project-details-view.tsx — Project details with tabs
"use client";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { UserAvatar } from "../user-avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  ArrowRight,
  MapPin,
  Calendar,
  Users,
  ListTodo,
  Wallet,
  Building,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Plus,
  FileText,
  Mail,
} from "lucide-react";
import {
  projects,
  tasks,
  documents,
  correspondences,
  users,
} from "@/lib/mock-data";
import { faNum, faCurrency, faLabels } from "@/lib/fa-utils";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from "recharts";

export function ProjectDetailsView() {
  const { contextId, navigate } = useNav();
  const project = projects.find((p) => p.id === contextId) ?? projects[0];
  const projectTasks = tasks.filter((t) => t.projectId === project.id);
  const projectDocs = documents.filter((d) => d.projectId === project.id);
  const projectCorrs = correspondences.filter((c) => c.projectId === project.id);

  const budgetUsedPercent = Math.round((project.spentBudget / project.budget) * 100);

  const taskStatusData = [
    { name: "انجام شده", value: projectTasks.filter((t) => t.status === "done").length, color: "var(--chart-4)" },
    { name: "در حال انجام", value: projectTasks.filter((t) => t.status === "in_progress").length, color: "var(--chart-1)" },
    { name: "در انتظار", value: projectTasks.filter((t) => t.status === "todo" || t.status === "backlog").length, color: "var(--chart-2)" },
    { name: "بازبینی", value: projectTasks.filter((t) => t.status === "review").length, color: "var(--chart-3)" },
    { name: "مسدود", value: projectTasks.filter((t) => t.status === "blocked").length, color: "var(--chart-5)" },
  ].filter((d) => d.value > 0);

  return (
    <div className="space-y-6">
      <button
        onClick={() => navigate("projects")}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowRight className="size-4 rotate-180" />
        بازگشت به فهرست پروژه‌ها
      </button>

      <PageHeader
        title={project.name}
        subtitle={`${project.code} • ${project.description.slice(0, 100)}...`}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => navigate("correspondence")}>
              <Mail className="size-4" />
              مکاتبه
            </Button>
            <Button size="sm" onClick={() => navigate("tasks")}>
              <Plus className="size-4" />
              وظیفه جدید
            </Button>
          </>
        }
      />

      {/* Top info cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Calendar className="size-3.5" />
              تاریخ شروع
            </div>
            <p className="font-semibold">{project.startDate}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Clock className="size-3.5" />
              تاریخ پایان
            </div>
            <p className="font-semibold">{project.endDate}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <MapPin className="size-3.5" />
              موقعیت
            </div>
            <p className="font-semibold text-sm truncate">{project.location}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Users className="size-3.5" />
              اعضای تیم
            </div>
            <p className="font-semibold">{faNum(project.teamSize)} نفر</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="w-full justify-start overflow-x-auto">
          <TabsTrigger value="overview">نمای کلی</TabsTrigger>
          <TabsTrigger value="tasks">وظایف</TabsTrigger>
          <TabsTrigger value="documents">اسناد</TabsTrigger>
          <TabsTrigger value="correspondence">مکاتبات</TabsTrigger>
          <TabsTrigger value="team">تیم</TabsTrigger>
          <TabsTrigger value="financial">مالی</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Progress card */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">پیشرفت پروژه</CardTitle>
              </CardHeader>
              <CardContent className="space-y-5">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">پیشرفت کلی</span>
                    <span className="text-2xl font-bold text-primary">{faNum(project.progress)}٪</span>
                  </div>
                  <Progress value={project.progress} className="h-2.5" />
                </div>

                <div className="grid grid-cols-3 gap-4 pt-2">
                  <div className="text-center p-3 rounded-lg bg-success/10">
                    <CheckCircle2 className="size-5 mx-auto text-success mb-1" />
                    <p className="text-xl font-bold text-success">{faNum(projectTasks.filter(t => t.status === "done").length)}</p>
                    <p className="text-[11px] text-muted-foreground">انجام شده</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-warning/10">
                    <Clock className="size-5 mx-auto text-warning-foreground mb-1" />
                    <p className="text-xl font-bold text-warning-foreground">{faNum(project.openTasks)}</p>
                    <p className="text-[11px] text-muted-foreground">در حال انجام</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-destructive/10">
                    <AlertTriangle className="size-5 mx-auto text-destructive mb-1" />
                    <p className="text-xl font-bold text-destructive">{faNum(project.overdueTasks)}</p>
                    <p className="text-[11px] text-muted-foreground">تأخیری</p>
                  </div>
                </div>

                <div className="pt-2">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-muted-foreground">مصرف بودجه</span>
                    <span className="font-semibold">{faCurrency(project.spentBudget)} از {faCurrency(project.budget)}</span>
                  </div>
                  <Progress value={budgetUsedPercent} className="h-2.5" />
                  <p className="text-[11px] text-muted-foreground mt-1">{faNum(budgetUsedPercent)}٪ از بودجه مصرف شده</p>
                </div>
              </CardContent>
            </Card>

            {/* Task status pie */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">وضعیت وظایف</CardTitle>
              </CardHeader>
              <CardContent>
                {taskStatusData.length > 0 ? (
                  <>
                    <ResponsiveContainer width="100%" height={180}>
                      <PieChart>
                        <Pie
                          data={taskStatusData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={45}
                          outerRadius={75}
                          paddingAngle={2}
                          stroke="none"
                        >
                          {taskStatusData.map((entry, idx) => (
                            <Cell key={idx} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            background: "var(--popover)",
                            border: "1px solid var(--border)",
                            borderRadius: 8,
                            fontSize: 12,
                            direction: "rtl",
                          }}
                          formatter={(v: number) => faNum(v)}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                    <ul className="space-y-1.5 mt-2">
                      {taskStatusData.map((item) => (
                        <li key={item.name} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <span className="size-2.5 rounded-sm" style={{ background: item.color }} />
                            <span className="text-muted-foreground">{item.name}</span>
                          </div>
                          <span className="font-semibold">{faNum(item.value)}</span>
                        </li>
                      ))}
                    </ul>
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-8">وظیفه‌ای ثبت نشده است.</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Description + Parties */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">شرح پروژه و طرفین قرارداد</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <p className="text-sm leading-relaxed text-foreground/90">{project.description}</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 border-t">
                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5">
                    <Building className="size-3" />
                    کارفرما
                  </p>
                  <p className="text-sm font-medium">{project.client}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5">
                    <Building className="size-3" />
                    مهندس مشاور
                  </p>
                  <p className="text-sm font-medium">{project.consultant ?? "—"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5">
                    <Building className="size-3" />
                    پیمانکار
                  </p>
                  <p className="text-sm font-medium">{project.contractor ?? "—"}</p>
                </div>
              </div>

              {project.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-3 border-t">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[11px] px-2 py-1 rounded-md bg-muted text-muted-foreground"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tasks tab */}
        <TabsContent value="tasks" className="space-y-4">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-base">وظایف پروژه</CardTitle>
              <Button size="sm" variant="outline" onClick={() => navigate("tasks")}>
                <ListTodo className="size-4" />
                مشاهده در تابلو
              </Button>
            </CardHeader>
            <CardContent className="divide-y">
              {projectTasks.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">وظیفه‌ای برای این پروژه ثبت نشده است.</p>
              ) : (
                projectTasks.map((task) => (
                  <button
                    key={task.id}
                    onClick={() => navigate("task-details", task.id)}
                    className="w-full text-right py-3 flex items-center gap-3 hover:bg-accent/30 -mx-2 px-2 rounded-lg transition-colors"
                  >
                    <ListTodo className="size-4 text-muted-foreground shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{task.title}</p>
                      <p className="text-[11px] text-muted-foreground">
                        سررسید: {task.dueDate} • {faNum(task.spentHours)} ساعت
                      </p>
                    </div>
                    <StatusBadge status={task.priority} />
                    <StatusBadge status={task.status} />
                  </button>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Documents tab */}
        <TabsContent value="documents" className="space-y-4">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-base">اسناد پروژه</CardTitle>
              <Button size="sm" variant="outline" onClick={() => navigate("documents")}>
                <FileText className="size-4" />
                مدیریت اسناد
              </Button>
            </CardHeader>
            <CardContent className="divide-y">
              {projectDocs.map((doc) => (
                <div key={doc.id} className="py-3 flex items-center gap-3">
                  <div className="size-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <FileText className="size-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{doc.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      نسخه {doc.currentVersion} • {doc.uploadedBy} • {doc.uploadedAt}
                    </p>
                  </div>
                  <StatusBadge status={doc.status} />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Correspondence tab */}
        <TabsContent value="correspondence" className="space-y-4">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-base">مکاتبات پروژه</CardTitle>
              <Button size="sm" variant="outline" onClick={() => navigate("correspondence")}>
                <Mail className="size-4" />
                همه مکاتبات
              </Button>
            </CardHeader>
            <CardContent className="divide-y">
              {projectCorrs.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">مکاتبه‌ای ثبت نشده است.</p>
              ) : (
                projectCorrs.map((c) => (
                  <div key={c.id} className="py-3 flex items-start gap-3">
                    <div className={`size-9 rounded-lg flex items-center justify-center shrink-0 ${c.direction === "inbound" ? "bg-success/10 text-success" : "bg-info/10 text-info"}`}>
                      <Mail className="size-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="text-sm font-medium truncate">{c.subject}</p>
                        <StatusBadge status={c.direction} />
                      </div>
                      <p className="text-[11px] text-muted-foreground">
                        {c.number} • {c.from} → {c.to} • {c.date}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Team tab */}
        <TabsContent value="team" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">اعضای تیم پروژه</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {users.slice(0, 6).map((user) => (
                <div
                  key={user.id}
                  className="flex items-center gap-3 p-3 rounded-lg border border-border/60 hover:border-primary/30 transition-colors"
                >
                  <UserAvatar name={user.name} size="lg" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{user.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {faLabels[user.role as keyof typeof faLabels]}
                    </p>
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-[10px] text-muted-foreground">بهره‌وری:</span>
                      <span className="text-[10px] font-semibold text-success">
                        {faNum(user.productivityScore)}٪
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Financial tab */}
        <TabsContent value="financial" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                  <Wallet className="size-3.5" />
                  بودجه کل
                </div>
                <p className="text-xl font-bold">{faCurrency(project.budget)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                  <Wallet className="size-3.5" />
                  هزینه شده
                </div>
                <p className="text-xl font-bold text-warning-foreground">{faCurrency(project.spentBudget)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                  <Wallet className="size-3.5" />
                  باقی‌مانده
                </div>
                <p className="text-xl font-bold text-success">{faCurrency(project.budget - project.spentBudget)}</p>
              </CardContent>
            </Card>
          </div>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">صورت‌وضعیت‌های اخیر</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                صورت‌وضعیت دوره ۱۳ ارسال شده، در انتظار تأیید کارفرما (مبلغ: ۱۲۴ میلیارد تومان)
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
