// procurement-new-view.tsx — Purchase request creation form
// Required fields: شرح دقیق، مقدار، محل مصرف، درصد سفارش، مشخصات فنی، وندور
"use client";
import { useState, useMemo } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { ValidatedInput } from "../validated-input";
import { JalaliDatePicker } from "../jalali-date-picker";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowRight,
  ShoppingCart,
  Plus,
  Trash2,
  Save,
  Send,
  Package,
  MapPin,
  Truck,
  FileText,
  Percent,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { vendors } from "@/lib/procurement-mock-data";
import {
  itemCategoryLabels,
  prPriorityLabels,
  defaultWorkflowSteps,
  type PurchaseRequestItem,
  type ItemCategory,
  type PRPriority,
} from "@/lib/procurement-types";
import { DEFAULT_UNITS } from "@/lib/contract-types";
import { faNum, faCurrency } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface DraftItem {
  id: string;
  row: number;
  name: string;            // شرح دقیق مصالح/تجهیزات
  category: ItemCategory;
  quantity: number;        // مقدار
  unit: string;
  unitPriceEstimate: number;
  totalPriceEstimate: number;
  consumptionLocation: string; // محل مصرف
  technicalSpec: string;       // مشخصات فنی
  vendorId: string;
  vendorName: string;
  orderPercent: number;        // درصد سفارش
  notes: string;
}

export function ProcurementNewView() {
  const { navigate } = useNav();
  const [saveMode, setSaveMode] = useState<"draft" | "submit">("draft");

  // Header info
  const [title, setTitle] = useState("");
  const [projectId, setProjectId] = useState("p-1001");
  const [priority, setPriority] = useState<PRPriority>("medium");
  const [neededByDate, setNeededByDate] = useState("");
  const [description, setDescription] = useState("");
  const [justification, setJustification] = useState("");

  // Items
  const [items, setItems] = useState<DraftItem[]>([
    createEmptyItem(1),
  ]);

  function createEmptyItem(row: number): DraftItem {
    return {
      id: `item-${Date.now()}-${row}`,
      row,
      name: "",
      category: "material",
      quantity: 0,
      unit: "عدد",
      unitPriceEstimate: 0,
      totalPriceEstimate: 0,
      consumptionLocation: "",
      technicalSpec: "",
      vendorId: "",
      vendorName: "",
      orderPercent: 0,
      notes: "",
    };
  }

  const projects = [
    { value: "p-1001", label: "برج مسکونی آرین" },
    { value: "p-1002", label: "مجتمع تجاری-اداری پاسارگاد" },
    { value: "p-1003", label: "بیمارستان تخصصی شفا" },
    { value: "p-1004", label: "ویلاهای لوکس هشتگرد" },
  ];

  const updateItem = (id: string, updates: Partial<DraftItem>) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id !== id) return it;
        const updated = { ...it, ...updates };
        // Recalculate total
        if (updates.quantity !== undefined || updates.unitPriceEstimate !== undefined) {
          updated.totalPriceEstimate = updated.quantity * updated.unitPriceEstimate;
        }
        return updated;
      })
    );
  };

  const addItem = () => {
    setItems((prev) => [...prev, createEmptyItem(prev.length + 1)]);
  };

  const removeItem = (id: string) => {
    setItems((prev) => {
      const filtered = prev.filter((it) => it.id !== id);
      // Re-number rows
      return filtered.map((it, idx) => ({ ...it, row: idx + 1 }));
    });
  };

  const totalEstimate = useMemo(
    () => items.reduce((acc, it) => acc + it.totalPriceEstimate, 0),
    [items]
  );

  // Validation
  const errors = useMemo(() => {
    const errs: string[] = [];
    if (!title.trim()) errs.push("عنوان درخواست");
    if (!neededByDate) errs.push("تاریخ نیاز");
    items.forEach((it, idx) => {
      if (!it.name.trim()) errs.push(`شرح ردیف ${idx + 1}`);
      if (it.quantity <= 0) errs.push(`مقدار ردیف ${idx + 1}`);
      if (!it.consumptionLocation.trim()) errs.push(`محل مصرف ردیف ${idx + 1}`);
      if (!it.technicalSpec.trim()) errs.push(`مشخصات فنی ردیف ${idx + 1}`);
      if (it.orderPercent < 0 || it.orderPercent > 100) errs.push(`درصد سفارش ردیف ${idx + 1} باید بین ۰ تا ۱۰۰ باشد`);
    });
    return errs;
  }, [title, neededByDate, items]);

  const canSubmit = errors.length === 0;

  const handleSubmit = (mode: "draft" | "submit") => {
    if (mode === "submit" && !canSubmit) {
      toast.error("لطفاً همه فیلدهای ضروری را تکمیل کنید", {
        description: errors.slice(0, 3).join("، ") + (errors.length > 3 ? "..." : ""),
      });
      return;
    }
    toast.success(
      mode === "draft" ? "درخواست به‌عنوان پیش‌نویس ذخیره شد" : "درخواست خرید ارسال شد",
      {
        description: `شماره: PR-1403-024 • ${faNum(items.length)} قلم • ${faCurrency(totalEstimate)}`,
      }
    );
    navigate("procurement");
  };

  return (
    <div className="space-y-6">
      <button
        onClick={() => navigate("procurement")}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowRight className="size-4 rotate-180" />
        بازگشت به فهرست درخواست‌های خرید
      </button>

      <PageHeader
        title="درخواست خرید جدید"
        subtitle="فرم زیر را برای ایجاد درخواست خرید تکمیل کنید. فیلدهای ستاره‌دار الزامی هستند."
        icon={ShoppingCart}
      />

      {/* Header info card */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">اطلاعات کلی درخواست</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <Label className="text-xs flex items-center gap-1">
                عنوان درخواست
                <span className="text-destructive">*</span>
              </Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: درخواست خرید بتن فاز ۲ اسکلت"
                className="mt-1"
              />
            </div>

            <div>
              <Label className="text-xs">پروژه مربوطه</Label>
              <Select value={projectId} onValueChange={setProjectId}>
                <SelectTrigger className="mt-1 w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((p) => (
                    <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs">اولویت</Label>
              <Select value={priority} onValueChange={(v) => setPriority(v as PRPriority)}>
                <SelectTrigger className="mt-1 w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(prPriorityLabels).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs flex items-center gap-1">
                تاریخ نیاز
                <span className="text-destructive">*</span>
              </Label>
              <div className="mt-1">
                <JalaliDatePicker
                  value={neededByDate}
                  onChange={setNeededByDate}
                  placeholder="انتخاب تاریخ از تقویم..."
                />
              </div>
            </div>

            <div className="sm:col-span-2">
              <Label className="text-xs">شرح درخواست</Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="توضیحات کلی درخواست خرید..."
                className="mt-1 min-h-16"
              />
            </div>

            <div className="sm:col-span-2">
              <Label className="text-xs">توجیه نیاز</Label>
              <Textarea
                value={justification}
                onChange={(e) => setJustification(e.target.value)}
                placeholder="چرا این خرید ضروری است؟"
                className="mt-1 min-h-16"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Items card */}
      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Package className="size-4 text-primary" />
            اقلام درخواست خرید
            <span className="text-xs text-muted-foreground font-normal">({faNum(items.length)} قلم)</span>
          </CardTitle>
          <Button size="sm" variant="outline" onClick={addItem}>
            <Plus className="size-4" />
            افزودن قلم
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {items.map((item, idx) => (
            <ItemEditor
              key={item.id}
              item={item}
              index={idx}
              onUpdate={(updates) => updateItem(item.id, updates)}
              onRemove={() => removeItem(item.id)}
              canRemove={items.length > 1}
            />
          ))}

          {items.length === 0 && (
            <div className="text-center py-8 text-muted-foreground text-sm">
              <Package className="size-10 mx-auto mb-2 opacity-30" />
              هنوز قلمی اضافه نشده است.
            </div>
          )}

          {/* Total */}
          {items.length > 0 && (
            <div className="p-4 rounded-lg bg-muted/40 flex items-center justify-between">
              <span className="text-sm font-semibold">جمع کل تخمینی:</span>
              <span className="text-lg font-bold text-primary">{faCurrency(totalEstimate)}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Workflow preview */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <CheckCircle2 className="size-4 text-success" />
            گردش کار پیش‌فرض
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {defaultWorkflowSteps.map((step, idx) => (
              <div key={idx} className="flex items-center gap-2 shrink-0">
                <div className="flex flex-col items-center gap-1.5 min-w-24">
                  <div className="size-8 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold">
                    {faNum(idx + 1)}
                  </div>
                  <span className="text-[11px] font-medium text-center leading-tight">{step.title}</span>
                </div>
                {idx < defaultWorkflowSteps.length - 1 && (
                  <div className="h-0.5 w-6 bg-border" />
                )}
              </div>
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground mt-3">
            پس از ارسال، درخواست از این مراحل عبور می‌کند. هر مرحله توسط مسئول مربوطه تأیید می‌شود.
          </p>
        </CardContent>
      </Card>

      {/* Validation errors */}
      {errors.length > 0 && (
        <Card className="border-destructive/30 bg-destructive/5">
          <CardContent className="p-4">
            <div className="flex items-start gap-2">
              <AlertCircle className="size-5 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-destructive mb-1">
                  {faNum(errors.length)} مورد نیازمند تکمیل:
                </p>
                <ul className="text-xs text-foreground/80 space-y-0.5 list-disc pr-4">
                  {errors.slice(0, 5).map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                  {errors.length > 5 && (
                    <li className="text-muted-foreground">+ {faNum(errors.length - 5)} مورد دیگر...</li>
                  )}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between gap-3 pt-4 border-t">
        <Button
          variant="outline"
          onClick={() => navigate("procurement")}
        >
          انصراف
        </Button>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            onClick={() => handleSubmit("draft")}
          >
            <Save className="size-4" />
            ذخیره پیش‌نویس
          </Button>
          <Button
            onClick={() => handleSubmit("submit")}
            disabled={!canSubmit}
          >
            <Send className="size-4" />
            ارسال برای بررسی
          </Button>
        </div>
      </div>
    </div>
  );
}

// ===== Item editor =====
function ItemEditor({
  item,
  index,
  onUpdate,
  onRemove,
  canRemove,
}: {
  item: DraftItem;
  index: number;
  onUpdate: (updates: Partial<DraftItem>) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  return (
    <div className="border border-border/60 rounded-lg p-4 space-y-4 bg-card">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="size-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
            {faNum(item.row)}
          </div>
          <span className="text-sm font-semibold">قلم {faNum(item.row)}</span>
          {item.name && (
            <span className="text-xs text-muted-foreground">- {item.name}</span>
          )}
        </div>
        {canRemove && (
          <Button
            variant="ghost"
            size="icon"
            className="size-7 text-muted-foreground hover:text-destructive"
            onClick={onRemove}
          >
            <Trash2 className="size-3.5" />
          </Button>
        )}
      </div>

      {/* Row 1: شرح + دسته */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="sm:col-span-2">
          <Label className="text-xs flex items-center gap-1">
            <FileText className="size-3" />
            شرح دقیق مصالح/تجهیزات
            <span className="text-destructive">*</span>
          </Label>
          <Input
            value={item.name}
            onChange={(e) => onUpdate({ name: e.target.value })}
            placeholder="مثال: بتن آماده M30 با پمپ"
            className="mt-1"
          />
        </div>
        <div>
          <Label className="text-xs">دسته‌بندی</Label>
          <Select
            value={item.category}
            onValueChange={(v) => onUpdate({ category: v as ItemCategory })}
          >
            <SelectTrigger className="mt-1 w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(itemCategoryLabels).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Row 2: مقدار + واحد + بهای واحد */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <Label className="text-xs flex items-center gap-1">
            <Package className="size-3" />
            مقدار
            <span className="text-destructive">*</span>
          </Label>
          <Input
            type="number"
            min={0}
            step="any"
            value={item.quantity || ""}
            onChange={(e) => onUpdate({ quantity: parseFloat(e.target.value) || 0 })}
            placeholder="0"
            className="mt-1 font-mono"
            dir="ltr"
          />
        </div>
        <div>
          <Label className="text-xs">واحد</Label>
          <Select
            value={item.unit}
            onValueChange={(v) => onUpdate({ unit: v })}
          >
            <SelectTrigger className="mt-1 w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {DEFAULT_UNITS.map((u) => (
                <SelectItem key={u} value={u}>{u}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">تخمین بهای واحد (ریال)</Label>
          <Input
            type="number"
            min={0}
            value={item.unitPriceEstimate || ""}
            onChange={(e) => onUpdate({ unitPriceEstimate: parseInt(e.target.value) || 0 })}
            placeholder="0"
            className="mt-1 font-mono"
            dir="ltr"
          />
        </div>
      </div>

      {/* محاسبه مبلغ کل */}
      {item.totalPriceEstimate > 0 && (
        <div className="text-xs text-muted-foreground bg-muted/40 p-2 rounded">
          مبلغ کل تخمینی: <span className="font-bold text-primary">{faCurrency(item.totalPriceEstimate)}</span>
        </div>
      )}

      {/* Row 3: محل مصرف */}
      <div>
        <Label className="text-xs flex items-center gap-1">
          <MapPin className="size-3" />
          محل مصرف
          <span className="text-destructive">*</span>
        </Label>
        <Input
          value={item.consumptionLocation}
          onChange={(e) => onUpdate({ consumptionLocation: e.target.value })}
          placeholder="مثال: طبقه ۱۸ - دال سقف، موتورخانه، کارگاه"
          className="mt-1"
        />
        <p className="text-[10px] text-muted-foreground mt-1">
          مکان دقیق استفاده از مصالح/تجهیزات را وارد کنید
        </p>
      </div>

      {/* Row 4: مشخصات فنی */}
      <div>
        <Label className="text-xs flex items-center gap-1">
          <FileText className="size-3" />
          مشخصات فنی
          <span className="text-destructive">*</span>
        </Label>
        <Textarea
          value={item.technicalSpec}
          onChange={(e) => onUpdate({ technicalSpec: e.target.value })}
          placeholder="مثال: عیار M30، اسامپ ۸-۱۲ سانتی‌متر، بدون کلرید، با گواهی طرح اختلاط، مطابق نشریه ۵۵۴"
          className="mt-1 min-h-20"
        />
        <p className="text-[10px] text-muted-foreground mt-1">
          مشخصات فنی دقیق شامل استاندارد، برند، مدل، ابعاد و سایر ملزومات
        </p>
      </div>

      {/* Row 5: وندور + درصد سفارش */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <Label className="text-xs flex items-center gap-1">
            <Truck className="size-3" />
            وندور پیشنهادی
          </Label>
          <Select
            value={item.vendorId}
            onValueChange={(v) => {
              const vendor = vendors.find((vd) => vd.id === v);
              onUpdate({
                vendorId: v,
                vendorName: vendor?.name ?? "",
              });
            }}
          >
            <SelectTrigger className="mt-1 w-full">
              <SelectValue placeholder="انتخاب وندور..." />
            </SelectTrigger>
            <SelectContent>
              {vendors.map((v) => (
                <SelectItem key={v.id} value={v.id}>
                  {v.name}
                  {v.previousOrders ? ` (${faNum(v.previousOrders)} سفارش قبلی)` : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {item.vendorName && (
            <p className="text-[10px] text-success mt-1 flex items-center gap-1">
              <CheckCircle2 className="size-3" />
              {item.vendorName}
            </p>
          )}
        </div>
        <div>
          <Label className="text-xs flex items-center gap-1">
            <Percent className="size-3" />
            درصد سفارش (۰ تا ۱۰۰)
          </Label>
          <div className="flex items-center gap-2 mt-1">
            <Input
              type="number"
              min={0}
              max={100}
              value={item.orderPercent}
              onChange={(e) => {
                let v = parseInt(e.target.value) || 0;
                if (v < 0) v = 0;
                if (v > 100) v = 100;
                onUpdate({ orderPercent: v });
              }}
              className="font-mono"
              dir="ltr"
            />
            <span className="text-sm shrink-0">٪</span>
          </div>
          <div className="mt-1.5">
            <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
              <span>۰٪</span>
              <span className="font-bold text-info">{faNum(item.orderPercent)}٪</span>
              <span>۱۰۰٪</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-info rounded-full transition-all"
                style={{ width: `${item.orderPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Row 6: توضیحات */}
      <div>
        <Label className="text-xs">توضیحات تکمیلی (اختیاری)</Label>
        <Textarea
          value={item.notes}
          onChange={(e) => onUpdate({ notes: e.target.value })}
          placeholder="توضیحات اضافی درباره این قلم..."
          className="mt-1 min-h-12"
        />
      </div>
    </div>
  );
}
