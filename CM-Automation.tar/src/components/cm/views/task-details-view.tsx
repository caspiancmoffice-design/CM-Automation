// task-details-view.tsx — Task details with multi-person roles, time tracking, workflow
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge, PriorityBadge } from "../status-badge";
import { UserAvatar } from "../user-avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  ArrowRight,
  Calendar,
  Clock,
  Paperclip,
  MessageSquare,
  CheckSquare,
  Square,
  Plus,
  Play,
  Pause,
  Send,
  FileText,
  GitBranch,
  CheckCircle2,
  Circle,
  Timer,
} from "lucide-react";
import { tasks, users } from "@/lib/mock-data";
import { faNum, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";

export function TaskDetailsView() {
  const { contextId, navigate } = useNav();
  const task = tasks.find((t) => t.id === contextId) ?? tasks[0];
  const [newComment, setNewComment] = useState("");
  const [tracking, setTracking] = useState(false);

  const completedSubtasks = task.subtasks.filter((s) => s.done).length;
  const subtaskPercent = task.subtasks.length > 0
    ? Math.round((completedSubtasks / task.subtasks.length) * 100)
    : 0;

  return (
    <div className="space-y-6">
      <button
        onClick={() => navigate("tasks")}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowRight className="size-4 rotate-180" />
        بازگشت به مدیریت وظایف
      </button>

      <PageHeader
        title={task.title}
        subtitle={`${task.projectName} • ایجاد شده در ${task.startDate}`}
        actions={
          <>
            <PriorityBadge priority={task.priority} />
            <StatusBadge status={task.status} />
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Description */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">شرح وظیفه</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed text-foreground/90">{task.description}</p>
              {task.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-4 pt-4 border-t">
                  {task.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[11px] px-2 py-1 rounded-md bg-muted text-muted-foreground"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Subtasks */}
          {task.subtasks.length > 0 && (
            <Card>
              <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
                <CardTitle className="text-base">زیروظایف</CardTitle>
                <span className="text-xs text-muted-foreground">
                  {faNum(completedSubtasks)} از {faNum(task.subtasks.length)} انجام شده
                </span>
              </CardHeader>
              <CardContent className="space-y-1">
                <Progress value={subtaskPercent} className="h-1.5 mb-3" />
                <ul className="space-y-1">
                  {task.subtasks.map((s) => (
                    <li key={s.id}>
                      <button className="w-full flex items-center gap-2 p-2 rounded hover:bg-accent/50 transition-colors text-right">
                        {s.done ? (
                          <CheckSquare className="size-4 text-success shrink-0" />
                        ) : (
                          <Square className="size-4 text-muted-foreground shrink-0" />
                        )}
                        <span
                          className={cn(
                            "text-sm",
                            s.done && "line-through text-muted-foreground"
                          )}
                        >
                          {s.title}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2 text-muted-foreground mt-2">
                  <Plus className="size-4" />
                  افزودن زیروظیفه
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Workflow */}
          {task.workflow && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <GitBranch className="size-4 text-primary" />
                  گردش کار
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="flex items-center gap-1 overflow-x-auto pb-2">
                  {task.workflow.steps.map((step, idx) => {
                    const isLast = idx === task.workflow!.steps.length - 1;
                    return (
                      <li key={idx} className="flex items-center gap-1 shrink-0">
                        <div className="flex flex-col items-center gap-2 min-w-24">
                          <div
                            className={cn(
                              "size-9 rounded-full flex items-center justify-center text-xs font-semibold",
                              step.status === "done" && "bg-success text-success-foreground",
                              step.status === "current" && "bg-primary text-primary-foreground ring-4 ring-primary/20",
                              step.status === "pending" && "bg-muted text-muted-foreground"
                            )}
                          >
                            {step.status === "done" ? (
                              <CheckCircle2 className="size-4" />
                            ) : (
                              faNum(idx + 1)
                            )}
                          </div>
                          <span
                            className={cn(
                              "text-[11px] font-medium text-center max-w-24 leading-tight",
                              step.status === "current" ? "text-primary" : step.status === "pending" ? "text-muted-foreground" : "text-foreground"
                            )}
                          >
                            {step.name}
                          </span>
                        </div>
                        {!isLast && (
                          <div
                            className={cn(
                              "h-0.5 w-12 -mt-6",
                              step.status === "done" ? "bg-success" : "bg-muted"
                            )}
                          />
                        )}
                      </li>
                    );
                  })}
                </ol>
              </CardContent>
            </Card>
          )}

          {/* Comments */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <MessageSquare className="size-4" />
                نظرات و بحث
                <span className="text-xs text-muted-foreground">({faNum(task.comments)})</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Sample comments */}
              <div className="flex gap-3">
                <UserAvatar name="مهندس مریم احمدی" size="sm" />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-semibold">مهندس مریم احمدی</span>
                    <span className="text-[11px] text-muted-foreground">۲ ساعت پیش</span>
                  </div>
                  <p className="text-sm leading-relaxed text-foreground/90">
                    بخش اول نقشه‌ها بررسی شد. نیاز به هماهنگی با مهندس محاسب برای مقاطع نبشی‌ها دارم.
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <UserAvatar name="مهندس رضا کریمی" size="sm" />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-semibold">مهندس رضا کریمی</span>
                    <span className="text-[11px] text-muted-foreground">۱ ساعت پیش</span>
                  </div>
                  <p className="text-sm leading-relaxed text-foreground/90">
                    تأیید شد. لطفاً با ایشان هماهنگ کنید و نتیجه را در همین بخش اعلام فرمایید.
                  </p>
                </div>
              </div>

              <Separator />

              {/* New comment */}
              <div className="flex gap-3">
                <UserAvatar name="مهندس رضا کریمی" size="sm" />
                <div className="flex-1 space-y-2">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="نظر خود را بنویسید..."
                    className="min-h-20 resize-none"
                  />
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Button variant="ghost" size="icon" className="size-8">
                        <Paperclip className="size-4" />
                      </Button>
                    </div>
                    <Button
                      size="sm"
                      disabled={!newComment.trim()}
                      onClick={() => {
                        setNewComment("");
                      }}
                    >
                      <Send className="size-4" />
                      ارسال نظر
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Time tracking */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Timer className="size-4 text-primary" />
                زمان‌سنجی
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-[11px] text-muted-foreground mb-1">زمان تخمینی</p>
                  <p className="text-lg font-bold">{faNum(task.estimatedHours)}<span className="text-xs font-normal text-muted-foreground"> ساعت</span></p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-[11px] text-muted-foreground mb-1">زمان صرف‌شده</p>
                  <p className="text-lg font-bold text-warning-foreground">{faNum(task.spentHours)}<span className="text-xs font-normal text-muted-foreground"> ساعت</span></p>
                </div>
              </div>
              <Progress
                value={(task.spentHours / task.estimatedHours) * 100}
                className="h-1.5"
              />
              <Button
                variant={tracking ? "destructive" : "default"}
                className="w-full"
                onClick={() => setTracking((v) => !v)}
              >
                {tracking ? <Pause className="size-4" /> : <Play className="size-4" />}
                {tracking ? "توقف ثبت زمان" : "شروع ثبت زمان"}
              </Button>
            </CardContent>
          </Card>

          {/* Assignees */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">اعضای وظیفه</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {task.assignees.map((a) => (
                <div key={a.userId} className="flex items-center gap-3">
                  <UserAvatar name={a.userName} size="sm" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{a.userName}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {faLabels[a.role as keyof typeof faLabels]} • مشارکت {faNum(a.participationPercent)}٪
                    </p>
                  </div>
                  <span className="text-[11px] text-muted-foreground shrink-0">
                    {faNum(a.timeSpentHours)} ساعت
                  </span>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full gap-2">
                <Plus className="size-4" />
                افزودن عضو
              </Button>
            </CardContent>
          </Card>

          {/* Properties */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">مشخصات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground flex items-center gap-1.5">
                  <Calendar className="size-3.5" />
                  تاریخ شروع
                </span>
                <span className="font-medium">{task.startDate}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground flex items-center gap-1.5">
                  <Calendar className="size-3.5" />
                  سررسید
                </span>
                <span className="font-medium">{task.dueDate}</span>
              </div>
              {task.completedAt && (
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground flex items-center gap-1.5">
                    <CheckCircle2 className="size-3.5" />
                    تکمیل شده
                  </span>
                  <span className="font-medium text-success">{task.completedAt}</span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground flex items-center gap-1.5">
                  <FileText className="size-3.5" />
                  پروژه
                </span>
                <button
                  className="font-medium text-primary hover:underline truncate max-w-40 text-right"
                  onClick={() => navigate("project-details", task.projectId)}
                >
                  {task.projectName}
                </button>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground flex items-center gap-1.5">
                  <Paperclip className="size-3.5" />
                  پیوست‌ها
                </span>
                <span className="font-medium">{faNum(task.attachments)} فایل</span>
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm">
              ویرایش
            </Button>
            <Button variant="outline" size="sm">
              کپی لینک
            </Button>
            <Button size="sm" className="col-span-2 bg-success hover:bg-success/90">
              <CheckCircle2 className="size-4" />
              تأیید انجام
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
