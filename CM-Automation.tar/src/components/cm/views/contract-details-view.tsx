// contract-details-view.tsx — Contract details with tabs
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { StatusBadge } from "../status-badge";
import { getContractIcon, getContractColor, ContractIcon } from "../contract-icon";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import {
  ArrowRight,
  Building2,
  User as UserIcon,
  Calendar,
  Wallet,
  Clock,
  FileText,
  Shield,
  AlertTriangle,
  Printer,
  Edit,
  Copy,
  CheckCircle2,
  ScrollText,
  MapPin,
  Phone,
  Mail,
  CreditCard,
  Hash,
  Percent,
  Scale,
  FileCheck,
  Download,
  ChevronDown,
  Loader2,
} from "lucide-react";
import { mockContracts } from "@/lib/contract-mock-data";
import { contractTemplates, contractTypeLabels, contractCategoryLabels, paymentMethodLabels, guaranteeTypeLabels, obligationCategoryLabels } from "@/lib/contract-templates";
import { faNum, faCurrency, faLabels } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";
import { exportContractToWord, exportContractToPdf, printContract } from "@/lib/contract-export";
import { toast } from "sonner";

export function ContractDetailsView() {
  const { contextId, navigate } = useNav();
  const [activeTab, setActiveTab] = useState("overview");
  const [exporting, setExporting] = useState<"word" | "pdf" | "print" | null>(null);
  const contract = mockContracts.find((c) => c.id === contextId) ?? mockContracts[0];
  const template = contractTemplates[contract.type];

  const handlePrint = async () => {
    setExporting("print");
    try {
      printContract(contract);
      toast.success("آماده چاپ", { description: "پنجره چاپ باز شد. می‌توانید به عنوان PDF ذخیره کنید." });
    } catch (e) {
      toast.error("خطا در چاپ", { description: "لطفاً دوباره تلاش کنید." });
    } finally {
      setTimeout(() => setExporting(null), 1500);
    }
  };

  const handleWordExport = async () => {
    setExporting("word");
    try {
      await exportContractToWord(contract);
      toast.success("فایل Word آماده شد", { description: `قرارداد ${contract.number} به‌عنوان .docx دانلود شد.` });
    } catch (e) {
      console.error(e);
      toast.error("خطا در ایجاد فایل Word", { description: "لطفاً دوباره تلاش کنید." });
    } finally {
      setExporting(null);
    }
  };

  const handlePdfExport = async () => {
    setExporting("pdf");
    try {
      await exportContractToPdf(contract);
      toast.success("آماده ذخیره PDF", { description: "در پنجره چاپ، گزینه «ذخیره به‌عنوان PDF» را انتخاب کنید." });
    } catch (e) {
      console.error(e);
      toast.error("خطا در ایجاد PDF", { description: "لطفاً دوباره تلاش کنید." });
    } finally {
      setTimeout(() => setExporting(null), 1500);
    }
  };

  return (
    <div className="space-y-6">
      <button
        onClick={() => navigate("contracts")}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowRight className="size-4 rotate-180" />
        بازگشت به فهرست قراردادها
      </button>

      <PageHeader
        title={contract.title}
        subtitle={`${contract.number} • ${contractTypeLabels[contract.type]} • ${contract.projectName}`}
        icon={template.iconKey ? undefined : ScrollText}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={handlePrint} disabled={exporting !== null}>
              {exporting === "print" ? <Loader2 className="size-4 animate-spin" /> : <Printer className="size-4" />}
              چاپ
            </Button>
            <Button variant="outline" size="sm" onClick={handleWordExport} disabled={exporting !== null}>
              {exporting === "word" ? <Loader2 className="size-4 animate-spin" /> : <FileText className="size-4" />}
              <span className="hidden sm:inline">Word</span>
            </Button>
            <Button variant="outline" size="sm" onClick={handlePdfExport} disabled={exporting !== null}>
              {exporting === "pdf" ? <Loader2 className="size-4 animate-spin" /> : <Download className="size-4" />}
              <span className="hidden sm:inline">PDF</span>
            </Button>
            <Button size="sm">
              <Edit className="size-4" />
              <span className="hidden sm:inline">ویرایش</span>
            </Button>
          </>
        }
      />

      {/* Top info cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Wallet className="size-3.5" />
              مبلغ کل
            </div>
            <p className="font-bold text-primary">{faCurrency(contract.financial.totalAmount)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Calendar className="size-3.5" />
              مدت قرارداد
            </div>
            <p className="font-bold">{faNum(contract.duration.totalMonths)} ماه</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              {contract.duration.startDate} تا {contract.duration.endDate}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Percent className="size-3.5" />
              پیش‌پرداخت
            </div>
            <p className="font-bold">{faNum(contract.financial.prepaymentPercent)}٪</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              {faCurrency(Math.round(contract.financial.totalAmount * contract.financial.prepaymentPercent / 100))}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Shield className="size-3.5" />
              تضمین
            </div>
            <p className="font-bold text-xs">{guaranteeTypeLabels[contract.financial.guaranteeType]}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              {faCurrency(contract.financial.guaranteeAmount)}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="w-full justify-start overflow-x-auto">
          <TabsTrigger value="overview">نمای کلی</TabsTrigger>
          <TabsTrigger value="parties">طرفین</TabsTrigger>
          <TabsTrigger value="financial">مالی و پرداخت</TabsTrigger>
          <TabsTrigger value="obligations">تعهدات</TabsTrigger>
          <TabsTrigger value="attachments">ضمائم</TabsTrigger>
          <TabsTrigger value="conditions">شرایط و جرایم</TabsTrigger>
          <TabsTrigger value="preview">پیش‌نمایش</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Subject card */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">موضوع قرارداد (ماده ۱)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start gap-3 mb-4">
                  <div className={cn("size-12 rounded-lg flex items-center justify-center shrink-0", getContractColor(contract.type))}>
                    <ContractIcon iconKey={template.iconKey} className="size-6" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm leading-relaxed">{contract.subject}</p>
                  </div>
                </div>
                <Separator className="my-3" />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5">
                      <Building2 className="size-3" />
                      پروژه
                    </p>
                    <p className="font-medium">{contract.projectName}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5">
                      <MapPin className="size-3" />
                      محل اجرا (ماده ۲)
                    </p>
                    <p className="font-medium">{contract.projectAddress}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5">
                      <Hash className="size-3" />
                      شماره قرارداد
                    </p>
                    <p className="font-medium font-mono">{contract.number}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5">
                      <FileText className="size-3" />
                      دسته‌بندی
                    </p>
                    <p className="font-medium">{contractCategoryLabels[contract.category]}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Duration & status */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="size-4 text-primary" />
                  وضعیت و زمان‌بندی
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">وضعیت فعلی</span>
                  <StatusBadge status={contract.status} />
                </div>
                <Separator />
                <div>
                  <p className="text-xs text-muted-foreground mb-1">تاریخ ابلاغ</p>
                  <p className="font-medium text-sm">{contract.issuedAt ?? "—"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">شروع</p>
                  <p className="font-medium text-sm">{contract.duration.startDate}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">پایان</p>
                  <p className="font-medium text-sm">{contract.duration.endDate}</p>
                </div>
                {contract.duration.phases && contract.duration.phases.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">مراحل اجرا</p>
                      <ul className="space-y-2">
                        {contract.duration.phases.map((phase, idx) => (
                          <li key={idx} className="text-xs">
                            <p className="font-medium">{phase.name}</p>
                            <p className="text-muted-foreground">
                              {faNum(phase.durationDays)} روز
                              {phase.description && ` • ${phase.description}`}
                            </p>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Special conditions preview */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">شرایط خصوصی (ماده ۱۰)</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {contract.specialConditions.map((cond, idx) => (
                  <li key={idx} className="flex gap-2 text-sm">
                    <span className="text-primary font-bold shrink-0">{faNum(idx + 1)}-</span>
                    <span className="text-foreground/90 leading-relaxed">{cond}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Parties */}
        <TabsContent value="parties" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Employer */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <div className="size-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                    <Building2 className="size-5" />
                  </div>
                  کارفرما
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <PartyInfo party={contract.employer} />
              </CardContent>
            </Card>

            {/* Contractor */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <div className={cn("size-9 rounded-lg flex items-center justify-center", getContractColor(contract.type))}>
                    <UserIcon className="size-5" />
                  </div>
                  پیمانکار
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <PartyInfo party={contract.contractor} />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Financial */}
        <TabsContent value="financial" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Amount summary */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">مبلغ و مالیات (ماده ۳)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground mb-1">مبلغ کل قرارداد</p>
                    <p className="text-xl font-bold text-primary">{faCurrency(contract.financial.totalAmount)}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground mb-1">مبلغ به حروف</p>
                    <p className="text-sm font-medium leading-snug">{contract.financial.totalAmountWords}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="p-3 rounded-lg border border-border/60">
                    <p className="text-xs text-muted-foreground">مالیات</p>
                    <p className="text-base font-bold mt-1">{faNum(contract.financial.taxPercent)}٪</p>
                  </div>
                  <div className="p-3 rounded-lg border border-border/60">
                    <p className="text-xs text-muted-foreground">بیمه</p>
                    <p className="text-base font-bold mt-1">{faNum(contract.financial.insurancePercent)}٪</p>
                  </div>
                  <div className="p-3 rounded-lg border border-border/60">
                    <p className="text-xs text-muted-foreground">سپرده حسن انجام</p>
                    <p className="text-base font-bold mt-1">{faNum(contract.financial.retentionPercent)}٪</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment method */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">نحوه پرداخت (ماده ۶)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">روش پرداخت</p>
                  <p className="text-sm font-medium">{paymentMethodLabels[contract.financial.paymentMethod]}</p>
                </div>
                <Separator />
                <div>
                  <p className="text-xs text-muted-foreground mb-1">زمان‌بندی پرداخت</p>
                  <p className="text-xs leading-relaxed">{contract.financial.paymentSchedule}</p>
                </div>
                {contract.financial.prepaymentPercent > 0 && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">پیش‌پرداخت</p>
                      <p className="text-sm font-bold text-primary">
                        {faNum(contract.financial.prepaymentPercent)}٪ ({faCurrency(Math.round(contract.financial.totalAmount * contract.financial.prepaymentPercent / 100))})
                      </p>
                      {contract.financial.prepaymentConditions && (
                        <p className="text-[11px] text-muted-foreground mt-1">{contract.financial.prepaymentConditions}</p>
                      )}
                    </div>
                  </>
                )}
                {contract.financial.retentionReleaseMonths > 0 && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">آزادسازی سپرده</p>
                      <p className="text-sm font-medium">{faNum(contract.financial.retentionReleaseMonths)} ماه پس از تحویل قطعی</p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Payment milestones */}
          {contract.financial.milestones.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">مراحل پرداخت</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {contract.financial.milestones.map((m, idx) => (
                    <div key={m.id} className="flex items-center gap-3 p-3 rounded-lg border border-border/60">
                      <div className="size-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold shrink-0">
                        {faNum(idx + 1)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{m.title}</p>
                        <p className="text-[11px] text-muted-foreground">{m.condition}</p>
                      </div>
                      <div className="text-left shrink-0">
                        <p className="text-base font-bold text-primary">{faNum(m.percent)}٪</p>
                        <p className="text-[11px] text-muted-foreground">
                          {faCurrency(Math.round(contract.financial.totalAmount * m.percent / 100))}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Guarantee */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="size-4 text-primary" />
                تضمین انجام تعهدات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">نوع تضمین</p>
                  <p className="text-sm font-medium">{guaranteeTypeLabels[contract.financial.guaranteeType]}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">مبلغ تضمین</p>
                  <p className="text-sm font-bold">{faCurrency(contract.financial.guaranteeAmount)}</p>
                </div>
                {contract.financial.guaranteeDetails && (
                  <div className="sm:col-span-2">
                    <p className="text-xs text-muted-foreground mb-1">جزئیات</p>
                    <p className="text-sm">{contract.financial.guaranteeDetails}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Obligations */}
        <TabsContent value="obligations" className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <UserIcon className="size-4 text-primary" />
                تعهدات پیمانکار (ماده ۸)
                <span className="text-xs text-muted-foreground font-normal">({faNum(contract.contractorObligations.length)} بند)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2.5">
                {contract.contractorObligations.map((ob) => (
                  <li key={ob.id} className="flex gap-3 text-sm p-2.5 rounded-lg hover:bg-accent/30 transition-colors">
                    <span className="text-primary font-bold text-xs shrink-0 mt-0.5">{ob.code}</span>
                    <div className="flex-1 min-w-0">
                      <p className="leading-relaxed">{ob.text}</p>
                      <span className="inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                        {obligationCategoryLabels[ob.category] ?? ob.category}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="size-4 text-primary" />
                تعهدات کارفرما (ماده ۹)
                <span className="text-xs text-muted-foreground font-normal">({faNum(contract.employerObligations.length)} بند)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2.5">
                {contract.employerObligations.map((ob) => (
                  <li key={ob.id} className="flex gap-3 text-sm p-2.5 rounded-lg hover:bg-accent/30 transition-colors">
                    <span className="text-primary font-bold text-xs shrink-0 mt-0.5">{ob.code}</span>
                    <div className="flex-1 min-w-0">
                      <p className="leading-relaxed">{ob.text}</p>
                      <span className="inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                        {obligationCategoryLabels[ob.category] ?? ob.category}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Attachments */}
        <TabsContent value="attachments" className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <FileCheck className="size-4 text-primary" />
                ضمائم قرارداد (ماده ۴)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="divide-y">
                {contract.attachments.map((att, idx) => (
                  <li key={att.id} className="flex items-center gap-3 py-3">
                    <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <FileText className="size-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">
                        {att.title}
                        {att.required && (
                          <span className="text-[10px] text-destructive mr-1">*</span>
                        )}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {att.fileName ?? "فایل پیوست نشده"}
                      </p>
                    </div>
                    <Button variant="outline" size="sm" className="shrink-0">
                      <FileText className="size-3.5" />
                      مشاهده
                    </Button>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Conditions & Penalties */}
        <TabsContent value="conditions" className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <AlertTriangle className="size-4 text-warning-foreground" />
                جرایم و تأخیرات (ماده ۱۴)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-lg bg-destructive/5">
                  <p className="text-xs text-muted-foreground mb-1">جریمه تأخیر روزانه</p>
                  <p className="text-base font-bold text-destructive">{faCurrency(contract.penalties.delayPenaltyPerDay)}</p>
                </div>
                {contract.penalties.delayPenaltyMaxDays && (
                  <div className="p-3 rounded-lg bg-warning/5">
                    <p className="text-xs text-muted-foreground mb-1">حداکثر روز جریمه</p>
                    <p className="text-base font-bold text-warning-foreground">{faNum(contract.penalties.delayPenaltyMaxDays)} روز</p>
                  </div>
                )}
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground mb-1">حداکثر تأخیر مجاز</p>
                  <p className="text-base font-bold">{faNum(contract.penalties.delayMaxPercent)}٪</p>
                </div>
              </div>
              {contract.penalties.delayPenaltyAfterMax && (
                <div className="text-sm">
                  <span className="text-muted-foreground">جریمه پس از حداکثر: </span>
                  <span className="font-bold text-destructive">{faCurrency(contract.penalties.delayPenaltyAfterMax)}</span>
                  <span className="text-muted-foreground"> در روز</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Scale className="size-4 text-destructive" />
                شرایط فسخ قرارداد (ماده ۱۳)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {contract.penalties.terminationConditions.map((cond, idx) => (
                  <li key={idx} className="flex gap-2 text-sm">
                    <span className="text-destructive shrink-0">•</span>
                    <span className="text-foreground/90 leading-relaxed">{cond}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">حل اختلاف (ماده ۱۲)</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed text-foreground/90">{contract.disputeResolution}</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Preview */}
        <TabsContent value="preview" className="space-y-6">
          <ContractPreview contract={contract} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function PartyInfo({ party }: { party: import("@/lib/contract-types").ContractParty }) {
  return (
    <>
      <div>
        <p className="text-xs text-muted-foreground mb-0.5">نام / عنوان</p>
        <p className="font-medium">{party.name}</p>
        <p className="text-[11px] text-muted-foreground">
          {party.legalType === "company" ? "شخص حقوقی" : "شخص حقیقی"}
        </p>
      </div>
      {party.representative && (
        <div>
          <p className="text-xs text-muted-foreground mb-0.5">نماینده</p>
          <p className="font-medium text-sm">{party.representative}</p>
          {party.representativeNationalId && (
            <p className="text-[11px] text-muted-foreground">کدملی: {party.representativeNationalId}</p>
          )}
        </div>
      )}
      {party.nationalId && (
        <div>
          <p className="text-xs text-muted-foreground mb-0.5">{party.legalType === "company" ? "شناسه ملی" : "کدملی"}</p>
          <p className="font-mono text-sm" dir="ltr">{party.nationalId}</p>
        </div>
      )}
      {party.registrationNumber && (
        <div>
          <p className="text-xs text-muted-foreground mb-0.5">شماره ثبت</p>
          <p className="font-mono text-sm">{party.registrationNumber}</p>
        </div>
      )}
      <div>
        <p className="text-xs text-muted-foreground mb-0.5 flex items-center gap-1">
          <MapPin className="size-3" />
          نشانی
        </p>
        <p className="text-sm leading-relaxed">{party.address}</p>
      </div>
      {party.phone && (
        <div>
          <p className="text-xs text-muted-foreground mb-0.5 flex items-center gap-1">
            <Phone className="size-3" />
            تلفن
          </p>
          <p className="text-sm font-mono" dir="ltr">{party.phone}</p>
        </div>
      )}
      {party.email && (
        <div>
          <p className="text-xs text-muted-foreground mb-0.5 flex items-center gap-1">
            <Mail className="size-3" />
            ایمیل
          </p>
          <p className="text-sm font-mono" dir="ltr">{party.email}</p>
        </div>
      )}
      {party.iban && (
        <div>
          <p className="text-xs text-muted-foreground mb-0.5 flex items-center gap-1">
            <CreditCard className="size-3" />
            شماره شبا
          </p>
          <p className="text-sm font-mono" dir="ltr">{party.iban}</p>
        </div>
      )}
    </>
  );
}

function ContractPreview({ contract }: { contract: import("@/lib/contract-types").Contract }) {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div className="bg-background p-6 lg:p-10 print:p-8 print:shadow-none" dir="rtl" id="contract-print-area">
          {/* Header */}
          <div className="text-center mb-8 pb-6 border-b-2 border-primary/20">
            <p className="text-sm text-muted-foreground mb-1">به نام خدا</p>
            <h1 className="text-2xl font-bold mb-1">قرارداد مقاطعه‌کاری</h1>
            <p className="text-base">{contractTypeLabels[contract.type]}</p>
            <p className="text-sm text-muted-foreground mt-2">
              شماره: <span className="font-mono">{contract.number}</span>
            </p>
          </div>

          {/* Moafegatnameh */}
          <div className="mb-6">
            <h2 className="font-bold mb-2">موافقت‌نامه</h2>
            <p className="text-sm leading-loose text-foreground/90">
              موافقت‌نامه حاضر، همراه با اسناد و مدارک موضوع ماده ۱ آن، که مجموعه‌ای غیرقابل تفکیک است و از این پس قرارداد نامیده می‌شود، که بر اساس ماده ۱۰ قانون مدنی جمهوری اسلامی ایران نیز می‌باشد؛ در تاریخ {contract.issuedAt ?? contract.createdAt} بین{" "}
              <strong>{contract.employer.name}</strong>
              {contract.employer.representative && ` به نمایندگی ${contract.employer.representative}`}
              {" "}به نشانی: {contract.employer.address} که از این پس <strong>کارفرما</strong> نامیده می‌شود و{" "}
              <strong>{contract.contractor.name}</strong>
              {contract.contractor.representative && ` به نمایندگی ${contract.contractor.representative}`}
              {" "}به نشانی: {contract.contractor.address} از طرف دیگر که <strong>پیمانکار</strong> نامیده می‌شود، مطابق با شرایط و مشخصات ذیل منعقد می‌گردد.
            </p>
          </div>

          {/* Article 1: Subject */}
          <ArticleBlock number="۱" title="موضوع قرارداد">
            {contract.subject}
          </ArticleBlock>

          {/* Article 2: Location */}
          <ArticleBlock number="۲" title="محل اجرا">
            پروژه {contract.projectName} واقع در {contract.projectAddress}
          </ArticleBlock>

          {/* Article 3: Amount */}
          <ArticleBlock number="۳" title="مبلغ قرارداد">
            مبلغ کل: <strong>{faNum(contract.financial.totalAmount)} ریال</strong> معادل {contract.financial.totalAmountWords}
          </ArticleBlock>

          {/* Article 4: Attachments */}
          <ArticleBlock number="۴" title="ضمائم قرارداد">
            <ul className="list-disc pr-5 space-y-1">
              {contract.attachments.map((att, idx) => (
                <li key={att.id} className="text-sm">
                  {faNum(idx + 1)}- {att.title}
                </li>
              ))}
            </ul>
          </ArticleBlock>

          {/* Article 5: Duration */}
          <ArticleBlock number="۵" title="مدت قرارداد">
            مدت زمان کل اجرای عملیات موضوع قرارداد <strong>{faNum(contract.duration.totalMonths)} ماه</strong> از تاریخ ابلاغ قرارداد می‌باشد.
            {contract.duration.extensionConditions && (
              <p className="mt-2 text-xs text-muted-foreground">{contract.duration.extensionConditions}</p>
            )}
            {contract.duration.phases && contract.duration.phases.length > 0 && (
              <ul className="mt-2 list-disc pr-5 space-y-1">
                {contract.duration.phases.map((phase, idx) => (
                  <li key={idx} className="text-sm">
                    {faNum(idx + 1)}- {phase.name}: {faNum(phase.durationDays)} روز
                    {phase.description && ` (${phase.description})`}
                  </li>
                ))}
              </ul>
            )}
          </ArticleBlock>

          {/* Article 6: Financial */}
          <ArticleBlock number="۶" title="مسائل مالی">
            <p><strong>۱-۶ پیش‌پرداخت:</strong> {faNum(contract.financial.prepaymentPercent)}٪ از مبلغ قرارداد
              {contract.financial.prepaymentConditions && ` (${contract.financial.prepaymentConditions})`}</p>
            <p className="mt-2"><strong>۲-۶ تضمین انجام تعهدات:</strong> {guaranteeTypeLabels[contract.financial.guaranteeType]} به مبلغ {faCurrency(contract.financial.guaranteeAmount)}
              {contract.financial.guaranteeDetails && ` (${contract.financial.guaranteeDetails})`}</p>
            <p className="mt-2"><strong>۳-۶ نحوه پرداخت:</strong> {paymentMethodLabels[contract.financial.paymentMethod]} - {contract.financial.paymentSchedule}</p>
            {contract.financial.milestones.length > 0 && (
              <ul className="mt-2 list-disc pr-5 space-y-1">
                {contract.financial.milestones.map((m, idx) => (
                  <li key={m.id} className="text-sm">
                    {faNum(idx + 1)}- {m.title}: {faNum(m.percent)}٪ - {m.condition}
                  </li>
                ))}
              </ul>
            )}
          </ArticleBlock>

          {/* Article 7: Retention */}
          <ArticleBlock number="۷" title="کسورات">
            صورت‌وضعیت کارکرد پیمانکار پس از کسر <strong>{faNum(contract.financial.retentionPercent)}٪</strong> بابت سپرده حسن انجام کار قابل پرداخت می‌باشد. سپده حسن انجام کار نزد کارفرما باقی خواهد ماند و پس از گذشت <strong>{faNum(contract.financial.retentionReleaseMonths)} ماه</strong> از تاریخ ارسال صورت‌وضعیت قطعی به پیمانکار قابل پرداخت خواهد بود.
          </ArticleBlock>

          {/* Article 8: Contractor obligations */}
          <ArticleBlock number="۸" title="تعهدات پیمانکار">
            <ol className="list-decimal pr-5 space-y-1.5">
              {contract.contractorObligations.map((ob) => (
                <li key={ob.id} className="text-sm leading-relaxed">
                  {ob.text}
                </li>
              ))}
            </ol>
          </ArticleBlock>

          {/* Article 9: Employer obligations */}
          <ArticleBlock number="۹" title="تعهدات کارفرما">
            <ol className="list-decimal pr-5 space-y-1.5">
              {contract.employerObligations.map((ob) => (
                <li key={ob.id} className="text-sm leading-relaxed">
                  {ob.text}
                </li>
              ))}
            </ol>
          </ArticleBlock>

          {/* Article 10: Special conditions */}
          <ArticleBlock number="۱۰" title="شرایط خصوصی">
            <ol className="list-decimal pr-5 space-y-1.5">
              {contract.specialConditions.map((cond, idx) => (
                <li key={idx} className="text-sm leading-relaxed">{cond}</li>
              ))}
            </ol>
          </ArticleBlock>

          {/* Article 11: Delivery */}
          <ArticleBlock number="۱۱" title="تحویل موقت و قطعی">
            در پایان کار و پس از تقاضای پیمانکار مراحل تحویل موقت انجام می‌شود و کارفرما پس از بازدید کارها، هرگاه عیب و نقصی که ناشی از کار پیمانکار باشد مشاهده ننماید کار را به صورت قطعی تحویل گرفته و طی صورتجلسه‌ای به پیمانکار ابلاغ می‌نماید.
          </ArticleBlock>

          {/* Article 12: Dispute */}
          <ArticleBlock number="۱۲" title="حل اختلاف">
            {contract.disputeResolution}
          </ArticleBlock>

          {/* Article 13: Termination */}
          <ArticleBlock number="۱۳" title="فسخ قرارداد">
            کارفرما می‌تواند در موارد ذیل قرارداد را بصورت یک‌طرفه فسخ نماید:
            <ol className="list-decimal pr-5 mt-2 space-y-1">
              {contract.penalties.terminationConditions.map((cond, idx) => (
                <li key={idx} className="text-sm">{cond}</li>
              ))}
            </ol>
          </ArticleBlock>

          {/* Article 14: Penalties */}
          <ArticleBlock number="۱۴" title="تأخیرات">
            چنانچه پیمانکار ظرف مدت مقرر در ماده ۵ پیمان عملیات به تعهدات خود عمل ننماید، به ازای هر یک روز تأخیر مبلغ <strong>{faNum(contract.penalties.delayPenaltyPerDay)} ریال</strong> به عنوان جریمه به حساب بدهکاری ایشان منظور و از مبلغ کل کارکرد پیمانکار کسر خواهد گردید.
            {contract.penalties.delayPenaltyMaxDays && (
              <p className="mt-1 text-xs">
                حداکثر {faNum(contract.penalties.delayPenaltyMaxDays)} روز با نرخ فوق و پس از آن به ازای هر روز {faNum(contract.penalties.delayPenaltyAfterMax ?? 0)} ریال.
              </p>
            )}
          </ArticleBlock>

          {/* Article 15: Addresses */}
          <ArticleBlock number="۱۵" title="نشانی طرفین">
            <p><strong>کارفرما:</strong> {contract.employer.name} - {contract.employer.address}</p>
            <p className="mt-2"><strong>پیمانکار:</strong> {contract.contractor.name} - {contract.contractor.address}</p>
          </ArticleBlock>

          {/* Article 16: Force Majeure */}
          <ArticleBlock number="۱۶" title="حوادث قهری">
            حوادث قهری و غیرمترقبه (جنگ اعم از اعلام شده یا نشده، انقلابات و اعتصابات عمومی، زلزله، سیل، طغیان‌های غیرعادی کار، بیماری‌های واگیردار و آتش‌سوزی‌های دامنه‌دار که ناشی از قصور پیمانکار نباشد) جزء حوادث قهری محسوب شده و به عنوان تأخیرات مجاز پیمانکار تلقی می‌گردد.
          </ArticleBlock>

          {/* Signatures */}
          <div className="mt-12 pt-6 border-t-2 border-border grid grid-cols-2 gap-8">
            <div className="text-center">
              <p className="text-sm font-bold mb-2">مهر و امضای کارفرما</p>
              <div className="h-24 border-2 border-dashed border-border/60 rounded-lg flex items-center justify-center text-xs text-muted-foreground">
                {contract.employer.name}
              </div>
            </div>
            <div className="text-center">
              <p className="text-sm font-bold mb-2">مهر و امضای پیمانکار</p>
              <div className="h-24 border-2 border-dashed border-border/60 rounded-lg flex items-center justify-center text-xs text-muted-foreground">
                {contract.contractor.name}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ArticleBlock({ number, title, children }: { number: string; title: string; children: React.ReactNode }) {
  return (
    <div className="mb-5">
      <h3 className="font-bold mb-2 text-sm bg-muted/40 inline-block px-2 py-1 rounded">
        ماده {number} – {title}
      </h3>
      <div className="text-sm leading-loose text-foreground/90 pr-2">{children}</div>
    </div>
  );
}
