// reports-view.tsx — Reports with charts and drill-down
"use client";
import { useState } from "react";
import { PageHeader } from "../page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart3,
  Download,
  Calendar,
  TrendingUp,
  TrendingDown,
  FolderKanban,
  Users,
  CheckCircle2,
  Clock,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
  RadialBarChart,
  RadialBar,
} from "recharts";
import { projects, productivityTrend, taskDistributionByStatus } from "@/lib/mock-data";
import { faNum, faCurrency } from "@/lib/fa-utils";
import { cn } from "@/lib/utils";

const teamPerformance = [
  { name: "مهندس مریم احمدی", score: 92, tasks: 18 },
  { name: "مهندس رضا کریمی", score: 87, tasks: 24 },
  { name: "امیر صادقی", score: 88, tasks: 15 },
  { name: "مهندس زهرا حسینی", score: 85, tasks: 12 },
  { name: "مهندس علی محمودی", score: 78, tasks: 14 },
  { name: "مهندس حسین رضایی", score: 81, tasks: 11 },
];

const monthlyProgress = [
  { month: "فروردین", planned: 25, actual: 22 },
  { month: "اردیبهشت", planned: 30, actual: 28 },
  { month: "خرداد", planned: 28, actual: 30 },
  { month: "تیر", planned: 35, actual: 31 },
  { month: "مرداد", planned: 32, actual: 33 },
  { month: "شهریور", planned: 38, actual: 36 },
  { month: "مهر", planned: 40, actual: 42 },
];

const projectBudget = projects.map((p) => ({
  name: p.name.length > 15 ? p.name.slice(0, 15) + "..." : p.name,
  budget: Math.round(p.budget / 1_000_000_000),
  spent: Math.round(p.spentBudget / 1_000_000_000),
}));

export function ReportsView() {
  const [period, setPeriod] = useState("month");
  const [projectFilter, setProjectFilter] = useState("all");

  return (
    <div className="space-y-6">
      <PageHeader
        title="گزارش‌ها و تحلیل‌ها"
        subtitle="تحلیل عملکرد پروژه‌ها، تیم‌ها و بهره‌وری سازمانی"
        icon={BarChart3}
        actions={
          <>
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-32">
                <Calendar className="size-3.5" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">هفته</SelectItem>
                <SelectItem value="month">ماه</SelectItem>
                <SelectItem value="quarter">فصل</SelectItem>
                <SelectItem value="year">سال</SelectItem>
              </SelectContent>
            </Select>
            <Button size="sm" variant="outline">
              <Download className="size-4" />
              خروجی
            </Button>
          </>
        }
      />

      {/* Top stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "میانگین بهره‌وری", value: "۸۴٪", change: "+۳٪", trend: "up", icon: TrendingUp, color: "text-success" },
          { label: "نرخ انجام به‌موقع", value: "۹۱٪", change: "+۵٪", trend: "up", icon: CheckCircle2, color: "text-success" },
          { label: "وظایف رسوبی", value: "۷ مورد", change: "-۲ مورد", trend: "down", icon: Clock, color: "text-warning-foreground" },
          { label: "پروژه‌های فعال", value: faNum(projects.filter(p => p.status === "active").length), change: "ثابت", trend: "flat", icon: FolderKanban, color: "text-primary" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-2">
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <stat.icon className={cn("size-4", stat.color)} />
              </div>
              <p className="text-2xl font-bold mb-1">{stat.value}</p>
              <p className={cn(
                "text-xs flex items-center gap-1",
                stat.trend === "up" ? "text-success" : stat.trend === "down" ? "text-destructive" : "text-muted-foreground"
              )}>
                {stat.trend === "up" && <TrendingUp className="size-3" />}
                {stat.trend === "down" && <TrendingDown className="size-3" />}
                {stat.change}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Productivity trend */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">روند بهره‌وری سازمانی</CardTitle>
            <CardDescription className="text-xs">مقایسه ۷ ماه اخیر</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={productivityTrend}>
                <defs>
                  <linearGradient id="reportProd" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  reversed
                />
                <YAxis
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  orientation="right"
                  domain={[60, 100]}
                  tickFormatter={(v) => `${faNum(v)}٪`}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    direction: "rtl",
                  }}
                  formatter={(v: number) => [`${faNum(v)}٪`, "بهره‌وری"]}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="var(--chart-1)"
                  strokeWidth={2.5}
                  fill="url(#reportProd)"
                  dot={{ r: 3, fill: "var(--chart-1)" }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Planned vs Actual */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">پیشرفت برنامه‌ریزی‌شده در برابر واقعی</CardTitle>
            <CardDescription className="text-xs">مقایسه ماهانه (درصد)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={monthlyProgress}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  reversed
                />
                <YAxis
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  orientation="right"
                  tickFormatter={(v) => faNum(v)}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    direction: "rtl",
                  }}
                  formatter={(v: number) => faNum(v)}
                />
                <Legend
                  formatter={(v) => <span style={{ fontSize: 11 }}>{v === "planned" ? "برنامه‌ریزی‌شده" : "واقعی"}</span>}
                  wrapperStyle={{ fontSize: 11 }}
                />
                <Line
                  type="monotone"
                  dataKey="planned"
                  stroke="var(--chart-2)"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={{ r: 3 }}
                />
                <Line
                  type="monotone"
                  dataKey="actual"
                  stroke="var(--chart-1)"
                  strokeWidth={2.5}
                  dot={{ r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Budget by project */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">بودجه پروژه‌ها</CardTitle>
            <CardDescription className="text-xs">مقایسه بودجه کل و هزینه شده (میلیارد تومان)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={projectBudget}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 10, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  reversed
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                  height={60}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickLine={false}
                  axisLine={false}
                  orientation="right"
                  tickFormatter={(v) => faNum(v)}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    direction: "rtl",
                  }}
                  formatter={(v: number) => `${faNum(v)} میلیارد تومان`}
                />
                <Legend
                  formatter={(v) => (
                    <span style={{ fontSize: 11 }}>
                      {v === "budget" ? "بودجه کل" : "هزینه شده"}
                    </span>
                  )}
                  wrapperStyle={{ fontSize: 11 }}
                />
                <Bar dataKey="budget" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="spent" fill="var(--chart-2)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Task distribution pie */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">وضعیت وظایف</CardTitle>
            <CardDescription className="text-xs">توزیع کلی</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={taskDistributionByStatus}
                  dataKey="value"
                  nameKey="label"
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={2}
                  stroke="none"
                >
                  {taskDistributionByStatus.map((entry, idx) => (
                    <Cell key={idx} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    direction: "rtl",
                  }}
                  formatter={(v: number) => faNum(v)}
                />
              </PieChart>
            </ResponsiveContainer>
            <ul className="space-y-1.5 mt-2">
              {taskDistributionByStatus.map((item) => (
                <li key={item.label} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="size-2.5 rounded-sm" style={{ background: item.color }} />
                    <span className="text-muted-foreground">{item.label}</span>
                  </div>
                  <span className="font-semibold">{faNum(item.value)}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Team performance table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Users className="size-4 text-primary" />
            عملکرد اعضای تیم
          </CardTitle>
          <CardDescription className="text-xs">رتبه‌بندی بر اساس بهره‌وری و تعداد وظایف</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs">
                <tr className="text-right">
                  <th className="px-4 py-3 font-semibold text-muted-foreground">رتبه</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">نام</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">امتیاز بهره‌وری</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">وظایف انجام‌شده</th>
                  <th className="px-4 py-3 font-semibold text-muted-foreground">نمودار</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {teamPerformance
                  .sort((a, b) => b.score - a.score)
                  .map((member, idx) => (
                    <tr key={member.name} className="hover:bg-accent/30 transition-colors">
                      <td className="px-4 py-3">
                        <span className={cn(
                          "inline-flex items-center justify-center size-6 rounded-full text-[11px] font-bold",
                          idx === 0 && "bg-amber-100 text-amber-700",
                          idx === 1 && "bg-slate-100 text-slate-700",
                          idx === 2 && "bg-orange-100 text-orange-700",
                          idx > 2 && "bg-muted text-muted-foreground"
                        )}>
                          {faNum(idx + 1)}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-medium">{member.name}</td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          "font-bold",
                          member.score >= 85 ? "text-success" : member.score >= 75 ? "text-warning-foreground" : "text-destructive"
                        )}>
                          {faNum(member.score)}٪
                        </span>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{faNum(member.tasks)} وظیفه</td>
                      <td className="px-4 py-3">
                        <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full"
                            style={{ width: `${member.score}%` }}
                          />
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
