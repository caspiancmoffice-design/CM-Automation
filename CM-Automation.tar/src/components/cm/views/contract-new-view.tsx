// contract-new-view.tsx — Parametric contract creation wizard
"use client";
import { useState, useMemo, useEffect } from "react";
import { useNav } from "@/lib/nav-context";
import { PageHeader } from "../page-header";
import { getContractIcon, getContractColor, ContractIcon } from "../contract-icon";
import { ValidatedInput, validateNationalId, validateCompanyNationalId, validatePhone, validateIban } from "../validated-input";
import { JalaliDatePicker } from "../jalali-date-picker";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowRight,
  ArrowLeft,
  Check,
  FileText,
  Building2,
  User as UserIcon,
  Wallet,
  Calendar,
  Shield,
  ListChecks,
  ChevronLeft,
  ChevronRight,
  Plus,
  Trash2,
  Eye,
  Save,
  X,
} from "lucide-react";
import { contractTemplates, contractTypeLabels, contractCategoryLabels, paymentMethodLabels, guaranteeTypeLabels, obligationCategoryLabels } from "@/lib/contract-templates";
import { DEFAULT_UNITS, type Contract, type ContractType, type PriceItem, type PaymentMilestone, type Obligation } from "@/lib/contract-types";
import { faNum, faCurrency } from "@/lib/fa-utils";
import { addMonthsToJalali, toPersianDigits } from "@/lib/jalali-utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const STEPS = [
  { id: 1, title: "انتخاب نوع قرارداد", icon: FileText },
  { id: 2, title: "مشخصات و موضوع", icon: ListChecks },
  { id: 3, title: "طرفین قرارداد", icon: Building2 },
  { id: 4, title: "مدت و زمان‌بندی", icon: Calendar },
  { id: 5, title: "مالی و پرداخت", icon: Wallet },
  { id: 6, title: "تعهدات پیمانکار", icon: Shield },
  { id: 7, title: "بهای پیمان (ردیف‌ها)", icon: ListChecks },
  { id: 8, title: "پیش‌نمایش و تأیید", icon: Eye },
];

interface DraftContract {
  type: ContractType;
  title: string;
  number: string;
  subject: string;
  projectName: string;
  projectAddress: string;
  employerName: string;
  employerType: "person" | "company";
  employerNationalId: string;
  employerAddress: string;
  employerRepresentative: string;
  contractorName: string;
  contractorType: "person" | "company";
  contractorNationalId: string;
  contractorAddress: string;
  contractorPhone: string;
  contractorIban: string;
  durationMonths: number;
  durationDays: number;
  startDate: string;
  endDate: string;
  totalAmount: number;
  totalAmountWords: string;
  prepaymentPercent: number;
  guaranteeType: "safteh" | "bank_guarantee" | "check" | "none";
  guaranteeAmount: number;
  retentionPercent: number;
  retentionReleaseMonths: number;
  paymentMethod: "monthly_statement" | "milestone" | "lump_sum" | "advance_balance";
  paymentSchedule: string;
  milestones: PaymentMilestone[];
  obligations: Obligation[];
  priceItems: PriceItem[];
  specialConditions: string[];
  delayPenaltyPerDay: number;
  delayMaxPercent: number;
  disputeResolution: string;
}

export function ContractNewView() {
  const { navigate } = useNav();
  const [step, setStep] = useState(1);
  const [selectedType, setSelectedType] = useState<ContractType | null>(null);

  // Initialize draft with template defaults when type selected
  const [draft, setDraft] = useState<DraftContract>(() => createInitialDraft("other"));

  const handleTypeSelect = (type: ContractType) => {
    setSelectedType(type);
    setDraft(createInitialDraft(type));
    setStep(2);
  };

  const updateDraft = (updates: Partial<DraftContract>) => {
    setDraft((prev) => ({ ...prev, ...updates }));
  };

  const canGoNext = useMemo(() => {
    switch (step) {
      case 1: return selectedType !== null;
      case 2: return draft.title && draft.subject && draft.projectName;
      case 3: return draft.employerName && draft.contractorName;
      case 4: return draft.durationMonths > 0 && draft.startDate && draft.endDate;
      case 5: return draft.totalAmount > 0;
      case 6: return draft.obligations.length > 0;
      case 7: return true;
      case 8: return true;
      default: return false;
    }
  }, [step, selectedType, draft]);

  const handleFinalSave = () => {
    toast.success("قرارداد با موفقیت ایجاد شد", {
      description: `${draft.title} - شماره ${draft.number}`,
    });
    navigate("contracts");
  };

  return (
    <div className="space-y-6">
      <button
        onClick={() => navigate("contracts")}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowRight className="size-4 rotate-180" />
        بازگشت به فهرست قراردادها
      </button>

      <PageHeader
        title="ایجاد قرارداد جدید"
        subtitle="با استفاده از قالب‌های آماده، به سرعت قرارداد پارامتریک بسازید"
        icon={FileText}
      />

      {/* Stepper */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between overflow-x-auto pb-2">
            {STEPS.map((s, idx) => {
              const isCurrent = step === s.id;
              const isPast = step > s.id;
              const Icon = s.icon;
              return (
                <div key={s.id} className="flex items-center shrink-0">
                  <button
                    onClick={() => s.id < step && setStep(s.id)}
                    disabled={s.id > step}
                    className={cn(
                      "flex items-center gap-2 px-2 py-1.5 rounded-lg transition-colors",
                      isCurrent && "bg-primary text-primary-foreground",
                      isPast && "text-primary cursor-pointer hover:bg-primary/10",
                      !isCurrent && !isPast && "text-muted-foreground"
                    )}
                  >
                    <div className={cn(
                      "size-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0",
                      isCurrent && "bg-primary-foreground text-primary",
                      isPast && "bg-primary text-primary-foreground",
                      !isCurrent && !isPast && "bg-muted text-muted-foreground"
                    )}>
                      {isPast ? <Check className="size-3.5" /> : faNum(s.id)}
                    </div>
                    <span className={cn(
                      "text-xs font-medium hidden sm:block whitespace-nowrap",
                      isCurrent && "text-primary-foreground"
                    )}>
                      {s.title}
                    </span>
                  </button>
                  {idx < STEPS.length - 1 && (
                    <ChevronLeft className={cn(
                      "size-4 mx-1 shrink-0 hidden sm:block",
                      isPast ? "text-primary" : "text-muted-foreground/40"
                    )} />
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Step content */}
      <div className="min-h-[400px]">
        {step === 1 && <Step1TypeSelect selected={selectedType} onSelect={handleTypeSelect} />}
        {step === 2 && <Step2Basic draft={draft} update={updateDraft} />}
        {step === 3 && <Step3Parties draft={draft} update={updateDraft} />}
        {step === 4 && <Step4Duration draft={draft} update={updateDraft} />}
        {step === 5 && <Step5Financial draft={draft} update={updateDraft} />}
        {step === 6 && <Step6Obligations draft={draft} update={updateDraft} />}
        {step === 7 && <Step7PriceItems draft={draft} update={updateDraft} />}
        {step === 8 && <Step8Preview draft={draft} />}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between gap-3 pt-4 border-t">
        <Button
          variant="outline"
          onClick={() => step > 1 ? setStep(step - 1) : navigate("contracts")}
        >
          <ChevronRight className="size-4" />
          {step > 1 ? "مرحله قبل" : "انصراف"}
        </Button>
        <div className="text-xs text-muted-foreground">
          مرحله {faNum(step)} از {faNum(STEPS.length)}
        </div>
        {step < STEPS.length ? (
          <Button
            onClick={() => setStep(step + 1)}
            disabled={!canGoNext}
          >
            مرحله بعد
            <ChevronLeft className="size-4" />
          </Button>
        ) : (
          <Button onClick={handleFinalSave} className="bg-success hover:bg-success/90">
            <Save className="size-4" />
            ثبت نهایی قرارداد
          </Button>
        )}
      </div>
    </div>
  );
}

function createInitialDraft(type: ContractType): DraftContract {
  const t = contractTemplates[type];
  return {
    type,
    title: t.title,
    number: "",
    subject: t.defaultSubject,
    projectName: "",
    projectAddress: "",
    employerName: "شرکت ساختمانی پارس آرین",
    employerType: "company",
    employerNationalId: "14006543210",
    employerAddress: "تهران - خیابان ولیعصر",
    employerRepresentative: "مهندس رضا کریمی",
    contractorName: "",
    contractorType: "person",
    contractorNationalId: "",
    contractorAddress: "",
    contractorPhone: "",
    contractorIban: "",
    durationMonths: t.recommendedDurationMonths,
    durationDays: 0,
    startDate: "", // Will be set via date picker
    endDate: "",   // Will auto-calculate from start date + duration
    totalAmount: 0,
    totalAmountWords: "",
    prepaymentPercent: t.defaultPrepaymentPercent,
    guaranteeType: "safteh",
    guaranteeAmount: 0,
    retentionPercent: t.defaultRetentionPercent,
    retentionReleaseMonths: 2,
    paymentMethod: t.defaultPaymentMethod,
    paymentSchedule: "",
    milestones: [],
    obligations: t.defaultObligations,
    priceItems: t.defaultPriceItems ?? [],
    specialConditions: t.defaultSpecialConditions,
    delayPenaltyPerDay: 500000,
    delayMaxPercent: 15,
    disputeResolution: "داوری - در صورت بروز اختلاف، طرفین داور منتخب خود را معرفی می‌کنند.",
  };
}

// ===== Step 1: Type selection =====
function Step1TypeSelect({ selected, onSelect }: {
  selected: ContractType | null;
  onSelect: (t: ContractType) => void;
}) {
  const [search, setSearch] = useState("");
  const types = Object.keys(contractTemplates) as ContractType[];
  const filtered = types.filter((t) =>
    !search || contractTypeLabels[t].includes(search) || contractTemplates[t].description.includes(search)
  );

  return (
    <div className="space-y-6">
      <div className="text-center max-w-2xl mx-auto">
        <h2 className="text-lg font-bold mb-2">نوع پیمانکار را انتخاب کنید</h2>
        <p className="text-sm text-muted-foreground">
          هر نوع قرارداد دارای قالب آماده با تعهدات و شرایط پیش‌فرض مختص به خود است. می‌توانید بعداً موارد را ویرایش کنید.
        </p>
      </div>

      <div className="relative max-w-md mx-auto">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="جستجوی نوع پیمانکار..."
          className="text-center"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((type) => {
          const t = contractTemplates[type];
          const Icon = getContractIcon(t.iconKey);
          const isSelected = selected === type;
          return (
            <button
              key={type}
              onClick={() => onSelect(type)}
              className={cn(
                "p-5 rounded-xl border-2 text-right transition-all group",
                isSelected
                  ? "border-primary bg-primary/5 shadow-md"
                  : "border-border hover:border-primary/40 hover:shadow-sm"
              )}
            >
              <div className={cn(
                "size-12 rounded-xl flex items-center justify-center mb-3 transition-colors",
                getContractColor(type),
                isSelected && "scale-110"
              )}>
                <Icon className="size-6" />
              </div>
              <h3 className="font-semibold text-sm mb-1">{contractTypeLabels[type]}</h3>
              <p className="text-[11px] text-muted-foreground line-clamp-2 leading-relaxed mb-3">
                {t.description}
              </p>
              <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                <span className="px-1.5 py-0.5 rounded bg-muted">
                  {faNum(t.recommendedDurationMonths)} ماه
                </span>
                <span className="px-1.5 py-0.5 rounded bg-muted">
                  پیش‌پرداخت {faNum(t.defaultPrepaymentPercent)}٪
                </span>
              </div>
              {isSelected && (
                <div className="mt-2 flex items-center gap-1 text-xs text-primary font-medium">
                  <Check className="size-3" />
                  انتخاب شده
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ===== Step 2: Basic info =====
function Step2Basic({ draft, update }: { draft: DraftContract; update: (u: Partial<DraftContract>) => void }) {
  const t = contractTemplates[draft.type];
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">مشخصات کلی قرارداد</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label className="text-xs">عنوان قرارداد</Label>
            <Input
              value={draft.title}
              onChange={(e) => update({ title: e.target.value })}
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-xs">شماره قرارداد</Label>
            <Input
              value={draft.number}
              onChange={(e) => update({ number: e.target.value })}
              placeholder="مثال: 1020/د/ق"
              className="mt-1 font-mono"
              dir="ltr"
            />
          </div>
        </div>

        <div>
          <Label className="text-xs">موضوع قرارداد (ماده ۱)</Label>
          <Textarea
            value={draft.subject}
            onChange={(e) => update({ subject: e.target.value })}
            className="mt-1 min-h-20"
          />
          <p className="text-[11px] text-muted-foreground mt-1">
            پیش‌فرض قالب: {t.defaultSubject}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label className="text-xs">نام پروژه (ماده ۲)</Label>
            <Input
              value={draft.projectName}
              onChange={(e) => update({ projectName: e.target.value })}
              placeholder="مثال: برج مسکونی آرین"
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-xs">محل اجرا</Label>
            <Input
              value={draft.projectAddress}
              onChange={(e) => update({ projectAddress: e.target.value })}
              placeholder="آدرس پروژه"
              className="mt-1"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Step 3: Parties =====
function Step3Parties({ draft, update }: { draft: DraftContract; update: (u: Partial<DraftContract>) => void }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Employer */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <div className="size-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <Building2 className="size-5" />
            </div>
            مشخصات کارفرما
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label className="text-xs">نام / عنوان</Label>
            <Input
              value={draft.employerName}
              onChange={(e) => update({ employerName: e.target.value })}
              className="mt-1"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">نوع شخص</Label>
              <Select
                value={draft.employerType}
                onValueChange={(v) => update({ employerType: v as "person" | "company" })}
              >
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="company">حقوقی</SelectItem>
                  <SelectItem value="person">حقیقی</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <ValidatedInput
              type={draft.employerType === "company" ? "companyNationalId" : "nationalId"}
              value={draft.employerNationalId}
              onChange={(v) => update({ employerNationalId: v })}
              label={draft.employerType === "company" ? "شناسه ملی" : "کدملی"}
              required
            />
          </div>
          <div>
            <Label className="text-xs">نماینده</Label>
            <Input
              value={draft.employerRepresentative}
              onChange={(e) => update({ employerRepresentative: e.target.value })}
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-xs">نشانی</Label>
            <Textarea
              value={draft.employerAddress}
              onChange={(e) => update({ employerAddress: e.target.value })}
              className="mt-1 min-h-16"
            />
          </div>
        </CardContent>
      </Card>

      {/* Contractor */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <div className={cn("size-9 rounded-lg flex items-center justify-center", getContractColor(draft.type))}>
              <UserIcon className="size-5" />
            </div>
            مشخصات پیمانکار
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label className="text-xs">نام / عنوان</Label>
            <Input
              value={draft.contractorName}
              onChange={(e) => update({ contractorName: e.target.value })}
              placeholder="نام پیمانکار"
              className="mt-1"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">نوع شخص</Label>
              <Select
                value={draft.contractorType}
                onValueChange={(v) => update({ contractorType: v as "person" | "company" })}
              >
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="person">حقیقی</SelectItem>
                  <SelectItem value="company">حقوقی</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <ValidatedInput
              type={draft.contractorType === "company" ? "companyNationalId" : "nationalId"}
              value={draft.contractorNationalId}
              onChange={(v) => update({ contractorNationalId: v })}
              label={draft.contractorType === "company" ? "شناسه ملی" : "کدملی"}
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <ValidatedInput
              type="phone"
              value={draft.contractorPhone}
              onChange={(v) => update({ contractorPhone: v })}
              label="تلفن همراه"
              required
            />
            <ValidatedInput
              type="iban"
              value={draft.contractorIban}
              onChange={(v) => update({ contractorIban: v })}
              label="شماره شبا"
            />
          </div>
          <div>
            <Label className="text-xs">نشانی</Label>
            <Textarea
              value={draft.contractorAddress}
              onChange={(e) => update({ contractorAddress: e.target.value })}
              className="mt-1 min-h-16"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ===== Step 4: Duration =====
function Step4Duration({ draft, update }: { draft: DraftContract; update: (u: Partial<DraftContract>) => void }) {
  // Auto-calculate end date whenever start date or duration changes
  useEffect(() => {
    if (draft.startDate && draft.durationMonths > 0) {
      const computed = addMonthsToJalali(draft.startDate, draft.durationMonths);
      if (computed && computed !== draft.endDate) {
        update({ endDate: computed });
      }
    } else if (!draft.startDate && draft.endDate) {
      update({ endDate: "" });
    }
  }, [draft.startDate, draft.durationMonths]);

  const handleStartDateChange = (date: string) => {
    update({ startDate: date });
    // End date will be auto-calculated by useEffect
  };

  const handleDurationChange = (months: number) => {
    update({ durationMonths: months });
    // End date will be auto-calculated by useEffect
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Calendar className="size-4 text-primary" />
          مدت و زمان‌بندی قرارداد (ماده ۵)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label className="text-xs">مدت قرارداد (ماه)</Label>
            <Input
              type="number"
              min={1}
              max={60}
              value={draft.durationMonths || ""}
              onChange={(e) => handleDurationChange(parseInt(e.target.value) || 0)}
              className="mt-1"
            />
            <p className="text-[11px] text-muted-foreground mt-1">
              پیشنهاد قالب: {faNum(contractTemplates[draft.type].recommendedDurationMonths)} ماه
            </p>
          </div>
          <div>
            <Label className="text-xs">یا مدت به روز (اختیاری)</Label>
            <Input
              type="number"
              min={0}
              max={1800}
              value={draft.durationDays || ""}
              onChange={(e) => update({ durationDays: parseInt(e.target.value) || 0 })}
              className="mt-1"
              placeholder="مثال: ۳۵"
            />
            <p className="text-[11px] text-muted-foreground mt-1">
              در صورت وارد کردن روز، این مقدار بر مدت ماه اولویت دارد
            </p>
          </div>
        </div>

        <Separator />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label className="text-xs flex items-center gap-1">
              <Calendar className="size-3" />
              تاریخ شروع
              <span className="text-destructive">*</span>
            </Label>
            <div className="mt-1">
              <JalaliDatePicker
                value={draft.startDate}
                onChange={handleStartDateChange}
                placeholder="انتخاب از تقویم..."
              />
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">
              تاریخ شروع از تقویم شمسی انتخاب می‌شود
            </p>
          </div>
          <div>
            <Label className="text-xs flex items-center gap-1">
              <Calendar className="size-3" />
              تاریخ پایان (محاسبه خودکار)
            </Label>
            <div className="mt-1">
              <div className={cn(
                "h-9 px-3 flex items-center rounded-md border font-mono text-sm",
                draft.endDate
                  ? "border-success/40 bg-success/5 text-success"
                  : "border-input bg-muted/30 text-muted-foreground"
              )}>
                {draft.endDate
                  ? toPersianDigits(draft.endDate)
                  : "پس از انتخاب تاریخ شروع محاسبه می‌شود"}
              </div>
            </div>
            <p className="text-[11px] text-success mt-1 flex items-center gap-1">
              <Check className="size-3" />
              {draft.durationMonths > 0 && draft.startDate
                ? `${faNum(draft.durationMonths)} ماه به تاریخ شروع اضافه شد`
                : "ابتدا مدت و تاریخ شروع را وارد کنید"}
            </p>
          </div>
        </div>

        <div className="p-3 rounded-lg bg-info/5 text-xs text-info border border-info/20">
          <p>💡 تاریخ شروع معمولاً از زمان ابلاغ قرارداد محاسبه می‌شود. در صورت تأخیر در تحویل زمین یا مصالح، این مدت صورتجلسه شده و اضافه می‌شود.</p>
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Step 5: Financial =====
function Step5Financial({ draft, update }: { draft: DraftContract; update: (u: Partial<DraftContract>) => void }) {
  const totalAfterPrepay = Math.round(draft.totalAmount * draft.prepaymentPercent / 100);
  const totalRetention = Math.round(draft.totalAmount * draft.retentionPercent / 100);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">مبلغ قرارداد (ماده ۳)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">مبلغ کل (ریال)</Label>
              <Input
                type="number"
                value={draft.totalAmount || ""}
                onChange={(e) => update({ totalAmount: parseInt(e.target.value) || 0 })}
                className="mt-1"
                dir="ltr"
              />
              <p className="text-[11px] text-primary mt-1 font-medium">
                {faCurrency(draft.totalAmount)}
              </p>
            </div>
            <div>
              <Label className="text-xs">مبلغ به حروف</Label>
              <Input
                value={draft.totalAmountWords}
                onChange={(e) => update({ totalAmountWords: e.target.value })}
                placeholder="مثال: سیصد میلیون ریال"
                className="mt-1"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Wallet className="size-4 text-primary" />
            مسائل مالی (ماده ۶)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <Label className="text-xs">درصد پیش‌پرداخت</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input
                  type="number"
                  value={draft.prepaymentPercent}
                  onChange={(e) => update({ prepaymentPercent: parseInt(e.target.value) || 0 })}
                  className="font-mono"
                  dir="ltr"
                />
                <span className="text-sm">٪</span>
              </div>
              <p className="text-[11px] text-muted-foreground mt-1">
                معادل: {faCurrency(totalAfterPrepay)}
              </p>
            </div>
            <div>
              <Label className="text-xs">درصد سپرده حسن انجام کار</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input
                  type="number"
                  value={draft.retentionPercent}
                  onChange={(e) => update({ retentionPercent: parseInt(e.target.value) || 0 })}
                  className="font-mono"
                  dir="ltr"
                />
                <span className="text-sm">٪</span>
              </div>
              <p className="text-[11px] text-muted-foreground mt-1">
                معادل: {faCurrency(totalRetention)}
              </p>
            </div>
            <div>
              <Label className="text-xs">مدت آزادسازی سپرده (ماه)</Label>
              <Input
                type="number"
                value={draft.retentionReleaseMonths}
                onChange={(e) => update({ retentionReleaseMonths: parseInt(e.target.value) || 0 })}
                className="mt-1 font-mono"
                dir="ltr"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">روش پرداخت</Label>
              <Select
                value={draft.paymentMethod}
                onValueChange={(v) => update({ paymentMethod: v as DraftContract["paymentMethod"] })}
              >
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(paymentMethodLabels).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">نوع تضمین</Label>
              <Select
                value={draft.guaranteeType}
                onValueChange={(v) => update({ guaranteeType: v as DraftContract["guaranteeType"] })}
              >
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(guaranteeTypeLabels).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">مبلغ تضمین (ریال)</Label>
              <Input
                type="number"
                value={draft.guaranteeAmount || ""}
                onChange={(e) => update({ guaranteeAmount: parseInt(e.target.value) || 0 })}
                className="mt-1"
                dir="ltr"
              />
              <p className="text-[11px] text-muted-foreground mt-1">
                {faCurrency(draft.guaranteeAmount)}
              </p>
            </div>
            <div>
              <Label className="text-xs">جریمه تأخیر روزانه (ریال)</Label>
              <Input
                type="number"
                value={draft.delayPenaltyPerDay}
                onChange={(e) => update({ delayPenaltyPerDay: parseInt(e.target.value) || 0 })}
                className="mt-1"
                dir="ltr"
              />
              <p className="text-[11px] text-muted-foreground mt-1">
                {faCurrency(draft.delayPenaltyPerDay)} در روز
              </p>
            </div>
          </div>

          <div>
            <Label className="text-xs">توضیح نحوه پرداخت</Label>
            <Textarea
              value={draft.paymentSchedule}
              onChange={(e) => update({ paymentSchedule: e.target.value })}
              placeholder="مثال: صورت‌وضعیت در مورخه ۱۳ و ۲۷ هر ماه"
              className="mt-1 min-h-16"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ===== Step 6: Obligations =====
function Step6Obligations({ draft, update }: { draft: DraftContract; update: (u: Partial<DraftContract>) => void }) {
  const [newText, setNewText] = useState("");
  const [newCategory, setNewCategory] = useState<string>("technical");

  const toggleObligation = (id: string) => {
    update({
      obligations: draft.obligations.map((o) =>
        o.id === id ? { ...o, ...{ _disabled: !(o as any)._disabled } } : o
      ) as any,
    });
  };

  const removeObligation = (id: string) => {
    update({ obligations: draft.obligations.filter((o) => o.id !== id) });
  };

  const addObligation = () => {
    if (!newText.trim()) return;
    const newId = `custom-${Date.now()}`;
    const code = `۸-${faNum(draft.obligations.length + 1)}`;
    update({
      obligations: [
        ...draft.obligations,
        { id: newId, code, text: newText, category: newCategory as any },
      ],
    });
    setNewText("");
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Shield className="size-4 text-primary" />
          تعهدات پیمانکار (ماده ۸)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-3 rounded-lg bg-info/5 text-xs text-info border border-info/20">
          <p>💡 تعهدات زیر از قالب «{contractTypeLabels[draft.type]}» بارگذاری شده‌اند. می‌توانید تعهدات را ویرایش، حذف یا اضافه کنید.</p>
        </div>

        <ul className="space-y-2">
          {draft.obligations.map((ob) => (
            <li
              key={ob.id}
              className="flex gap-3 p-3 rounded-lg border border-border/60 hover:border-primary/30 transition-colors"
            >
              <span className="text-primary font-bold text-xs shrink-0 mt-0.5">{ob.code}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm leading-relaxed">{ob.text}</p>
                <span className="inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                  {obligationCategoryLabels[ob.category] ?? ob.category}
                </span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="size-7 shrink-0 text-muted-foreground hover:text-destructive"
                onClick={() => removeObligation(ob.id)}
              >
                <Trash2 className="size-3.5" />
              </Button>
            </li>
          ))}
        </ul>

        <Separator />

        <div className="space-y-3">
          <p className="text-sm font-medium">افزودن تعهد جدید</p>
          <Select value={newCategory} onValueChange={setNewCategory}>
            <SelectTrigger className="w-full sm:w-48"><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(obligationCategoryLabels).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Textarea
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            placeholder="متن تعهد پیمانکار را وارد کنید..."
            className="min-h-20"
          />
          <Button onClick={addObligation} disabled={!newText.trim()} size="sm">
            <Plus className="size-4" />
            افزودن تعهد
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Step 7: Price items =====
function Step7PriceItems({ draft, update }: { draft: DraftContract; update: (u: Partial<DraftContract>) => void }) {
  const updateItem = (id: string, updates: Partial<PriceItem>) => {
    update({
      priceItems: draft.priceItems.map((p) =>
        p.id === id ? { ...p, ...updates, totalPrice: (updates.quantity ?? p.quantity) * (updates.unitPrice ?? p.unitPrice) } : p
      ),
    });
  };

  const addItem = () => {
    const newId = `pi-${Date.now()}`;
    update({
      priceItems: [
        ...draft.priceItems,
        { id: newId, code: faNum(draft.priceItems.length + 1), description: "", unit: contractTemplates[draft.type].defaultUnit, quantity: 0, unitPrice: 0, totalPrice: 0 },
      ],
    });
  };

  const removeItem = (id: string) => {
    update({ priceItems: draft.priceItems.filter((p) => p.id !== id) });
  };

  const total = draft.priceItems.reduce((acc, p) => acc + p.totalPrice, 0);

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-base">ردیف‌های بهای پیمان (پیوست ۱)</CardTitle>
        <Button size="sm" variant="outline" onClick={addItem}>
          <Plus className="size-4" />
          ردیف جدید
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs">
              <tr className="text-right">
                <th className="px-2 py-2 font-semibold text-muted-foreground">ردیف</th>
                <th className="px-2 py-2 font-semibold text-muted-foreground">شرح</th>
                <th className="px-2 py-2 font-semibold text-muted-foreground">واحد</th>
                <th className="px-2 py-2 font-semibold text-muted-foreground">مقدار</th>
                <th className="px-2 py-2 font-semibold text-muted-foreground">بهای واحد</th>
                <th className="px-2 py-2 font-semibold text-muted-foreground">مبلغ کل</th>
                <th className="px-2 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {draft.priceItems.map((item) => (
                <tr key={item.id} className="hover:bg-accent/20">
                  <td className="px-2 py-2 text-xs text-muted-foreground font-mono">{item.code}</td>
                  <td className="px-2 py-2 min-w-[200px]">
                    <Textarea
                      value={item.description}
                      onChange={(e) => updateItem(item.id, { description: e.target.value })}
                      className="h-auto min-h-[36px] py-1.5 text-xs resize-none"
                      placeholder="شرح کامل کار (مثال: آرماتوربندی پایه و ستون)"
                      rows={2}
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Select
                      value={item.unit}
                      onValueChange={(v) => updateItem(item.id, { unit: v })}
                    >
                      <SelectTrigger className="h-8 text-xs w-28">
                        <SelectValue placeholder="واحد" />
                      </SelectTrigger>
                      <SelectContent>
                        {DEFAULT_UNITS.map((u) => (
                          <SelectItem key={u} value={u}>{u}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      type="number"
                      min={0}
                      step="any"
                      value={item.quantity || ""}
                      onChange={(e) => updateItem(item.id, { quantity: parseFloat(e.target.value) || 0 })}
                      className="h-8 text-xs w-20 font-mono"
                      dir="ltr"
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      type="number"
                      min={0}
                      step="any"
                      value={item.unitPrice || ""}
                      onChange={(e) => updateItem(item.id, { unitPrice: parseInt(e.target.value) || 0 })}
                      className="h-8 text-xs w-28 font-mono"
                      dir="ltr"
                    />
                  </td>
                  <td className="px-2 py-2 text-xs font-bold text-primary whitespace-nowrap">
                    {faNum(item.totalPrice)}
                  </td>
                  <td className="px-2 py-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-7 text-muted-foreground hover:text-destructive"
                      onClick={() => removeItem(item.id)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </td>
                </tr>
              ))}
              {draft.priceItems.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-muted-foreground text-xs">
                    هنوز ردیفی اضافه نشده است. روی «ردیف جدید» کلیک کنید.
                  </td>
                </tr>
              )}
            </tbody>
            {draft.priceItems.length > 0 && (
              <tfoot className="bg-muted/30">
                <tr>
                  <td colSpan={5} className="px-2 py-3 text-left text-sm font-bold">جمع کل:</td>
                  <td className="px-2 py-3 text-sm font-bold text-primary whitespace-nowrap">
                    {faNum(total)} ریال
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
        <div className="p-3 rounded-lg bg-muted/40 text-xs text-muted-foreground">
          <p>💡 اگر مبلغ کل قرارداد را به صورت دستی در مرحله ۵ وارد نکرده‌اید، می‌توانید از جمع کل ردیف‌ها استفاده کنید.</p>
          {total > 0 && (
            <Button
              variant="outline"
              size="sm"
              className="mt-2"
              onClick={() => update({ totalAmount: total })}
            >
              استفاده از جمع کل ({faCurrency(total)})
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Step 8: Preview =====
function Step8Preview({ draft }: { draft: DraftContract }) {
  const t = contractTemplates[draft.type];

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className={cn("size-16 rounded-xl flex items-center justify-center shrink-0", getContractColor(draft.type))}>
              <ContractIcon iconKey={t.iconKey} className="size-8" />
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold">{draft.title}</h2>
              <p className="text-sm text-muted-foreground mt-1">
                {contractTypeLabels[draft.type]} • {contractCategoryLabels[t.category]}
              </p>
              {draft.number && (
                <p className="text-xs text-muted-foreground mt-1 font-mono">شماره: {draft.number}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">خلاصه قرارداد</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Row label="موضوع" value={draft.subject} />
            <Row label="پروژه" value={draft.projectName} />
            <Row label="محل اجرا" value={draft.projectAddress} />
            <Separator />
            <Row label="کارفرما" value={draft.employerName} />
            <Row label="پیمانکار" value={draft.contractorName} />
            <Separator />
            <Row label="مدت قرارداد" value={`${faNum(draft.durationMonths)} ماه`} />
            <Row label="شروع" value={draft.startDate} />
            <Row label="پایان" value={draft.endDate} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">خلاصه مالی</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Row label="مبلغ کل" value={faCurrency(draft.totalAmount)} bold />
            {draft.totalAmountWords && <Row label="به حروف" value={draft.totalAmountWords} />}
            <Separator />
            <Row label="پیش‌پرداخت" value={`${faNum(draft.prepaymentPercent)}٪ (${faCurrency(Math.round(draft.totalAmount * draft.prepaymentPercent / 100))})`} />
            <Row label="سپرده حسن انجام کار" value={`${faNum(draft.retentionPercent)}٪`} />
            <Row label="آزادسازی سپرده" value={`${faNum(draft.retentionReleaseMonths)} ماه`} />
            <Row label="روش پرداخت" value={paymentMethodLabels[draft.paymentMethod]} />
            <Separator />
            <Row label="نوع تضمین" value={guaranteeTypeLabels[draft.guaranteeType]} />
            <Row label="مبلغ تضمین" value={faCurrency(draft.guaranteeAmount)} />
            <Row label="جریمه تأخیر روزانه" value={faCurrency(draft.delayPenaltyPerDay)} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">تعهدات پیمانکار ({faNum(draft.obligations.length)} بند)</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-1.5">
            {draft.obligations.slice(0, 5).map((ob) => (
              <li key={ob.id} className="text-xs flex gap-2">
                <span className="text-primary font-bold shrink-0">{ob.code}</span>
                <span className="text-muted-foreground line-clamp-1">{ob.text}</span>
              </li>
            ))}
            {draft.obligations.length > 5 && (
              <li className="text-xs text-muted-foreground">
                + {faNum(draft.obligations.length - 5)} تعهد دیگر...
              </li>
            )}
          </ul>
        </CardContent>
      </Card>

      <div className="p-4 rounded-lg bg-success/5 border border-success/20">
        <p className="text-sm text-success font-medium flex items-center gap-2">
          <Check className="size-4" />
          قرارداد آماده ثبت است
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          با کلیک روی «ثبت نهایی قرارداد»، این قرارداد با وضعیت پیش‌نویس در سامانه ذخیره می‌شود و پس از تأیید مدیر قابل ابلاغ خواهد بود.
        </p>
      </div>
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="text-xs text-muted-foreground shrink-0">{label}</span>
      <span className={cn("text-sm", bold && "font-bold text-primary")}>{value || "—"}</span>
    </div>
  );
}
