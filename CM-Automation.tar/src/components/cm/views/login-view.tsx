// login-view.tsx — Login page
"use client";
import { useState } from "react";
import { useNav } from "@/lib/nav-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import {
  Building2,
  Lock,
  User,
  Eye,
  EyeOff,
  Shield,
  Zap,
  TrendingUp,
  Users,
} from "lucide-react";
import { toast } from "sonner";

export function LoginView() {
  const { navigate } = useNav();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState("r.karimi");
  const [password, setPassword] = useState("••••••••");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("خوش آمدید!", {
        description: "ورود با موفقیت انجام شد.",
      });
      navigate("dashboard");
    }, 900);
  };

  return (
    <div className="min-h-screen flex">
      {/* Branding side */}
      <div className="hidden lg:flex lg:w-1/2 bg-sidebar relative overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-10" />
        <div className="absolute -top-24 -left-24 size-96 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 size-96 rounded-full bg-chart-2/20 blur-3xl" />

        <div className="relative flex flex-col justify-between p-12 text-sidebar-foreground w-full">
          <div className="flex items-center gap-3">
            <div className="size-12 rounded-xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg">
              <Building2 className="size-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight">CM Automation</h1>
              <p className="text-xs text-sidebar-foreground/60">سامانه مدیریت هوشمند ساخت</p>
            </div>
          </div>

          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold leading-tight">
                پلتفرم یکپارچه مدیریت
                <br />
                پروژه‌های عمرانی
              </h2>
              <p className="text-sidebar-foreground/70 leading-relaxed max-w-md">
                مدیریت پروژه‌ها، اسناد، مکاتبات، قراردادها، بهره‌وری منابع انسانی و دانش
                سازمانی در یک بستر امن و هوشمند.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 max-w-md">
              {[
                { icon: Shield, title: "امنیت چندلایه", desc: "کنترل دسترسی مبتنی بر نقش" },
                { icon: Zap, title: "گردش کار هوشمند", desc: "اتوماسیون فرآیندها" },
                { icon: TrendingUp, title: "تحلیل بهره‌وری", desc: "شاخص‌های KPI دقیق" },
                { icon: Users, title: "کار تیمی", desc: "وظایف چندنفره با نقش مستقل" },
              ].map((f) => (
                <div
                  key={f.title}
                  className="p-4 rounded-xl bg-sidebar-accent/60 border border-sidebar-border/50 backdrop-blur-sm"
                >
                  <f.icon className="size-5 text-sidebar-primary mb-2" />
                  <p className="text-sm font-semibold">{f.title}</p>
                  <p className="text-[11px] text-sidebar-foreground/60 mt-0.5">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-sidebar-foreground/50">
            <span>© ۱۴۰۳ CM Automation</span>
            <span>نسخه ۱.۰.۰</span>
          </div>
        </div>
      </div>

      {/* Form side */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12 bg-background">
        <div className="w-full max-w-sm space-y-6">
          {/* Mobile logo */}
          <div className="lg:hidden flex flex-col items-center text-center gap-3 mb-6">
            <div className="size-14 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg">
              <Building2 className="size-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold">CM Automation</h1>
              <p className="text-xs text-muted-foreground">سامانه مدیریت هوشمند ساخت</p>
            </div>
          </div>

          <div className="space-y-1.5">
            <h2 className="text-2xl font-bold tracking-tight">ورود به حساب کاربری</h2>
            <p className="text-sm text-muted-foreground">
              برای دسترسی به سامانه، اطلاعات کاربری خود را وارد نمایید.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-medium">
                نام کاربری
              </Label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pr-9 h-11"
                  placeholder="نام کاربری خود را وارد کنید"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-sm font-medium">
                  رمز عبور
                </Label>
                <button
                  type="button"
                  className="text-xs text-primary hover:underline"
                  onClick={() => toast.info("لینک بازیابی ارسال شد")}
                >
                  فراموشی رمز؟
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pr-9 pl-9 h-11"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox id="remember" defaultChecked />
              <Label htmlFor="remember" className="text-xs text-muted-foreground cursor-pointer">
                مرا به خاطر بسپار (۳۰ روز)
              </Label>
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full h-11 text-sm font-semibold"
              disabled={loading}
            >
              {loading ? "در حال ورود..." : "ورود به سامانه"}
            </Button>
          </form>

          <Card className="bg-muted/40 border-dashed">
            <CardContent className="p-3 text-center text-xs text-muted-foreground leading-relaxed">
              دسترسی فقط برای کاربران مجاز سازمان‌های همکار امکان‌پذیر است.
              <br />
              برای دریافت حساب کاربری با مدیر سیستم تماس بگیرید.
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
