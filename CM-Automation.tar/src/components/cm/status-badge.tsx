// status-badge.tsx — Reusable status badge
"use client";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { faLabels, statusColors } from "@/lib/fa-utils";

export function StatusBadge({
  status,
  label,
  className,
}: {
  status: string;
  label?: string;
  className?: string;
}) {
  const text = label ?? faLabels[status as keyof typeof faLabels] ?? status;
  const colorClass = statusColors[status] ?? "bg-muted text-muted-foreground";
  return (
    <Badge
      variant="outline"
      className={cn("font-medium border-transparent rounded-md px-2 py-0.5", colorClass, className)}
    >
      {text}
    </Badge>
  );
}

export function PriorityBadge({ priority }: { priority: string }) {
  return <StatusBadge status={priority} />;
}
