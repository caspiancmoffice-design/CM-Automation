// entity-form-modal.tsx — Reusable modal for creating new entities
// (tasks, projects, correspondence, documents, etc.)
"use client";
import { useState, type ReactNode } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { JalaliDatePicker } from "./jalali-date-picker";
import { Check, Loader2, X, UserPlus } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

export interface FormField {
  name: string;
  label: string;
  type: "text" | "textarea" | "number" | "select" | "date" | "user" | "multiselect";
  placeholder?: string;
  required?: boolean;
  options?: { value: string; label: string }[];
  defaultValue?: string | number;
  helperText?: string;
  colSpan?: 1 | 2;
}

export interface EntityFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  icon?: ReactNode;
  fields: FormField[];
  onSubmit?: (data: Record<string, string | number>) => Promise<void> | void;
  submitLabel?: string;
  size?: "default" | "lg" | "xl";
}

export function EntityFormModal({
  open,
  onOpenChange,
  title,
  description,
  icon,
  fields,
  onSubmit,
  submitLabel = "ذخیره",
  size = "default",
}: EntityFormModalProps) {
  const [submitting, setSubmitting] = useState(false);
  const [values, setValues] = useState<Record<string, string | number>>(() => {
    const init: Record<string, string | number> = {};
    fields.forEach((f) => {
      if (f.defaultValue !== undefined) init[f.name] = f.defaultValue;
    });
    return init;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Validate required fields
    const missing = fields.filter((f) => f.required && !values[f.name]);
    if (missing.length > 0) {
      toast.error("لطفاً همه فیلدهای ضروری را پر کنید", {
        description: missing.map((f) => f.label).join("، "),
      });
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit?.(values);
      toast.success(`${title} با موفقیت ایجاد شد`);
      onOpenChange(false);
      // Reset form
      const reset: Record<string, string | number> = {};
      fields.forEach((f) => {
        if (f.defaultValue !== undefined) reset[f.name] = f.defaultValue;
      });
      setValues(reset);
    } catch (err) {
      console.error(err);
      toast.error("خطا در ایجاد", { description: "لطفاً دوباره تلاش کنید" });
    } finally {
      setSubmitting(false);
    }
  };

  const sizeClass = size === "xl" ? "max-w-4xl" : size === "lg" ? "max-w-3xl" : "max-w-xl";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`${sizeClass} max-h-[90vh] flex flex-col overflow-hidden`} dir="rtl">
        <DialogHeader className="shrink-0">
          <DialogTitle className="flex items-center gap-2 text-right">
            {icon}
            {title}
          </DialogTitle>
          {description && <DialogDescription className="text-right">{description}</DialogDescription>}
        </DialogHeader>

        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
          {/* Scrollable form body - native overflow instead of ScrollArea for mobile compatibility */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden pr-1 pb-2 min-h-0">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-1">
              {fields.map((field) => {
                const colSpan = field.colSpan === 2 ? "sm:col-span-2" : "";
                return (
                  <div key={field.name} className={`space-y-1.5 ${colSpan}`}>
                    <label className="text-xs font-medium flex items-center gap-1">
                      {field.label}
                      {field.required && <span className="text-destructive">*</span>}
                    </label>
                    <FieldInput
                      field={field}
                      value={values[field.name] ?? ""}
                      onChange={(v) => setValues((prev) => ({ ...prev, [field.name]: v }))}
                    />
                    {field.helperText && (
                      <p className="text-[10px] text-muted-foreground">{field.helperText}</p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Fixed footer - always visible, not covered by content */}
          <DialogFooter className="border-t pt-4 mt-2 shrink-0 bg-background">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={submitting}
              className="shrink-0"
            >
              <X className="size-4" />
              انصراف
            </Button>
            <Button type="submit" disabled={submitting} className="shrink-0">
              {submitting ? <Loader2 className="size-4 animate-spin" /> : <Check className="size-4" />}
              {submitting ? "در حال ذخیره..." : submitLabel}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function FieldInput({
  field,
  value,
  onChange,
}: {
  field: FormField;
  value: string | number;
  onChange: (v: string | number) => void;
}) {
  switch (field.type) {
    case "textarea":
      return (
        <Textarea
          value={value as string}
          onChange={(e) => onChange(e.target.value)}
          placeholder={field.placeholder}
          className="min-h-20 resize-y"
        />
      );
    case "number":
      return (
        <Input
          type="number"
          value={value as number}
          onChange={(e) => onChange(e.target.value)}
          placeholder={field.placeholder}
          dir="ltr"
          className="text-right"
        />
      );
    case "select":
      return (
        <Select value={value as string} onValueChange={onChange}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder={field.placeholder ?? "انتخاب کنید"} />
          </SelectTrigger>
          <SelectContent>
            {field.options?.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    case "date":
      return (
        <JalaliDatePicker
          value={value as string}
          onChange={(v) => onChange(v)}
          placeholder={field.placeholder ?? "انتخاب از تقویم..."}
        />
      );
    case "multiselect": {
      // value is comma-separated string of selected values
      const selected = (value as string)
        ? String(value).split(",").filter(Boolean)
        : [];
      const toggle = (v: string) => {
        const next = selected.includes(v)
          ? selected.filter((s) => s !== v)
          : [...selected, v];
        onChange(next.join(","));
      };
      return (
        <div className="border rounded-md p-3 max-h-48 overflow-y-auto">
          {field.options?.map((opt) => (
            <label
              key={opt.value}
              className="flex items-center gap-2 py-1.5 cursor-pointer hover:bg-accent/30 rounded px-2 transition-colors"
            >
              <Checkbox
                checked={selected.includes(opt.value)}
                onCheckedChange={() => toggle(opt.value)}
              />
              <span className="text-sm">{opt.label}</span>
            </label>
          ))}
          {selected.length > 0 && (
            <div className="mt-2 pt-2 border-t text-xs text-muted-foreground">
              {selected.length} نفر انتخاب شده
            </div>
          )}
        </div>
      );
    }
    default:
      return (
        <Input
          type="text"
          value={value as string}
          onChange={(e) => onChange(e.target.value)}
          placeholder={field.placeholder}
        />
      );
  }
}
