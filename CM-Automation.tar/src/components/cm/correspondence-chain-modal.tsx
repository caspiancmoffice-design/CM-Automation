// correspondence-chain-modal.tsx — Graphical horizontal timeline for correspondence chains
// Design based on reference image: alternating top/bottom cards, central timeline axis
"use client";
import { useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Calendar,
  User as UserIcon,
  Building2,
  ChevronLeft,
  Download,
  Loader2,
} from "lucide-react";
import { getCorrespondenceChain } from "@/lib/correspondence-chain";
import { toPersianDigits } from "@/lib/jalali-utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Correspondence } from "@/lib/types";

interface CorrespondenceChainModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  correspondences: Correspondence[];
  currentId: string;
  onSelect: (id: string) => void;
}

// Color schemes for inbound (green) and outbound (blue)
const COLOR_SCHEMES = {
  inbound: {
    bg: "bg-emerald-50",
    border: "border-emerald-200",
    dot: "bg-emerald-500",
    badge: "bg-emerald-500",
    icon: "text-emerald-600",
    label: "text-emerald-700",
    connector: "border-emerald-400",
    label_text: "وارده",
  },
  outbound: {
    bg: "bg-sky-50",
    border: "border-sky-200",
    dot: "bg-sky-500",
    badge: "bg-sky-500",
    icon: "text-sky-600",
    label: "text-sky-700",
    connector: "border-sky-400",
    label_text: "صادره",
  },
};

export function CorrespondenceChainModal({
  open,
  onOpenChange,
  correspondences,
  currentId,
  onSelect,
}: CorrespondenceChainModalProps) {
  const chain = useMemo(
    () => getCorrespondenceChain(correspondences, currentId),
    [correspondences, currentId]
  );

  const timelineRef = useRef<HTMLDivElement>(null);
  const [saving, setSaving] = useState(false);

  const handleSelect = (id: string) => {
    onSelect(id);
    onOpenChange(false);
  };

  const handleSaveImage = async () => {
    if (!timelineRef.current || chain.length <= 1) return;
    setSaving(true);
    try {
      // Use canvas API to draw the timeline manually
      // This avoids html2canvas issues with oklch color functions
      const cards = chain;
      const cardWidth = 200;
      const cardHeight = 170;
      const gap = 16;
      const timelineHeight = 40;
      const padding = 40;
      const totalWidth = cards.length * (cardWidth + gap) - gap + padding * 2;
      const totalHeight = cardHeight * 2 + timelineHeight + padding * 2 + 60; // +60 for title

      const canvas = document.createElement("canvas");
      const scale = 2; // 2x for high DPI
      canvas.width = totalWidth * scale;
      canvas.height = totalHeight * scale;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Canvas not supported");

      ctx.scale(scale, scale);

      // Background
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, totalWidth, totalHeight);

      // Title
      ctx.fillStyle = "#1a5f4a";
      ctx.font = "bold 20px Vazirmatn, sans-serif";
      ctx.textAlign = "right";
      ctx.direction = "rtl";
      ctx.fillText(`زنجیره مکاتبات (${toPersianDigits(cards.length)} نامه)`, totalWidth - padding, 30);

      // Timeline axis (horizontal line in center)
      const axisY = padding + 60 + cardHeight + timelineHeight / 2;
      const startX = padding;
      const endX = totalWidth - padding;

      ctx.strokeStyle = "#9ca3af";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(startX, axisY);
      ctx.lineTo(endX, axisY);
      ctx.stroke();

      // Arrow at end (left side in RTL)
      ctx.beginPath();
      ctx.moveTo(endX, axisY);
      ctx.lineTo(endX - 8, axisY - 4);
      ctx.lineTo(endX - 8, axisY + 4);
      ctx.closePath();
      ctx.fillStyle = "#9ca3af";
      ctx.fill();

      // Draw each card
      cards.forEach((letter, idx) => {
        const isInbound = letter.direction === "inbound";
        const isCurrent = letter.id === currentId;
        const isTop = idx % 2 === 0;

        // Colors
        const colors = isInbound
          ? { bg: "#ecfdf5", border: "#a7f3d0", dot: "#10b981", badge: "#10b981", label: "#047857" }
          : { bg: "#f0f9ff", border: "#bae6fd", dot: "#0ea5e9", badge: "#0ea5e9", label: "#0369a1" };

        const cardX = padding + idx * (cardWidth + gap);
        const cardW = cardWidth - 10;

        // Dashed connector
        ctx.strokeStyle = isInbound ? "#34d399" : "#38bdf8";
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        const dotX = cardX + cardW / 2;
        if (isTop) {
          ctx.moveTo(dotX, padding + 60 + cardHeight);
          ctx.lineTo(dotX, axisY);
        } else {
          ctx.moveTo(dotX, axisY);
          ctx.lineTo(dotX, padding + 60 + cardHeight + timelineHeight);
        }
        ctx.stroke();
        ctx.setLineDash([]);

        // Dot on timeline
        ctx.fillStyle = colors.dot;
        ctx.beginPath();
        ctx.arc(dotX, axisY, isCurrent ? 10 : 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.stroke();
        if (isCurrent) {
          ctx.strokeStyle = "#1a5f4a";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(dotX, axisY, 12, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Card position
        const cardY = isTop
          ? padding + 60
          : padding + 60 + cardHeight + timelineHeight;

        // Card background
        ctx.fillStyle = colors.bg;
        ctx.strokeStyle = isCurrent ? "#1a5f4a" : colors.border;
        ctx.lineWidth = isCurrent ? 2 : 1;
        roundRect(ctx, cardX, cardY, cardW, cardHeight, 8);
        ctx.fill();
        ctx.stroke();

        // Number badge
        ctx.fillStyle = colors.badge;
        ctx.beginPath();
        ctx.arc(cardX + 16, cardY + 16, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 12px Vazirmatn, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(toPersianDigits(idx + 1), cardX + 16, cardY + 20);

        // Direction label
        ctx.fillStyle = colors.label;
        ctx.font = "10px Vazirmatn, sans-serif";
        ctx.textAlign = "right";
        ctx.fillText(colors.label === "#047857" ? "↓ وارده" : "↑ صادره", cardX + cardW - 8, cardY + 20);

        // Person name
        const personName = isInbound ? (letter.senderName || letter.from) : (letter.receiverName || letter.to);
        const personRole = isInbound ? letter.senderRole : letter.receiverRole;
        ctx.fillStyle = "#1f2937";
        ctx.font = "bold 12px Vazirmatn, sans-serif";
        ctx.textAlign = "right";
        ctx.fillText(truncate(ctx, personName, cardW - 16), cardX + cardW - 8, cardY + 44);

        // Role
        if (personRole) {
          ctx.fillStyle = colors.label;
          ctx.font = "10px Vazirmatn, sans-serif";
          ctx.fillText(truncate(ctx, personRole, cardW - 16), cardX + cardW - 8, cardY + 58);
        }

        // Subject (wrapped)
        ctx.fillStyle = "#4b5563";
        ctx.font = "11px Vazirmatn, sans-serif";
        wrapText(ctx, letter.subject, cardX + cardW - 8, cardY + 78, cardW - 16, 14, 2);

        // Date
        ctx.fillStyle = "#6b7280";
        ctx.font = "10px Vazirmatn, sans-serif";
        ctx.fillText(`📅 ${toPersianDigits(letter.date)}`, cardX + cardW - 8, cardY + cardHeight - 12);

        // Current badge
        if (isCurrent) {
          ctx.fillStyle = "#1a5f4a";
          roundRect(ctx, cardX + cardW / 2 - 35, cardY + cardHeight - 28, 70, 16, 4);
          ctx.fill();
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 9px Vazirmatn, sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("مکاتبه فعلی", cardX + cardW / 2, cardY + cardHeight - 17);
        }
      });

      // Download
      const link = document.createElement("a");
      link.download = `زنجیره-مکاتبات-${toPersianDigits(chain.length)}-نامه.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();

      toast.success("تصویر تایم‌لاین ذخیره شد", {
        description: `${toPersianDigits(chain.length)} نامه در تصویر`,
      });
    } catch (err) {
      console.error("Save image error:", err);
      toast.error("خطا در ذخیره تصویر", {
        description: "لطفاً دوباره تلاش کنید",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden flex flex-col" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-right flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span>زنجیره مکاتبات</span>
              <span className="text-xs text-muted-foreground font-normal">
                {toPersianDigits(chain.length)} نامه
              </span>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={handleSaveImage}
              disabled={saving || chain.length <= 1}
              className="gap-1.5"
            >
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Download className="size-4" />}
              <span className="hidden sm:inline">ذخیره تصویر</span>
            </Button>
          </DialogTitle>
          <DialogDescription className="text-right">
            برای مشاهده هر مکاتبه، روی کارت آن کلیک کنید
          </DialogDescription>
        </DialogHeader>

        {/* Horizontal timeline */}
        <div ref={timelineRef} className="flex-1 overflow-x-auto overflow-y-auto p-4 bg-white">
          {chain.length <= 1 ? (
            <div className="py-12 text-center text-muted-foreground">
              <p className="text-sm">این مکاتبه بخشی از زنجیره‌ای نیست.</p>
            </div>
          ) : (
            <div className="relative inline-block min-w-full">
              {/* Timeline grid: 3 rows - top cards, center axis, bottom cards */}
              <div className="grid grid-rows-[auto_40px_auto] gap-0">
                {/* Top row cards */}
                <div className="flex">
                  {chain.map((letter, idx) => {
                    const isInbound = letter.direction === "inbound";
                    const colors = isInbound ? COLOR_SCHEMES.inbound : COLOR_SCHEMES.outbound;
                    const isTop = idx % 2 === 0; // Even indices on top
                    const isCurrent = letter.id === currentId;
                    const personName = isInbound
                      ? letter.senderName || letter.from
                      : letter.receiverName || letter.to;
                    const personRole = isInbound ? letter.senderRole : letter.receiverRole;

                    if (!isTop) {
                      // Empty spacer for bottom-row items
                      return <div key={letter.id} className="w-[200px] shrink-0" />;
                    }

                    return (
                      <div key={letter.id} className="w-[200px] shrink-0 flex flex-col items-center">
                        {/* Card */}
                        <button
                          onClick={() => handleSelect(letter.id)}
                          className={cn(
                            "w-[190px] rounded-lg border p-3 text-right transition-all hover:shadow-md",
                            colors.bg,
                            colors.border,
                            isCurrent && "ring-2 ring-primary ring-offset-2"
                          )}
                        >
                          {/* Number badge + direction label */}
                          <div className="flex items-center justify-between mb-2">
                            <span className={cn(
                              "size-6 rounded-full flex items-center justify-center text-[11px] font-bold text-white",
                              colors.badge
                            )}>
                              {toPersianDigits(idx + 1)}
                            </span>
                            <span className={cn(
                              "text-[10px] font-medium flex items-center gap-1",
                              colors.label
                            )}>
                              {isInbound ? <ArrowDownLeft className="size-3" /> : <ArrowUpRight className="size-3" />}
                              {colors.label_text}
                            </span>
                          </div>

                          {/* Person + role */}
                          <div className="flex items-center gap-1.5 mb-1.5">
                            <UserIcon className={cn("size-3.5 shrink-0", colors.icon)} />
                            <div className="min-w-0">
                              <p className="text-xs font-semibold text-foreground truncate">
                                {personName}
                              </p>
                              {personRole && (
                                <p className={cn("text-[10px] truncate", colors.label)}>
                                  {personRole}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Subject */}
                          <p className="text-[11px] text-foreground/80 leading-snug line-clamp-2 mb-2 min-h-[28px]">
                            {letter.subject}
                          </p>

                          {/* Date */}
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                            <Calendar className={cn("size-3", colors.icon)} />
                            <span>{toPersianDigits(letter.date)}</span>
                          </div>

                          {isCurrent && (
                            <div className="mt-2 text-[9px] font-bold text-center py-0.5 rounded bg-primary text-primary-foreground">
                              مکاتبه فعلی
                            </div>
                          )}
                        </button>

                        {/* Dashed connector down to timeline */}
                        <div className={cn("w-px h-6 border-l-2 border-dashed my-1", colors.connector)} />
                      </div>
                    );
                  })}
                </div>

                {/* Center timeline axis with dots */}
                <div className="relative flex items-center">
                  {/* Horizontal line */}
                  <div className="absolute inset-x-0 top-1/2 h-0.5 bg-foreground/30" />
                  {/* Arrow at end (left side in RTL) */}
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 -ml-1">
                    <ChevronLeft className="size-4 text-foreground/40" />
                  </div>

                  {chain.map((letter, idx) => {
                    const isInbound = letter.direction === "inbound";
                    const colors = isInbound ? COLOR_SCHEMES.inbound : COLOR_SCHEMES.outbound;
                    const isCurrent = letter.id === currentId;

                    return (
                      <div key={letter.id} className="w-[200px] shrink-0 flex justify-center">
                        <div className={cn(
                          "size-4 rounded-full border-2 border-background z-10",
                          colors.dot,
                          isCurrent && "ring-2 ring-primary ring-offset-1 size-5"
                        )} />
                      </div>
                    );
                  })}
                </div>

                {/* Bottom row cards */}
                <div className="flex">
                  {chain.map((letter, idx) => {
                    const isInbound = letter.direction === "inbound";
                    const colors = isInbound ? COLOR_SCHEMES.inbound : COLOR_SCHEMES.outbound;
                    const isTop = idx % 2 === 0;
                    const isCurrent = letter.id === currentId;
                    const personName = isInbound
                      ? letter.senderName || letter.from
                      : letter.receiverName || letter.to;
                    const personRole = isInbound ? letter.senderRole : letter.receiverRole;

                    if (isTop) {
                      // Empty spacer for top-row items
                      return <div key={letter.id} className="w-[200px] shrink-0" />;
                    }

                    return (
                      <div key={letter.id} className="w-[200px] shrink-0 flex flex-col items-center">
                        {/* Dashed connector up to timeline */}
                        <div className={cn("w-px h-6 border-l-2 border-dashed my-1", colors.connector)} />

                        {/* Card */}
                        <button
                          onClick={() => handleSelect(letter.id)}
                          className={cn(
                            "w-[190px] rounded-lg border p-3 text-right transition-all hover:shadow-md",
                            colors.bg,
                            colors.border,
                            isCurrent && "ring-2 ring-primary ring-offset-2"
                          )}
                        >
                          {/* Number badge + direction label */}
                          <div className="flex items-center justify-between mb-2">
                            <span className={cn(
                              "size-6 rounded-full flex items-center justify-center text-[11px] font-bold text-white",
                              colors.badge
                            )}>
                              {toPersianDigits(idx + 1)}
                            </span>
                            <span className={cn(
                              "text-[10px] font-medium flex items-center gap-1",
                              colors.label
                            )}>
                              {isInbound ? <ArrowDownLeft className="size-3" /> : <ArrowUpRight className="size-3" />}
                              {colors.label_text}
                            </span>
                          </div>

                          {/* Person + role */}
                          <div className="flex items-center gap-1.5 mb-1.5">
                            <UserIcon className={cn("size-3.5 shrink-0", colors.icon)} />
                            <div className="min-w-0">
                              <p className="text-xs font-semibold text-foreground truncate">
                                {personName}
                              </p>
                              {personRole && (
                                <p className={cn("text-[10px] truncate", colors.label)}>
                                  {personRole}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Subject */}
                          <p className="text-[11px] text-foreground/80 leading-snug line-clamp-2 mb-2 min-h-[28px]">
                            {letter.subject}
                          </p>

                          {/* Date */}
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                            <Calendar className={cn("size-3", colors.icon)} />
                            <span>{toPersianDigits(letter.date)}</span>
                          </div>

                          {isCurrent && (
                            <div className="mt-2 text-[9px] font-bold text-center py-0.5 rounded bg-primary text-primary-foreground">
                              مکاتبه فعلی
                            </div>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t p-3 flex items-center justify-between text-[11px] text-muted-foreground">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="size-2.5 rounded-full bg-sky-500" />
              صادره: {toPersianDigits(chain.filter((c) => c.direction === "outbound").length)}
            </span>
            <span className="flex items-center gap-1">
              <span className="size-2.5 rounded-full bg-emerald-500" />
              وارده: {toPersianDigits(chain.filter((c) => c.direction === "inbound").length)}
            </span>
          </div>
          <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>
            بستن
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ===== Canvas helper functions =====

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function truncate(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let truncated = text;
  while (truncated.length > 0 && ctx.measureText(truncated + "…").width > maxWidth) {
    truncated = truncated.slice(0, -1);
  }
  return truncated + "…";
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines: number
) {
  const words = text.split(" ");
  let line = "";
  let lines: string[] = [];

  for (const word of words) {
    const testLine = line ? line + " " + word : word;
    if (ctx.measureText(testLine).width > maxWidth && line) {
      lines.push(line);
      line = word;
      if (lines.length >= maxLines - 1) break;
    } else {
      line = testLine;
    }
  }
  if (line && lines.length < maxLines) {
    lines.push(line);
  }

  // Truncate last line if too long
  if (lines.length === maxLines) {
    lines[maxLines - 1] = truncate(ctx, lines[maxLines - 1], maxWidth);
  }

  lines.forEach((l, i) => {
    ctx.fillText(l, x, y + i * lineHeight);
  });
}
