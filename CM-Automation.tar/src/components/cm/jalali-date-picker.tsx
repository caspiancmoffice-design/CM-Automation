// jalali-date-picker.tsx — Persian (Jalali) calendar date picker
"use client";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarIcon, ChevronRight, ChevronLeft } from "lucide-react";
import {
  gregorianToJalali,
  jalaliToGregorian,
  jalaliMonthDays,
  isJalaliLeap,
  jalaliMonthNames,
  toPersianDigits,
  parseJalali,
  formatJalali,
} from "@/lib/jalali-utils";
import { cn } from "@/lib/utils";

interface JalaliDatePickerProps {
  value: string; // "YYYY/MM/DD" Jalali format
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  minDate?: string; // Jalali YYYY/MM/DD
  maxDate?: string;
}

const WEEKDAY_NAMES = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

export function JalaliDatePicker({
  value,
  onChange,
  placeholder = "۱۴۰۳/۰۱/۰۱",
  className,
  disabled,
  minDate,
  maxDate,
}: JalaliDatePickerProps) {
  const [open, setOpen] = useState(false);

  // Parse current value or default to today
  const current = useMemo(() => {
    if (value) {
      const parsed = parseJalali(value);
      if (parsed) {
        return gregorianToJalali(parsed.getFullYear(), parsed.getMonth() + 1, parsed.getDate());
      }
    }
    const today = new Date();
    return gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
  }, [value]);

  // Calendar navigation state
  const [viewYear, setViewYear] = useState(current.year);
  const [viewMonth, setViewMonth] = useState(current.month); // 1-12

  const minJ = minDate ? (() => {
    const p = parseJalali(minDate);
    return p ? gregorianToJalali(p.getFullYear(), p.getMonth() + 1, p.getDate()) : null;
  })() : null;
  const maxJ = maxDate ? (() => {
    const p = parseJalali(maxDate);
    return p ? gregorianToJalali(p.getFullYear(), p.getMonth() + 1, p.getDate()) : null;
  })() : null;

  // Generate calendar grid for current view month
  const calendar = useMemo(() => {
    // First day of Jalali month - find its Gregorian equivalent, then weekday
    const g = jalaliToGregorian(viewYear, viewMonth, 1);
    const firstDate = new Date(g.year, g.month - 1, g.day);
    // getDay: 0=Sunday. We want Saturday=0 in Persian calendar
    let firstWeekday = firstDate.getDay() + 1; // Sat=0, Sun=1, ..., Fri=6
    firstWeekday = firstWeekday % 7;

    const daysInMonth = jalaliMonthDays(viewYear, viewMonth);
    const weeks: (number | null)[][] = [];
    let week: (number | null)[] = [];

    // Padding before first day
    for (let i = 0; i < firstWeekday; i++) week.push(null);

    for (let day = 1; day <= daysInMonth; day++) {
      week.push(day);
      if (week.length === 7) {
        weeks.push(week);
        week = [];
      }
    }
    // Padding after last day
    if (week.length > 0) {
      while (week.length < 7) week.push(null);
      weeks.push(week);
    }
    return weeks;
  }, [viewYear, viewMonth]);

  const isDayDisabled = (day: number | null): boolean => {
    if (day === null) return true;
    if (minJ) {
      if (viewYear < minJ.year) return true;
      if (viewYear === minJ.year && viewMonth < minJ.month) return true;
      if (viewYear === minJ.year && viewMonth === minJ.month && day < minJ.day) return true;
    }
    if (maxJ) {
      if (viewYear > maxJ.year) return true;
      if (viewYear === maxJ.year && viewMonth > maxJ.month) return true;
      if (viewYear === maxJ.year && viewMonth === maxJ.month && day > maxJ.day) return true;
    }
    return false;
  };

  const isDaySelected = (day: number | null): boolean => {
    if (day === null) return false;
    return current.year === viewYear && current.month === viewMonth && current.day === day;
  };

  const isToday = (day: number | null): boolean => {
    if (day === null) return false;
    const today = new Date();
    const t = gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
    return t.year === viewYear && t.month === viewMonth && t.day === day;
  };

  const handleDayClick = (day: number) => {
    if (isDayDisabled(day)) return;
    const newValue = `${viewYear}/${String(viewMonth).padStart(2, "0")}/${String(day).padStart(2, "0")}`;
    onChange(newValue);
    setOpen(false);
  };

  const goToPrevMonth = () => {
    if (viewMonth === 1) {
      setViewMonth(12);
      setViewYear(viewYear - 1);
    } else {
      setViewMonth(viewMonth - 1);
    }
  };

  const goToNextMonth = () => {
    if (viewMonth === 12) {
      setViewMonth(1);
      setViewYear(viewYear + 1);
    } else {
      setViewMonth(viewMonth + 1);
    }
  };

  const goToPrevYear = () => setViewYear(viewYear - 1);
  const goToNextYear = () => setViewYear(viewYear + 1);

  const displayValue = value ? toPersianDigits(value) : "";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          type="button"
          disabled={disabled}
          className={cn(
            "w-full justify-start text-right font-normal h-9",
            !value && "text-muted-foreground",
            className
          )}
        >
          <CalendarIcon className="size-4 ml-2 text-muted-foreground" />
          {displayValue || placeholder}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start" sideOffset={4}>
        <div className="p-3" dir="rtl">
          {/* Header */}
          <div className="flex items-center justify-between mb-3 gap-2">
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" className="size-7" onClick={goToPrevYear} title="سال قبل">
                <ChevronRight className="size-3.5" />
                <ChevronRight className="size-3.5 -mr-2" />
              </Button>
              <Button variant="ghost" size="icon" className="size-7" onClick={goToPrevMonth} title="ماه قبل">
                <ChevronRight className="size-4" />
              </Button>
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold">
                {jalaliMonthNames[viewMonth - 1]} {toPersianDigits(viewYear)}
              </p>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" className="size-7" onClick={goToNextMonth} title="ماه بعد">
                <ChevronLeft className="size-4" />
              </Button>
              <Button variant="ghost" size="icon" className="size-7" onClick={goToNextYear} title="سال بعد">
                <ChevronLeft className="size-3.5" />
                <ChevronLeft className="size-3.5 -mr-2" />
              </Button>
            </div>
          </div>

          {/* Weekday header */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {WEEKDAY_NAMES.map((d) => (
              <div key={d} className="size-8 flex items-center justify-center text-[11px] font-medium text-muted-foreground">
                {d}
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1">
            {calendar.flat().map((day, idx) => {
              const disabledDay = isDayDisabled(day);
              const selected = isDaySelected(day);
              const today = isToday(day);
              return (
                <button
                  key={idx}
                  type="button"
                  disabled={disabledDay}
                  onClick={() => day && handleDayClick(day)}
                  className={cn(
                    "size-8 flex items-center justify-center text-xs rounded-md transition-colors",
                    "hover:bg-accent",
                    !day && "invisible",
                    disabledDay && "text-muted-foreground/40 cursor-not-allowed hover:bg-transparent",
                    selected && "bg-primary text-primary-foreground hover:bg-primary",
                    !selected && today && "ring-1 ring-primary/40 bg-accent/50",
                    !selected && !today && !disabledDay && "text-foreground"
                  )}
                >
                  {day ? toPersianDigits(day) : ""}
                </button>
              );
            })}
          </div>

          {/* Footer */}
          <div className="mt-3 pt-3 border-t flex items-center justify-between text-[11px]">
            <button
              type="button"
              className="text-primary hover:underline"
              onClick={() => {
                const today = new Date();
                const t = gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
                setViewYear(t.year);
                setViewMonth(t.month);
                onChange(`${t.year}/${String(t.month).padStart(2, "0")}/${String(t.day).padStart(2, "0")}`);
                setOpen(false);
              }}
            >
              امروز
            </button>
            <button
              type="button"
              className="text-muted-foreground hover:text-foreground"
              onClick={() => {
                onChange("");
                setOpen(false);
              }}
            >
              پاک کردن
            </button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
