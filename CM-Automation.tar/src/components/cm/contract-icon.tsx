// contract-icon.tsx — Icon resolver for contract types
"use client";
import {
  PaintRoller,
  Container,
  DoorOpen,
  ArrowUpDown,
  Wind,
  Flame,
  Zap,
  Grid3X3,
  BrickWall,
  Droplets,
  Cable,
  Brush,
  LayoutGrid,
  Warehouse,
  Hammer,
  FileText,
  type LucideIcon,
  type LucideProps,
} from "lucide-react";

const iconMap: Record<string, LucideIcon> = {
  PaintRoller,
  Container,
  DoorOpen,
  ArrowUpDown,
  Wind,
  Flame,
  Zap,
  Grid3X3,
  BrickWall,
  Droplets,
  Cable,
  Brush,
  LayoutGrid,
  Warehouse,
  Hammer,
  FileText,
};

export function getContractIcon(iconKey: string): LucideIcon {
  return iconMap[iconKey] ?? FileText;
}

// React component wrapper for use inside JSX (avoids ESLint "components created during render")
export function ContractIcon({ iconKey, ...props }: { iconKey: string } & LucideProps) {
  const Cmp = iconMap[iconKey] ?? FileText;
  return <Cmp {...props} />;
}

// Color per contract type for visual distinction
const colorMap: Record<string, string> = {
  gypsum: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  concrete: "bg-stone-100 text-stone-700 dark:bg-stone-800 dark:text-stone-300",
  plywood_door: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",
  elevator: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
  fan_coil: "bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300",
  mechanical: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  electrical_panel: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300",
  rebar: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  brickwork: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
  plumbing: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300",
  wiring: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300",
  painting: "bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300",
  tile: "bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300",
  roofing: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300",
  demolition: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  other: "bg-muted text-muted-foreground",
};

export function getContractColor(type: string): string {
  return colorMap[type] ?? colorMap.other;
}
