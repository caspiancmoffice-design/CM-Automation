# CM Automation — سامانه مدیریت هوشمند ساخت

![Version](https://img.shields.io/badge/version-1.0.0-emerald)
![Next.js](https://img.shields.io/badge/Next.js-16-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)
![Tailwind](https://img.shields.io/badge/Tailwind_CSS-4-38bdf8)
![License](https://img.shields.io/badge/License-MIT-green)

پلتفرم یکپارچه، هوشمند و ماژولار برای مدیریت پروژه‌های عمرانی — طراحی شده برای شرکت‌های پیمانکار، مهندس مشاور، کارفرما و سازمان‌های پروژه‌محور.

## ✨ ویژگی‌ها

### ماژول‌های اصلی
- 📊 **داشبورد** — نمای جامع KPI‌ها، نمودارها و فعالیت‌های اخیر
- 📁 **پروژه‌ها** — مدیریت چرخه حیات کامل پروژه‌های عمرانی
- ✅ **وظایف** — Kanban Board با وظایف چندنفره و نقش‌های مستقل
- 📄 **اسناد** — مدیریت اسناد با نسخه‌بندی و کنترل دسترسی
- 📧 **مکاتبات** — مدیریت نامه‌های وارده/صادره با زنجیره تایم‌لاین
- 📜 **قراردادها** — قراردادهای پارامتریک با ۱۶ قالب آماده + خروجی Word/PDF
- 🛒 **تدارکات** — درخواست خرید با گردش کار ۷ مرحله‌ای
- 🚚 **تأمین‌کنندگان** — مدیریت وندورها با ارزیابی عملکرد
- 📈 **گزارش‌ها** — گزارش‌گیری تحلیلی با Drill-down
- 👥 **کاربران و نقش‌ها** — RBAC + Scope با ۱۳ نقش سیستمی
- 🔔 **اعلان‌ها** — سیستم اعلان چندکاناله
- 🔍 **جستجو** — جستجوی سراسری با پشتیبانی فارسی

### ویژگی‌های فنی
- 🌐 **پشتیبانی کامل RTL** — زبان فارسی با تقویم شمسی
- 📱 **Mobile First** — واکنش‌گرا برای موبایل، تبلت و دسکتاپ
- 🌓 **Dark/Light Mode** — پشتیبانی از حالت تاریک
- 📅 **تقویم شمسی** — انتخابگر تاریخ جلالی اختصاصی
- ✅ **اعتبارسنجی** — کدملی، شماره موبایل، شماره شبا با الگوریتم‌های ایرانی
- 📝 **خروجی Word/PDF** — برای قراردادها با قالب قابل چاپ

## 🛠 تکنولوژی‌ها

| لایه | تکنولوژی |
|------|----------|
| Frontend | Next.js 16, React 19, TypeScript 5 |
| Styling | Tailwind CSS 4, shadcn/ui |
| Charts | Recharts |
| Icons | Lucide React |
| Font | Vazirmatn (فارسی) |
| Backend (پیشنهادی) | ASP.NET Core |
| Database (پیشنهادی) | PostgreSQL 16 |
| Auth (پیشنهادی) | Keycloak |
| Storage (پیشنهادی) | MinIO |
| Search (پیشنهادی) | OpenSearch |

## 🚀 شروع سریع

### پیش‌نیازها
- Node.js 18+ یا Bun
- npm / yarn / bun

### نصب و اجرا

```bash
# کلون کردن پروژه
git clone https://github.com/your-username/cm-automation.git
cd cm-automation

# نصب وابستگی‌ها
npm install   # یا: bun install

# اجرای سرور توسعه
npm run dev   # یا: bun run dev

# باز کردن مرورگر
# http://localhost:3000
```

### Build برای Production

```bash
npm run build
npm start
```

## 📂 ساختار پروژه

```
cm-automation/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── layout.tsx          # Root layout (RTL, Vazirmatn)
│   │   ├── page.tsx            # Page اصلی
│   │   └── globals.css         # استایل‌های سراسری + Design System
│   ├── components/
│   │   ├── ui/                 # shadcn/ui components
│   │   └── cm/                 # کامپوننت‌های اختصاصی
│   │       ├── views/          # ۱۴ view ماژول‌ها
│   │       ├── entity-form-modal.tsx
│   │       ├── jalali-date-picker.tsx
│   │       ├── validated-input.tsx
│   │       └── ...
│   └── lib/
│       ├── types.ts            # تعریف نوع‌های دامنه
│       ├── mock-data.ts        # داده‌های نمونه
│       ├── fa-utils.ts         # توابع فرمت فارسی
│       ├── nav-context.tsx     # مدیریت state ناوبری
│       ├── contract-types.ts   # انواع قرارداد پارامتریک
│       ├── contract-templates.ts # ۱۶ قالب قرارداد
│       ├── procurement-types.ts # انواع تدارکات
│       ├── jalali-utils.ts     # توابع تاریخ شمسی
│       └── ...
├── prisma/                     # Prisma schema
├── public/                     # فایل‌های استاتیک
└── package.json
```

## 🗄 پایگاه داده

طراحی کامل پایگاه داده PostgreSQL در پوشه `download/database/`:

- `01-task-management-schema.sql` — ماژول وظایف (۱۵ جدول)
- `03-users-roles-schema.sql` — ماژول کاربران و نقش‌ها (۱۱ جدول)
- ERD diagrams و مستندات Word

## 📐 معماری

مستندات معماری کامل در پوشه `download/architecture-docs/`:

- سند معماری کلی سامانه (IEEE 1471 + 4+1 View)
- ۱۳ سند معماری ماژول‌ها (هر کدام ۱۰ فصل)
- شامل: Data Model، API Spec، Use Cases، Sequence Diagrams، Security، Business Rules

## 📝 لایسنس

MIT License — استفاده آزاد برای پروژه‌های تجاری و غیرتجاری.

## 🤝 مشارکت

Pull Request‌ها welcome هستند. برای تغییرات بزرگ لطفاً ابتدا issue باز کنید.
