// seed.ts — Complete seed for ALL modules
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

// Fixed user IDs for consistency
const U = {
  u1: "user-001", u2: "user-002", u3: "user-003",
  u4: "user-004", u5: "user-005", u6: "user-006",
};

async function main() {
  console.log("🌱 Seeding all modules...");
  await prisma.taskActivityLog.deleteMany();
  await prisma.taskTimeLog.deleteMany();
  await prisma.taskComment.deleteMany();
  await prisma.taskMember.deleteMany();
  await prisma.subtask.deleteMany();
  await prisma.task.deleteMany();
  await prisma.documentVersion.deleteMany();
  await prisma.document.deleteMany();
  await prisma.correspondence.deleteMany();
  await prisma.priceItem.deleteMany();
  await prisma.contractObligation.deleteMany();
  await prisma.contract.deleteMany();
  await prisma.workflowHistory.deleteMany();
  await prisma.workflowStep.deleteMany();
  await prisma.purchaseRequestItem.deleteMany();
  await prisma.purchaseRequest.deleteMany();
  await prisma.vendor.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.projectMember.deleteMany();
  await prisma.project.deleteMany();
  await prisma.user.deleteMany();
  await prisma.organization.deleteMany();

  // --- Organizations ---
  const org1 = await prisma.organization.create({ data: { id: "org-1", name: "شرکت ساختمانی پارس آرین", type: "contractor", phone: "021-22030405", email: "info@parsarian.ir", nationalId: "14006543210" } });
  const org2 = await prisma.organization.create({ data: { id: "org-2", name: "مهندسین مشاور راه و ساختمان پایدار", type: "consultant", phone: "021-22889900" } });
  const org3 = await prisma.organization.create({ data: { id: "org-3", name: "سازمان نوسازی تهران", type: "employer", phone: "021-33912000" } });

  // --- Users ---
  const users = [
    { id: U.u1, name: "مهندس رضا کریمی", email: "r.karimi@parsarian.ir", phone: "09123456789", defaultRole: "project_manager", organizationId: org1.id, department: "دفتر فنی", status: "active", productivityScore: 87 },
    { id: U.u2, name: "مهندس مریم احمدی", email: "m.ahmadi@parsarian.ir", phone: "09121112233", defaultRole: "technical_office", organizationId: org1.id, department: "دفتر فنی", status: "active", productivityScore: 92 },
    { id: U.u3, name: "مهندس علی محمودی", email: "a.mahmoudi@parsarian.ir", phone: "09124445566", defaultRole: "execution_engineer", organizationId: org1.id, department: "اجرا", status: "active", productivityScore: 78 },
    { id: U.u4, name: "مهندس زهرا حسینی", email: "z.hosseini@parsarian.ir", phone: "09127778899", defaultRole: "electrical_engineer", organizationId: org1.id, department: "تأسیسات", status: "active", productivityScore: 85 },
    { id: U.u5, name: "مهندس حسین رضایی", email: "h.rezaei@parsarian.ir", phone: "09122223334", defaultRole: "mechanical_engineer", organizationId: org1.id, department: "تأسیسات", status: "active", productivityScore: 81 },
    { id: U.u6, name: "امیر صادقی", email: "a.sadeghi@parsarian.ir", phone: "09125556677", defaultRole: "site_manager", organizationId: org1.id, department: "کارگاه", status: "active", productivityScore: 88 },
  ];
  for (const u of users) await prisma.user.create({ data: u });

  // --- Projects ---
  const p1 = await prisma.project.create({ data: { name: "برج مسکونی آرین", code: "PA-1402-01", description: "ساخت برج ۲۴ طبقه مسکونی", status: "active", organizationId: org1.id, client: "سازمان نوسازی تهران", consultant: "مهندسین مشاور پایدار", contractor: "شرکت پارس آرین", startDate: "1402/07/01", endDate: "1404/12/29", progress: 62, budget: BigInt(1850000000000), spentBudget: BigInt(1147000000000), location: "تهران - فرشته", managerId: U.u1, teamSize: 24, tags: '["مسکونی","برج"]', createdBy: U.u1 } });
  const p2 = await prisma.project.create({ data: { name: "مجتمع تجاری-اداری پاسارگاد", code: "PA-1402-02", description: "ساخت مجتمع ۸ طبقه", status: "active", organizationId: org1.id, client: "هلدینگ توسعه پاسارگاد", startDate: "1402/09/15", endDate: "1404/06/30", progress: 38, budget: BigInt(920000000000), spentBudget: BigInt(349600000000), location: "تهران - منطقه ۵", managerId: U.u1, teamSize: 18, tags: '["تجاری"]', createdBy: U.u1 } });

  // Project members
  for (const [pid, uid, role] of [[p1.id,U.u1,"project_manager"],[p1.id,U.u2,"technical_office"],[p1.id,U.u3,"execution_engineer"],[p1.id,U.u4,"electrical_engineer"],[p1.id,U.u6,"site_manager"],[p2.id,U.u1,"project_manager"],[p2.id,U.u3,"execution_engineer"]] as const) {
    await prisma.projectMember.create({ data: { projectId: pid, userId: uid, role } });
  }

  // --- Tasks ---
  const tasks = [
    { title: "بازبینی نقشه‌های اجرایی فاز ۲ اسکلت", desc: "بازبینی نقشه‌های فاز ۲ اسکلت برج آرین", status: "in_progress", priority: "high", projectId: p1.id, startDate: "1403/10/01", dueDate: "1403/10/15", progress: 65, estimatedHours: 40, spentHours: 24, tags: '["نقشه","اسکلت"]', createdBy: U.u1, members: [[U.u2,"owner",60,18],[U.u1,"reviewer",20,4],[U.u6,"approver",20,2]], subtasks: [["بررسی نقشه‌های تیرچه‌ها",true],["بررسی اتصالات ستون‌ها",true],["تأیید مقاطع نبشی‌ها",false],["ارتباط با مهندس محاسب",false]] },
    { title: "تأمین مصالح بتن فاز ۳", desc: "سفارش و تأمین بتن M30", status: "todo", priority: "critical", projectId: p1.id, startDate: "1403/10/05", dueDate: "1403/10/10", progress: 0, estimatedHours: 16, spentHours: 0, tags: '["تأمین","بتن"]', createdBy: U.u1, members: [[U.u3,"owner",70,0],[U.u6,"contributor",30,0]], subtasks: [["تماس با تأمین‌کنندگان",false],["مقایسه قیمت‌ها",false],["صدور سفارش",false]] },
    { title: "بازبینی تأسیسات برق طبقه ۱۵", desc: "بازبینی نهایی تاسیسات برق", status: "review", priority: "medium", projectId: p1.id, startDate: "1403/09/25", dueDate: "1403/10/03", progress: 85, estimatedHours: 20, spentHours: 15, tags: '["برق"]', createdBy: U.u1, members: [[U.u4,"owner",80,12],[U.u5,"reviewer",20,3]], subtasks: [] },
    { title: "ارائه گزارش پیشرفت ماهانه", desc: "تهیه و ارائه گزارش به کارفرما", status: "done", priority: "high", projectId: p1.id, startDate: "1403/09/20", dueDate: "1403/09/30", progress: 100, estimatedHours: 24, spentHours: 24, completedAt: new Date(), tags: '["گزارش"]', createdBy: U.u1, members: [[U.u1,"owner",50,14],[U.u2,"contributor",50,10]], subtasks: [] },
    { title: "حل اختلاف با پیمانکار جزء", desc: "حل اختلاف مالی با پیمانکار تأسیسات", status: "blocked", priority: "high", projectId: p2.id, startDate: "1403/09/15", dueDate: "1403/10/05", progress: 40, estimatedHours: 12, spentHours: 6, tags: '["اختلاف"]', createdBy: U.u1, members: [[U.u1,"owner",100,6]], subtasks: [] },
  ];
  for (const t of tasks) {
    const task = await prisma.task.create({ data: { title: t.title, description: t.desc, status: t.status, priority: t.priority, projectId: t.projectId, startDate: t.startDate, dueDate: t.dueDate, progress: t.progress, estimatedHours: t.estimatedHours, spentHours: t.spentHours, completedAt: t.completedAt, tags: t.tags, createdBy: t.createdBy } });
    for (const [uid, role, pct, hrs] of t.members) { await prisma.taskMember.create({ data: { taskId: task.id, userId: uid, role, participationPercent: pct, timeSpentHours: hrs } }); }
    for (const [stitle, done] of t.subtasks) { await prisma.subtask.create({ data: { taskId: task.id, title: stitle, isDone: done, displayOrder: 0, createdBy: U.u1, completedAt: done ? new Date() : null } }); }
    await prisma.taskActivityLog.create({ data: { taskId: task.id, activityType: "created", actorId: U.u1, description: "وظیفه ایجاد شد" } });
  }

  // --- Documents ---
  const docs = [
    { name: "نقشه‌های اجرایی فاز ۲ اسکلت.pdf", category: "drawing", projectId: p1.id, mimeType: "application/pdf", size: 24580000, currentVersion: "v3.0", status: "approved", tags: '["اسکلت","فاز ۲"]', uploadedBy: U.u2, versions: [["v3.0","اصلاحات نهایی"],["v2.1","به‌روزرسانی"],["v1.0","نسخه اولیه"]] },
    { name: "قرارداد پیمان اصلی.pdf", category: "contract", projectId: p1.id, mimeType: "application/pdf", size: 8200000, currentVersion: "v1.2", status: "approved", tags: '["قرارداد"]', uploadedBy: U.u1, versions: [["v1.2","متمم اول"],["v1.0","نسخه اصلی"]] },
    { name: "گزارش پیشرفت مهر.docx", category: "report", projectId: p1.id, mimeType: "application/msword", size: 3200000, currentVersion: "v1.0", status: "approved", tags: '["گزارش"]', uploadedBy: U.u1, versions: [["v1.0","گزارش مهر"]] },
  ];
  for (const d of docs) {
    const doc = await prisma.document.create({ data: { name: d.name, category: d.category, projectId: d.projectId, mimeType: d.mimeType, size: d.size, currentVersion: d.currentVersion, status: d.status, tags: d.tags, uploadedBy: d.uploadedBy } });
    for (const [ver, cmt] of d.versions) { await prisma.documentVersion.create({ data: { documentId: doc.id, version: ver, uploadedBy: d.uploadedBy, comment: cmt } }); }
  }

  // --- Correspondence ---
  const corrs = [
    { number: "PA-1403/1024", subject: "درخواست تأیید نقشه‌های فاز ۲ اسکلت", direction: "outbound", status: "answered", from: "شرکت پارس آرین", to: "مهندسین مشاور پایدار", date: "1403/09/28", projectId: p1.id, priority: "high", body: "پیوست نقشه‌های فاز ۲ اسکلت برج آرین جهت بازبینی ارسال می‌گردد.", category: "فنی", senderName: "مهندس رضا کریمی", senderRole: "مدیر پروژه", receiverName: "مهندس سعید جعفری", receiverRole: "ناظر مشاور", action: "ارسال درخواست", createdBy: U.u1 },
    { number: "RM-1403/0512", subject: "پاسخ: تأیید نقشه‌های فاز ۲ اسکلت", direction: "inbound", status: "received", from: "مهندسین مشاور پایدار", to: "شرکت پارس آرین", date: "1403/10/01", projectId: p1.id, priority: "high", body: "نقشه‌ها بررسی شد. موارد اصلاحی در پیوست.", category: "فنی", responseTo: "PA-1403/1024", senderName: "مهندس سعید جعفری", senderRole: "ناظر مشاور", receiverName: "مهندس رضا کریمی", receiverRole: "مدیر پروژه", action: "پاسخ با اصلاحات", createdBy: U.u1 },
    { number: "PA-1403/1028", subject: "اعلام رفع اصلاحات نقشه‌ها", direction: "outbound", status: "answered", from: "شرکت پارس آرین", to: "مهندسین مشاور پایدار", date: "1403/10/05", projectId: p1.id, priority: "high", body: "نسخه اصلاح‌شده ارسال می‌گردد.", category: "فنی", responseTo: "RM-1403/0512", senderName: "مهندس مریم احمدی", senderRole: "کارشناس دفتر فنی", receiverName: "مهندس سعید جعفری", receiverRole: "ناظر مشاور", action: "ارسال نسخه اصلاح‌شده", createdBy: U.u2 },
    { number: "RM-1403/0518", subject: "تأیید نهایی نقشه‌های فاز ۲", direction: "inbound", status: "archived", from: "مهندسین مشاور پایدار", to: "شرکت پارس آرین", date: "1403/10/08", projectId: p1.id, priority: "medium", body: "تأیید نهایی گردید. مجوز اجرای اسکلت صادر می‌گردد.", category: "فنی", responseTo: "PA-1403/1028", senderName: "مهندس سعید جعفری", senderRole: "ناظر مشاور", receiverName: "مهندس رضا کریمی", receiverRole: "مدیر پروژه", action: "تأیید نهایی", createdBy: U.u1 },
    { number: "PA-1403/1025", subject: "ارسال صورت‌وضعیت دوره ۱۳", direction: "outbound", status: "in_review", from: "شرکت پارس آرین", to: "سازمان نوسازی تهران", date: "1403/09/06", projectId: p1.id, priority: "medium", body: "صورت‌وضعیت دوره ۱۳ ارسال می‌گردد.", category: "مالی", senderName: "مهندس رضا کریمی", senderRole: "مدیر پروژه", receiverName: "آقای محمد کاظمی", receiverRole: "کارفرما", action: "ارسال صورت‌وضعیت", createdBy: U.u1 },
  ];
  for (const c of corrs) await prisma.correspondence.create({ data: c });

  // --- Contracts ---
  const contract = await prisma.contract.create({ data: { number: "1019/د/ق", title: "قرارداد گچ و خاک و سفیدکاری - حسن حسین‌زاده", type: "gypsum", category: "execution", status: "active", subject: "اجرای گچ و خاک و سفیدکاری دیوارها", projectId: p1.id, projectName: "برج مسکونی آرین", projectAddress: "تهران - فرشته", employer: "شرکت پارس آرین", contractor: "حسن حسین‌زاده", totalAmount: BigInt(791000000), prepaymentPercent: 0, guaranteeType: "safteh", guaranteeAmount: BigInt(200000000), retentionPercent: 10, paymentMethod: "monthly_statement", durationMonths: 6, startDate: "1403/05/01", endDate: "1403/11/01", delayPenalty: BigInt(500000), disputeResolution: "داوری", createdBy: U.u1 } });
  const obls = [["8-1","پیمانکار کلیه اسناد را مطالعه نموده است","general"],["8-2","حضور مداوم پیمانکار در کارگاه الزامی است","general"],["8-3","تأمین ابزارآلات ظرف ۲ روز","tools"],["8-4","بدون موافکت کتبی حق واگذاری ندارد","general"],["8-5","آموزش ایمنی و تحویل لوازم ایمنی","safety"]];
  for (const [code, text, cat] of obls) await prisma.contractObligation.create({ data: { contractId: contract.id, code, text, category: cat, party: "contractor" } });
  const items = [["۱","اندود گچ و خاک دیوار","مترمربع",1500,250000,375000000],["۲","سفیدکاری نهایی سقف","مترمربع",800,180000,144000000]];
  for (const [code, desc, unit, qty, price, total] of items) await prisma.priceItem.create({ data: { contractId: contract.id, code, description: desc, unit, quantity: qty, unitPrice: BigInt(price), totalPrice: BigInt(total) } });

  // --- Vendors ---
  const vendors = [
    { id: "v-1", name: "شرکت بتن آرین شرق", type: "company", phone: "021-56789012", contactPerson: "مهندس کاوه نیا", rating: 4, tags: '["بتن آماده"]', previousOrders: 18, organizationId: org1.id },
    { id: "v-2", name: "فولاد نگین ایران", type: "company", phone: "021-33445566", contactPerson: "آقای محمدی", rating: 5, tags: '["میلگرد","فولاد"]', previousOrders: 32 },
    { id: "v-3", name: "تأسیسات مهدی نقی‌زاده", type: "person", phone: "09153858767", contactPerson: "مهدی نقی‌زاده", rating: 4, tags: '["لوله","موتورخانه"]', previousOrders: 5 },
    { id: "v-4", name: "برق نیرو پارس", type: "company", phone: "021-77778899", contactPerson: "مهندس رحیمی", rating: 5, tags: '["کابل","تابلو برق"]', previousOrders: 14 },
    { id: "v-5", name: "سیمان تهران", type: "company", phone: "021-55556677", contactPerson: "آقای احمدی", rating: 4, tags: '["سیمان"]', previousOrders: 22 },
  ];
  for (const v of vendors) await prisma.vendor.create({ data: v });

  // --- Purchase Requests ---
  const pr1 = await prisma.purchaseRequest.create({ data: { number: "PR-1403-018", title: "درخواست خرید بتن فاز ۲ اسکلت", status: "in_order", priority: "critical", projectId: p1.id, requesterId: U.u2, requesterName: "مهندس مریم احمدی", neededByDate: "1403/10/10", totalEstimate: BigInt(4110000000), description: "تأمین بتن فاز ۲" } });
  const pr1Items = [["بتن آماده M30 با پمپ","material","مترمکعب",300,"طبقه ۱۸ - دال سقف","عیار M30 با گواهی", "v-1", "شرکت بتن آرین شرق", 100],["بتن آماده M25","material","مترمکعب",200,"طبقه ۱۹","عیار M25","v-1","شرکت بتن آرین شرق",100]];
  for (const [name, cat, unit, qty, loc, spec, vid, vname, pct] of pr1Items) await prisma.purchaseRequestItem.create({ data: { purchaseRequestId: pr1.id, row: 1, name, category: cat, quantity: qty, unit, consumptionLocation: loc, technicalSpec: spec, vendorId: vid, vendorName: vname, orderPercent: pct, unitPriceEstimate: BigInt(8500000), totalPriceEstimate: BigInt(8500000 * qty) } });

  // Workflow for PR
  for (const [type, title, status, assignedTo] of [["submit","ارسال درخواست","done",U.u2],["technical_review","بازبینی فنی","done",U.u3],["manager_approval","تأیید مدیر","done",U.u1],["financial_review","بازبینی مالی","done",null],["order","صدور سفارش","current",null],["delivery","تحویل","pending",null],["close","خاتمه","pending",null]]) {
    await prisma.workflowStep.create({ data: { purchaseRequestId: pr1.id, type, title, status, assignedTo } });
  }

  // --- Notifications ---
  const notifs = [
    { userId: U.u1, type: "task_assigned", title: "وظیفه جدید", message: "وظیفه «صدور صورت‌وضعیت دوره ۱۴» به شما محول شد", read: false },
    { userId: U.u1, type: "task_due", title: "سررسید نزدیک", message: "وظیفه «بازبینی نقشه‌ها» ۵ روز دیگر سررسید دارد", read: false },
    { userId: U.u1, type: "correspondence", title: "نامه جدید", message: "نامه از مشاور دریافت شد", read: false },
    { userId: U.u2, type: "approval", title: "در انتظار تأیید", message: "گزارش پیشرفت تأیید شد", read: true },
  ];
  for (const n of notifs) await prisma.notification.create({ data: n });

  console.log("✅ All modules seeded!");
  console.log(`   3 orgs, 6 users, 2 projects, 5 tasks, 3 docs, 5 corrs, 1 contract, 5 vendors, 1 PR, 4 notifs`);
}

main().catch(e => { console.error("❌", e); process.exit(1); }).finally(async () => { await prisma.$disconnect(); });
