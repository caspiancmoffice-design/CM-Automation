const fs = require("fs");
const path = require("path");
const H = require("./docx-helpers");
const { P, rtlRun, rtlParagraph, heading, bullet, numberedItem, codeBlock, makeTable, note, spacer, buildCover, Paragraph, TextRun, Document, Packer, AlignmentType, PageBreak, SectionType, Header, Footer, PageNumber, NumberFormat, TableOfContents, StyleLevel } = H;

const OUT_DIR = "/home/z/my-project/download/database";
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

function tocSection() {
  return [
    new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, spacing: { before: 480, after: 400, line: 480 },
      children: [new TextRun({ text: "فهرست مطالب", rightToLeft: true, bold: true, size: 44, color: P.primary, font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING } })] }),
    new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3", stylesWithLevels: [new StyleLevel("Heading1", 1), new StyleLevel("Heading2", 2), new StyleLevel("Heading3", 3)] }),
    new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, spacing: { before: 200 }, children: [new TextRun({ text: "(برای به‌روزرسانی فهرست، روی آن کلیک راست کرده و Update Field را انتخاب کنید)", rightToLeft: true, italics: true, size: 18, color: P.muted })] }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

const chapters = [
  heading("فصل اول: معرفی", 1),
  rtlParagraph("این سند، طراحی پایگاه داده ماژول کاربران و نقش‌ها (RBAC) سامانه CM Automation را تشریح می‌کند. این ماژول مدیریت هویت، کنترل دسترسی مبتنی بر نقش با scope، نشست‌ها، دعوت‌نامه‌ها و Audit Trail کامل را پشتیبانی می‌کند."),
  heading("۱.۱ مدل دسترسی", 2),
  rtlParagraph("مدل دسترسی ترکیبی RBAC + Scope است: User → UserRoles → Role → RolePermissions → Permission. هر کاربر می‌تواند چندین نقش با scope متفاوت (خودی، دپارتمان، پروژه، سازمان، همه) داشته باشد."),
  spacer(),
  heading("۱.۲ جداول ماژول", 2),
  makeTable(["جدول", "توضیح", "رکورد مورد انتظار"], [
    ["departments", "دپارتمان‌های سازمان", "۱۰-۱۰۰"],
    ["users", "کاربران (گسترش یافته)", "۱۰۰-۱۰۰۰"],
    ["roles", "نقش‌ها (سیستمی + سفارشی)", "۱۳+ سفارشی"],
    ["permissions", "دسترسی‌های atomic", "۵۰+"],
    ["role_permissions", "نقش ↔ دسترسی", "۳۰۰+"],
    ["user_roles", "کاربر ↔ نقش با scope", "۵۰۰-۵۰۰۰"],
    ["user_sessions", "نشست‌های فعال", "۱۰۰-۲۰۰۰"],
    ["user_activity_log", "لاگ فعالیت (append-only)", "۱۰۰,۰۰۰+"],
    ["user_preferences", "تنظیمات کاربر", "۱:۱ با users"],
    ["invitations", "دعوت‌نامه‌ها", "۵۰-۵۰۰"],
    ["api_tokens", "توکن‌های API", "۱۰-۱۰۰"],
  ], [25, 50, 25]),
  new Paragraph({ children: [new PageBreak()] }),

  heading("فصل دوم: طراحی دقیق جداول", 1),

  heading("۲.۱ جدول roles (نقش‌ها)", 2),
  makeTable(["ستون", "نوع", "الزامی", "توضیح"], [
    ["id", "UUID", "بله", "کلید اصلی"],
    ["name", "VARCHAR(100)", "بله", "نام نقش"],
    ["code", "VARCHAR(50)", "بله", "کد یکتا (مثال: project_manager)"],
    ["description", "TEXT", "خیر", "توضیح نقش"],
    ["role_type", "role_type (ENUM)", "بله", "system, custom"],
    ["default_scope", "permission_scope (ENUM)", "بله", "own, department, project, organization, all"],
    ["is_system", "BOOLEAN", "بله", "نقش سیستمی (غیرقابل حذف)"],
    ["organization_id", "UUID (FK)", "خیر", "سازمان (NULL برای نقش سیستمی سراسری)"],
  ], [22, 25, 10, 43]),
  spacer(),
  heading("نقش‌های سیستمی (۱۳ نقش)", 3),
  makeTable(["کد", "نام", "سطح دسترسی"], [
    ["system_admin", "مدیر سیستم", "all (کامل)"],
    ["senior_manager", "مدیر ارشد", "organization"],
    ["middle_manager", "مدیر میانی", "department"],
    ["project_manager", "مدیر پروژه", "project"],
    ["site_manager", "سرپرست کارگاه", "project"],
    ["technical_office", "کارشناس دفتر فنی", "project"],
    ["execution_engineer", "کارشناس اجرا", "project"],
    ["electrical_engineer", "کارشناس برق", "project"],
    ["mechanical_engineer", "کارشناس مکانیک", "project"],
    ["financial", "امور مالی", "organization"],
    ["procurement", "واحد خرید", "organization"],
    ["warehouse", "انبار", "project"],
    ["viewer", "کاربر عادی", "project (فقط مشاهده)"],
  ], [25, 35, 40]),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۲.۲ جدول permissions (دسترسی‌ها)", 2),
  rtlParagraph("هر دسترسی یک ترکیب یکتا از module + resource + action است. مثال: (tasks, task, create) یعنی «ایجاد وظیفه در ماژول وظایف»."),
  makeTable(["module", "resources", "actions"], [
    ["dashboard", "dashboard", "read"],
    ["projects", "project", "create, read, update, delete, export"],
    ["tasks", "task", "create, read, update, delete, assign, approve"],
    ["documents", "document", "create, read, update, delete, share, export"],
    ["correspondence", "correspondence", "create, read, update, delete"],
    ["contracts", "contract", "create, read, update, delete, approve, export"],
    ["procurement", "purchase_request, workflow", "create, read, update, delete, approve"],
    ["vendors", "vendor", "create, read, update, delete"],
    ["reports", "report", "read, export"],
    ["users", "user, role", "create, read, update, delete, assign"],
    ["settings", "settings", "read, update"],
  ], [20, 35, 45]),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۲.۳ جدول user_roles (تخصیص نقش)", 2),
  rtlParagraph("ارتباط چند به چند بین کاربر و نقش با scope context. هر تخصیص می‌تواند به یک پروژه یا دپارتمان خاص محدود شود."),
  makeTable(["ستون", "نوع", "توضیح"], [
    ["user_id", "UUID (FK)", "کاربر"],
    ["role_id", "UUID (FK)", "نقش"],
    ["scope", "permission_scope", "own, department, project, organization, all"],
    ["scope_project_id", "UUID (FK)", "پروژه (اگر scope=project)"],
    ["scope_department_id", "UUID (FK)", "دپارتمان (اگر scope=department)"],
    ["expires_at", "TIMESTAMPTZ", "انقضای تخصیص (اختیاری)"],
    ["is_active", "BOOLEAN", "آیا فعال"],
  ], [25, 25, 50]),
  spacer(),
  note("محدودیت CHECK تضمین می‌کند که scope context با نوع scope سازگار است. مثلاً scope=project نیاز به scope_project_id دارد.", "info"),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۲.۴ جدول user_sessions (نشست‌ها)", 2),
  makeTable(["ستون", "نوع", "توضیح"], [
    ["user_id", "UUID (FK)", "کاربر"],
    ["session_type", "session_type", "web, mobile, api"],
    ["refresh_token_hash", "VARCHAR(500)", "هش توکن refresh"],
    ["ip_address", "INET", "IP درخواست"],
    ["user_agent", "TEXT", "مرورگر/دستگاه"],
    ["keycloak_session_id", "VARCHAR(200)", "شناسه نشست Keycloak"],
    ["expires_at", "TIMESTAMPTZ", "انقضای نشست"],
    ["revoked_at", "TIMESTAMPTZ", "ابطال دستی"],
    ["is_active", "BOOLEAN", "آیا نشست فعال"],
  ], [25, 25, 50]),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۲.۵ جدول user_activity_log (Audit Trail)", 2),
  rtlParagraph("این جدول append-only است و تمام فعالیت‌های مرتبط با کاربران را ثبت می‌کند. شامل ورود، خروج، تغییر رمز، تخصیص نقش، تغییر وضعیت و ..."),
  makeTable(["activity_type", "توضیح"], [
    ["login", "ورود موفق"],
    ["logout", "خروج"],
    ["login_failed", "ورود ناموفق"],
    ["password_changed", "تغییر رمز"],
    ["password_reset", "بازنشانی رمز"],
    ["role_assigned", "تخصیص نقش"],
    ["role_removed", "حذف نقش"],
    ["status_changed", "تغییر وضعیت کاربر"],
    ["2fa_enabled / 2fa_disabled", "فعال/غیرفعال‌سازی 2FA"],
    ["session_revoked", "ابطال نشست"],
    ["invitation_sent / invitation_accepted", "دعوت‌نامه"],
  ], [35, 65]),
  new Paragraph({ children: [new PageBreak()] }),

  heading("فصل سوم: توابع و تریگرها", 1),
  makeTable(["تابع/تریگر", "کاربرد"], [
    ["user_has_permission()", "بررسی دسترسی کاربر به module+resource+action با scope"],
    ["log_user_activity()", "ثبت فعالیت در audit log"],
    ["check_user_lock_status()", "بررسی قفل بودن کاربر"],
    ["increment_failed_login()", "افزایش شمارنده ورود ناموفق + قفل خودکار بعد از ۵ بار"],
    ["reset_failed_login()", "بازنشانی شمارنده پس از ورود موفق"],
    ["trg_log_role_assignment", "ثبت خودکار تخصیص/حذف نقش در audit log"],
    ["trg_user_status_change", "ثبت خودکار تغییر وضعیت در audit log"],
  ], [40, 60]),
  new Paragraph({ children: [new PageBreak()] }),

  heading("فصل چهارم: امنیت", 1),
  numberedItem("۱", "قفل خودکار بعد از ۵ ورود ناموفق (۳۰ دقیقه)"),
  numberedItem("۲", "2FA با TOTP (Google Authenticator)"),
  numberedItem("۳", "هش کردن refresh token و API token"),
  numberedItem("۴", "Audit trail append-only برای حسابرسی"),
  numberedItem("۵", "انقضای خودکار دعوت‌نامه (۷ روز)"),
  numberedItem("۶", "ابطال نشست از راه دور (session revocation)"),
  numberedItem("۷", "scope-based access control برای دسترسی دقیق"),
  numberedItem("۸", "System roles غیرقابل حذف"),
  numberedItem("۹", "API tokens با scopes محدود"),
  new Paragraph({ children: [new PageBreak()] }),

  heading("فصل پنجم: نماهای (Views)", 1),
  heading("۵.۱ v_user_access_summary", 2),
  rtlParagraph("خلاصه دسترسی هر کاربر شامل نقش‌های فعال (به‌صورت JSON)، تعداد دسترسی‌ها، تعداد نشست‌های فعال و آخرین ورود."),
  heading("۵.۲ v_role_summary", 2),
  rtlParagraph("خلاصه هر نقش شامل تعداد دسترسی‌ها و تعداد کاربران دارای آن نقش."),
  new Paragraph({ children: [new PageBreak()] }),

  heading("فصل ششم: تصمیمات طراحی", 1),
  heading("۶.۱ RBAC + Scope", 2),
  rtlParagraph("مدل خالص RBAC برای سامانه‌های چندسازمانی کافی نیست. اضافه کردن scope به هر تخصیص نقش امکان محدود کردن دسترسی به پروژه یا دپارتمان خاص را فراهم می‌کند."),
  heading("۶.۲ System vs Custom Roles", 2),
  rtlParagraph("۱۳ نقش سیستمی به‌صورت پیش‌فرض تعریف شده‌اند (is_system=TRUE) که غیرقابل حذف هستند. سازمان‌ها می‌توانند نقش‌های سفارشی با دسترسی‌های دلخواه ایجاد کنند."),
  heading("۶.۳ Keycloak Integration", 2),
  rtlParagraph("احراز هویت به Keycloak سپرده شده است. جدول users با keycloak_id به Keycloak متصل است و نشست‌ها با keycloak_session_id هماهنگ می‌شوند."),
  new Paragraph({ children: [new PageBreak()] }),

  heading("تاریخچه تغییرات", 1),
  makeTable(["نسخه", "تاریخ", "توضیح"], [
    ["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه - ماژول کاربران و نقش‌ها"],
  ], [15, 25, 60]),
];

const doc = new Document({
  creator: "CM Automation Team",
  title: "طراحی پایگاه داده - ماژول کاربران و نقش‌ها",
  styles: { default: { document: { run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY }, size: 24, color: P.body }, paragraph: { spacing: { line: 360 } } },
    heading1: { run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 36, bold: true, color: P.primary }, paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 480, after: 200, line: 480 } } },
    heading2: { run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 30, bold: true, color: P.primary }, paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 360, after: 160, line: 400 } } },
    heading3: { run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 26, bold: true, color: P.primaryDark }, paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 240, after: 120, line: 360 } } } } },
  sections: [
    { properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 } } },
      children: buildCover("طراحی پایگاه داده: ماژول کاربران و نقش‌ها", "Database Design: Users & Roles Module", "نسخه ۱.۰", "۱۴۰۳/۱۰/۰۱", "DB-USER-002") },
    { properties: { type: SectionType.NEXT_PAGE, page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 }, pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } } },
      headers: { default: new Header({ children: [new Paragraph({ bidirectional: true, alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "طراحی پایگاه داده - کاربران و نقش‌ها - نسخه ۱.۰", rightToLeft: true, size: 18, color: P.muted, font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY } })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "صفحه ", rightToLeft: true, size: 18, color: P.muted }), new TextRun({ children: [PageNumber.CURRENT], size: 18, color: P.muted })] })] }) },
      children: [...tocSection(), ...chapters] },
  ],
});

Packer.toBuffer(doc).then(buffer => {
  const outPath = path.join(OUT_DIR, "04-مستندات-پایگاه-داده-کاربران-و-نقش‌ها.docx");
  fs.writeFileSync(outPath, buffer);
  console.log(`✓ Generated: ${outPath} (${(buffer.length / 1024).toFixed(1)} KB)`);
}).catch(err => { console.error("Error:", err); process.exit(1); });
