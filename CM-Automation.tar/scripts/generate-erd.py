#!/usr/bin/env python3
"""Generate ERD diagram for Task Management module using Mermaid."""
import subprocess
import os

OUT_DIR = "/home/z/my-project/download/database"
os.makedirs(OUT_DIR, exist_ok=True)

mermaid_code = """erDiagram
    organizations ||--o{ users : "has"
    organizations ||--o{ projects : "owns"
    users ||--o{ projects : "manages"
    projects ||--o{ project_members : "has"
    users ||--o{ project_members : "joins"
    projects ||--o{ tasks : "contains"
    users ||--o{ tasks : "creates"
    tasks ||--o{ task_members : "has"
    users ||--o{ task_members : "assigned to"
    tasks ||--o{ subtasks : "has"
    tasks ||--o{ task_workflow_steps : "has"
    users ||--o{ task_workflow_steps : "assigned to"
    tasks ||--o{ task_comments : "has"
    users ||--o{ task_comments : "writes"
    task_comments ||--o{ task_comments : "replies to"
    tasks ||--o{ task_time_logs : "has"
    users ||--o{ task_time_logs : "logs"
    tasks ||--o{ task_attachments : "has"
    users ||--o{ task_attachments : "uploads"
    tasks ||--o{ task_activity_log : "tracked in"
    users ||--o{ task_activity_log : "performs"
    projects ||--o{ task_labels : "defines"
    tasks ||--o{ task_label_associations : "tagged with"
    task_labels ||--o{ task_label_associations : "applied to"
    tasks ||--o{ task_watchers : "watched by"
    users ||--o{ task_watchers : "watches"
    tasks ||--o{ tasks : "parent of"

    organizations {
        UUID id PK
        VARCHAR name
        organization_type type
        VARCHAR national_id
        VARCHAR phone
        VARCHAR email
        TEXT address
        BOOLEAN is_active
        TIMESTAMPTZ created_at
        TIMESTAMPTZ updated_at
        TIMESTAMPTZ deleted_at
    }

    users {
        UUID id PK
        VARCHAR name
        VARCHAR email UK
        VARCHAR phone
        project_role default_role
        UUID organization_id FK
        VARCHAR department
        user_status status
        INTEGER productivity_score
        VARCHAR keycloak_id UK
        JSONB preferences
        TIMESTAMPTZ last_seen_at
        TIMESTAMPTZ created_at
        TIMESTAMPTZ updated_at
        TIMESTAMPTZ deleted_at
    }

    projects {
        UUID id PK
        VARCHAR name
        VARCHAR code UK
        project_status status
        UUID organization_id FK
        VARCHAR client
        VARCHAR consultant
        VARCHAR contractor
        DATE start_date
        DATE end_date
        INTEGER progress
        BIGINT budget
        BIGINT spent_budget
        VARCHAR location
        UUID manager_id FK
        INTEGER team_size
        INTEGER open_tasks
        INTEGER overdue_tasks
        JSONB tags
        UUID created_by FK
        TIMESTAMPTZ created_at
        TIMESTAMPTZ updated_at
        TIMESTAMPTZ deleted_at
    }

    project_members {
        UUID id PK
        UUID project_id FK
        UUID user_id FK
        project_role role
        TIMESTAMPTZ assigned_at
        BOOLEAN is_active
    }

    tasks {
        UUID id PK
        VARCHAR title
        TEXT description
        task_status status
        task_priority priority
        UUID project_id FK
        UUID parent_task_id FK
        VARCHAR start_date
        VARCHAR due_date
        TIMESTAMPTZ completed_at
        INTEGER progress
        NUMERIC estimated_hours
        NUMERIC spent_hours
        JSONB tags
        VARCHAR workflow_current
        UUID created_by FK
        UUID updated_by FK
        INTEGER version
        TIMESTAMPTZ created_at
        TIMESTAMPTZ updated_at
        TIMESTAMPTZ deleted_at
    }

    task_members {
        UUID id PK
        UUID task_id FK
        UUID user_id FK
        task_member_role role
        INTEGER participation_percent
        NUMERIC time_spent_hours
        TIMESTAMPTZ assigned_at
        TIMESTAMPTZ unassigned_at
        BOOLEAN is_active
    }

    subtasks {
        UUID id PK
        UUID task_id FK
        VARCHAR title
        BOOLEAN is_done
        INTEGER display_order
        TIMESTAMPTZ completed_at
        UUID completed_by FK
        UUID created_by FK
        TIMESTAMPTZ created_at
        TIMESTAMPTZ updated_at
        TIMESTAMPTZ deleted_at
    }

    task_workflow_steps {
        UUID id PK
        UUID task_id FK
        VARCHAR step_name
        INTEGER step_order
        wf_step_status status
        UUID assigned_to FK
        TIMESTAMPTZ started_at
        TIMESTAMPTZ completed_at
        UUID completed_by FK
        TEXT comment
    }

    task_comments {
        UUID id PK
        UUID task_id FK
        UUID user_id FK
        task_comment_type type
        TEXT body
        UUID parent_comment_id FK
        BOOLEAN is_edited
        BOOLEAN is_deleted
        JSONB mentions
        TIMESTAMPTZ created_at
        TIMESTAMPTZ updated_at
    }

    task_time_logs {
        UUID id PK
        UUID task_id FK
        UUID user_id FK
        NUMERIC hours
        VARCHAR description
        DATE log_date
        time_log_source source
        TIMESTAMPTZ timer_started_at
        TIMESTAMPTZ timer_stopped_at
        TIMESTAMPTZ created_at
    }

    task_attachments {
        UUID id PK
        UUID task_id FK
        UUID document_id
        VARCHAR file_name
        BIGINT file_size
        VARCHAR mime_type
        VARCHAR storage_path
        UUID uploaded_by FK
        TIMESTAMPTZ created_at
        TIMESTAMPTZ deleted_at
    }

    task_activity_log {
        UUID id PK
        UUID task_id FK
        task_activity_type activity_type
        UUID actor_id FK
        VARCHAR actor_name
        VARCHAR actor_role
        VARCHAR field_name
        TEXT old_value
        TEXT new_value
        TEXT description
        INET ip_address
        TEXT user_agent
        JSONB metadata
        TIMESTAMPTZ created_at
    }

    task_labels {
        UUID id PK
        UUID project_id FK
        VARCHAR name
        VARCHAR color
        VARCHAR description
        INTEGER display_order
        TIMESTAMPTZ created_at
        TIMESTAMPTZ updated_at
    }

    task_label_associations {
        UUID task_id PK
        UUID label_id PK
        TIMESTAMPTZ assigned_at
        UUID assigned_by FK
    }

    task_watchers {
        UUID task_id PK
        UUID user_id PK
        TIMESTAMPTZ watched_at
    }
"""

# Write Mermaid file
mmd_path = os.path.join(OUT_DIR, "erd-task-management.mmd")
with open(mmd_path, "w", encoding="utf-8") as f:
    f.write(mermaid_code)

print(f"✓ Mermaid file: {mmd_path}")

# Try to render with mermaid-cli
try:
    png_path = os.path.join(OUT_DIR, "erd-task-management.png")
    result = subprocess.run(
        ["mmdc", "-i", mmd_path, "-o", png_path, "-w", "2400", "-H", "1600", "-b", "white"],
        capture_output=True, text=True, timeout=60
    )
    if result.returncode == 0:
        print(f"✓ PNG rendered: {png_path}")
    else:
        print(f"⚠ mmdc failed: {result.stderr[:200]}")
        # Try alternative: use playwright
        print("  Trying alternative render...")
except FileNotFoundError:
    print("⚠ mmdc not found, trying npx...")
    try:
        png_path = os.path.join(OUT_DIR, "erd-task-management.png")
        result = subprocess.run(
            ["npx", "-y", "@mermaid-js/mermaid-cli", "-i", mmd_path, "-o", png_path,
             "-w", "2400", "-H", "1600", "-b", "white"],
            capture_output=True, text=True, timeout=120
        )
        if result.returncode == 0:
            print(f"✓ PNG rendered via npx: {png_path}")
        else:
            print(f"⚠ npx mmdc failed: {result.stderr[:200]}")
    except Exception as e:
        print(f"⚠ Render failed: {e}")
except Exception as e:
    print(f"⚠ Render failed: {e}")

print("\nDone!")
