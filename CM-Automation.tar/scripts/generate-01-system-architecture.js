// generate-01-system-architecture.js
// System Architecture Document (SAD) - IEEE 1471 + 4+1 View Model

const fs = require("fs");
const path = require("path");
const H = require("./docx-helpers");
const {
  P, rtlParagraph, heading, bullet, numberedItem, codeBlock, makeTable,
  note, spacer, buildCover, Paragraph, TextRun, Document, Packer,
  AlignmentType, PageBreak, SectionType, Header, Footer, PageNumber,
  NumberFormat, TableOfContents, StyleLevel,
} = H;

const OUT_DIR = "/home/z/my-project/download/architecture-docs";
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

// ===== Content sections =====

function tocSection() {
  return [
    new Paragraph({
      bidirectional: true,
      alignment: AlignmentType.CENTER,
      spacing: { before: 480, after: 400, line: 480 },
      children: [new TextRun({
        text: "فهرست مطالب",
        rightToLeft: true,
        bold: true,
        size: 44,
        color: P.primary,
        font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
      })],
    }),
    new TableOfContents("Table of Contents", {
      hyperlink: true,
      headingStyleRange: "1-3",
      stylesWithLevels: [
        new StyleLevel("Heading1", 1),
        new StyleLevel("Heading2", 2),
        new StyleLevel("Heading3", 3),
      ],
    }),
    new Paragraph({
      bidirectional: true,
      alignment: AlignmentType.CENTER,
      spacing: { before: 200, after: 0 },
      children: [new TextRun({
        text: "(برای به‌روزرسانی فهرست، روی آن کلیک راست کرده و Update Field را انتخاب کنید)",
        rightToLeft: true,
        italics: true,
        size: 18,
        color: P.muted,
      })],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter1Introduction() {
  return [
    heading("فصل اول: معرفی سند", 1),
    rtlParagraph("این سند، معماری نرم‌افزاری سامانه مدیریت هوشمند ساخت (CM Automation) را بر اساس استاندارد IEEE 1471 برای توصیف معماری نرم‌افزار و مدل 4+1 Kruchten برای نمایش دیدگاه‌های متعدد معماری، تشریح می‌کند. هدف این سند، ارائه تصویری جامع، دقیق و قابل اجرا از ساختار سامانه برای تیم توسعه، معماران نرم‌افزار، مدیران پروژه و ذی‌نفعان فنی است."),

    heading("۱.۱ هدف سند", 2),
    rtlParagraph("سند حاضر مرجع رسمی معماری سامانه CM Automation است و اهداف زیر را دنبال می‌کند:"),
    numberedItem("۱", "ارائه نمای جامع از ساختار معماری سامانه و ماژول‌های تشکیل‌دهنده آن"),
    numberedItem("۲", "تعیین و تبیین تصمیمات معماری و رationale آن‌ها"),
    numberedItem("۳", "تعریف رابط‌های بین ماژول‌ها و کامپوننت‌های سیستم"),
    numberedItem("۴", "ارائه مدل داده، API و قوانین کسب‌وکار برای هر ماژول"),
    numberedItem("۵", "تعیین الزامات امنیتی، مقیاس‌پذیری و عملکرد"),
    numberedItem("۶", "ایجاد مبنای مشترک برای توسعه، تست و استقرار آینده"),
    spacer(),

    heading("۱.۲ مخاطبان سند", 2),
    rtlParagraph("این سند برای گروه‌های زیر تهیه شده است:"),
    bullet("معماران نرم‌افزار: برای درک تصمیمات معماری و رعایت آن‌ها در توسعه"),
    bullet("توسعه‌دهندگان Frontend و Backend: برای درک ساختار ماژول‌ها، API‌ها و مدل داده"),
    bullet("مدیران پروژه: برای درک دامنه، وابستگی‌ها و ریسک‌های فنی"),
    bullet("مهندسان DevOps: برای طراحی زیرساخت استقرار و پیکربندی"),
    bullet("ذی‌نفعان فنی کارفرما: برای ارزیابی تطابق راه‌حل با نیازهای کسب‌وکار"),
    spacer(),

    heading("۱.۳ دامنه سند", 2),
    rtlParagraph("این سند معماری سامانه CM Automation نسخه ۱.۰ (Baseline) را پوشش می‌دهد. سامانه شامل ۱۳ ماژول اصلی است که در قالب پلتفرم یکپارچه تحت وب برای مدیریت پروژه‌های عمرانی ارائه می‌شود. دامنه شامل معماری نرم‌افزار، مدل داده، API، امنیت و فرآیندهای کسب‌وکار می‌باشد و خارج از دامنه آن، جزئیات پیاده‌سازی کد، تست‌های واحد و مستندات کاربر نهایی قرار می‌گیرند."),
    spacer(),

    heading("۱.۴ تعاریف، اختصارات و اصطلاحات", 2),
    makeTable(
      ["اصطلاح", "تعریف"],
      [
        ["SAD", "Software Architecture Document - سند توصیف معماری نرم‌افزار"],
        ["IEEE 1471", "استاندارد IEEE برای توصیف معماری نرم‌افزار"],
        ["4+1 View", "مدل دیدگاهی Kruchten شامل منطقی، پردازشی، توسعه، فیزیکی و سناریوها"],
        ["RBAC", "Role-Based Access Control - کنترل دسترسی مبتنی بر نقش"],
        ["BFF", "Backend-For-Frontend - الگوی رابط مخصوص فرانت‌اند"],
        ["PWA", "Progressive Web Application - اپلیکیشن وب پیشرونده"],
        ["RTL", "Right-to-Left - چینش راست به چپ (مناسب زبان فارسی)"],
        ["Audit Trail", "ثبت کامل رویدادها برای ردیابی و حسابرسی"],
        ["Multi-Tenant", "معماری چندسازمانی با ایزوله‌سازی داده"],
      ],
      [25, 75]
    ),
    spacer(),

    heading("۱.۵ مراجع", 2),
    numberedItem("۱", "IEEE Std 1471-2000: Recommended Practice for Architectural Description of Software-Intensive Systems"),
    numberedItem("۲", "Kruchten, P. (1995): The 4+1 View Model of Architecture, IEEE Software"),
    numberedItem("۳", "سند چشم‌انداز محصول CM Automation نسخه ۱.۰"),
    numberedItem("۴", "سند نیازمندی‌های محصول (PRD) نسخه ۱.۰"),
    numberedItem("۵", "سند معماری نرم‌افزار (SAPDS) نسخه ۱.۰"),
    numberedItem("۶", "سند مشخصات طراحی رابط و تجربه کاربری (UI/UX) نسخه ۱.۰"),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter2ArchitecturalRepresentation() {
  return [
    heading("فصل دوم: نمای کلی معماری", 1),

    heading("۲.۱ رویکرد معماری", 2),
    rtlParagraph("معماری سامانه CM Automation بر اساس رویکرد ترکیبی از استاندارد IEEE 1471 و مدل 4+1 Kruchten تدوین شده است. این رویکرد امکان توصیف جامع سیستم را از دیدگاه‌های مختلف (منطقی، پردازشی، توسعه، فیزیکی و سناریوها) فراهم می‌کند و نیازهای متنوع ذی‌نفعان فنی و غیرفنی را پوشش می‌دهد. در ادامه، هر یک از دیدگاه‌های معماری به تفصیل تشریح می‌شود."),
    spacer(),

    heading("۲.۲ دیدگاه‌های معماری (Architecture Viewpoints)", 2),
    makeTable(
      ["دیدگاه", "هدف", "ذی‌نفعان اصلی"],
      [
        ["منطقی (Logical)", "مدل‌سازی کامپوننت‌ها، کلاس‌ها و روابط منطقی", "معماران، توسعه‌دهندگان"],
        ["پردازشی (Process)", "توصیف پردازش‌ها، همزمانی و تخصیص منابع", "معماران، مهندسان عملکرد"],
        ["توسعه (Development)", "ساختار کد، پکیج‌ها و سازمان‌دهی فیزیکی کد", "توسعه‌دهندگان، مدیر کد"],
        ["فیزیکی (Physical)", "توزیع نرم‌افزار روی سخت‌افزار و شبکه", "مهندسان DevOps، مدیر سیستم"],
        ["سناریوها (Scenarios)", "تأیید صحت معماری از طریق موارد استفاده کلیدی", "همه ذی‌نفعان"],
      ],
      [25, 45, 30]
    ),
    spacer(),

    heading("۲.۳ اصول حاکم بر معماری", 2),
    rtlParagraph("معماری سامانه CM Automation بر اساس اصول زیر بنا شده است. این اصول تصمیمات معماری را هدایت کرده و مبنای ارزیابی تطابق راه‌حل‌ها هستند:"),
    numberedItem("۱", "تحت وب با پشتیبانی PWA - دسترسی از هر دستگاه با قابلیت آفلاین محدود"),
    numberedItem("۲", "طراحی Mobile First - اولویت با تجربه موبایل و سپس گسترش به دسکتاپ"),
    numberedItem("۳", "زبان پایه فارسی با چینش RTL - پشتیبانی کامل از زبان و فرهنگ ایرانی"),
    numberedItem("۴", "استفاده انحصاری از فناوری‌های متن‌باز - جلوگیری از وابستگی به فروشگاه‌های تجاری"),
    numberedItem("۵", "معماری Modular Monolith با مسیر مهاجرت به Microservices"),
    numberedItem("۶", "الگوی Core Platform + Plugin - هسته مشترک با قابلیت توسعه از طریق افزونه‌ها"),
    numberedItem("۷", "Multi-Organization و Multi-Project - پشتیبانی از چند سازمان و پروژه همزمان"),
    numberedItem("۸", "Event-Driven با ثبت کامل Audit Trail - ردیابی کامل رویدادها برای حسابرسی"),
    numberedItem("۹", "API First - طراحی API قبل از پیاده‌سازی رابط کاربری"),
    numberedItem("۱۰", "AI-Ready - آماده‌سازی زیرساخت برای ادغام هوش مصنوعی در آینده"),
    spacer(),

    heading("۲.۴ تصمیمات معماری کلیدی (Architectural Decisions)", 2),
    makeTable(
      ["تصمیم", "توضیح", "دلیل"],
      [
        ["Modular Monolith", "ساختار یکپارچه ماژولار به جای Microservices", "سادگی توسعه، استقرار و دیباگ در فاز اول با مسیر مهاجرت آینده"],
        ["Next.js 16 + React 19", "فریم‌ورک فرانت‌اند با App Router", "SSR، پشتیبانی PWA، اکوسیستم قوی، TypeScript بومی"],
        ["ASP.NET Core", "بک‌اند با معماری Clean Architecture", "عملکرد بالا، امنیت، پشتیبانی از CQRS و MediatR"],
        ["PostgreSQL", "پایگاه داده رابطه‌ای اصلی", "پشتیبانی از JSON، عملکرد بالا، متن‌باز، مقیاس‌پذیر"],
        ["Keycloak", "سرور احراز هویت و مدیریت هویت", "پشتیبانی از OAuth2، OIDC، SSO، متن‌باز"],
        ["MinIO", "ذخیره‌سازی اشیاء (Object Storage)", "سازگار با S3، متن‌باز، مناسب برای اسناد و فایل‌ها"],
        ["OpenSearch", "موتور جستجوی توزیع‌شده", "جستجوی فارسی، عملکرد بالا، تحلیل لاگ"],
        ["Docker + Nginx", "کانتینری‌سازی و Reverse Proxy", "قابلیت حمل، استقرار آسان، مقیاس‌پذیری"],
      ],
      [20, 40, 40]
    ),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter3LogicalView() {
  return [
    heading("فصل سوم: دیدگاه منطقی (Logical View)", 1),
    rtlParagraph("دیدگاه منطقی، ساختار عملکردی سامانه را از منظر کامپوننت‌های منطقی، ماژول‌ها و روابط بین آن‌ها نشان می‌دهد. این دیدگاه مستقل از پیاده‌سازی فیزیکی است و بر مدل‌سازی دامنه کسب‌وکار تمرکز دارد."),
    spacer(),

    heading("۳.۱ لایه‌های منطقی سامانه", 2),
    rtlParagraph("سامانه CM Automation از پنج لایه منطقی تشکیل شده است. هر لایه مسئولیت مشخصی دارد و با رابط‌های تعریف‌شده با لایه‌های دیگر ارتباط می‌کند:"),
    makeTable(
      ["لایه", "مسئولیت", "تکنولوژی"],
      [
        ["Presentation Layer", "نمایش رابط کاربری، مدیریت تعامل کاربر، اعتبارسنجی کلاینت", "Next.js 16, React 19, Tailwind CSS 4"],
        ["API Gateway Layer", "مسیریابی درخواست‌ها، احراز هویت، Rate Limiting", "ASP.NET Core API, Middleware"],
        ["Business Logic Layer", "پیاده‌سازی قوانین کسب‌وکار، گردش کار، اعتبارسنجی", "ASP.NET Core, Domain Services"],
        ["Data Access Layer", "تبادل داده با پایگاه داده، Repository Pattern", "Entity Framework Core, Dapper"],
        ["Infrastructure Layer", "خدمات جانبی: صندوق پیام، ذخیره فایل، جستجو", "MinIO, OpenSearch, RabbitMQ"],
      ],
      [22, 48, 30]
    ),
    spacer(),

    heading("۳.۲ ماژول‌های اصلی سیستم", 2),
    rtlParagraph("سامانه شامل ۱۳ ماژول اصلی است که در دو دسته «ماژول‌های هسته» و «ماژول‌های پشتیبان» طبقه‌بندی می‌شوند. هر ماژول دارای مرزهای مشخص، مدل داده مستقل و API اختصاصی است:"),
    makeTable(
      ["ردیف", "ماژول", "دسته", "مسئولیت اصلی"],
      [
        ["۱", "داشبورد (Dashboard)", "پشتیبان", "نمای کلی KPI‌ها، نمودارها و فعالیت‌های اخیر"],
        ["۲", "پروژه‌ها (Projects)", "هسته", "مدیریت چرخه حیات پروژه‌های عمرانی"],
        ["۳", "وظایف (Tasks)", "هسته", "مدیریت وظایف چندنفره با نقش‌های مستقل"],
        ["۴", "اسناد (Documents)", "هسته", "مدیریت اسناد با نسخه‌بندی و کنترل دسترسی"],
        ["۵", "مکاتبات (Correspondence)", "هسته", "مدیریت نامه‌های وارده و صادره"],
        ["۶", "قراردادها (Contracts)", "هسته", "قراردادهای پارامتریک با ۱۶ قالب آماده"],
        ["۷", "تدارکات (Procurement)", "هسته", "درخواست خرید با گردش کار ۷ مرحله‌ای"],
        ["۸", "تأمین‌کنندگان (Vendors)", "هسته", "مدیریت وندورها و ارزیابی عملکرد"],
        ["۹", "گزارش‌ها (Reports)", "پشتیبان", "گزارش‌گیری تحلیلی با Drill-down"],
        ["۱۰", "کاربران و نقش‌ها (Users & Roles)", "پشتیبان", "RBAC و مدیریت حساب‌های کاربری"],
        ["۱۱", "اعلان‌ها (Notifications)", "پشتیبان", "سیستم اعلان چندکاناله"],
        ["۱۲", "جستجو (Search)", "پشتیبان", "جستجوی سراسری با OpenSearch"],
        ["۱۳", "پروفایل و تنظیمات (Profile & Settings)", "پشتیبان", "مدیریت پروفایل و پیکربندی سامانه"],
      ],
      [8, 25, 12, 55]
    ),
    spacer(),

    heading("۳.۳ الگوی معماری Core Platform + Plugin", 2),
    rtlParagraph("سامانه از الگوی Core Platform + Plugin استفاده می‌کند. در این الگو، هسته مشترک (Core Platform) خدمات پایه را فراهم می‌کند و قابلیت‌های تخصصی از طریق افزونه‌ها (Plugins) اضافه می‌شوند. این رویکرد امکان سفارشی‌سازی سامانه برای انواع سازمان‌های پیمانکار، مهندس مشاور، کارفرما و EPC را بدون تغییر در هسته فراهم می‌کند."),
    note("هسته مشترک شامل: احراز هویت، مدیریت کاربران، سازمان‌ها، پروژه‌ها، دسترسی‌ها، اعلان‌ها، گردش کار، جستجو، گزارش‌گیری و موتور KPI است.", "info"),
    spacer(),

    heading("۳.۴ روابط بین ماژول‌ها", 2),
    rtlParagraph("ماژول‌های سامانه از طریق رابط‌های تعریف‌شده با یکدیگر ارتباط برقرار می‌کنند. روابط اصلی به شرح زیر است:"),
    bullet("پروژه‌ها ← وظایف: هر پروژه شامل چندین وظیفه است (یک به چند)"),
    bullet("پروژه‌ها ← اسناد: اسناد به پروژه‌ها متصل می‌شوند (یک به چند)"),
    bullet("پروژه‌ها ← مکاتبات: مکاتبات می‌توانند به پروژه مرتبط باشند (یک به چند)"),
    bullet("پروژه‌ها ← قراردادها: قراردادها به پروژه‌ها متصل هستند (یک به چند)"),
    bullet("پروژه‌ها ← تدارکات: درخواست‌های خرید به پروژه‌ها مربوط می‌شوند (یک به چند)"),
    bullet("وظایف ← کاربران: وظایف به چند کاربر با نقش‌های مستقل تخصیص می‌یابند (چند به چند)"),
    bullet("تدارکات ← تأمین‌کنندگان: درخواست خرید به وندور مرتبط می‌شود (چند به چند)"),
    bullet("قراردادها ← تأمین‌کنندگان: قراردادها با وندورها منعقد می‌شوند (یک به چند)"),
    bullet("همه ماژول‌ها ← اعلان‌ها: رویدادهای هر ماژول اعلان تولید می‌کنند"),
    bullet("همه ماژول‌ها ← جستجو: داده‌های ماژول‌ها در موتور جستجو ایندکس می‌شوند"),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter4ProcessView() {
  return [
    heading("فصل چهارم: دیدگاه پردازشی (Process View)", 1),
    rtlParagraph("دیدگاه پردازشی، نحوه اجرای پردازش‌ها در زمان اجرا، همزمانی، تخصیص منابع و ارتباط بین پردازش‌ها را توصیف می‌کند. این دیدگاه برای درک عملکرد سیستم، مقیاس‌پذیری و مدیریت همزمانی ضروری است."),
    spacer(),

    heading("۴.۱ پردازش‌های اصلی", 2),
    makeTable(
      ["پردازش", "نوع", "توضیح"],
      [
        ["Web Server Process", "همزمان", "پاسخ به درخواست‌های HTTP با ASP.NET Core Kestrel"],
        ["Background Worker", "ناهمزمان", "اجرای کارهای پس‌زمینه: ارسال اعلان، تولید گزارش"],
        ["Event Processor", "ناهمزمان", "پردازش رویدادهای صف (RabbitMQ) برای Audit Trail"],
        ["Search Indexer", "ناهمزمان", "به‌روزرسانی ایندکس OpenSearch پس از تغییر داده"],
        ["File Processor", "ناهمزمان", "پردازش فایل‌های آپلودی: thumbnail، OCR، نسخه‌بندی"],
        ["Notification Dispatcher", "ناهمزمان", "ارسال اعلان از طریق ایمیل، SMS و Push"],
        ["Scheduled Tasks", "زمان‌بندی‌شده", "اجرای وظایف زمان‌بندی‌شده: یادآوری سررسید، گزارش‌های دوره‌ای"],
      ],
      [25, 18, 57]
    ),
    spacer(),

    heading("۴.۲ مدل همزمانی (Concurrency Model)", 2),
    rtlParagraph("سامانه از مدل همزمانی مبتنی بر async/await در ASP.NET Core استفاده می‌کند. این مدل امکان پردازش همزمان درخواست‌ها بدون ایجاد thread اضافی را فراهم می‌کند و عملکرد بالایی در سناریوهای I/O-bound دارد. برای پردازش‌های CPU-intensive مانند OCR و تولید گزارش‌های سنگین، از Background Workers مجزا استفاده می‌شود."),
    spacer(),

    heading("۴.۳ مدیریت وضعیت (State Management)", 2),
    bullet("State در سمت سرور: Stateless API با ذخیره session در Redis (اختیاری)"),
    bullet("State در سمت کلاینت: Zustand برای state سراسری، React Query برای cache داده‌ها"),
    bullet("State در پایگاه داده: Transaction با Entity Framework Core و optimistic concurrency"),
    bullet("Real-time state: SignalR برای اعلان‌های زنده و به‌روزرسانی حضور کاربران"),
    spacer(),

    heading("۴.۴ مدیریت صف و رویدادها", 2),
    rtlParagraph("برای پردازش‌های ناهمزمان، از RabbitMQ به عنوان message broker استفاده می‌شود. رویدادهای کلیدی سیستم مانند ایجاد وظیفه، تغییر وضعیت قرارداد، دریافت مکاتبه و تکمیل درخواست خرید در صف publish می‌شوند و مصرف‌کنندگان مربوطه (consumers) آن‌ها را پردازش می‌کنند. این الگو امکان decoupling ماژول‌ها و پردازش قابل اعتماد را فراهم می‌کند."),
    note("همه رویدادها برای Audit Trail در پایگاه داده ثبت می‌شوند. این ثبت شامل: نوع رویداد، کاربر انجام‌دهنده، timestamp، موجودیت مرتبط و تغییرات اعمال‌شده است.", "info"),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter5DevelopmentView() {
  return [
    heading("فصل پنجم: دیدگاه توسعه (Development View)", 1),
    rtlParagraph("دیدگاه توسعه، سازمان‌دهی کد منبع، ساختار پروژه، پکیج‌ها و ماژول‌های توسعه را توصیف می‌کند. این دیدگاه برای تیم توسعه جهت درک ساختار کد و رعایت استانداردها ضروری است."),
    spacer(),

    heading("۵.۱ ساختار پروژه Frontend", 2),
    codeBlock(`cm-automation-frontend/
├── src/
│   ├── app/                          # Next.js App Router
│   │   ├── layout.tsx                # Root layout با RTL و فونت فارسی
│   │   ├── page.tsx                  # Page اصلی
│   │   └── globals.css               # استایل‌های سراسری
│   ├── components/
│   │   ├── ui/                       # shadcn/ui components
│   │   └── cm/                       # کامپوننت‌های اختصاصی سامانه
│   │       ├── views/                # View‌های هر ماژول
│   │       ├── entity-form-modal.tsx # Modal عمومی ایجاد موجودیت
│   │       ├── jalali-date-picker.tsx# تقویم شمسی
│   │       └── validated-input.tsx   # Input اعتبارسنجی‌شده
│   ├── lib/
│   │   ├── types.ts                  # تعریف نوع‌های دامنه
│   │   ├── mock-data.ts              # داده‌های نمونه
│   │   ├── fa-utils.ts               # توابع فرمت فارسی
│   │   ├── nav-context.tsx           # مدیریت state ناوبری
│   │   ├── contract-types.ts         # انواع قرارداد
│   │   ├── contract-templates.ts     # ۱۶ قالب قرارداد
│   │   ├── procurement-types.ts      # انواع تدارکات
│   │   └── jalali-utils.ts           # توابع تاریخ شمسی
│   └── hooks/                        # React hooks
├── public/                           # فایل‌های استاتیک
└── package.json`),
    spacer(),

    heading("۵.۲ ساختار پروژه Backend (ASP.NET Core)", 2),
    codeBlock(`CM.Automation.Backend/
├── src/
│   ├── CM.Automation.Domain/         # لایه دامنه (Entity, Value Object, Domain Event)
│   │   ├── Entities/                 # موجودیت‌ها: Project, Task, Document, Contract
│   │   ├── Events/                   # رویدادهای دامنه
│   │   └── Interfaces/               # رابط‌های Repository
│   ├── CM.Automation.Application/    # لایه کاربرد (Use Cases, CQRS Handlers)
│   │   ├── Projects/                 # Commands و Queries پروژه
│   │   ├── Tasks/                    # Commands و Queries وظیفه
│   │   ├── Contracts/                # Commands و Queries قرارداد
│   │   └── Procurement/              # Commands و Queries تدارکات
│   ├── CM.Automation.Infrastructure/ # لایه زیرساخت
│   │   ├── Persistence/              # DbContext, Repository‌ها
│   │   ├── Identity/                 # Keycloak integration
│   │   ├── Storage/                  # MinIO file storage
│   │   ├── Search/                   # OpenSearch integration
│   │   └── Messaging/                # RabbitMQ event bus
│   └── CM.Automation.Api/            # لایه API (Controllers, Middleware)
│       ├── Controllers/              # REST API endpoints
│       ├── Middleware/               # Authentication, Exception handling
│       └── Configuration/            # تنظیمات سامانه
└── tests/                            # پروژه‌های تست
    ├── CM.Automation.UnitTests/
    └── CM.Automation.IntegrationTests/`),
    spacer(),

    heading("۵.۳ الگوهای طراحی به‌کاررفته", 2),
    makeTable(
      ["الگو", "کاربرد در سامانه"],
      [
        ["Clean Architecture", "جداسازی لایه‌های Domain، Application، Infrastructure و API"],
        ["CQRS", "جداسازی Command و Query با MediatR برای عملکرد بهتر"],
        ["Repository Pattern", "انتزاع دسترسی داده با رابط‌های Repository"],
        ["Unit of Work", "مدیریت transaction با EF Core DbContext"],
        ["Domain Events", "انتشار رویداد پس از تغییر موجودیت"],
        ["Factory Pattern", "ایجاد موجودیت‌های پیچیده مانند Contract با پارامترهای متغیر"],
        ["Strategy Pattern", "الگوریتم‌های مختلف اعتبارسنجی (NationalId, Phone, IBAN)"],
        ["Observer Pattern", "اعلان تغییرات به مشترکین (SignalR)"],
        ["Decorator Pattern", "افزودن caching، logging به handler‌ها با MediatR pipeline"],
        ["Specification Pattern", "فیلترهای پویا برای query‌های پیچیده"],
      ],
      [25, 75]
    ),
    spacer(),

    heading("۵.۴ کنوانسیون‌های کدنویسی", 2),
    bullet("TypeScript در فرانت‌اند با strict mode فعال"),
    bullet("C# در بک‌اند با nullable reference types فعال"),
    bullet("ESLint و Prettier در فرانت‌اند با قواعد سفارشی RTL"),
    bullet("命名: PascalCase برای کلاس‌ها و کامپوننت‌ها، camelCase برای متغیرها و توابع"),
    bullet("命名 موجودیت‌ها: مفرد به انگلیسی (Project, Task, Contract)"),
    bullet("命名 API: kebab-case برای URL، camelCase برای JSON body"),
    bullet("کامنت‌گذاری: XML comments در C# برای مستندسازی API"),
    bullet("Git branching: GitFlow با شاخه‌های main, develop, feature/, hotfix/"),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter6PhysicalView() {
  return [
    heading("فصل ششم: دیدگاه فیزیکی (Physical View)", 1),
    rtlParagraph("دیدگاه فیزیکی، نحوه استقرار سامانه روی زیرساخت سخت‌افزاری و شبکه را توصیف می‌کند. این دیدگاه شامل توزیع کامپوننت‌ها روی سرورها، تنظیمات شبکه، ذخیره‌سازی و زیرساخت استقرار است."),
    spacer(),

    heading("۶.۱ معماری استقرار", 2),
    rtlParagraph("سامانه CM Automation بر روی زیرساخت Docker و Ubuntu Linux مستقر می‌شود. معماری استقرار شامل کامپوننت‌های زیر است که در شبکه داخلی سازمان قرار می‌گیرند:"),
    spacer(),

    heading("۶.۲ کامپوننت‌های زیرساخت", 2),
    makeTable(
      ["کامپوننت", "تکنولوژی", "منابع پیشنهادی", "توضیح"],
      [
        ["Reverse Proxy", "Nginx", "2 CPU, 2GB RAM", "SSL termination, load balancing"],
        ["Frontend (SSR)", "Next.js Node.js", "4 CPU, 4GB RAM", "Server-side rendering برای SEO و عملکرد"],
        ["Backend API", "ASP.NET Core", "4 CPU, 8GB RAM", "REST API، چند نمونه برای مقیاس‌پذیری"],
        ["Database", "PostgreSQL 16", "8 CPU, 16GB RAM", "پایگاه داده اصلی با replication"],
        ["Cache", "Redis", "2 CPU, 4GB RAM", "Cache و session state"],
        ["Object Storage", "MinIO", "4 CPU, 8GB RAM + 1TB Disk", "ذخیره اسناد و فایل‌ها"],
        ["Search Engine", "OpenSearch", "4 CPU, 8GB RAM", "جستجوی سراسری و تحلیل لاگ"],
        ["Message Broker", "RabbitMQ", "2 CPU, 4GB RAM", "صف پیام برای پردازش ناهمزمان"],
        ["Identity Server", "Keycloak", "2 CPU, 4GB RAM", "احراز هویت و مدیریت هویت"],
        ["Monitoring", "Prometheus + Grafana", "2 CPU, 4GB RAM", "مانیتورینگ و هشدار"],
      ],
      [18, 18, 22, 42]
    ),
    spacer(),

    heading("۶.۳ توپولوژی شبکه", 2),
    bullet("شبکه خارجی: کاربران از طریق HTTPS (پورت 443) به Nginx متصل می‌شوند"),
    bullet("شبکه دمیلیتاریزه (DMZ): Nginx و Frontend در این منطقه قرار دارند"),
    bullet("شبکه داخلی: Backend API، Database و سایر سرویس‌ها در این منطقه هستند"),
    bullet("فایروال: فقط پورت‌های ضروری (443, 80) از خارج قابل دسترسی هستند"),
    bullet("VPN: دسترسی مدیران سیستم از طریق VPN با احراز هویت دو مرحله‌ای"),
    spacer(),

    heading("۶.۴ استراتژی پشتیبان‌گیری (Backup)", 2),
    makeTable(
      ["نوع داده", "فرکانس", "نگهداری", "محل ذخیره"],
      [
        ["پایگاه داده PostgreSQL", "روزانه (Full) + ساعتی (Incremental)", "۳۰ روز", "سرور backup مجزا + cloud"],
        ["MinIO Object Storage", "هفتگی", "۹۰ روز", "سرور backup مجزا"],
        ["OpenSearch Indices", "هفتگی", "۳۰ روز", "سرور backup مجزا"],
        ["Configuration Files", "روی تغییر", "نسخه‌های نامحدود", "Git repository"],
        ["Audit Logs", "روزانه", "یک سال", "سرور backup مجزا + archive"],
      ],
      [25, 25, 15, 35]
    ),
    spacer(),

    heading("۶.۵ مقیاس‌پذیری (Scalability)", 2),
    rtlParagraph("سامانه CM Automation از مقیاس‌پذیری افقی (Horizontal Scaling) پشتیبانی می‌کند. کامپوننت‌های Stateless مانند Frontend و Backend API می‌توانند با اضافه کردن نمونه‌های جدید مقیاس شوند. برای کامپوننت‌های Stateful مانند PostgreSQL و MinIO، از الگوهای Replication و Sharding استفاده می‌شود. баланс بار با Nginx انجام می‌شود و از Docker Swarm یا Kubernetes برای orchestration استفاده می‌شود."),
    note("در فاز اول، استقرار با Docker Compose روی یک سرور پیشنهاد می‌شود. در فاز دوم، مهاجرت به Kubernetes برای مقیاس‌پذیری بهتر توصیه می‌گردد.", "warning"),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter7Scenarios() {
  return [
    heading("فصل هفتم: سناریوها (Scenarios)", 1),
    rtlParagraph("دیدگاه سناریوها، معماری سامانه را از منزل موارد استفاده کلیدی تأیید می‌کند. این دیدگاه نشان می‌دهد که چگونه معماری تعریف‌شده، نیازهای کسب‌وکار را برآورده می‌کند. در ادامه، پنج سناریوی کلیدی بررسی می‌شود."),
    spacer(),

    heading("۷.۱ سناریوی ۱: ایجاد قرارداد پارامتریک", 2),
    rtlParagraph("کارشناس دفتر فنی قصد ایجاد یک قرارداد جدید با پیمانکار گچ‌کار دارد. او از داشبورد به ماژول قراردادها می‌رود، دکمه «قرارداد جدید» را می‌زند و ویزارد ۸ مرحله‌ای را طی می‌کند:"),
    numberedItem("۱", "انتخاب نوع قرارداد (گچ‌کاری از ۱۶ قالب آماده)"),
    numberedItem("۲", "وارد کردن مشخصات کلی: عنوان، شماره، موضوع، پروژه"),
    numberedItem("۳", "وارد کردن اطلاعات طرفین: کارفرما و پیمانکار با اعتبارسنجی کدملی"),
    numberedItem("۴", "انتخاب تاریخ شروع از تقویم شمسی - تاریخ پایان خودکار محاسبه می‌شود"),
    numberedItem("۵", "تعیین شرایط مالی: مبلغ، پیش‌پرداخت، تضمین، نحوه پرداخت"),
    numberedItem("۶", "بازبینی تعهدات پیمانکار (پیش‌فرض قالب) - امکان ویرایش، حذف، افزودن"),
    numberedItem("۷", "تعریف ردیف‌های بهای پیمان با واحدهای آماده"),
    numberedItem("۸", "پیش‌نمایش نهایی و ثبت"),
    rtlParagraph("پس از ثبت، قرارداد با وضعیت «پیش‌نویس» ذخیره می‌شود. مدیر پروژه آن را بازبینی و تأیید می‌کند. پس از تأیید، امکان خروجی Word و PDF و چاپ فراهم می‌شود."),
    spacer(),

    heading("۷.۲ سناریوی ۲: گردش کار درخواست خرید", 2),
    rtlParagraph("کارشناس دفتر فنی برای تأمین بتن مورد نیاز فاز ۲ اسکلت، درخواست خرید ایجاد می‌کند:"),
    numberedItem("۱", "ایجاد درخواست با عنوان و انتخاب پروژه (برج آرین)"),
    numberedItem("۲", "افزودن اقلام: بتن M30 با مقدار ۳۰۰ مترمکعب، محل مصرف: طبقه ۱۸، مشخصات فنی کامل، انتخاب وندور (بتن آرین شرق)، درصد سفارش ۱۰۰٪"),
    numberedItem("۳", "ارسال درخواست - شروع گردش کار ۷ مرحله‌ای"),
    numberedItem("۴", "بازبینی فنی توسط مهندس علی محمودی - تأیید"),
    numberedItem("۵", "تأیید مدیر پروژه (مهندس رضا کریمی)"),
    numberedItem("۶", "بازبینی مالی توسط امور مالی - بررسی بودجه"),
    numberedItem("۷", "صدور سفارش توسط واحد خرید - ثبت درصد سفارش ۱۰۰٪"),
    numberedItem("۸", "دریافت کالا توسط انبار - ثبت مقدار دریافت شده"),
    numberedItem("۹", "خاتمه خودکار پس از دریافت کامل"),
    rtlParagraph("در هر مرحله، اعلان به مسئول مربوطه ارسال می‌شود و تاریخچه کامل در سیستم ثبت می‌گردد."),
    spacer(),

    heading("۷.۳ سناریوی ۳: مدیریت وظیفه چندنفره", 2),
    rtlParagraph("مدیر پروژه وظیفه «بازبینی نقشه‌های فاز ۲ اسکلت» را ایجاد می‌کند و سه نفر را با نقش‌های مستقل تخصیص می‌دهد:"),
    bullet("مهندس مریم احمدی - مسئول (۶۰٪ مشارکت)"),
    bullet("مهندس رضا کریمی - بازبین (۲۰٪ مشارکت)"),
    bullet("امیر صادقی - تأییدکننده (۲۰٪ مشارکت)"),
    rtlParagraph("وظیفه در Kanban Board قابل drag-and-drop است. هر عضف می‌تواند زمان صرف‌شده خود را ثبت کند. سیستم KPI بر اساس نقش، درصد مشارکت و زمان، بهره‌وری هر عضف را محاسبه می‌کند. نظرات و فایل‌های پیوست در همان وظیفه قابل مدیریت هستند."),
    spacer(),

    heading("۷.۴ سناریوی ۴: جستجوی سراسری", 2),
    rtlParagraph("کاربر در نوار جستجوی هدر، عبارت «قرارداد بتن» را وارد می‌کند. سیستم در همه ماژول‌ها (پروژه‌ها، وظایف، اسناد، مکاتبات، قراردادها، تدارکات، کاربران) جستجو می‌کند و نتایج را در تب‌های مجزا نمایش می‌دهد. OpenSearch با پشتیبانی از زبان فارسی و stemming، نتایج مرتبط را در کمتر از ۲۰۰ms برمی‌گرداند."),
    spacer(),

    heading("۷.۵ سناریوی ۵: گزارش‌گیری با Drill-down", 2),
    rtlParagraph("مدیر ارشد سازمان وارد ماژول گزارش‌ها می‌شود. در داشبورد، نمودار روند بهره‌وری ۷ ماه گذشته را می‌بیند. با کلیک روی ماه مهر، به جزئیات آن ماه می‌رود: پروژه‌ها، وظایف، کاربران. با کلیک روی یک پروژه، جزئیات آن پروژه در آن ماه نمایش داده می‌شود. این Drill-down تا سطح وظیفه فردی ادامه دارد."),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter8Security() {
  return [
    heading("فصل هشتم: معماری امنیت", 1),
    rtlParagraph("امنیت سامانه CM Automation بر اساس اصل Defense in Depth (دفاع در عمق) طراحی شده است. چندین لایه امنیتی از شبکه تا کاربرد، از داده تا احراز هویت، در سامانه پیاده‌سازی شده‌اند."),
    spacer(),

    heading("۸.۱ مدل احراز هویت و مجوزدهی", 2),
    bullet("احراز هویت: Keycloak با پشتیبانی از OAuth 2.0 و OpenID Connect"),
    bullet("توکن: JWT با زمان انقضای ۱۵ دقیقه برای access token و ۷ روز برای refresh token"),
    bullet("SSO: پشتیبانی از Single Sign-On برای یکپارچه‌سازی با سامانه‌های سازمانی"),
    bullet("MFA: احراز هویت چندمرحله‌ای اختیاری با TOTP (Google Authenticator)"),
    bullet("Session: مدیریت session در Keycloak با امکان logout از همه دستگاه‌ها"),
    spacer(),

    heading("۸.۲ مدل کنترل دسترسی (RBAC + Scope)", 2),
    rtlParagraph("سامانه از مدل ترکیبی RBAC (Role-Based Access Control) و Scope استفاده می‌کند. هر کاربر یک یا چند نقش دارد و هر نقش دارای دسترسی‌های مشخص به ماژول‌ها و عملیات است. علاوه بر این، scope دسترسی را به سازمان، پروژه و دپارتمان محدود می‌کند. به عنوان مثال، یک کارشناس دفتر فنی ممکن است به پروژه‌های دپارتمان خود دسترسی داشته باشد اما به پروژه‌های دپارتمان‌های دیگر دسترسی نداشته باشد."),
    makeTable(
      ["نقش", "دسترسی‌های اصلی"],
      [
        ["مدیر ارشد", "دسترسی کامل به همه ماژول‌ها و همه سازمان‌ها"],
        ["مدیر میانی", "دسترسی به پروژه‌های سازمان خود + گزارش‌های تحلیلی"],
        ["مدیر پروژه", "مدیریت کامل پروژه‌های خود: وظایف، اسناد، مکاتبات، قراردادها"],
        ["کارشناس دفتر فنی", "ایجاد و ویرایش وظایف، اسناد، مکاتبات در پروژه‌های محدود"],
        ["کارشناس اجرا", "ثبت گزارش روزانه، ثبت زمان، وظایف محول‌شده"],
        ["سرپرست کارگاه", "مدیریت کارگاه، بازدیدها، گزارش‌های روزانه"],
        ["امور مالی", "بازبینی مالی قراردادها، تأیید درخواست‌های خرید"],
        ["واحد خرید", "صدور سفارش، مدیریت وندورها"],
        ["انبار", "ثبت دریافت کالا، مدیریت موجودی"],
        ["مدیر سیستم", "مدیریت کاربران، نقش‌ها، تنظیمات سامانه"],
      ],
      [25, 75]
    ),
    spacer(),

    heading("۸.۳ امنیت داده", 2),
    bullet("رمزنگاری in-transit: TLS 1.3 برای همه ارتباطات"),
    bullet("رمزنگاری at-rest: AES-256 برای داده‌های حساس در پایگاه داده"),
    bullet("رمزنگاری فایل‌ها: MinIO با Server-Side Encryption"),
    bullet("هش کردن رمز عبور: bcrypt با cost factor 12 (توسط Keycloak)"),
    bullet("پاسکال‌سازی داده حساس: کدملی، شماره شبا در گزارش‌ها mask می‌شوند"),
    spacer(),

    heading("۸.۴ Audit Trail و حسابرسی", 2),
    rtlParagraph("تمام رویدادهای سامانه برای اهداف حسابرسی و ردیابی ثبت می‌شوند. Audit Trail شامل اطلاعات زیر است:"),
    bullet("نوع رویداد (ایجاد، ویرایش، حذف، مشاهده، تأیید، رد)"),
    bullet("کاربر انجام‌دهنده (با IP و User-Agent)"),
    bullet("Timestamp دقیق (با میلی‌ثانیه)"),
    bullet("موجودیت مرتبط (نوع و شناسه)"),
    bullet("تغییرات اعمال‌شده (diff قدیم و جدید)"),
    bullet("نتیجه عملیات (موفق/ناموفق با دلیل)"),
    rtlParagraph("لاگ‌های Audit Trail به صورت append-only هستند و امکان تغییر یا حذف ندارند. این لاگ‌ها برای یک سال نگهداری می‌شوند و در صورت نیاز قابل export به فرمت‌های مختلف هستند."),
    spacer(),

    heading("۸.۵ محافظت در برابر تهدیدات رایج (OWASP Top 10)", 2),
    makeTable(
      ["تهدید", "اقدام پیشگیرانه"],
      [
        ["Injection", "Parameterized queries با EF Core، اعتبارسنجی ورودی با FluentValidation"],
        ["Broken Authentication", "Keycloak با سیاست رمز عبور قوی، lockout بعد از ۵ تلاش ناموفق"],
        ["Sensitive Data Exposure", "رمزنگاری at-rest و in-transit، mask داده حساس"],
        ["XXE", "غیرفعال کردن DTD processing در XML parser"],
        ["Broken Access Control", "اعتبارسنجی scope در هر درخواست، policy-based authorization"],
        ["Security Misconfiguration", "Docker imageهای minimal، disable default accounts"],
        ["XSS", "React escape خودکار، CSP header، sanitize ورودی HTML"],
        ["Insecure Deserialization", "Type-safe deserialization با System.Text.Json"],
        ["Known Vulnerabilities", "اسکن وابستگی‌ها با Snyk، به‌روزرسانی منظم"],
        ["Insufficient Logging", "Audit Trail کامل، alerting با Prometheus"],
      ],
      [30, 70]
    ),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter9DataArchitecture() {
  return [
    heading("فصل نهم: معماری داده", 1),
    rtlParagraph("معماری داده سامانه CM Automation بر اساس مدل رابطه‌ای با PostgreSQL طراحی شده است. برای داده‌های غیرساختاریافته مانند متادیتای اسناد و لاگ‌های Audit Trail، از قابلیت JSONB PostgreSQL استفاده می‌شود. داده‌های اسناد و فایل‌ها در MinIO ذخیره می‌شوند و ایندکس جستجو در OpenSearch نگهداری می‌گردد."),
    spacer(),

    heading("۹.۱ استراتژی چندسازمانی (Multi-Tenancy)", 2),
    rtlParagraph("سامانه از الگوی «Database per Tenant» استفاده نمی‌کند. در عوض، از الگوی «Shared Database, Shared Schema با discriminator column» بهره می‌برد. هر جدول دارای فیلد organization_id است و تمام query‌ها با فیلتر این فیلد اجرا می‌شوند. این رویکرد، سادگی نگهداری و بهره‌وری منابع را فراهم می‌کند و در عین حال ایزوله‌سازی داده سازمان‌ها را تضمین می‌نماید."),
    spacer(),

    heading("۹.۲ موجودیت‌های اصلی", 2),
    makeTable(
      ["موجودیت", "جدول", "توضیح"],
      [
        ["Organization", "organizations", "سازمان‌ها (پیمانکار، مشاور، کارفرما)"],
        ["User", "users", "کاربران سامانه"],
        ["Role", "roles", "نقش‌های سیستم"],
        ["Permission", "permissions", "دسترسی‌های atomic"],
        ["Project", "projects", "پروژه‌های عمرانی"],
        ["Task", "tasks", "وظایف"],
        ["TaskMember", "task_members", "اعضای وظیفه با نقش"],
        ["Document", "documents", "اسناد"],
        ["DocumentVersion", "document_versions", "نسخه‌های سند"],
        ["Correspondence", "correspondences", "مکاتبات"],
        ["Contract", "contracts", "قراردادها"],
        ["ContractTemplate", "contract_templates", "قالب‌های قرارداد"],
        ["PurchaseRequest", "purchase_requests", "درخواست‌های خرید"],
        ["PurchaseRequestItem", "pr_items", "اقلام درخواست خرید"],
        ["WorkflowStep", "workflow_steps", "مراحل گردش کار"],
        ["WorkflowHistory", "workflow_history", "تاریخچه گردش کار"],
        ["Vendor", "vendors", "تأمین‌کنندگان"],
        ["Notification", "notifications", "اعلان‌ها"],
        ["AuditLog", "audit_logs", "لاگ‌های حسابرسی"],
      ],
      [22, 25, 53]
    ),
    spacer(),

    heading("۹.۳ استراتژی ایندکس‌گذاری", 2),
    bullet("B-Tree Index: برای فیلدهای FK و جستجوهای equality (project_id, user_id)"),
    bullet("GIN Index: برای فیلدهای JSONB و full-text search"),
    bullet("Partial Index: برای query‌های پرتکرار با شرط (WHERE status = 'active')"),
    bullet("Composite Index: برای query‌های چندفیلدی (organization_id + project_id)"),
    bullet("OpenSearch Index: برای جستجوی سراسری روی title, description, content"),
    spacer(),

    heading("۹.۴ استراتژی迁移شن و نسخه‌بندی پایگاه داده", 2),
    rtlParagraph("مدیریت schema پایگاه داده با Entity Framework Core Migrations انجام می‌شود. هر migration در فایل جداگانه با timestamp ذخیره می‌شود. قبل از اعمال migration در محیط production، در محیط staging تست می‌شود. برای migrations حساس (مثل تغییر نوع ستون)، از الگوی «expand and contract» استفاده می‌شود: ابتدا ساختار جدید اضافه می‌شود، داده‌ها منتقل می‌شوند، و سپس ساختار قدیمی حذف می‌گردد."),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter10QualityAttributes() {
  return [
    heading("فصل دهم: ویژگی‌های کیفیت (Quality Attributes)", 1),
    rtlParagraph("ویژگی‌های کیفیت، الزامات غیرعملکردی سامانه را تعریف می‌کنند. این ویژگی‌ها قابل اندازه‌گیری هستند و در طول توسعه و استقرار پایش می‌شوند."),
    spacer(),

    heading("۱۰.۱ عملکرد (Performance)", 2),
    makeTable(
      ["معیار", "هدف", "ابزار پایش"],
      [
        ["زمان پاسخ API (P95)", "< 200ms", "Application Insights, Prometheus"],
        ["زمان بارگذاری صفحه", "< ۲ ثانیه", "Lighthouse, Web Vitals"],
        ["پردازش درخواست/ثانیه", "۱۰۰۰ RPS", "Load testing با k6"],
        ["زمان جستجو", "< 500ms", "OpenSearch slowlog"],
        ["زمان بارگذاری سند (10MB)", "< ۵ ثانیه", "MinIO metrics"],
        ["زمان گزارش‌گیری", "< ۳ ثانیه", "Query store PostgreSQL"],
      ],
      [35, 30, 35]
    ),
    spacer(),

    heading("۱۰.۲ قابلیت دسترسی (Availability)", 2),
    bullet("SLA هدف: 99.5٪ (در ساعات کاری)"),
    bullet("Health check endpoints برای همه سرویس‌ها"),
    bullet("Auto-restart در Docker در صورت crash"),
    bullet("Database replication (Primary-Replica) برای failover"),
    bullet("Backup روزانه با RTO < ۴ ساعت و RPO < ۱ ساعت"),
    spacer(),

    heading("۱۰.۳ مقیاس‌پذیری (Scalability)", 2),
    bullet("Scale-out: Frontend و Backend API به صورت افقی مقیاس می‌شوند"),
    bullet("Scale-up: PostgreSQL و MinIO با افزایش منابع مقیاس می‌شوند"),
    bullet("Read Replica: برای query‌های سنگین گزارش‌گیری از read replica استفاده می‌شود"),
    bullet("Caching: Redis برای cache داده‌های پرتکرار (mapping، تنظیمات)"),
    bullet("CDN: برای فایل‌های استاتیک و assets"),
    spacer(),

    heading("۱۰.۴ قابلیت نگهداری (Maintainability)", 2),
    bullet("Code coverage > ۸۰٪ با unit test و integration test"),
    bullet("Static analysis با SonarQube برای شناسایی code smell"),
    bullet("CI/CD pipeline با GitHub Actions یا GitLab CI"),
    bullet("Documentation: سند معماری، API doc با Swagger/OpenAPI"),
    bullet("پشتیبانی از آخرین نسخه Framework‌ها به مدت ۲ سال"),
    spacer(),

    heading("۱۰.۵ قابلیت حمل (Portability)", 2),
    bullet("Docker containerization برای portability محیطی"),
    bullet("معماری cloud-agnostic با امکان استقرار روی cloud یا on-premise"),
    bullet("پشتیبانی از Linux Ubuntu به عنوان سیستم‌عامل اصلی"),
    bullet("پشتیبانی از PostgreSQL 14+ برای portability پایگاه داده"),
    spacer(),

    heading("۱۰.۶ بین‌المللی‌سازی (Internationalization)", 2),
    bullet("پشتیبانی کامل از زبان فارسی با چینش RTL"),
    bullet("پشتیبانی از تاریخ شمسی (Jalali) با تقویم اختصاصی"),
    bullet("فرمت اعداد، ارز و تاریخ مطابق با استانداردهای ایرانی"),
    bullet("اعتبارسنجی کدملی، شماره موبایل و شماره شبا مطابق استانداردهای ایران"),
    bullet("آماده‌سازی برای پشتیبانی از زبان‌های دیگر (انگلیسی، عربی) در آینده"),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function chapter11Appendix() {
  return [
    heading("فصل یازدهم: ضمائم", 1),

    heading("۱۱.۱ واژه‌نامه فنی", 2),
    makeTable(
      ["اصطلاح", "تعریف"],
      [
        ["Modular Monolith", "معماری یکپارچه با ماژول‌های مستقل که قابلیت مهاجرت به microservices دارد"],
        ["CQRS", "Command Query Responsibility Segregation - جداسازی عملیات خواندن و نوشتن"],
        ["BFF", "Backend For Frontend - رابط مخصوص هر نوع کلاینت"],
        ["Idempotent", "عملیاتی که چندبار اجرای آن نتیجه یکسانی دارد"],
        ["ETag", "Entity Tag - مکانیزم caching HTTP"],
        ["Saga Pattern", "مدیریت transaction توزیع‌شده با rollback"],
        ["Backpressure", "مدیریت فشار ورودی در سیستم‌های ناهمزمان"],
        ["Circuit Breaker", "الگوی جلوگیری از failure cascade"],
      ],
      [25, 75]
    ),
    spacer(),

    heading("۱۱.۲ تاریخچه تغییرات سند", 2),
    makeTable(
      ["نسخه", "تاریخ", "توضیح تغییرات"],
      [
        ["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه - ایجاد سند معماری سامانه"],
      ],
      [15, 25, 60]
    ),
    spacer(),

    heading("۱۱.۳ مستندات مرتبط", 2),
    numberedItem("۱", "سند چشم‌انداز محصول CM Automation نسخه ۱.۰"),
    numberedItem("۲", "سند نیازمندی‌های محصول (PRD) نسخه ۱.۰"),
    numberedItem("۳", "سند معماری نرم‌افزار (SAPDS) نسخه ۱.۰"),
    numberedItem("۴", "سند مشخصات طراحی رابط و تجربه کاربری (UI/UX) نسخه ۱.۰"),
    numberedItem("۵", "اسناد معماری ماژول‌ها (۱۳ سند مجزا)"),
    numberedItem("۶", "مستندات API (Swagger/OpenAPI)"),
    numberedItem("۷", "راهنمای استقرار (Deployment Guide)"),
    spacer(),

    heading("۱۱.۴ تأیید سند", 2),
    makeTable(
      ["نقش", "نام", "تاریخ", "امضا"],
      [
        ["معمار نرم‌افزار", "【نام معمار】", "【تاریخ】", "【امضا】"],
        ["مدیر پروژه", "【نام مدیر】", "【تاریخ】", "【امضا】"],
        ["مدیر فنی", "【نام مدیر فنی】", "【تاریخ】", "【امضا】"],
        ["کارفرما", "【نام نماینده】", "【تاریخ】", "【امضا】"],
      ],
      [25, 25, 20, 30]
    ),
  ];
}

// ===== Document assembly =====

const doc = new Document({
  creator: "CM Automation Team",
  title: "سند معماری کلی سامانه CM Automation",
  description: "Software Architecture Document based on IEEE 1471 and 4+1 View Model",
  styles: {
    default: {
      document: {
        run: {
          font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY },
          size: 24,
          color: P.body,
        },
        paragraph: {
          spacing: { line: 360 },
        },
      },
      heading1: {
        run: {
          font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
          size: 36,
          bold: true,
          color: P.primary,
        },
        paragraph: {
          alignment: AlignmentType.RIGHT,
          bidirectional: true,
          spacing: { before: 480, after: 200, line: 480 },
        },
      },
      heading2: {
        run: {
          font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
          size: 30,
          bold: true,
          color: P.primary,
        },
        paragraph: {
          alignment: AlignmentType.RIGHT,
          bidirectional: true,
          spacing: { before: 360, after: 160, line: 400 },
        },
      },
      heading3: {
        run: {
          font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
          size: 26,
          bold: true,
          color: P.primaryDark,
        },
        paragraph: {
          alignment: AlignmentType.RIGHT,
          bidirectional: true,
          spacing: { before: 240, after: 120, line: 360 },
        },
      },
    },
  },
  sections: [
    // Section 1: Cover
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
        },
      },
      children: buildCover(
        "سند معماری کلی سامانه",
        "Software Architecture Document (SAD)",
        "نسخه ۱.۰",
        "۱۴۰۳/۱۰/۰۱",
        "SAD-CMA-001"
      ),
    },
    // Section 2: TOC + Body
    {
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            bidirectional: true,
            alignment: AlignmentType.RIGHT,
            children: [new TextRun({
              text: "سند معماری کلی سامانه CM Automation - نسخه ۱.۰",
              rightToLeft: true,
              size: 18,
              color: P.muted,
              font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY },
            })],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: "صفحه ",
                rightToLeft: true,
                size: 18,
                color: P.muted,
              }),
              new TextRun({
                children: [PageNumber.CURRENT],
                size: 18,
                color: P.muted,
              }),
            ],
          })],
        }),
      },
      children: [
        ...tocSection(),
        ...chapter1Introduction(),
        ...chapter2ArchitecturalRepresentation(),
        ...chapter3LogicalView(),
        ...chapter4ProcessView(),
        ...chapter5DevelopmentView(),
        ...chapter6PhysicalView(),
        ...chapter7Scenarios(),
        ...chapter8Security(),
        ...chapter9DataArchitecture(),
        ...chapter10QualityAttributes(),
        ...chapter11Appendix(),
      ],
    },
  ],
});

// ===== Generate =====
Packer.toBuffer(doc).then(buffer => {
  const outPath = path.join(OUT_DIR, "01-سند-معماری-کلی-سیستم.docx");
  fs.writeFileSync(outPath, buffer);
  console.log(`✓ Generated: ${outPath} (${(buffer.length / 1024).toFixed(1)} KB)`);
}).catch(err => {
  console.error("Error:", err);
  process.exit(1);
});
