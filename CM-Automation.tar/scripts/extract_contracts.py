#!/usr/bin/env python3
"""Extract text from contract files (docx + pdf) including textboxes."""
import os
from docx import Document
from docx.oxml.ns import qn
import pdfplumber

UPLOAD = "/home/z/my-project/upload"
OUT = "/home/z/my-project/extracted_contracts"
os.makedirs(OUT, exist_ok=True)

CONTRACT_FILES = [
    "14050217 ملزومات مهم قرارداد موتورخانه.docx",
    "قرارداد تابلو برق داروسازی.pdf",
    "قرارداد اسانسور (1) (Autosaved).docx",
    "قرارداد بتن-اصلاحی.docx",
    "01- درب پلی وود قرارداد (1).docx",
    "قرارداد حسین زاده گچ کار.docx",
    "14040425 قرارداد فنکویل فرم (1).docx",
]


def extract_textboxes(doc) -> list[str]:
    """Extract text from all textboxes (w:txbxContent) in document order."""
    body = doc.element.body
    textboxes = body.findall(".//" + qn("w:txbxContent"))
    results = []
    for tb in textboxes:
        # Get all <w:p> inside this textbox
        paragraphs = tb.findall(".//" + qn("w:p"))
        for p in paragraphs:
            # Concatenate all <w:t> in this paragraph
            texts = p.findall(".//" + qn("w:t"))
            combined = "".join(t.text or "" for t in texts)
            if combined.strip():
                results.append(combined)
    return results


def extract_docx(path: str) -> str:
    doc = Document(path)
    lines = []

    # First, try regular paragraphs
    body = doc.element.body
    para_map = {p._p: p for p in doc.paragraphs}
    table_map = {t._tbl: t for t in doc.tables}

    has_regular = any(p.text.strip() for p in doc.paragraphs)

    if has_regular:
        for child in body.iterchildren():
            if child.tag == qn("w:p"):
                p = para_map.get(child)
                if p is None:
                    continue
                text = p.text
                if text.strip():
                    lines.append(text)
            elif child.tag == qn("w:tbl"):
                t = table_map.get(child)
                if t is None:
                    continue
                lines.append("\n[TABLE]")
                for row in t.rows:
                    cells = [c.text.strip().replace("\n", " ") for c in row.cells]
                    lines.append(" | ".join(cells))
                lines.append("[/TABLE]\n")
    else:
        # Fallback: extract from textboxes
        lines.append("[متن از داخل textboxها استخراج شده است]\n")
        tb_lines = extract_textboxes(doc)
        lines.extend(tb_lines)

    return "\n".join(lines)


def extract_pdf(path: str) -> str:
    lines = []
    with pdfplumber.open(path) as pdf:
        for i, page in enumerate(pdf.pages):
            lines.append(f"\n--- Page {i+1} ---\n")
            text = page.extract_text() or ""
            lines.append(text)
            tables = page.extract_tables()
            for j, table in enumerate(tables):
                lines.append(f"\n[TABLE {j+1}]")
                for row in table:
                    cells = [(c or "").strip().replace("\n", " ") for c in row]
                    lines.append(" | ".join(cells))
                lines.append("[/TABLE]\n")
    return "\n".join(lines)


for fname in CONTRACT_FILES:
    src = os.path.join(UPLOAD, fname)
    if not os.path.exists(src):
        print(f"MISS: {fname}")
        continue
    try:
        if fname.lower().endswith(".pdf"):
            text = extract_pdf(src)
        else:
            text = extract_docx(src)
    except Exception as e:
        print(f"ERR {fname}: {e}")
        continue
    safe_name = fname.replace(" ", "_").replace("/", "_").replace("(", "").replace(")", "")
    out_path = os.path.join(OUT, safe_name.rsplit(".", 1)[0] + ".txt")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"OK {fname} -> {out_path} ({len(text)} chars)")
