#!/usr/bin/env python3
"""Extract text from uploaded docx documents."""
import os
from docx import Document

UPLOAD_DIR = "/home/z/my-project/upload"
OUT_DIR = "/home/z/my-project/extracted_docs"

os.makedirs(OUT_DIR, exist_ok=True)

files = sorted(os.listdir(UPLOAD_DIR))
for fname in files:
    if not fname.lower().endswith(".docx"):
        continue
    src = os.path.join(UPLOAD_DIR, fname)
    try:
        doc = Document(src)
    except Exception as e:
        print(f"ERR opening {fname}: {e}")
        continue

    out_lines = []
    # Walk through document body in order (paragraphs + tables)
    from docx.oxml.ns import qn
    body = doc.element.body
    # Build a map from xml element to paragraph / table object
    para_map = {p._p: p for p in doc.paragraphs}
    table_map = {t._tbl: t for t in doc.tables}

    for child in body.iterchildren():
        if child.tag == qn('w:p'):
            p = para_map.get(child)
            if p is None:
                continue
            text = p.text
            style = p.style.name if p.style else ""
            if text.strip():
                if style and ("Heading" in style or "Title" in style):
                    out_lines.append(f"\n## [{style}] {text}\n")
                else:
                    out_lines.append(text)
            else:
                out_lines.append("")
        elif child.tag == qn('w:tbl'):
            t = table_map.get(child)
            if t is None:
                continue
            out_lines.append("\n[TABLE]")
            for row in t.rows:
                cells = [c.text.strip().replace("\n", " ") for c in row.cells]
                out_lines.append(" | ".join(cells))
            out_lines.append("[/TABLE]\n")

    out_path = os.path.join(OUT_DIR, fname.replace(".docx", ".txt"))
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(out_lines))
    size = os.path.getsize(out_path)
    print(f"OK {fname} -> {out_path} ({size} bytes, {len(out_lines)} lines)")

print("\n--- Files in extracted_docs ---")
for f in sorted(os.listdir(OUT_DIR)):
    print(f"  {f}: {os.path.getsize(os.path.join(OUT_DIR, f))} bytes")
