// generate-db-doc-task-management.js
// Database Design Document for Task Management Module

const fs = require("fs");
const path = require("path");
const H = require("./docx-helpers");
const {
  P, rtlRun, rtlParagraph, heading, bullet, numberedItem, codeBlock, makeTable,
  note, spacer, buildCover, Paragraph, TextRun, Document, Packer,
  AlignmentType, PageBreak, SectionType, Header, Footer, PageNumber,
  NumberFormat, TableOfContents, StyleLevel, ImageRun,
} = H;

const OUT_DIR = "/home/z/my-project/download/database";
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

function tocSection() {
  return [
    new Paragraph({
      bidirectional: true, alignment: AlignmentType.CENTER,
      spacing: { before: 480, after: 400, line: 480 },
      children: [new TextRun({
        text: "فهرست مطالب", rightToLeft: true, bold: true, size: 44, color: P.primary,
        font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
      })],
    }),
    new TableOfContents("Table of Contents", {
      hyperlink: true, headingStyleRange: "1-3",
      stylesWithLevels: [new StyleLevel("Heading1", 1), new StyleLevel("Heading2", 2), new StyleLevel("Heading3", 3)],
    }),
    new Paragraph({
      bidirectional: true, alignment: AlignmentType.CENTER, spacing: { before: 200 },
      children: [new TextRun({
        text: "(برای به‌روزرسانی فهرست، روی آن کلیک راست کرده و Update Field را انتخاب کنید)",
        rightToLeft: true, italics: true, size: 18, color: P.muted,
      })],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

const chapters = [
  // Chapter 1: Introduction
  heading("فصل اول: معرفی", 1),
  rtlParagraph("این سند، طراحی پایگاه داده ماژول مدیریت وظایف سامانه CM Automation را تشریح می‌کند. این ماژول هسته اصلی سامانه است و مدیریت وظایف چندنفره با نقش‌های مستقل، گردش کار، زمان‌سنجی و Audit Trail کامل را پشتیبانی می‌کند."),
  heading("۱.۱ هدف سند", 2),
  bullet("ارائه ساختار کامل جداول پایگاه داده برای ماژول وظایف"),
  bullet("تعریف روابط، ایندکس‌ها، محدودیت‌ها و تریگرها"),
  bullet("توضیح تصمیمات طراحی و rationale آن‌ها"),
  bullet("ارائه مرجع برای توسعه‌دهندگان و DBA‌ها"),
  spacer(),
  heading("۱.۲ دامنه", 2),
  rtlParagraph("این سند شامل ۱۵ جدول است که ماژول مدیریت وظایف و جداول وابسته (organizations، users، projects، project_members) را پوشش می‌دهد. جداول سایر ماژول‌ها (اسناد، مکاتبات، قراردادها، تدارکات) در اسناد جداگانه ارائه خواهند شد."),
  spacer(),
  heading("۱.۳ تکنولوژی", 2),
  makeTable(["مولفه", "تکنولوژی"], [
    ["پایگاه داده", "PostgreSQL 16+"],
    ["نوع کلید اصلی", "UUID (uuid_generate_v4)"],
    ["زمان", "TIMESTAMPTZ (با timezone)"],
    ["Encoding", "UTF-8"],
    ["Extension‌ها", "uuid-ossp, pgcrypto, pg_trgm"],
  ], [40, 60]),
  spacer(),
  heading("۱.۴ کنوانسیون‌های نام‌گذاری", 2),
  makeTable(["عنصر", "کنوانسیون", "مثال"], [
    ["جدول", "snake_case، جمع", "tasks, task_members"],
    ["ستون", "snake_case", "task_id, created_at"],
    ["FK", "{table_singular}_id", "task_id, user_id"],
    ["ایندکس", "idx_{table}_{cols}", "idx_tasks_project"],
    ["محدودیت", "chk/uq_{table}_{desc}", "chk_tasks_progress"],
    ["تریگر", "trg_{table}_{action}", "trg_tasks_updated"],
    ["نما", "v_{name}", "v_task_summary"],
  ], [20, 35, 45]),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 2: Schema Overview
  heading("فصل دوم: نمای کلی Schema", 1),
  rtlParagraph("ماژول مدیریت وظایف شامل ۱۵ جدول است که در ۴ دسته طبقه‌بندی می‌شوند:"),
  spacer(),
  heading("۲.۱ جداول پایه (وابسته)", 2),
  makeTable(["جدول", "توضیح", "رکورد مورد انتظار"], [
    ["organizations", "سازمان‌ها (پیمانکار، مشاور، کارفرما)", "۱۰-۱۰۰"],
    ["users", "کاربران سامانه", "۱۰۰-۱۰۰۰"],
    ["projects", "پروژه‌های عمرانی", "۵۰-۵۰۰"],
    ["project_members", "ارتباط کاربر-پروژه با نقش", "۵۰۰-۵۰۰۰"],
  ], [25, 50, 25]),
  spacer(),
  heading("۲.۲ جداول اصلی وظایف", 2),
  makeTable(["جدول", "توضیح", "رکورد مورد انتظار"], [
    ["tasks", "وظایف اصلی - موجودیت هسته", "۱,۰۰۰-۱۰,۰۰۰"],
    ["task_members", "اعضای وظیفه با نقش و درصد مشارکت", "۳,۰۰۰-۳۰,۰۰۰"],
    ["subtasks", "زیروظایف", "۵,۰۰۰-۵۰,۰۰۰"],
    ["task_workflow_steps", "مراحل گردش کار هر وظیفه", "۵,۰۰۰-۵۰,۰۰۰"],
  ], [25, 50, 25]),
  spacer(),
  heading("۲.۳ جداول ارتباطی", 2),
  makeTable(["جدول", "توضیح", "رکورد مورد انتظار"], [
    ["task_comments", "نظرات و بحث وظیفه", "۱۰,۰۰۰-۱۰۰,۰۰۰"],
    ["task_time_logs", "ثبت زمان صرف‌شده", "۵۰,۰۰۰-۵۰۰,۰۰۰"],
    ["task_attachments", "پیوست‌های وظیفه", "۵,۰۰۰-۵۰,۰۰۰"],
    ["task_labels", "برچسب‌های پروژه", "۱۰۰-۱,۰۰۰"],
    ["task_label_associations", "ارتباط وظیفه-برچسب", "۱۰,۰۰۰-۱۰۰,۰۰۰"],
    ["task_watchers", "دنبال‌کنندگان وظیفه", "۵,۰۰۰-۵۰,۰۰۰"],
  ], [25, 50, 25]),
  spacer(),
  heading("۲.۴ جدول Audit Trail", 2),
  makeTable(["جدول", "توضیح", "رکورد مورد انتظار"], [
    ["task_activity_log", "لاگ کامل فعالیت‌ها (append-only)", "۱۰۰,۰۰۰-۱,۰۰۰,۰۰۰"],
  ], [30, 55, 15]),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 3: Detailed Table Designs
  heading("فصل سوم: طراحی دقیق جداول", 1),

  heading("۳.۱ جدول tasks (وظایف)", 2),
  rtlParagraph("جدول اصلی ماژول - هر رکورد یک وظیفه را نشان می‌دهد. شامل وضعیت، اولویت، پیشرفت، زمان‌بندی و گردش کار است."),
  makeTable(["ستون", "نوع", "الزامی", "توضیح"], [
    ["id", "UUID", "بله", "کلید اصلی (auto-generated)"],
    ["title", "VARCHAR(300)", "بله", "عنوان وظیفه"],
    ["description", "TEXT", "خیر", "شرح کامل وظیفه"],
    ["status", "task_status (ENUM)", "بله", "backlog, todo, in_progress, review, done, blocked"],
    ["priority", "task_priority (ENUM)", "بله", "low, medium, high, critical"],
    ["project_id", "UUID (FK)", "بله", "پروژه مربوطه"],
    ["parent_task_id", "UUID (FK self)", "خیر", "وظیفه والد (برای سلسله‌مراتب)"],
    ["start_date", "VARCHAR(10)", "بله", "تاریخ شروع (شمسی YYYY/MM/DD)"],
    ["due_date", "VARCHAR(10)", "بله", "تاریخ سررسید (شمسی)"],
    ["completed_at", "TIMESTAMPTZ", "خیر", "تاریخ تکمیل واقعی (auto-set)"],
    ["progress", "INTEGER", "بله", "درصد پیشرفت 0-100 (auto-calculated)"],
    ["estimated_hours", "NUMERIC(8,2)", "بله", "زمان تخمینی به ساعت"],
    ["spent_hours", "NUMERIC(8,2)", "بله", "زمان صرف‌شده (auto-calculated)"],
    ["tags", "JSONB", "بله", "آرایه تگ‌ها"],
    ["workflow_current", "VARCHAR(100)", "خیر", "نام مرحله فعلی گردش کار"],
    ["created_by", "UUID (FK)", "بله", "ایجادکننده"],
    ["updated_by", "UUID (FK)", "خیر", "آخرین ویرایشگر"],
    ["version", "INTEGER", "بله", "نسخه (optimistic concurrency)"],
    ["created_at", "TIMESTAMPTZ", "بله", "تاریخ ایجاد"],
    ["updated_at", "TIMESTAMPTZ", "بله", "تاریخ به‌روزرسانی (auto-trigger)"],
    ["deleted_at", "TIMESTAMPTZ", "خیر", "Soft delete"],
  ], [22, 22, 10, 46]),
  spacer(),
  heading("ایندکس‌های جدول tasks", 3),
  makeTable(["نام", "ستون‌ها", "نوع", "دلیل"], [
    ["idx_tasks_project", "project_id", "B-Tree", "فیلتر وظایف یک پروژه"],
    ["idx_tasks_status", "status", "B-Tree", "فیلتر Kanban Board"],
    ["idx_tasks_priority", "priority", "B-Tree", "فیلتر اولویت"],
    ["idx_tasks_parent", "parent_task_id", "B-Tree", "سلسله‌مراتب زیروظیفه"],
    ["idx_tasks_created_by", "created_by", "B-Tree", "وظایف یک کاربر"],
    ["idx_tasks_due_date", "due_date", "B-Tree", "وظایف سررسید نزدیک (partial)"],
    ["idx_tasks_title_trgm", "title", "GIN (trigram)", "جستجوی فازی"],
    ["idx_tasks_tags", "tags", "GIN", "جستجو در تگ‌های JSONB"],
    ["idx_tasks_project_status", "project_id, status", "Composite", "Kanban یک پروژه"],
  ], [25, 22, 18, 35]),
  spacer(),
  note("تریکر trg_task_status_change به‌صورت خودکار completed_at را هنگام تغییر وضعیت به 'done' تنظیم می‌کند و در task_activity_log ثبت می‌نماید.", "info"),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۳.۲ جدول task_members (اعضای وظیفه)", 2),
  rtlParagraph("ارتباط چند به چند بین کاربران و وظایف با نقش مستقل و درصد مشارکت. هر وظیفه می‌تواند چندین عضو با نقش‌های مختلف (مسئول، همکار، بازبین، تأییدکننده، ناظر) داشته باشد."),
  makeTable(["ستون", "نوع", "الزامی", "توضیح"], [
    ["id", "UUID", "بله", "کلید اصلی"],
    ["task_id", "UUID (FK)", "بله", "وظیفه"],
    ["user_id", "UUID (FK)", "بله", "کاربر"],
    ["role", "task_member_role (ENUM)", "بله", "owner, contributor, reviewer, approver, observer"],
    ["participation_percent", "INTEGER", "بله", "درصد مشارکت 0-100 (مجموع باید ۱۰۰ باشد)"],
    ["time_spent_hours", "NUMERIC(8,2)", "بله", "زمان صرف‌شده این عضو (auto-calculated)"],
    ["assigned_at", "TIMESTAMPTZ", "بله", "تاریخ تخصیص"],
    ["unassigned_at", "TIMESTAMPTZ", "خیر", "تاریخ حذف از وظیفه"],
    ["is_active", "BOOLEAN", "بله", "آیا عضو فعال است"],
  ], [22, 25, 10, 43]),
  spacer(),
  note("محدودیت UNIQUE (task_id, user_id) WHERE is_active = TRUE تضمین می‌کند که هر کاربر فقط یک بار عضو فعال یک وظیفه باشد.", "info"),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۳.۳ جدول subtasks (زیروظایف)", 2),
  makeTable(["ستون", "نوع", "الزامی", "توضیح"], [
    ["id", "UUID", "بله", "کلید اصلی"],
    ["task_id", "UUID (FK)", "بله", "وظیفه والد"],
    ["title", "VARCHAR(200)", "بله", "عنوان زیروظیفه"],
    ["is_done", "BOOLEAN", "بله", "آیا انجام شده"],
    ["display_order", "INTEGER", "بله", "ترتیب نمایش"],
    ["completed_at", "TIMESTAMPTZ", "خیر", "تاریخ تکمیل (auto-set via trigger)"],
    ["completed_by", "UUID (FK)", "خیر", "تکمیل‌کننده"],
  ], [22, 22, 10, 46]),
  spacer(),
  note("تریکر trg_subtask_completion به‌صورت خودکار completed_at را هنگام is_done = TRUE تنظیم می‌کند. تریگر recalculate_task_progress به‌صورت خودکار progress وظیفه والد را از وضعیت زیروظایف محاسبه می‌کند.", "info"),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۳.۴ جدول task_workflow_steps (مراحل گردش کار)", 2),
  makeTable(["ستون", "نوع", "الزامی", "توضیح"], [
    ["id", "UUID", "بله", "کلید اصلی"],
    ["task_id", "UUID (FK)", "بله", "وظیفه"],
    ["step_name", "VARCHAR(100)", "بله", "نام مرحله"],
    ["step_order", "INTEGER", "بله", "ترتیب مرحله"],
    ["status", "wf_step_status (ENUM)", "بله", "done, current, pending"],
    ["assigned_to", "UUID (FK)", "خیر", "مسئول مرحله"],
    ["started_at", "TIMESTAMPTZ", "خیر", "شروع مرحله"],
    ["completed_at", "TIMESTAMPTZ", "خیر", "تکمیل مرحله"],
    ["completed_by", "UUID (FK)", "خیر", "تأییدکننده"],
    ["comment", "TEXT", "خیر", "نظر مسئول"],
  ], [22, 25, 10, 43]),
  spacer(),
  note("محدودیت CHECK تضمین می‌کند که وضعیت و تاریخ‌ها سازگار هستند: pending → بدون تاریخ، current → فقط started_at، done → هر دو تاریخ.", "info"),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۳.۵ جدول task_time_logs (ثبت زمان)", 2),
  makeTable(["ستون", "نوع", "الزامی", "توضیح"], [
    ["id", "UUID", "بله", "کلید اصلی"],
    ["task_id", "UUID (FK)", "بله", "وظیفه"],
    ["user_id", "UUID (FK)", "بله", "کاربر"],
    ["hours", "NUMERIC(6,2)", "بله", "ساعت (0 < hours ≤ 24)"],
    ["description", "VARCHAR(500)", "خیر", "شرح کار انجام‌شده"],
    ["log_date", "DATE", "بله", "تاریخ ثبت"],
    ["source", "time_log_source (ENUM)", "بله", "manual, timer, import"],
    ["timer_started_at", "TIMESTAMPTZ", "خیر", "شروع تایمر (فقط source=timer)"],
    ["timer_stopped_at", "TIMESTAMPTZ", "خیر", "توقف تایمر"],
  ], [22, 25, 10, 43]),
  spacer(),
  note("تریکر trg_time_log_update_hours به‌صورت خودکار spent_hours در tasks و time_spent_hours در task_members را پس از هر INSERT/UPDATE/DELETE به‌روزرسانی می‌کند.", "info"),
  new Paragraph({ children: [new PageBreak()] }),

  heading("۳.۶ جدول task_activity_log (Audit Trail)", 2),
  rtlParagraph("این جدول append-only است (بدون UPDATE و DELETE) و تمام فعالیت‌های مرتبط با وظایف را ثبت می‌کند. شامل snapshot نام و نقش کاربر برای دقت تاریخی."),
  makeTable(["ستون", "نوع", "الزامی", "توضیح"], [
    ["id", "UUID", "بله", "کلید اصلی"],
    ["task_id", "UUID (FK)", "بله", "وظیفه"],
    ["activity_type", "task_activity_type (ENUM)", "بله", "نوع فعالیت (۱۵ نوع)"],
    ["actor_id", "UUID (FK)", "بله", "انجام‌دهنده"],
    ["actor_name", "VARCHAR(100)", "بله", "نام کاربر (snapshot)"],
    ["actor_role", "VARCHAR(50)", "خیر", "نقش در زمان اقدام"],
    ["field_name", "VARCHAR(100)", "خیر", "فیلد تغییر یافته"],
    ["old_value", "TEXT", "خیر", "مقدار قبلی"],
    ["new_value", "TEXT", "خیر", "مقدار جدید"],
    ["description", "TEXT", "خیر", "شرح انسانی"],
    ["ip_address", "INET", "خیر", "IP درخواست"],
    ["user_agent", "TEXT", "خیر", "مرورگر/دستگاه"],
    ["metadata", "JSONB", "بله", "داده‌های ساختاریافته اضافی"],
  ], [22, 25, 10, 43]),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 4: Enums
  heading("فصل چهارم: انواع شمارشی (Enums)", 1),
  rtlParagraph("پایگاه داده از ۹ نوع ENUM استفاده می‌کند که type safety را تضمین می‌کنند:"),
  makeTable(["Enum", "مقادیر", "کاربرد"], [
    ["organization_type", "contractor, consultant, employer, epc, subcontractor, custom", "نوع سازمان"],
    ["user_status", "active, inactive, invited", "وضعیت کاربر"],
    ["project_status", "planning, active, on_hold, completed, cancelled", "وضعیت پروژه"],
    ["project_role", "project_manager, site_manager, technical_office, execution_engineer, electrical_engineer, mechanical_engineer, custom", "نقش در پروژه"],
    ["task_status", "backlog, todo, in_progress, review, done, blocked", "وضعیت وظیفه (Kanban)"],
    ["task_priority", "low, medium, high, critical", "اولویت وظیفه"],
    ["task_member_role", "owner, contributor, reviewer, approver, observer", "نقش عضو وظیفه"],
    ["wf_step_status", "done, current, pending", "وضعیت مرحله گردش کار"],
    ["task_activity_type", "created, updated, status_changed, ... (15 نوع)", "نوع فعالیت Audit Trail"],
  ], [20, 55, 25]),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 5: Triggers & Functions
  heading("فصل پنجم: تریگرها و توابع", 1),
  rtlParagraph("۸ تریگر و تابع در این schema تعریف شده‌اند که منطق کسب‌وکار را در سطح پایگاه داده اعمال می‌کنند:"),
  makeTable(["تریگر", "جدول", "عملکرد"], [
    ["trg_organizations_updated", "organizations", "به‌روزرسانی updated_at"],
    ["trg_users_updated", "users", "به‌روزرسانی updated_at"],
    ["trg_projects_updated", "projects", "به‌روزرسانی updated_at"],
    ["trg_tasks_updated", "tasks", "به‌روزرسانی updated_at + increment version"],
    ["trg_task_status_change", "tasks", "ثبت Audit Trail + تنظیم completed_at"],
    ["trg_subtask_completion", "subtasks", "تنظیم خودکار completed_at"],
    ["trg_subtask_progress_update", "subtasks", "محاسبه خودکار progress وظیفه"],
    ["trg_time_log_update_hours", "task_time_logs", "به‌روزرسانی spent_hours"],
    ["trg_update_project_counts_*", "tasks", "به‌روزرسانی open_tasks/overdue_tasks پروژه"],
  ], [30, 20, 50]),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 6: Views
  heading("فصل ششم: نماهای (Views)", 1),
  rtlParagraph("دو view برای query‌های پرتکرار تعریف شده‌اند:"),
  heading("۶.۱ v_task_summary", 2),
  rtlParagraph("خلاصه هر وظیفه با شمارش اعضا، زیروظایف، نظرات، پیوست‌ها و وضعیت سررسید. برای نمایش در فهرست‌ها و داشبورد استفاده می‌شود."),
  spacer(),
  heading("۶.۲ v_user_task_workload", 2),
  rtlParagraph("بار کاری هر کاربر: تعداد وظایف فعال، وظایف بحرانی، ساعت باقی‌مانده و وظایف سررسید گذشته. برای داشبورد مدیر و KPI استفاده می‌شود."),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 7: Design Decisions
  heading("فصل هفتم: تصمیمات طراحی", 1),
  heading("۷.۱ UUID به جای SERIAL", 2),
  rtlParagraph("از UUID به جای SERIAL (integer auto-increment) استفاده شده است. مزایا: ایمن در محیط توزیع‌شده، عدم قابل حدس بودن، امکان تولید در سمت کلاینت، عدم نیاز به round-trip برای دریافت ID پس از INSERT."),
  spacer(),
  heading("۷.۲ Soft Delete", 2),
  rtlParagraph("جداول اصلی از soft delete (deleted_at) استفاده می‌کنند. این رویکرد امکان بازیابی داده‌های حذف‌شده و حفظ referential integrity را فراهم می‌کند. تمام query‌ها با WHERE deleted_at IS NULL فیلتر می‌شوند."),
  spacer(),
  heading("۷.۳ تاریخ شمسی به‌صورت VARCHAR", 2),
  rtlParagraph("تاریخ‌های شمسی (Jalali) به‌صورت VARCHAR(10) با فرمت YYYY/MM/DD ذخیره می‌شوند. دلیل: PostgreSQL از تاریخ شمسی به‌صورت بومی پشتیبانی نمی‌کند و ذخیره به‌صورت رشته امکان مقایسه رشته‌ای (مرتب‌سازی صحیح) را فراهم می‌کند."),
  spacer(),
  heading("۷.۴ JSONB برای tags و preferences", 2),
  rtlParagraph("از JSONB برای ذخیره آرایه‌های پویا (tags) و تنظیمات (preferences) استفاده شده است. JSONB عملکرد بهتری از JSON دارد و از GIN index برای جستجوی سریع پشتیبانی می‌کند."),
  spacer(),
  heading("۷.۵ Audit Trail Append-Only", 2),
  rtlParagraph("جدول task_activity_log فقط INSERT را اجازه می‌دهد (بدون UPDATE و DELETE). این رویکرد تضمین می‌کند که تاریخچه فعالیت‌ها غیرقابل تغییر است و برای حسابرسی قانونی قابل اعتماد است."),
  spacer(),
  heading("۷.۶ Optimistic Concurrency با version", 2),
  rtlParagraph("جدول tasks دارای فیلد version است که با هر UPDATE به‌صورت خودکار (trigger) افزایش می‌یابد. این الگو امکان optimistic locking را فراهم می‌کند و از lost update در محیط‌های همزمان جلوگیری می‌نماید."),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 8: Performance
  heading("فصل هشتم: ملاحظات عملکرد", 1),
  heading("۸.۱ استراتژی ایندکس‌گذاری", 2),
  bullet("B-Tree برای فیلدهای FK و equality lookup"),
  bullet("GIN (trigram) برای جستجوی فازی در title و name"),
  bullet("GIN (JSONB) برای جستجو در tags و mentions"),
  bullet("Partial Index برای query‌های پرتکرار با شرط (WHERE deleted_at IS NULL)"),
  bullet("Composite Index برای query‌های چندستونه (project_id + status)"),
  spacer(),
  heading("۸.۲ Partitioning (آینده)", 2),
  rtlParagraph("برای جداول با رشد بالا (task_activity_log, task_time_logs)، partitioning بر اساس زمان (monthly) در فاز دوم توصیه می‌شود. PostgreSQL از declarative partitioning پشتیبانی می‌کند."),
  spacer(),
  heading("۸.۳ Materialized Views (آینده)", 2),
  rtlParagraph("برای گزارش‌های تحلیلی سنگین، Materialized Views با refresh دوره‌ای (هر ساعت) می‌تواند عملکرد را بهبود بخشد."),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 9: Security
  heading("فصل نهم: ملاحظات امنیتی", 1),
  bullet("Row Level Security (RLS): فیلتر خودکار بر اساس organization_id کاربر"),
  bullet("Soft delete: جلوگیری از حذف تصادفی داده"),
  bullet("Audit Trail: ثبت کامل فعالیت‌ها با IP و User-Agent"),
  bullet("UUID: عدم قابل حدس بودن ID‌ها برای جلوگیری از enumeration"),
  bullet("CHECK constraints: اعتبارسنجی در سطح پایگاه داده"),
  bullet("version field: جلوگیری از lost update"),
  new Paragraph({ children: [new PageBreak()] }),

  // Chapter 10: Future
  heading("فصل دهم: توسعه آینده", 1),
  numberedItem("۱", "افزودن جداول اسناد و پیوست مستقل (documents, document_versions)"),
  numberedItem("۲", "افزودن جداول مکاتبات و قراردادها"),
  numberedItem("۳", "افزودن جداول تدارکات و وندورها"),
  numberedItem("۴", "Partitioning جداول Audit Trail و Time Logs بر اساس زمان"),
  numberedItem("۵", "Full-text search با pg_trgm و materialized views"),
  numberedItem("۶", "Read replica برای گزارش‌های سنگین"),
  numberedItem("۷", "Database backup با pg_dump و point-in-time recovery"),
  spacer(),
  heading("تاریخچه تغییرات", 2),
  makeTable(["نسخه", "تاریخ", "توضیح"], [
    ["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه - ماژول مدیریت وظایف"],
  ], [15, 25, 60]),
];

// ===== Assemble document =====
const doc = new Document({
  creator: "CM Automation Team",
  title: "طراحی پایگاه داده - ماژول مدیریت وظایف",
  description: "Database Design Document for Task Management Module",
  styles: {
    default: {
      document: {
        run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY }, size: 24, color: P.body },
        paragraph: { spacing: { line: 360 } },
      },
      heading1: {
        run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 36, bold: true, color: P.primary },
        paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 480, after: 200, line: 480 } },
      },
      heading2: {
        run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 30, bold: true, color: P.primary },
        paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 360, after: 160, line: 400 } },
      },
      heading3: {
        run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 26, bold: true, color: P.primaryDark },
        paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 240, after: 120, line: 360 } },
      },
    },
  },
  sections: [
    {
      properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 } } },
      children: buildCover(
        "طراحی پایگاه داده: ماژول مدیریت وظایف",
        "Database Design: Task Management Module",
        "نسخه ۱.۰",
        "۱۴۰۳/۱۰/۰۱",
        "DB-TASK-001"
      ),
    },
    {
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 }, pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: new Header({ children: [new Paragraph({ bidirectional: true, alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "طراحی پایگاه داده - ماژول مدیریت وظایف - نسخه ۱.۰", rightToLeft: true, size: 18, color: P.muted, font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY } })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "صفحه ", rightToLeft: true, size: 18, color: P.muted }), new TextRun({ children: [PageNumber.CURRENT], size: 18, color: P.muted })] })] }) },
      children: [...tocSection(), ...chapters],
    },
  ],
});

Packer.toBuffer(doc).then(buffer => {
  const outPath = path.join(OUT_DIR, "02-مستندات-پایگاه-داده-مدیریت-وظایف.docx");
  fs.writeFileSync(outPath, buffer);
  console.log(`✓ Generated: ${outPath} (${(buffer.length / 1024).toFixed(1)} KB)`);
}).catch(err => { console.error("Error:", err); process.exit(1); });
