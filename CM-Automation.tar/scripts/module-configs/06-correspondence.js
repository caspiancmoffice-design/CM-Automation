// 06-correspondence.js
module.exports = {
  meta: {
    title: "معماری ماژول مکاتبات",
    subtitle: "Correspondence Module Architecture",
    version: "نسخه ۱.۰",
    date: "۱۴۰۳/۱۰/۰۱",
    code: "MOD-CORR-006",
    fileName: "06-معماری-ماژول-مکاتبات.docx",
    description: "Architecture document for Correspondence module",
  },

  introduction: {
    purpose: "ماژول مکاتبات مدیریت نامه‌های وارده و صادره در پروژه‌های عمرانی را بر عهده دارد. این ماژول شامل ثبت نامه‌ها با شماره‌گذاری خودکار، پیوست فایل، ارتباط با پروژه‌ها، پیگیری وضعیت (پیش‌نویس، ارسال، دریافت، پاسخ، بایگانی) و جستجوی پیشرفته است. هر مکاتبه می‌تواند به مکاتبه والد (پاسخ به) متصل شود.",
    goals: [
      "مدیریت مکاتبات وارده و صادره با شماره‌گذاری خودکار",
      "پیوست فایل به مکاتبات",
      "ارتباط مکاتبات با پروژه‌ها",
      "پیگیری وضعیت پاسخ‌گویی",
      "زنجیره پاسخ (مکاتبه والد و فرزند)",
      "جستجوی پیشرفته در موضوع، شماره و محتوا",
    ],
    audience: ["توسعه‌دهندگان", "معماران نرم‌افزار", "مدیران محصول"],
    scope: "این ماژول شامل فهرست مکاتبات (با فیلتر وارده/صادره)، ایجاد مکاتبه جدید، نمایش جزئیات با محتوا و پیوست‌ها، پاسخ به مکاتبه است.",
    glossary: [
      ["Correspondence", "مکاتبه - نامه وارده یا صادره"],
      ["Inbound", "وارده - نامه دریافتی"],
      ["Outbound", "صادره - نامه ارسالی"],
      ["Parent Correspondence", "مکاتبه والد - نامه‌ای که این مکاتبه به آن پاسخ است"],
    ],
  },

  logical: {
    overview: "ماژول مکاتبات شامل فهرست مکاتبات با فیلتر وارده/صادره، مودال ایجاد نامه جدید، و دیالوگ نمایش جزئیات است. هر مکاتبه می‌تواند به یک پروژه و یک مکاتبه والد متصل باشد.",
    components: [
      ["CorrespondenceListView", "فهرست مکاتبات با فیلتر و جستجو", "Next.js + React"],
      ["CorrespondenceDetailsDialog", "دیالوگ نمایش جزئیات نامه", "React"],
      ["NewLetterModal", "مودال ایجاد نامه جدید با فرم کامل", "React Hook Form"],
      ["CorrespondenceAPI", "سرویس ارتباط با API مکاتبات", "Axios + React Query"],
    ],
    dependencies: [
      ["پروژه‌ها", "متعلق به", "مکاتبات می‌توانند به پروژه متصل شوند"],
      ["اسناد", "پیوست", "فایل‌های پیوست مکاتبه در ماژول اسناد ذخیره می‌شوند"],
      ["اعلان‌ها", "ارسال رویداد", "دریافت نامه جدید اعلان تولید می‌کند"],
      ["کاربران", "ارجاع", "مکاتبات می‌توانند به کاربران ارجاع داده شوند"],
    ],
    interfaces: [
      { name: "CorrespondenceCRUDAPI", description: "ایجاد، خواندن، ویرایش، حذف مکاتبه" },
      { name: "CorrespondenceReplyAPI", description: "پاسخ به مکاتبه (ایجاد مکاتبه فرزند)" },
      { name: "CorrespondenceSearchAPI", description: "جستجو در مکاتبات" },
    ],
  },

  dataModel: {
    overview: "موجودیت Correspondence موجودیت اصلی است. ارتباط والد-فرزند با self-reference برای زنجیره پاسخ‌ها.",
    entities: [
      {
        name: "Correspondence",
        tableName: "correspondences",
        description: "موجودیت مکاتبه - نامه وارده یا صادره",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["number", "VARCHAR(50)", "بله", "شماره نامه (auto-generated)"],
          ["subject", "VARCHAR(500)", "بله", "موضوع نامه"],
          ["direction", "ENUM", "بله", "inbound, outbound"],
          ["status", "ENUM", "بله", "draft, sent, received, in_review, answered, archived"],
          ["from_party", "VARCHAR(200)", "بله", "فرستنده"],
          ["to_party", "VARCHAR(200)", "بله", "گیرنده"],
          ["date", "DATE", "بله", "تاریخ نامه"],
          ["received_date", "DATE", "خیر", "تاریخ دریافت (برای وارده)"],
          ["project_id", "UUID", "خیر", "پروژه مربوطه (FK)"],
          ["priority", "ENUM", "بله", "low, medium, high, critical"],
          ["body", "TEXT", "بله", "متن نامه"],
          ["category", "VARCHAR(50)", "خیر", "دسته: فنی، مالی، اجرایی، رسمی"],
          ["parent_id", "UUID", "خیر", "مکاتبه والد (self-reference)"],
          ["created_by", "UUID", "بله", "ایجادکننده (FK)"],
          ["created_at", "TIMESTAMP", "بله", "تاریخ ایجاد"],
        ],
      },
      {
        name: "CorrespondenceAttachment",
        tableName: "correspondence_attachments",
        description: "پیوست‌های مکاتبه - ارجاع به اسناد",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["correspondence_id", "UUID", "بله", "مکاتبه (FK)"],
          ["document_id", "UUID", "بله", "سند پیوست (FK)"],
        ],
      },
    ],
    relationships: [
      "Correspondence ↔ Project (چند به یک)",
      "Correspondence ↔ Correspondence (self-reference - والد/فرزند)",
      "Correspondence ↔ Document (چند به چند از طریق CorrespondenceAttachment)",
    ],
    indexes: [
      ["idx_corr_project", "project_id", "B-Tree", "مکاتبات یک پروژه"],
      ["idx_corr_direction", "direction", "B-Tree", "فیلتر وارده/صادره"],
      ["idx_corr_status", "status", "B-Tree", "فیلتر وضعیت"],
      ["idx_corr_number", "number", "UNIQUE", "جستجو با شماره"],
      ["idx_corr_parent", "parent_id", "B-Tree", "زنجیره پاسخ"],
    ],
  },

  api: {
    overview: "API ماژول مکاتبات شامل endpoint‌های CRUD، پاسخ به مکاتبه، و جستجو است.",
    endpoints: [
      {
        id: "۱",
        method: "GET",
        path: "/api/v1/correspondences",
        description: "دریافت فهرست مکاتبات با فیلتر",
        request: `GET /api/v1/correspondences?direction=inbound&status=received
Authorization: Bearer {token}`,
        response: `{ "data": [{ "id": "uuid", "number": "PA-1403/1024", "subject": "..." }] }`,
        statusCodes: [["200", "موفق"]],
      },
      {
        id: "۲",
        method: "POST",
        path: "/api/v1/correspondences",
        description: "ایجاد مکاتبه جدید",
        request: `POST /api/v1/correspondences
{
  "subject": "درخواست تأیید نقشه‌ها",
  "direction": "outbound",
  "from_party": "شرکت پارس آرین",
  "to_party": "مهندس مشاور",
  "date": "1403/10/01",
  "priority": "high",
  "body": "متن نامه...",
  "project_id": "uuid"
}`,
        response: `{ "id": "uuid", "number": "PA-1403/1027" }`,
        statusCodes: [["201", "ایجاد شد"], ["400", "داده نامعتبر"]],
      },
      {
        id: "۳",
        method: "POST",
        path: "/api/v1/correspondences/{id}/reply",
        description: "پاسخ به مکاتبه (ایجاد مکاتبه فرزند)",
        request: `POST /api/v1/correspondences/{id}/reply
{ "subject": "پاسخ: ...", "body": "متن پاسخ...", "direction": "outbound" }`,
        response: `{ "id": "uuid", "parent_id": "uuid" }`,
        statusCodes: [["201", "پاسخ ثبت شد"]],
      },
    ],
  },

  useCases: {
    overview: "موارد استفاده شامل ایجاد نامه، پاسخ به نامه، و پیگیری وضعیت است.",
    cases: [
      {
        id: "UC-CORR-001",
        title: "ایجاد نامه صادره جدید",
        actor: "کاربر با دسترسی",
        preconditions: ["کاربر دسترسی دارد"],
        mainFlow: [
          "کاربر روی «نامه جدید» کلیک می‌کند",
          "مودال فرم ایجاد نامه باز می‌شود",
          "موضوع، نوع (صادره/وارده)، فرستنده، گیرنده وارد می‌شود",
          "تاریخ از تقویم شمسی انتخاب می‌شود",
          "متن نامه وارد می‌شود",
          "پروژه مربوطه انتخاب می‌شود",
          "شماره نامه خودکار تولید می‌شود",
          "نامه با وضعیت «ارسال شده» ثبت می‌شود",
        ],
        alternativeFlows: ["کاربر می‌تواند نامه را به‌عنوان پیش‌نویس ذخیره کند"],
        postconditions: ["نامه ثبت می‌شود", "شماره یکتا تولید می‌شود"],
      },
      {
        id: "UC-CORR-002",
        title: "پاسخ به مکاتبه",
        actor: "کاربر با دسترسی",
        preconditions: ["مکاتبه وجود دارد"],
        mainFlow: [
          "از جزئیات مکاتبه، کاربر روی «پاسخ» کلیک می‌کند",
          "فرم پاسخ با اطلاعات والد پر می‌شود",
          "کاربر متن پاسخ را وارد می‌کند",
          "مکاتبه فرزند ایجاد می‌شود",
          "وضعیت مکاتبه والد به «پاسخ داده شده» تغییر می‌کند",
        ],
        alternativeFlows: [],
        postconditions: ["مکاتبه فرزند ایجاد می‌شود", "وضعیت والد به‌روزرسانی می‌شود"],
      },
    ],
  },

  sequenceDiagrams: [
    {
      id: "SD-CORR-001",
      title: "ایجاد نامه با شماره‌گذاری خودکار",
      description: "توالی ایجاد نامه و تولید شماره یکتا",
      participants: ["User", "Frontend", "Backend API", "Database", "Counter Service"],
      flow: [
        "User فرم نامه را پر می‌کند",
        "Frontend POST /api/v1/correspondences می‌فرستد",
        "Backend شماره یکتا را از Counter Service دریافت می‌کند",
        "Counter شماره بعدی را generate و increment می‌کند",
        "Backend مکاتبه را با شماره در Database ثبت می‌کند",
        "Backend پاسخ 201 با شماره برمی‌گرداند",
      ],
    },
  ],

  security: {
    overview: "امنیت مکاتبات بر اساس RBAC است. کاربران فقط مکاتبات پروژه‌هایی که دسترسی دارند را می‌بینند. مکاتبات حساس می‌توانند محدود به کاربران خاص باشند.",
    roles: [
      ["مدیر پروژه", "دسترسی کامل به مکاتبات پروژه"],
      ["کارشناس", "ایجاد و مشاهده مکاتبات پروژه"],
      ["مدیر سیستم", "دسترسی کامل"],
    ],
    requirements: ["اعتبارسنجی دسترسی به پروژه", "Audit trail کامل", "محدودیت دسترسی به مکاتبات حساس"],
    auditTrail: "تمام عملیات مکاتبات (ایجاد، ویرایش، پاسخ، حذف) در Audit Trail ثبت می‌شوند.",
  },

  businessRules: [
    {
      id: "BR-CORR-001",
      title: "شماره‌گذاری خودکار و یکتا",
      description: "شماره نامه به‌صورت خودکار با فرمت {ORG-CODE}/{YEAR}/{SEQUENTIAL} تولید می‌شود. به عنوان مثال: PA-1403/1024. شماره‌ها در سال جدید از ۱ شروع می‌شوند.",
      validation: `const number = await counterService.getNext('correspondence', organization_id, year);
// Format: ORG-CODE/YEAR/SEQUENTIAL`,
    },
    {
      id: "BR-CORR-002",
      title: "وضعیت «پاسخ داده شده» خودکار",
      description: "وقتی مکاتبه فرزند (پاسخ) ایجاد می‌شود، وضعیت مکاتبه والد به‌صورت خودکار به «پاسخ داده شده» تغییر می‌کند.",
      validation: `if (reply.parent_id) {
  await updateStatus(reply.parent_id, 'answered');
}`,
    },
  ],

  quality: {
    performance: [["زمان پاسخ فهرست", "< ۲۰۰ms", "Prometheus"], ["زمان ایجاد", "< ۳۰۰ms", "-"]],
    availability: ["ماژول ۹۹.۵٪ در دسترس باشد", "Counter Service با Redis برای مقیاس‌پذیری"],
    scalability: ["صفحه‌بندی برای فهرست", "Index روی direction و status"],
  },

  implementation: {
    patterns: [
      ["Composite Pattern", "زنجیره مکاتبات والد-فرزند"],
      ["Counter Pattern", "شماره‌گذاری خودکار با Redis"],
      ["Repository Pattern", "CorrespondenceRepository"],
    ],
    notes: ["از Redis برای counter شماره‌گذاری", "پشتیبانی از rich text در body نامه", "جستجوی full-text با OpenSearch"],
    testing: "Unit test برای counter، integration test برای زنجیره پاسخ.",
    relatedDocs: ["سند معماری کلی سامانه", "مستندات API مکاتبات"],
    changelog: [["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه"]],
  },
};
