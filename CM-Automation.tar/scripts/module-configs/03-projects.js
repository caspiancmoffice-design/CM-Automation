// 03-projects.js — Module config for Projects module
module.exports = {
  meta: {
    title: "معماری ماژول پروژه‌ها",
    subtitle: "Projects Module Architecture",
    version: "نسخه ۱.۰",
    date: "۱۴۰۳/۱۰/۰۱",
    code: "MOD-PROJ-003",
    fileName: "03-معماری-ماژول-پروژه‌ها.docx",
    description: "Architecture document for Projects module",
  },

  introduction: {
    purpose: "ماژول پروژه‌ها یکی از ماژول‌های هسته سامانه CM Automation است و مدیریت چرخه حیات کامل پروژه‌های عمرانی را بر عهده دارد. این ماژول از ایجاد پروژه تا تکمیل، شامل مدیریت اطلاعات پایه، طرفین قرارداد، بودجه، زمان‌بندی، پیشرفت و مستندات را پوشش می‌دهد. هر پروژه می‌تواند شامل وظایف، اسناد، مکاتبات، قراردادها و درخواست‌های خرید باشد.",
    goals: [
      "مدیریت چرخه حیات کامل پروژه از ایجاد تا تکمیل",
      "ثبت اطلاعات پایه پروژه شامل کارفرما، مشاور، پیمانکار و محل اجرا",
      "مدیریت بودجه و زمان‌بندی پروژه با ردیابی پیشرفت",
      "ارائه نمای ۳۶۰ درجه از پروژه شامل همه ماژول‌های مرتبط",
      "پشتیبانی از چند نوع سازمان (پیمانکار، مشاور، کارفرما، EPC)",
      "ارائه گزارش‌های تحلیلی پیشرفت و بودجه",
    ],
    audience: ["توسعه‌دهندگان Frontend و Backend", "معماران نرم‌افزار", "مدیران محصول", "مدیران پروژه"],
    scope: "این ماژول شامل فهرست پروژه‌ها (کارت/جدول)، جزئیات پروژه با ۶ تب (نمای کلی، وظایف، اسناد، مکاتبات، تیم، مالی)، ایجاد/ویرایش پروژه، فیلتر و جستجوی پیشرفته است.",
    glossary: [
      ["Project", "پروژه عمرانی - واحد اصلی مدیریت در سامانه"],
      ["Project Status", "وضعیت پروژه: برنامه‌ریزی، فعال، متوقف، تکمیل شده، لغو شده"],
      ["Project Code", "کد یکتای پروژه (مثال: PA-1402-01)"],
      ["Stakeholder", "ذی‌نفع پروژه: کارفرما، مشاور، پیمانکار"],
    ],
  },

  logical: {
    overview: "ماژول پروژه‌ها به‌صورت یک aggregate root در DDD طراحی شده است. Project موجودیت اصلی است و سایر موجودیت‌ها (وظایف، اسناد، مکاتبات) به آن متصل می‌شوند. ماژول شامل دو view اصلی است: فهرست پروژه‌ها با فیلتر و نمایش کارت/جدول، و جزئیات پروژه با تب‌بندی.",
    components: [
      ["ProjectsListView", "نمایش فهرست پروژه‌ها با کارت/جدول، فیلتر و جستجو", "Next.js + React"],
      ["ProjectDetailsView", "نمایش جزئیات پروژه با ۶ تب", "Next.js + React"],
      ["ProjectFormModal", "مودال ایجاد/ویرایش پروژه با اعتبارسنجی", "React + React Hook Form"],
      ["ProjectCard", "کارت پروژه برای نمایش در فهرست", "React"],
      ["ProjectProgress", "نمایش progress bar پروژه", "React"],
      ["ProjectAPI", "سرویس ارتباط با API پروژه‌ها", "Axios + React Query"],
      ["ProjectDomainService", "منطق کسب‌وکار پروژه در Backend", "ASP.NET Core"],
    ],
    dependencies: [
      ["وظایف", "یک به چند", "هر پروژه شامل چندین وظیفه"],
      ["اسناد", "یک به چند", "اسناد به پروژه متصل می‌شوند"],
      ["مکاتبات", "یک به چند", "مکاتبات می‌توانند به پروژه مرتبط باشند"],
      ["قراردادها", "یک به چند", "قراردادها به پروژه‌ها متصل هستند"],
      ["تدارکات", "یک به چند", "درخواست‌های خرید به پروژه مربوط می‌شوند"],
      ["کاربران", "چند به چند", "اعضای تیم پروژه"],
      ["اعلان‌ها", "ارسال رویداد", "ایجاد/ویرایش پروژه اعلان تولید می‌کند"],
    ],
    interfaces: [
      { name: "ProjectCRUDAPI", description: "رابط ایجاد، خواندن، ویرایش، حذف پروژه" },
      { name: "ProjectSearchAPI", description: "رابط جستجو و فیلتر پروژه‌ها" },
      { name: "ProjectStatsAPI", description: "رابط دریافت آمار پروژه (وظایف، بودجه، پیشرفت)" },
    ],
  },

  dataModel: {
    overview: "موجودیت Project موجودیت اصلی این ماژول است و شامل اطلاعات کامل پروژه از جمله اطلاعات پایه، طرفین، بودجه، زمان‌بندی و پیشرفت است.",
    entities: [
      {
        name: "Project",
        tableName: "projects",
        description: "موجودیت اصلی پروژه - شامل تمام اطلاعات یک پروژه عمرانی",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتای پروژه"],
          ["name", "VARCHAR(200)", "بله", "نام پروژه"],
          ["code", "VARCHAR(50)", "بله", "کد یکتای پروژه (مثال: PA-1402-01)"],
          ["description", "TEXT", "خیر", "شرح پروژه"],
          ["status", "ENUM", "بله", "وضعیت: planning, active, on_hold, completed, cancelled"],
          ["organization_id", "UUID", "بله", "سازمان مالک پروژه (FK)"],
          ["client", "VARCHAR(200)", "بله", "نام کارفرما"],
          ["consultant", "VARCHAR(200)", "خیر", "نام مهندس مشاور"],
          ["contractor", "VARCHAR(200)", "خیر", "نام پیمانکار"],
          ["start_date", "DATE", "بله", "تاریخ شروع (شمسی)"],
          ["end_date", "DATE", "بله", "تاریخ پایان (شمسی)"],
          ["progress", "INTEGER", "بله", "درصد پیشرفت (0-100)"],
          ["budget", "BIGINT", "بله", "بودجه کل به ریال"],
          ["spent_budget", "BIGINT", "بله", "بودجه مصرف‌شده به ریال"],
          ["location", "VARCHAR(500)", "خیر", "محل اجرای پروژه"],
          ["manager_id", "UUID", "بله", "مدیر پروژه (FK به users)"],
          ["team_size", "INTEGER", "خیر", "تعداد اعضای تیم"],
          ["tags", "JSONB", "خیر", "تگ‌های پروژه به صورت آرایه"],
          ["created_at", "TIMESTAMP", "بله", "تاریخ ایجاد"],
          ["updated_at", "TIMESTAMP", "بله", "تاریخ به‌روزرسانی"],
        ],
      },
      {
        name: "ProjectMember",
        tableName: "project_members",
        description: "ارتباط چند به چند بین پروژه و کاربران با نقش پروژه",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["project_id", "UUID", "بله", "شناسه پروژه (FK)"],
          ["user_id", "UUID", "بله", "شناسه کاربر (FK)"],
          ["role", "ENUM", "بله", "نقش در پروژه: project_manager, site_manager, ..."],
          ["assigned_at", "TIMESTAMP", "بله", "تاریخ تخصیص"],
        ],
      },
    ],
    relationships: [
      "Project ↔ Organization (یک به چند - هر سازمان چند پروژه دارد)",
      "Project ↔ User (چند به چند - از طریق ProjectMember)",
      "Project ↔ Task (یک به چند)",
      "Project ↔ Document (یک به چند)",
      "Project ↔ Correspondence (یک به چند)",
      "Project ↔ Contract (یک به چند)",
      "Project ↔ PurchaseRequest (یک به چند)",
    ],
    indexes: [
      ["idx_projects_org", "organization_id", "B-Tree", "فیلتر پروژه‌ها بر اساس سازمان"],
      ["idx_projects_status", "status", "B-Tree", "فیلتر بر اساس وضعیت"],
      ["idx_projects_manager", "manager_id", "B-Tree", "پروژه‌های یک مدیر"],
      ["idx_projects_code", "code", "UNIQUE", "جستجوی سریع با کد"],
      ["idx_projects_tags", "tags", "GIN", "جستجو در تگ‌های JSONB"],
    ],
  },

  api: {
    overview: "API ماژول پروژه‌ها RESTful است و از conventional routing استفاده می‌کند. تمام endpoint‌ها نیاز به احراز هویت دارند و بر اساس scope دسترسی کاربر فیلتر می‌شوند.",
    endpoints: [
      {
        id: "۱",
        method: "GET",
        path: "/api/v1/projects",
        description: "دریافت فهرست پروژه‌ها با فیلتر و صفحه‌بندی",
        request: `GET /api/v1/projects?page=1&per_page=20&status=active&search=برج
Authorization: Bearer {token}`,
        response: `{
  "data": [
    {
      "id": "uuid",
      "name": "برج مسکونی آرین",
      "code": "PA-1402-01",
      "status": "active",
      "progress": 62,
      "budget": 1850000000000,
      "spent_budget": 1147000000000,
      "start_date": "1402/07/01",
      "end_date": "1404/12/29",
      "manager_name": "مهندس رضا کریمی",
      "team_size": 24,
      "open_tasks": 47,
      "overdue_tasks": 6
    }
  ],
  "meta": { "page": 1, "per_page": 20, "total": 5 }
}`,
        statusCodes: [["200", "موفق"], ["401", "احراز هویت ناموفق"], ["403", "دسترسی غیرمجاز"]],
      },
      {
        id: "۲",
        method: "POST",
        path: "/api/v1/projects",
        description: "ایجاد پروژه جدید",
        request: `POST /api/v1/projects
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "برج مسکونی آرین",
  "code": "PA-1402-01",
  "description": "...",
  "client": "سازمان نوسازی تهران",
  "start_date": "1402/07/01",
  "end_date": "1404/12/29",
  "budget": 1850000000000,
  "location": "تهران - منطقه ۲",
  "manager_id": "uuid"
}`,
        response: `{ "id": "uuid", "status": "planning", "created_at": "..." }`,
        statusCodes: [["201", "ایجاد شد"], ["400", "داده نامعتبر"], ["409", "کد پروژه تکراری"]],
      },
      {
        id: "۳",
        method: "GET",
        path: "/api/v1/projects/{id}",
        description: "دریافت جزئیات کامل پروژه شامل آمار",
        request: `GET /api/v1/projects/{id}?include=stats,tasks,documents
Authorization: Bearer {token}`,
        response: `{ "id": "uuid", "name": "...", "stats": {...}, "tasks": [...], "documents": [...] }`,
        statusCodes: [["200", "موفق"], ["404", "پروژه یافت نشد"]],
      },
      {
        id: "۴",
        method: "PUT",
        path: "/api/v1/projects/{id}",
        description: "ویرایش پروژه",
        request: `PUT /api/v1/projects/{id}\n{ "name": "نام جدید", "progress": 65 }`,
        response: `{ "id": "uuid", "updated_at": "..." }`,
        statusCodes: [["200", "ویرایش شد"], ["404", "یافت نشد"], ["403", "دسترسی غیرمجاز"]],
      },
      {
        id: "۵",
        method: "DELETE",
        path: "/api/v1/projects/{id}",
        description: "حذف نرم پروژه (soft delete)",
        request: `DELETE /api/v1/projects/{id}\nAuthorization: Bearer {token}`,
        response: `{ "deleted": true }`,
        statusCodes: [["200", "حذف شد"], ["404", "یافت نشد"], ["409", "قابل حذف نیست (وظایف فعال)"]],
      },
    ],
  },

  useCases: {
    overview: "موارد استفاده اصلی ماژول پروژه‌ها شامل ایجاد، مشاهده، ویرایش و مدیریت چرخه حیات پروژه است.",
    cases: [
      {
        id: "UC-PROJ-001",
        title: "ایجاد پروژه جدید",
        actor: "مدیر پروژه یا مدیر سیستم",
        preconditions: ["کاربر دسترسی ایجاد پروژه دارد", "کد پروژه یکتا است"],
        mainFlow: [
          "کاربر روی «پروژه جدید» کلیک می‌کند",
          "مودال فرم ایجاد پروژه باز می‌شود",
          "کاربر اطلاعات پایه را وارد می‌کند (نام، کد، کارفرما)",
          "کاربر تاریخ شروع و پایان را از تقویم شمسی انتخاب می‌کند",
          "کاربر بودجه و محل پروژه را وارد می‌کند",
          "کاربر مدیر پروژه را انتخاب می‌کند",
          "سیستم اعتبارسنجی می‌کند (کد یکتا، تاریخ معتبر)",
          "پروژه با وضعیت «برنامه‌ریزی» ایجاد می‌شود",
          "اعلان به مدیر پروژه ارسال می‌شود",
        ],
        alternativeFlows: ["اگر کد تکراری باشد، خطا نمایش داده می‌شود", "اگر تاریخ پایان قبل از شروع باشد، خطا"],
        postconditions: ["پروژه در پایگاه داده ایجاد می‌شود", "اعلان به مدیر پروژه ارسال می‌شود", "Audit log ثبت می‌شود"],
      },
      {
        id: "UC-PROJ-002",
        title: "مشاهده جزئیات پروژه",
        actor: "کاربر با دسترسی به پروژه",
        preconditions: ["پروژه وجود دارد", "کاربر دسترسی دارد"],
        mainFlow: [
          "کاربر از فهرست پروژه‌ها روی یک پروژه کلیک می‌کند",
          "سیستم به صفحه جزئیات هدایت می‌کند",
          "تب «نمای کلی» پیش‌فرض نمایش داده می‌شود",
          "KPI‌های پروژه (پیشرفت، بودجه، وظایف) نمایش داده می‌شود",
          "کاربر می‌تواند به تب‌های دیگر برود",
        ],
        alternativeFlows: ["اگر کاربر دسترسی نداشته باشد، صفحه 403 نمایش داده می‌شود"],
        postconditions: ["جزئیات پروژه نمایش داده می‌شود", "بازدید در audit log ثبت می‌شود"],
      },
      {
        id: "UC-PROJ-003",
        title: "تغییر وضعیت پروژه",
        actor: "مدیر پروژه",
        preconditions: ["پروژه در وضعیت قابل تغییر است"],
        mainFlow: [
          "مدیر پروژه از جزئیات پروژه وضعیت جدید را انتخاب می‌کند",
          "سیستم قوانین انتقال وضعیت را اعتبارسنجی می‌کند",
          "وضعیت جدید ثبت می‌شود",
          "اعلان به ذی‌نفعان ارسال می‌شود",
        ],
        alternativeFlows: ["اگر انتقال وضعیت مجاز نباشد، خطا نمایش داده می‌شود"],
        postconditions: ["وضعیت پروژه به‌روزرسانی می‌شود", "اعلان ارسال می‌شود"],
      },
    ],
  },

  sequenceDiagrams: [
    {
      id: "SD-PROJ-001",
      title: "ایجاد پروژه جدید",
      description: "توالی ایجاد پروژه از کلیک کاربر تا ثبت در پایگاه داده",
      participants: ["User", "Frontend", "Backend API", "Database", "Notification Service", "Audit Log"],
      flow: [
        "User روی «پروژه جدید» کلیک می‌کند",
        "Frontend مودال فرم را نمایش می‌دهد",
        "User فرم را پر کرده و submit می‌کند",
        "Frontend اعتبارسنجی کلاینت انجام می‌دهد",
        "Frontend POST /api/v1/projects می‌فرستد",
        "Backend توکن را اعتبارسنجی می‌کند",
        "Backend دسترسی کاربر را بررسی می‌کند",
        "Backend کد پروژه را برای یکتایی بررسی می‌کند",
        "Backend پروژه را در Database ایجاد می‌کند",
        "Backend رویداد ProjectCreated را publish می‌کند",
        "Notification Service اعلان به مدیر پروژه ارسال می‌کند",
        "Audit Log رویداد را ثبت می‌کند",
        "Backend پاسخ 201 به Frontend برمی‌گرداند",
        "Frontend به صفحه جزئیات پروژه هدایت می‌کند",
      ],
    },
  ],

  security: {
    overview: "امنیت ماژول پروژه‌ها بر اساس RBAC + Scope است. کاربران فقط به پروژه‌های سازمان خود و پروژه‌هایی که عضو تیم آن‌ها هستند دسترسی دارند. مدیر پروژه دسترسی کامل به پروژه‌های خود دارد، در حالی که کارشناس فقط می‌تواند پروژه‌هایی که عضو آن‌ها است را ببیند.",
    roles: [
      ["مدیر ارشد", "دسترسی به همه پروژه‌های سازمان + ایجاد/ویرایش/حذف"],
      ["مدیر پروژه", "دسترسی کامل به پروژه‌های خود + ایجاد پروژه جدید"],
      ["کارشناس", "فقط مشاهده پروژه‌هایی که عضو آن‌ها است"],
      ["مدیر سیستم", "دسترسی کامل + مدیریت تنظیمات"],
    ],
    requirements: [
      "اعتبارسنجی scope در هر درخواست API",
      "فیلتر خودکار پروژه‌ها بر اساس organization_id کاربر",
      "بررسی عضویت در team برای کاربران غیرمدیر",
      "Soft delete برای جلوگیری از حذف تصادفی",
      "Audit trail کامل برای ایجاد، ویرایش، حذف",
    ],
    auditTrail: "تمام عملیات روی پروژه‌ها (ایجاد، ویرایش، حذف، تغییر وضعیت) در Audit Trail ثبت می‌شوند. هر لاگ شامل: کاربر، نوع عملیات، فیلدهای تغییر یافته (diff)، timestamp و IP کاربر است.",
  },

  businessRules: [
    {
      id: "BR-PROJ-001",
      title: "کد پروژه یکتا در سازمان",
      description: "کد پروژه باید در هر سازمان یکتا باشد. دو پروژه در یک سازمان نمی‌توانند کد یکسان داشته باشند. اما پروژه‌های سازمان‌های مختلف می‌توانند کد یکسان داشته باشند.",
      validation: `const existing = await db.projects
  .where({ organization_id, code })
  .whereNull('deleted_at')
  .first();
if (existing) throw new Error('کد پروژه تکراری است');`,
    },
    {
      id: "BR-PROJ-002",
      title: "تاریخ پایان باید بعد از تاریخ شروع باشد",
      description: "تاریخ پایان پروژه نمی‌تواند قبل از تاریخ شروع باشد. این اعتبارسنجی در سمت کلاینت و سرور انجام می‌شود.",
      validation: `if (endDate <= startDate) {
  throw new ValidationError('تاریخ پایان باید بعد از تاریخ شروع باشد');
}`,
    },
    {
      id: "BR-PROJ-003",
      title: "قوانین انتقال وضعیت پروژه",
      description: "انتقال وضعیت پروژه باید مطابق state machine باشد. به عنوان مثال، پروژه «تکمیل شده» نمی‌تواند به «فعال» برگردد. انتقال‌های مجاز: planning→active، active→on_hold، on_hold→active، active→completed، active→cancelled.",
      validation: `const allowedTransitions = {
  planning: ['active'],
  active: ['on_hold', 'completed', 'cancelled'],
  on_hold: ['active', 'cancelled'],
  completed: [],
  cancelled: [],
};
if (!allowedTransitions[currentStatus].includes(newStatus)) {
  throw new Error('انتقال وضعیت مجاز نیست');
}`,
    },
    {
      id: "BR-PROJ-004",
      title: "حذف پروژه با وظایف فعال ممنوع",
      description: "پروژه‌ای که وظایف فعال (غیر انجام‌شده) دارد، نمی‌تواند حذف شود. ابتدا باید همه وظایف تکمیل یا لغو شوند.",
      validation: `const activeTasks = await db.tasks
  .where({ project_id, status: ['not_in', ['done', 'cancelled']] })
  .count();
if (activeTasks > 0) {
  throw new Error('پروژه دارای وظایف فعال است و قابل حذف نیست');
}`,
    },
  ],

  quality: {
    performance: [
      ["زمان پاسخ فهرست پروژه‌ها (P95)", "< ۲۰۰ms", "Application Insights"],
      ["زمان پاسخ جزئیات پروژه", "< ۳۰۰ms", "Prometheus"],
      ["زمان ایجاد پروژه", "< ۵۰۰ms", "Custom metric"],
      ["تعداد پروژه‌های قابل نمایش در صفحه", "۲۰ (با صفحه‌بندی)", "-"],
    ],
    availability: [
      "ماژول پروژه‌ها ۹۹.۵٪ در دسترس باشد",
      "Database replication برای failover",
      "Cache برای فهرست پروژه‌های پرتکرار",
    ],
    scalability: [
      "صفحه‌بندی برای فهرست پروژه‌ها",
      "Index روی organization_id و status",
      "Read replica برای گزارش‌های سنگین",
    ],
  },

  implementation: {
    patterns: [
      ["Aggregate Root (DDD)", "Project به‌عنوان aggregate root برای وظایف، اسناد و ..."],
      ["Repository Pattern", "ProjectRepository برای انتزاع دسترسی داده"],
      ["Factory Pattern", "ProjectFactory برای ایجاد پروژه با مقادیر پیش‌فرض"],
      ["State Machine", "مدیریت انتقال وضعیت پروژه"],
      ["Specification Pattern", "فیلترهای پویا برای جستجوی پروژه"],
    ],
    notes: [
      "از materialized view برای آمار پروژه استفاده شود",
      "Cache فهرست پروژه‌ها با TTL ۵ دقیقه",
      "Soft delete برای جلوگیری از حذف تصادفی",
      "به‌روزرسانی progress به‌صورت batch (هر شب) از وضعیت وظایف",
    ],
    testing: "Unit test برای domain logic (state machine، validation)، integration test برای repository، E2E test برای سناریوهای ایجاد/ویرایش/حذف.",
    relatedDocs: ["سند معماری کلی سامانه", "مستندات API پروژه‌ها (Swagger)", "راهنمای UI/UX پروژه‌ها"],
    changelog: [["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه"]],
  },
};
