// 07-contracts.js
module.exports = {
  meta: {
    title: "معماری ماژول قراردادها",
    subtitle: "Contracts Module Architecture",
    version: "نسخه ۱.۰",
    date: "۱۴۰۳/۱۰/۰۱",
    code: "MOD-CONT-007",
    fileName: "07-معماری-ماژول-قراردادها.docx",
    description: "Architecture document for Contracts module",
  },

  introduction: {
    purpose: "ماژول قراردادها مدیریت قراردادهای پارامتریک با ۱۶ قالب آماده را بر عهده دارد. این ماژول امکان ایجاد قرارداد با ویزارد ۸ مرحله‌ای، خروجی Word و PDF، چاپ، و مدیریت چرخه حیات کامل قرارداد را فراهم می‌کند. هر نوع قرارداد (گچ‌کاری، بتن، درب، آسانسور، موتورخانه، تابلو برق و ...) دارای تعهدات و شرایط پیش‌فرض مختص به خود است.",
    goals: [
      "مدیریت قراردادهای پارامتریک با ۱۶ قالب آماده",
      "ویزارد ۸ مرحله‌ای برای ایجاد قرارداد",
      "خروجی Word (.docx) و PDF با قالب قابل چاپ",
      "پشتیبانی از ۱۷ ماده استاندارد قرارداد",
      "تعهدات پارامتریک بر اساس نوع پیمانکار",
      "اعتبارسنجی کدملی، شماره موبایل و شماره شبا",
    ],
    audience: ["توسعه‌دهندگان", "معماران نرم‌افزار", "مدیران محصول", "کارشناسان حقوقی"],
    scope: "این ماژول شامل فهرست قراردادها، جزئیات با ۷ تب، ویزارد ایجاد قرارداد، خروجی Word/PDF است.",
    glossary: [
      ["Contract", "قرارداد پیمانکاری"],
      ["Contract Type", "نوع قرارداد (gypsum, concrete, plywood_door, elevator, ...)"],
      ["Template", "قالب آماده قرارداد با تعهدات پیش‌فرض"],
      ["Parametric", "پارامتریک - قابل تنظیم بر اساس پارامترها"],
      ["Obligation", "تعهد - بند قرارداد با دسته‌بندی"],
    ],
  },

  logical: {
    overview: "ماژول قراردادها از سه بخش تشکیل شده: فهرست قراردادها، جزئیات قرارداد با ۷ تب، و ویزارد ۸ مرحله‌ای ایجاد. هر قالب قرارداد دارای تعهدات پیش‌فرض است که قابل ویرایش، حذف و افزودن است. خروجی با کتابخانه docx برای Word و print iframe برای PDF تولید می‌شود.",
    components: [
      ["ContractsListView", "فهرست قراردادها با فیلتر نوع/وضعیت", "Next.js + React"],
      ["ContractDetailsView", "جزئیات با ۷ تب (نمای کلی، طرفین، مالی، تعهدات، ضمائم، جرایم، پیش‌نمایش)", "Next.js + React"],
      ["ContractNewWizard", "ویزارد ۸ مرحله‌ای ایجاد قرارداد", "React"],
      ["ContractPreview", "پیش‌نمایش قابل چاپ با ۱۷ ماده", "React + CSS Print"],
      ["ExportButtons", "دکمه‌های چاپ، Word، PDF", "React"],
      ["ValidatedInput", "input با اعتبارسنجی (کدملی، موبایل، شبا)", "React"],
      ["JalaliDatePicker", "تقویم شمسی", "React"],
      ["ContractAPI", "سرویس ارتباط با API قراردادها", "Axios + React Query"],
      ["ContractExportService", "سرویس خروجی Word/PDF", "docx + iframe print"],
    ],
    dependencies: [
      ["پروژه‌ها", "متعلق به", "قراردادها به پروژه متصل هستند"],
      ["تأمین‌کنندگان", "طرف قرارداد", "پیمانکار در قرارداد از وندورها انتخاب می‌شود"],
      ["اعلان‌ها", "ارسال رویداد", "تأیید/فسخ قرارداد اعلان تولید می‌کند"],
      ["اسناد", "ضمائم", "ضمائم قرارداد در ماژول اسناد ذخیره می‌شوند"],
    ],
    interfaces: [
      { name: "ContractCRUDAPI", description: "ایجاد، خواندن، ویرایش، حذف قرارداد" },
      { name: "ContractTemplateAPI", description: "دریافت قالب‌های آماده قرارداد" },
      { name: "ContractExportAPI", description: "خروجی Word و PDF" },
      { name: "ContractWorkflowAPI", description: "مدیریت وضعیت قرارداد (تأیید، ابلاغ، فسخ)" },
    ],
  },

  dataModel: {
    overview: "موجودیت Contract موجودیت اصلی است. ContractTemplate قالب‌های آماده را نگه می‌دارد. Obligation تعهدات پارامتریک را ذخیره می‌کند.",
    entities: [
      {
        name: "Contract",
        tableName: "contracts",
        description: "موجودیت اصلی قرارداد - پارامتریک با ۱۷ ماده",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["number", "VARCHAR(50)", "بله", "شماره قرارداد"],
          ["title", "VARCHAR(300)", "بله", "عنوان قرارداد"],
          ["type", "ENUM", "بله", "gypsum, concrete, plywood_door, elevator, fan_coil, mechanical, electrical_panel, rebar, brickwork, plumbing, wiring, painting, tile, roofing, demolition, other"],
          ["category", "ENUM", "بله", "execution, supply, service"],
          ["status", "ENUM", "بله", "draft, in_review, approved, active, suspended, terminated, completed, expired"],
          ["subject", "TEXT", "بله", "موضوع قرارداد (ماده ۱)"],
          ["project_id", "UUID", "خیر", "پروژه مربوطه (FK)"],
          ["project_name", "VARCHAR(200)", "بله", "نام پروژه"],
          ["project_address", "TEXT", "بله", "محل اجرا (ماده ۲)"],
          ["employer", "JSONB", "بله", "اطلاعات کارفرما (ContractParty)"],
          ["contractor", "JSONB", "بله", "اطلاعات پیمانکار (ContractParty)"],
          ["financial", "JSONB", "بله", "اطلاعات مالی (FinancialTerms)"],
          ["duration", "JSONB", "بله", "مدت قرارداد (ContractDuration)"],
          ["penalties", "JSONB", "بله", "جرایم و فسخ (PenaltyTerms)"],
          ["dispute_resolution", "TEXT", "بله", "حل اختلاف (ماده ۱۲)"],
          ["created_by", "UUID", "بله", "ایجادکننده (FK)"],
          ["created_at", "TIMESTAMP", "بله", "تاریخ ایجاد"],
          ["approved_at", "TIMESTAMP", "خیر", "تاریخ تأیید"],
          ["issued_at", "TIMESTAMP", "خیر", "تاریخ ابلاغ"],
        ],
      },
      {
        name: "ContractObligation",
        tableName: "contract_obligations",
        description: "تعهدات قرارداد - پارامتریک بر اساس نوع",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["contract_id", "UUID", "بله", "قرارداد (FK)"],
          ["code", "VARCHAR(10)", "بله", "شماره بند (مثال: 8-1)"],
          ["text", "TEXT", "بله", "متن تعهد"],
          ["category", "ENUM", "بله", "general, technical, safety, hse, personnel, tools, materials, reporting"],
          ["party", "ENUM", "بله", "contractor, employer"],
          ["order", "INTEGER", "بله", "ترتیب نمایش"],
        ],
      },
      {
        name: "ContractTemplate",
        tableName: "contract_templates",
        description: "قالب‌های آماده قرارداد - ۱۶ قالب",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["type", "ENUM", "بله", "نوع قرارداد (unique)"],
          ["title", "VARCHAR(200)", "بله", "عنوان قالب"],
          ["default_subject", "TEXT", "بله", "موضوع پیش‌فرض"],
          ["default_obligations", "JSONB", "بله", "تعهدات پیش‌فرض"],
          ["default_prepayment", "INTEGER", "بله", "پیش‌پرداخت پیش‌فرض (٪)"],
          ["default_retention", "INTEGER", "بله", "حسن انجام کار پیش‌فرض (٪)"],
          ["recommended_duration", "INTEGER", "بله", "مدت پیشنهادی (ماه)"],
        ],
      },
      {
        name: "PriceItem",
        tableName: "contract_price_items",
        description: "ردیف‌های بهای پیمان",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["contract_id", "UUID", "بله", "قرارداد (FK)"],
          ["code", "VARCHAR(10)", "بله", "کد ردیف"],
          ["description", "TEXT", "بله", "شرح"],
          ["unit", "VARCHAR(20)", "بله", "واحد"],
          ["quantity", "DECIMAL", "بله", "مقدار"],
          ["unit_price", "BIGINT", "بله", "بهای واحد (ریال)"],
          ["total_price", "BIGINT", "بله", "مبلغ کل (ریال)"],
        ],
      },
    ],
    relationships: [
      "Contract ↔ Project (چند به یک)",
      "Contract ↔ ContractObligation (یک به چند)",
      "Contract ↔ PriceItem (یک به چند)",
      "Contract ↔ Vendor (از طریق JSONB contractor)",
    ],
    indexes: [
      ["idx_contracts_type", "type", "B-Tree", "فیلتر نوع"],
      ["idx_contracts_status", "status", "B-Tree", "فیلتر وضعیت"],
      ["idx_contracts_project", "project_id", "B-Tree", "قراردادهای یک پروژه"],
      ["idx_contracts_number", "number", "UNIQUE", "جستجو با شماره"],
    ],
  },

  api: {
    overview: "API ماژول قراردادها شامل CRUD، قالب‌ها، خروجی و گردش کار است.",
    endpoints: [
      {
        id: "۱",
        method: "GET",
        path: "/api/v1/contracts",
        description: "دریافت فهرست قراردادها",
        request: `GET /api/v1/contracts?type=gypsum&status=active
Authorization: Bearer {token}`,
        response: `{ "data": [{ "id": "uuid", "number": "1019/د/ق", "title": "..." }] }`,
        statusCodes: [["200", "موفق"]],
      },
      {
        id: "۲",
        method: "POST",
        path: "/api/v1/contracts",
        description: "ایجاد قرارداد جدید (پارامتریک)",
        request: `POST /api/v1/contracts
{
  "type": "gypsum",
  "title": "قرارداد گچ‌کاری - حسن حسین‌زاده",
  "number": "1019/د/ق",
  "subject": "اجرای گچ و خاک و سفیدکاری",
  "project_id": "uuid",
  "employer": { "name": "...", "national_id": "..." },
  "contractor": { "name": "...", "national_id": "..." },
  "financial": { "total_amount": 791000000, "prepayment_percent": 0 },
  "duration": { "total_months": 6, "start_date": "1403/05/01" }
}`,
        response: `{ "id": "uuid", "status": "draft" }`,
        statusCodes: [["201", "ایجاد شد"], ["400", "داده نامعتبر"]],
      },
      {
        id: "۳",
        method: "GET",
        path: "/api/v1/contracts/{id}/export/word",
        description: "دانلود قرارداد به‌صورت Word (.docx)",
        request: `GET /api/v1/contracts/{id}/export/word
Authorization: Bearer {token}`,
        response: `Binary file (application/vnd.openxmlformats-officedocument.wordprocessingml.document)`,
        statusCodes: [["200", "دانلود"], ["404", "یافت نشد"]],
      },
      {
        id: "۴",
        method: "GET",
        path: "/api/v1/contracts/templates",
        description: "دریافت قالب‌های آماده قرارداد",
        request: `GET /api/v1/contracts/templates`,
        response: `{ "data": [{ "type": "gypsum", "title": "قرارداد گچ‌کاری", ... }] }`,
        statusCodes: [["200", "موفق"]],
      },
    ],
  },

  useCases: {
    overview: "موارد استفاده شامل ویزارد ایجاد، خروجی Word/PDF، و گردش کار تأیید است.",
    cases: [
      {
        id: "UC-CONT-001",
        title: "ایجاد قرارداد با ویزارد ۸ مرحله‌ای",
        actor: "کارشناس دفتر فنی",
        preconditions: ["کاربر دسترسی دارد"],
        mainFlow: [
          "کاربر روی «قرارداد جدید» کلیک می‌کند",
          "مرحله ۱: انتخاب نوع قرارداد (۱۶ قالب)",
          "مرحله ۲: مشخصات کلی (عنوان، شماره، موضوع، پروژه)",
          "مرحله ۳: طرفین (کارفرما و پیمانکار با اعتبارسنجی کدملی)",
          "مرحله ۴: مدت (با تقویم شمسی، تاریخ پایان خودکار)",
          "مرحله ۵: مالی (مبلغ، پیش‌پرداخت، تضمین)",
          "مرحله ۶: تعهدات (بازبینی تعهدات پیش‌فرض، ویرایش)",
          "مرحله ۷: ردیف‌های بهای پیمان",
          "مرحله ۸: پیش‌نمایش و ثبت",
        ],
        alternativeFlows: ["کاربر می‌تواند بین مراحل back/forward کند"],
        postconditions: ["قرارداد با وضعیت پیش‌نویس ایجاد می‌شود"],
      },
      {
        id: "UC-CONT-002",
        title: "خروجی Word قرارداد",
        actor: "کاربر با دسترسی",
        preconditions: ["قرارداد وجود دارد"],
        mainFlow: [
          "از جزئیات قرارداد، کاربر روی «Word» کلیک می‌کند",
          "Backend قرارداد را با کتابخانه docx به Word تبدیل می‌کند",
          "فایل .docx با ۱۷ ماده کامل تولید می‌شود",
          "فایل به کاربر دانلود می‌شود",
        ],
        alternativeFlows: ["خروجی PDF از طریق print مرورگر"],
        postconditions: ["فایل Word دانلود می‌شود"],
      },
    ],
  },

  sequenceDiagrams: [
    {
      id: "SD-CONT-001",
      title: "خروجی Word قرارداد",
      description: "توالی تولید فایل Word از قرارداد",
      participants: ["User", "Frontend", "Backend API", "docx library", "File System"],
      flow: [
        "User روی «Word» کلیک می‌کند",
        "Frontend GET /api/v1/contracts/{id}/export/word می‌فرستد",
        "Backend قرارداد را از Database دریافت می‌کند",
        "Backend با docx library فایل Word می‌سازد",
        "Backend ۱۷ ماده قرارداد را با فرمت RTL اضافه می‌کند",
        "Backend جدول تعهدات و ضمائم را اضافه می‌کند",
        "Backend فایل را به‌عنوان response برمی‌گرداند",
        "Frontend فایل را دانلود می‌کند",
      ],
    },
  ],

  security: {
    overview: "امنیت قراردادها بحرانی است. دسترسی به قراردادها محدود به کاربران مجاز است. اطلاعات مالی قرارداد فقط برای نقش‌های خاص قابل مشاهده است.",
    roles: [
      ["مدیر ارشد", "مشاهده همه قراردادها + خروجی"],
      ["مدیر پروژه", "ایجاد، ویرایش، خروجی قراردادهای پروژه"],
      ["امور مالی", "مشاهده بخش مالی قراردادها"],
      ["کارشناس", "فقط مشاهده (بدون بخش مالی)"],
    ],
    requirements: ["اعتبارسنجی کدملی با الگوریتم check digit", "محدودیت دسترسی به بخش مالی", "Audit trail کامل"],
    auditTrail: "تمام عملیات قراردادها ثبت می‌شود. به‌ویژه خروجی Word/PDF برای ردیابی استفاده.",
  },

  businessRules: [
    {
      id: "BR-CONT-001",
      title: "اعتبارسنجی کدملی با check digit",
      description: "کدملی ۱۰ رقمی باید با الگوریتم check digit ایران اعتبارسنجی شود. این rule در سمت کلاینت و سرور اعمال می‌شود.",
      validation: `function validateNationalId(id) {
  if (!/^\\d{10}$/.test(id)) return false;
  const digits = id.split('').map(Number);
  const check = digits[9];
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += digits[i] * (10 - i);
  const remainder = sum % 11;
  return remainder < 2 ? check === remainder : check === 11 - remainder;
}`,
    },
    {
      id: "BR-CONT-002",
      title: "تاریخ پایان خودکار",
      description: "تاریخ پایان قرارداد به‌صورت خودکار با اضافه کردن مدت قرارداد به تاریخ شروع محاسبه می‌شود. کاربر نمی‌تواند تاریخ پایان را مستقیم وارد کند.",
      validation: `const endDate = addMonthsToJalali(startDate, durationMonths);`,
    },
    {
      id: "BR-CONT-003",
      title: "تعهدات پیش‌فرض بر اساس نوع",
      description: "هنگام انتخاب نوع قرارداد، تعهدات پیش‌فرض آن نوع به‌صورت خودکار بارگذاری می‌شوند. کاربر می‌تواند این تعهدات را ویرایش، حذف یا تعهدات جدید اضافه کند.",
      validation: `const template = contractTemplates[type];
const obligations = template.defaultObligations;`,
    },
  ],

  quality: {
    performance: [["زمان خروجی Word", "< ۳ ثانیه", "Custom"], ["زمان ایجاد قرارداد", "< ۵۰۰ms", "-"]],
    availability: ["ماژول ۹۹.۵٪ در دسترس باشد"],
    scalability: ["docx generation در background برای قراردادهای بزرگ"],
  },

  implementation: {
    patterns: [
      ["Factory Pattern", "ایجاد قرارداد با پارامترهای متغیر بر اساس نوع"],
      ["Strategy Pattern", "الگوریتم‌های اعتبارسنجی مختلف (NationalId, Phone, IBAN)"],
      ["Template Method", "قالب ۱۷ ماده قرارداد با محتوای متغیر"],
      ["Builder Pattern", "ساخت فایل Word با docx library"],
    ],
    notes: ["از docx (npm) برای خروجی Word", "از print iframe برای PDF", "تقویم شمسی اختصاصی", "اعتبارسنجی real-time"],
    testing: "Unit test برای validation، integration test برای خروجی Word.",
    relatedDocs: ["سند معماری کلی سامانه", "مستندات API قراردادها", "راهنمای قالب‌های قرارداد"],
    changelog: [["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه - ۱۶ قالب آماده"]],
  },
};
