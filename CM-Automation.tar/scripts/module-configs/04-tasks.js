// 04-tasks.js — Module config for Tasks module
module.exports = {
  meta: {
    title: "معماری ماژول وظایف",
    subtitle: "Tasks Module Architecture",
    version: "نسخه ۱.۰",
    date: "۱۴۰۳/۱۰/۰۱",
    code: "MOD-TASK-004",
    fileName: "04-معماری-ماژول-وظایف.docx",
    description: "Architecture document for Tasks module",
  },

  introduction: {
    purpose: "ماژول وظایف یکی از ماژول‌های هسته سامانه CM Automation است و مدیریت وظایف چندنفره با نقش‌های مستقل را بر عهده دارد. این ماژول از Kanban Board برای نمایش بصری وظایف، گردش کار برای مدیریت وضعیت، و سیستم زمان‌سنجی برای ردیابی زمان صرف‌شده پشتیبانی می‌کند. هر وظیفه می‌تواند چندین عضو با نقش‌های مختلف (مسئول، همکار، بازبین، تأییدکننده، ناظر) داشته باشد.",
    goals: [
      "مدیریت وظایف چندنفره با نقش‌های مستقل",
      "ارائه Kanban Board با ۵ ستون برای نمایش بصری",
      "پشتیبانی از زیروظایف با progress tracking",
      "سیستم زمان‌سنجی برای ثبت زمان صرف‌شده",
      "گردش کار قابل تنظیم با مراحل قابل تأیید",
      "محاسبه KPI بر اساس نقش، درصد مشارکت و زمان",
    ],
    audience: ["توسعه‌دهندگان Frontend و Backend", "معماران نرم‌افزار", "مدیران محصول", "مدیران پروژه"],
    scope: "این ماژول شامل Kanban Board، فهرست وظایف، جزئیات وظیفه (شامل توضیحات، زیروظایف، نظرات، گردش کار، زمان‌سنجی، اعضا)، ایجاد/ویرایش وظیفه است.",
    glossary: [
      ["Task", "وظیفه - واحد قابل اجرا در یک پروژه"],
      ["Task Member Role", "نقش عضو: مسئول، همکار، بازبین، تأییدکننده، ناظر"],
      ["Kanban Board", "تابلوی بصری با ستون‌های وضعیت"],
      ["Subtask", "زیروظیفه - بخشی از یک وظیفه"],
      ["Workflow", "گردش کار - مراحل قابل تأیید یک وظیفه"],
    ],
  },

  logical: {
    overview: "ماژول وظایف شامل دو view اصلی است: Kanban Board برای نمایش بصری و فهرست وظایف برای نمایش جدولی. هر وظیفه می‌تواند چندین عضو با نقش‌های مستقل و درصد مشارکت متفاوت داشته باشد. گردش کار قابل تنظیم است و مراحل آن قابل تأیید توسط افراد مشخص است.",
    components: [
      ["TasksView", "نمایش Kanban Board یا فهرست وظایف با فیلتر", "Next.js + React"],
      ["TaskDetailsView", "نمایش جزئیات وظیفه با تب‌بندی", "Next.js + React"],
      ["KanbanColumn", "ستون Kanban با drag-and-drop", "React + @dnd-kit"],
      ["TaskCard", "کارت وظیفه در Kanban", "React"],
      ["TaskFormModal", "مودال ایجاد/ویرایش وظیفه", "React Hook Form"],
      ["WorkflowTracker", "نمایش گردش کار با مراحل", "React"],
      ["TimeTracker", "ثبت زمان صرف‌شده با start/stop", "React"],
      ["TaskAPI", "سرویس ارتباط با API وظایف", "Axios + React Query"],
    ],
    dependencies: [
      ["پروژه‌ها", "متعلق به", "هر وظیفه به یک پروژه متصل است"],
      ["کاربران", "چند به چند", "اعضای وظیفه با نقش‌های مستقل"],
      ["اسناد", "یک به چند", "پیوست‌های وظیفه"],
      ["اعلان‌ها", "ارسال رویداد", "تغییر وضعیت، تخصیص، نظر اعلان تولید می‌کند"],
      ["KPI/گزارش‌ها", "خواندن", "محاسبه بهره‌وری بر اساس داده وظایف"],
    ],
    interfaces: [
      { name: "TaskCRUDAPI", description: "ایجاد، خواندن، ویرایش، حذف وظیفه" },
      { name: "TaskWorkflowAPI", description: "مدیریت گردش کار و انتقال وضعیت" },
      { name: "TaskTimeTrackingAPI", description: "ثبت و مدیریت زمان صرف‌شده" },
      { name: "TaskMemberAPI", description: "مدیریت اعضای وظیفه و نقش‌ها" },
    ],
  },

  dataModel: {
    overview: "موجودیت Task موجودیت اصلی است. TaskMember ارتباط چند به چند بین Task و User را با نقش و درصد مشارکت نشان می‌دهد. Subtask برای زیروظایف و WorkflowStep برای مراحل گردش کار تعریف می‌شود.",
    entities: [
      {
        name: "Task",
        tableName: "tasks",
        description: "موجودیت اصلی وظیفه",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["title", "VARCHAR(300)", "بله", "عنوان وظیفه"],
          ["description", "TEXT", "خیر", "شرح وظیفه"],
          ["status", "ENUM", "بله", "backlog, todo, in_progress, review, done, blocked"],
          ["priority", "ENUM", "بله", "low, medium, high, critical"],
          ["project_id", "UUID", "بله", "پروژه مربوطه (FK)"],
          ["start_date", "DATE", "بله", "تاریخ شروع"],
          ["due_date", "DATE", "بله", "تاریخ سررسید"],
          ["completed_at", "TIMESTAMP", "خیر", "تاریخ تکمیل"],
          ["progress", "INTEGER", "بله", "درصد پیشرفت (0-100)"],
          ["estimated_hours", "DECIMAL", "خیر", "زمان تخمینی به ساعت"],
          ["spent_hours", "DECIMAL", "خیر", "زمان صرف‌شده به ساعت"],
          ["tags", "JSONB", "خیر", "تگ‌های وظیفه"],
          ["created_by", "UUID", "بله", "ایجادکننده (FK)"],
          ["created_at", "TIMESTAMP", "بله", "تاریخ ایجاد"],
          ["updated_at", "TIMESTAMP", "بله", "تاریخ به‌روزرسانی"],
        ],
      },
      {
        name: "TaskMember",
        tableName: "task_members",
        description: "ارتباط چند به چند بین وظیفه و کاربر با نقش مستقل",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["task_id", "UUID", "بله", "وظیفه (FK)"],
          ["user_id", "UUID", "بله", "کاربر (FK)"],
          ["role", "ENUM", "بله", "owner, contributor, reviewer, approver, observer"],
          ["participation_percent", "INTEGER", "بله", "درصد مشارکت (0-100)"],
          ["time_spent_hours", "DECIMAL", "خیر", "زمان صرف‌شده این عضو"],
          ["assigned_at", "TIMESTAMP", "بله", "تاریخ تخصیص"],
        ],
      },
      {
        name: "Subtask",
        tableName: "subtasks",
        description: "زیروظایف یک وظیفه",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["task_id", "UUID", "بله", "وظیفه والد (FK)"],
          ["title", "VARCHAR(200)", "بله", "عنوان زیروظیفه"],
          ["done", "BOOLEAN", "بله", "آیا انجام شده"],
          ["order", "INTEGER", "خیر", "ترتیب نمایش"],
        ],
      },
      {
        name: "WorkflowStep",
        tableName: "task_workflow_steps",
        description: "مراحل گردش کار یک وظیفه",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["task_id", "UUID", "بله", "وظیفه (FK)"],
          ["name", "VARCHAR(100)", "بله", "نام مرحله"],
          ["status", "ENUM", "بله", "done, current, pending"],
          ["order", "INTEGER", "بله", "ترتیب مرحله"],
          ["completed_at", "TIMESTAMP", "خیر", "تاریخ تکمیل"],
          ["completed_by", "UUID", "خیر", "تأییدکننده (FK)"],
        ],
      },
      {
        name: "TaskComment",
        tableName: "task_comments",
        description: "نظرات و بحث روی وظیفه",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["task_id", "UUID", "بله", "وظیفه (FK)"],
          ["user_id", "UUID", "بله", "نویسنده نظر (FK)"],
          ["body", "TEXT", "بله", "متن نظر"],
          ["created_at", "TIMESTAMP", "بله", "تاریخ ایجاد"],
        ],
      },
    ],
    relationships: [
      "Task ↔ Project (یک به چند)",
      "Task ↔ User (چند به چند از طریق TaskMember)",
      "Task ↔ Subtask (یک به چند)",
      "Task ↔ WorkflowStep (یک به چند)",
      "Task ↔ TaskComment (یک به چند)",
      "Task ↔ Document (یک به چند - پیوست‌ها)",
    ],
    indexes: [
      ["idx_tasks_project", "project_id", "B-Tree", "وظایف یک پروژه"],
      ["idx_tasks_status", "status", "B-Tree", "فیلتر Kanban"],
      ["idx_tasks_assignee", "created_by", "B-Tree", "وظایف یک کاربر"],
      ["idx_tasks_due_date", "due_date", "B-Tree", "وظایف سررسید نزدیک"],
      ["idx_task_members_user", "user_id, task_id", "Composite", "وظایف یک کاربر"],
    ],
  },

  api: {
    overview: "API ماژول وظایف از RESTful pattern استفاده می‌کند و شامل endpoint‌های CRUD، مدیریت اعضا، گردش کار و زمان‌سنجی است.",
    endpoints: [
      {
        id: "۱",
        method: "GET",
        path: "/api/v1/projects/{projectId}/tasks",
        description: "دریافت وظایف یک پروژه با فیلتر (برای Kanban)",
        request: `GET /api/v1/projects/{projectId}/tasks?status=in_progress&assignee=me
Authorization: Bearer {token}`,
        response: `{ "data": [{ "id": "uuid", "title": "...", "status": "...", "assignees": [...] }] }`,
        statusCodes: [["200", "موفق"], ["401", "احراز هویت"], ["403", "دسترسی غیرمجاز"]],
      },
      {
        id: "۲",
        method: "POST",
        path: "/api/v1/tasks",
        description: "ایجاد وظیفه جدید با اعضا و نقش‌ها",
        request: `POST /api/v1/tasks
{
  "title": "بازبینی نقشه‌های فاز ۲",
  "project_id": "uuid",
  "priority": "high",
  "due_date": "1403/10/15",
  "members": [
    { "user_id": "uuid", "role": "owner", "participation_percent": 60 },
    { "user_id": "uuid", "role": "reviewer", "participation_percent": 20 }
  ]
}`,
        response: `{ "id": "uuid", "status": "todo" }`,
        statusCodes: [["201", "ایجاد شد"], ["400", "داده نامعتبر"]],
      },
      {
        id: "۳",
        method: "PATCH",
        path: "/api/v1/tasks/{id}/status",
        description: "تغییر وضعیت وظیفه (با اعتبارسنجی گردش کار)",
        request: `PATCH /api/v1/tasks/{id}/status
{ "status": "in_progress", "comment": "شروع کار" }`,
        response: `{ "id": "uuid", "status": "in_progress", "updated_at": "..." }`,
        statusCodes: [["200", "تغییر کرد"], ["400", "انتقال مجاز نیست"], ["409", "تضاد"]],
      },
      {
        id: "۴",
        method: "POST",
        path: "/api/v1/tasks/{id}/time",
        description: "ثبت زمان صرف‌شده",
        request: `POST /api/v1/tasks/{id}/time
{ "hours": 2.5, "description": "بازبینی نقشه‌های طبقه ۱۸" }`,
        response: `{ "id": "uuid", "total_spent_hours": 24.5 }`,
        statusCodes: [["200", "ثبت شد"], ["400", "ساعت نامعتبر"]],
      },
      {
        id: "۵",
        method: "POST",
        path: "/api/v1/tasks/{id}/comments",
        description: "افزودن نظر به وظیفه",
        request: `POST /api/v1/tasks/{id}/comments\n{ "body": "نظر من..." }`,
        response: `{ "id": "uuid", "created_at": "..." }`,
        statusCodes: [["201", "نظر ثبت شد"]],
      },
    ],
  },

  useCases: {
    overview: "موارد استفاده اصلی شامل ایجاد وظیفه چندنفره، drag-and-drop در Kanban، ثبت زمان و مدیریت گردش کار است.",
    cases: [
      {
        id: "UC-TASK-001",
        title: "ایجاد وظیفه چندنفره با نقش‌های مستقل",
        actor: "مدیر پروژه",
        preconditions: ["کاربر دسترسی ایجاد وظیفه دارد"],
        mainFlow: [
          "مدیر پروژه روی «وظیفه جدید» کلیک می‌کند",
          "مودال فرم ایجاد وظیفه باز می‌شود",
          "عنوان، پروژه، اولویت و سررسید وارد می‌شود",
          "اعضا با نقش‌های مستقل اضافه می‌شوند (مسئول، همکار، بازبین)",
          "درصد مشارکت هر عضف مشخص می‌شود (مجموع باید ۱۰۰٪ باشد)",
          "وظیفه ایجاد و در Kanban Board نمایش داده می‌شود",
          "اعلان به اعضا ارسال می‌شود",
        ],
        alternativeFlows: ["اگر مجموع درصد مشارکت ۱۰۰٪ نباشد، خطا"],
        postconditions: ["وظیفه ایجاد می‌شود", "اعلان به اعضا ارسال می‌شود"],
      },
      {
        id: "UC-TASK-002",
        title: "Drag-and-drop در Kanban Board",
        actor: "کاربر با دسترسی ویرایش",
        preconditions: ["وظیفه در Kanban نمایش داده می‌شود"],
        mainFlow: [
          "کاربر کارت وظیفه را drag می‌کند",
          "سیستم مکان‌های قابل drop را هایلایت می‌کند",
          "کاربر کارت را در ستون جدید drop می‌کند",
          "سیستم انتقال وضعیت را اعتبارسنجی می‌کند",
          "وضعیت وظیفه به‌روزرسانی می‌شود",
          "اعلان به اعضا ارسال می‌شود",
        ],
        alternativeFlows: ["اگر انتقال مجاز نباشد، کارت به مکان قبلی برمی‌گردد"],
        postconditions: ["وضعیت وظیفه تغییر می‌کند", "Audit log ثبت می‌شود"],
      },
      {
        id: "UC-TASK-003",
        title: "ثبت زمان صرف‌شده",
        actor: "عضو وظیفه",
        preconditions: ["کاربر عضو وظیفه است"],
        mainFlow: [
          "کاربر در جزئیات وظیفه روی «شروع ثبت زمان» کلیک می‌کند",
          "تایمر شروع می‌شود",
          "کاربر روی «توقف» کلیک می‌کند",
          "زمان صرف‌شده ثبت می‌شود",
          "یا کاربر می‌تواند زمان را دستی وارد کند",
        ],
        alternativeFlows: ["کاربر می‌تواند چند session زمان ثبت کند"],
        postconditions: ["زمان صرف‌شده در TaskMember ثبت می‌شود"],
      },
    ],
  },

  sequenceDiagrams: [
    {
      id: "SD-TASK-001",
      title: "Drag-and-drop در Kanban با اعتبارسنجی",
      description: "توالی انتقال وظیفه بین ستون‌های Kanban",
      participants: ["User", "Frontend", "Backend API", "Database", "Notification Service"],
      flow: [
        "User کارت را drag می‌کند",
        "Frontend optimistic update انجام می‌دهد (کارت به ستون جدید می‌رود)",
        "Frontend PATCH /api/v1/tasks/{id}/status می‌فرستد",
        "Backend قوانین انتقال وضعیت را اعتبارسنجی می‌کند",
        "اگر مجاز باشد: وضعیت در Database به‌روزرسانی می‌شود",
        "Backend رویداد TaskStatusChanged را publish می‌کند",
        "Notification Service به اعضا اعلان می‌فرستد",
        "Backend پاسخ 200 برمی‌گرداند",
        "اگر مجاز نباشد: Backend خطا برمی‌گرداند",
        "Frontend کارت را به مکان قبلی برمی‌گرداند",
      ],
    },
  ],

  security: {
    overview: "امنیت ماژول وظایف بر اساس نقش کاربر در پروژه و وظیفه است. فقط اعضای وظیفه می‌توانند آن را ویرایش کنند. مدیر پروژه می‌تواند همه وظایف پروژه خود را ویرایش کند.",
    roles: [
      ["مدیر پروژه", "ایجاد، ویرایش، حذف همه وظایف پروژه"],
      ["مسئول وظیفه (Owner)", "ویرایش کامل وظیفه، تأیید تکمیل"],
      ["همکار (Contributor)", "ثبت زمان، افزودن نظر، تغییر وضعیت"],
      ["بازبین (Reviewer)", "مشاهده، افزودن نظر، تأیید/رد بازبینی"],
      ["ناظر (Observer)", "فقط مشاهده"],
    ],
    requirements: [
      "اعتبارسنجی عضویت در وظیفه برای ویرایش",
      "فقط Owner یا مدیر پروژه می‌توانند وظیفه را حذف کنند",
      "ثبت زمان فقط توسط خود کاربر یا مدیر",
      "Audit trail برای همه تغییرات",
    ],
    auditTrail: "تمام تغییرات وظیفه (ایجاد، ویرایش، تغییر وضعیت، تخصیص، ثبت زمان، نظر) در Audit Trail ثبت می‌شوند.",
  },

  businessRules: [
    {
      id: "BR-TASK-001",
      title: "مجموع درصد مشارکت اعضا باید ۱۰۰٪ باشد",
      description: "مجموع participation_percent همه اعضای یک وظیفه باید دقیقاً ۱۰۰ باشد. این rule در زمان ایجاد و ویرایش اعمال می‌شود.",
      validation: `const total = members.reduce((sum, m) => sum + m.participation_percent, 0);
if (total !== 100) {
  throw new Error('مجموع درصد مشارکت باید ۱۰۰ باشد');
}`,
    },
    {
      id: "BR-TASK-002",
      title: "قوانین انتقال وضعیت (State Machine)",
      description: "انتقال وضعیت وظیفه باید مطابق state machine باشد. انتقال‌های مجاز: backlog→todo، todo→in_progress، in_progress→review، review→done، review→in_progress، *→blocked، blocked→todo.",
      validation: `const transitions = {
  backlog: ['todo'],
  todo: ['in_progress', 'blocked'],
  in_progress: ['review', 'blocked', 'todo'],
  review: ['done', 'in_progress'],
  done: [],
  blocked: ['todo', 'in_progress'],
};`,
    },
    {
      id: "BR-TASK-003",
      title: "وظیفه سررسید گذشته نمی‌تواند به «انجام شده» تبدیل شود بدون نظر",
      description: "اگر وظیفه بعد از تاریخ سررسید به «انجالم شده» تبدیل شود، یک نظر توضیحی الزامی است.",
      validation: `if (newStatus === 'done' && task.due_date < today && !comment) {
  throw new Error('برای تکمیل وظیفه سررسید گذشته، نظر توضیحی الزامی است');
}`,
    },
    {
      id: "BR-TASK-004",
      title: "حداقل یک مسئول (Owner) الزامی است",
      description: "هر وظیفه باید حداقل یک عضو با نقش «owner» داشته باشد. امکان حذف آخرین owner وجود ندارد.",
      validation: `const owners = members.filter(m => m.role === 'owner');
if (owners.length === 0) {
  throw new Error('وظیفه باید حداقل یک مسئول داشته باشد');
}`,
    },
  ],

  quality: {
    performance: [
      ["زمان پاسخ فهرست وظایف", "< ۲۰۰ms", "Prometheus"],
      ["زمان drag-and-drop (optimistic)", "< ۵۰ms", "React Profiler"],
      ["تعداد وظایف در Kanban", "تا ۱۰۰ کارت بدون افت عملکرد", "-"],
    ],
    availability: [
      "ماژول وظایف ۹۹.۵٪ در دسترس باشد",
      "Real-time update با SignalR برای Kanban مشترک",
    ],
    scalability: [
      "صفحه‌بندی برای فهرست وظایف",
      "Index روی project_id و status",
      "Cache برای وظایف پرتکرار",
    ],
  },

  implementation: {
    patterns: [
      ["State Machine", "مدیریت انتقال وضعیت وظیفه"],
      ["Strategy Pattern", "الگوریتم‌های مختلف محاسبه KPI"],
      ["Observer Pattern", "اعلان تغییرات به اعضا"],
      ["Repository Pattern", "TaskRepository برای دسترسی داده"],
      ["CQRS", "جداسازی command (تغییر وضعیت) و query (فهرست)"],
    ],
    notes: [
      "از @dnd-kit برای drag-and-drop استفاده شود",
      "Optimistic update برای تجربه کاربری بهتر",
      "Real-time با SignalR برای به‌روزرسانی Kanban چند کاربره",
      "از React Query برای cache سمت کلاینت",
    ],
    testing: "Unit test برای state machine و validation، integration test برای API، E2E test برای drag-and-drop.",
    relatedDocs: ["سند معماری کلی سامانه", "مستندات API وظایف", "راهنمای UI/UX Kanban"],
    changelog: [["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه"]],
  },
};
