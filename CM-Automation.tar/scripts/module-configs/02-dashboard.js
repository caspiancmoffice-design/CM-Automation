// 02-dashboard.js — Module config for Dashboard
module.exports = {
  meta: {
    title: "معماری ماژول داشبورد",
    subtitle: "Dashboard Module Architecture",
    version: "نسخه ۱.۰",
    date: "۱۴۰۳/۱۰/۰۱",
    code: "MOD-DASH-002",
    fileName: "02-معماری-ماژول-داشبورد.docx",
    description: "Architecture document for Dashboard module",
  },

  introduction: {
    purpose: "ماژول داشبورد، نقطه ورود اصلی کاربران به سامانه CM Automation است و نمای جامعی از وضعیت پروژه‌ها، وظایف، فعالیت‌ها و KPI‌ها را ارائه می‌دهد. این ماژول نقش‌محور است و بر اساس نقش کاربر (مدیر ارشد، مدیر میانی، مدیر پروژه، کارشناس) محتوای متفاوتی نمایش می‌دهد. هدف اصلی، ارائه تصویری فوری و قابل فهم از وضعیت کلی سامانه برای تصمیم‌گیری سریع مدیران است.",
    goals: [
      "ارائه نمای جامع از وضعیت پروژه‌ها و وظایف کاربر",
      "نمایش KPI‌های کلیدی بهره‌وری در یک نگاه",
      "نمایش فعالیت‌های اخیر سامانه برای آگاهی از رویدادها",
      "ارائه دسترسی سریع به وظایف محول‌شده و پروژه‌های فعال",
      "نمایش نمودارهای تحلیلی برای روند بهره‌وری و توزیع وظایف",
      "نقش‌محور بودن - محتوای متفاوت بر اساس سطح دسترسی کاربر",
    ],
    audience: [
      "توسعه‌دهندگان Frontend برای درک ساختار view و کامپوننت‌ها",
      "توسعه‌دهندگان Backend برای طراحی API داشبورد",
      "معماران نرم‌افزار برای درک وابستگی‌ها و یکپارچگی",
      "مدیران محصول برای درک قابلیت‌های داشبورد",
    ],
    scope: "این ماژول شامل داشبورد اصلی، KPI کارت‌ها، نمودارهای تحلیلی (روند بهره‌وری، توزیع وظایف، اولویت‌ها)، فعالیت‌های اخیر، پروژه‌های فعال، و وظایف من است. خارج از دامنه آن، گزارش‌های تحلیلی پیشرفته (که در ماژول گزارش‌ها هستند) و تنظیمات شخصی‌سازی داشبورد قرار می‌گیرند.",
    glossary: [
      ["KPI", "Key Performance Indicator - شاخص کلیدی عملکرد"],
      ["Sparkline", "نمودار خطی کوچک درون کارت KPI"],
      ["Widget", "کامپوننت قابل استفاده مجدد در داشبورد"],
      ["Role-based Dashboard", "داشبورد با محتوای متفاوت بر اساس نقش کاربر"],
    ],
  },

  logical: {
    overview: "ماژول داشبورد از یک صفحه اصلی تشکیل شده که چندین widget را در خود جای می‌دهد. این widget‌ها به صورت مستقل داده‌های خود را از API‌های مختلف دریافت می‌کنند و به صورت reactive به‌روزرسانی می‌شوند. ساختار منطقی شامل لایه نمایش (Dashboard View)، لایه دریافت داده (API Client) و لایه cache (React Query) است.",
    components: [
      ["DashboardView", "کامپوننت اصلی داشبورد که همه widget‌ها را هماهنگ می‌کند", "Next.js + React"],
      ["KPICard", "کارت‌های KPI با icon، value، change و trend", "React + Recharts"],
      ["ActivityFeed", "نمایش فعالیت‌های اخیر با user avatar و timestamp", "React"],
      ["ProjectList", "لیست پروژه‌های فعال با progress bar", "React"],
      ["MyTasksWidget", "وظایف محول‌شده به کاربر فعلی", "React"],
      ["ChartWidget", "نمودارهای مختلف (Area، Pie، Bar) با Recharts", "Recharts"],
      ["DashboardAPI", "سرویس دریافت داده‌های داشبورد از Backend", "Axios + React Query"],
    ],
    dependencies: [
      ["پروژه‌ها", "خواندن", "دریافت لیست پروژه‌های فعال برای نمایش"],
      ["وظایف", "خواندن", "دریافت وظایف محول‌شده و آمار"],
      ["اسناد", "خواندن", "دریافت آمار اسناد اخیر"],
      ["مکاتبات", "خواندن", "دریافت آمار مکاتبات"],
      ["اعلان‌ها", "خواندن", "دریافت اعلان‌های اخیر"],
      ["کاربران", "خواندن", "دریافت نقش و اطلاعات کاربر فعلی"],
      ["گزارش‌ها", "خواندن", "دریافت داده‌های نمودار و KPI"],
    ],
    interfaces: [
      { name: "DashboardDataAPI", description: "رابط دریافت همه داده‌های داشبورد در یک درخواست برای بهینه‌سازی" },
      { name: "WidgetRefreshAPI", description: "رابط refresh اختصاصی هر widget" },
      { name: "RoleBasedContentAPI", description: "رابط دریافت محتوای نقش‌محور داشبورد" },
    ],
  },

  dataModel: {
    overview: "ماژول داشبورد موجودیت مستقل خود را ندارد و داده‌های خود را از دیگر ماژول‌ها با aggregation دریافت می‌کند. با این حال، یک view مخصوص داشبورد برای ذخیره تنظیمات شخصی‌سازی کاربر تعریف می‌شود.",
    entities: [
      {
        name: "DashboardPreference",
        tableName: "dashboard_preferences",
        description: "تنظیمات شخصی‌سازی داشبورد کاربر - شامل ترتیب widget‌ها، widget‌های فعال/غیرفعال و تنظیمات فیلتر",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["user_id", "UUID", "بله", "شناسه کاربر (FK به users)"],
          ["widget_config", "JSONB", "خیر", "پیکربندی widget‌ها به صورت JSON"],
          ["layout", "JSONB", "خیر", "ترتیب و موقعیت widget‌ها"],
          ["filters", "JSONB", "خیر", "فیلترهای پیش‌فرض داشبورد"],
          ["last_viewed_at", "TIMESTAMP", "خیر", "آخرین بازدید کاربر"],
          ["created_at", "TIMESTAMP", "بله", "تاریخ ایجاد"],
          ["updated_at", "TIMESTAMP", "بله", "تاریخ به‌روزرسانی"],
        ],
      },
    ],
    relationships: [
      "DashboardPreference ↔ User (یک به یک)",
      "داشبورد از داده‌های Project، Task، Document، Correspondence، Notification استفاده می‌کند (aggregation)",
    ],
    indexes: [
      ["idx_dashboard_pref_user", "user_id", "B-Tree", "جستجوی سریع تنظیمات کاربر"],
    ],
  },

  api: {
    overview: "API داشبورد برای دریافت داده‌های تجمیعی طراحی شده است. به جای اینکه کاربر چندین درخواست به API‌های مختلف بفرستد، یک درخواست به داشبورد داده‌های همه widget‌ها را دریافت می‌کند. این رویکرد تعداد درخواست‌های HTTP را کاهش می‌دهد و عملکرد بهتری دارد.",
    endpoints: [
      {
        id: "۱",
        method: "GET",
        path: "/api/v1/dashboard",
        description: "دریافت همه داده‌های داشبورد در یک درخواست",
        request: `GET /api/v1/dashboard
Authorization: Bearer {token}
Accept: application/json

Query Parameters:
- timeframe: today | week | month | quarter | year (default: month)
- project_id: UUID (optional - filter by project)`,
        response: `{
  "kpi": {
    "active_projects": 4,
    "my_open_tasks": 8,
    "completed_this_month": 23,
    "overdue_tasks": 2
  },
  "productivity_trend": [
    { "month": "فروردین", "value": 72 },
    { "month": "اردیبهشت", "value": 75 }
  ],
  "task_distribution": {
    "by_status": [...],
    "by_priority": [...]
  },
  "recent_activities": [...],
  "my_tasks": [...],
  "active_projects": [...]
}`,
        statusCodes: [
          ["200", "دریافت موفق داده‌های داشبورد"],
          ["401", "احراز هویت ناموفق"],
          ["403", "دسترسی غیرمجاز"],
        ],
      },
      {
        id: "۲",
        method: "PUT",
        path: "/api/v1/dashboard/preferences",
        description: "ذخیره تنظیمات شخصی‌سازی داشبورد کاربر",
        request: `PUT /api/v1/dashboard/preferences
Authorization: Bearer {token}
Content-Type: application/json

{
  "widget_config": {
    "kpi_cards": { "visible": true, "order": 1 },
    "productivity_chart": { "visible": true, "order": 2 },
    "activity_feed": { "visible": true, "order": 3 }
  },
  "filters": {
    "default_timeframe": "month"
  }
}`,
        response: `{
  "id": "uuid",
  "user_id": "uuid",
  "widget_config": { ... },
  "updated_at": "2024-01-01T10:00:00Z"
}`,
        statusCodes: [
          ["200", "ذخیره موفق"],
          ["400", "داده ورودی نامعتبر"],
          ["401", "احراز هویت ناموفق"],
        ],
      },
    ],
  },

  useCases: {
    overview: "موارد استفاده اصلی ماژول داشبورد شامل مشاهده نمای کلی، شخصی‌سازی داشبورد، و دسترسی سریع به جزئیات است.",
    cases: [
      {
        id: "UC-DASH-001",
        title: "مشاهده نمای کلی داشبورد",
        actor: "کاربر وارد شده (هر نقش)",
        preconditions: [
          "کاربر وارد سامانه شده است",
          "کاربر حداقل به یک پروژه دسترسی دارد",
        ],
        mainFlow: [
          "کاربر وارد صفحه اصلی سامانه می‌شود",
          "سیستم نقش کاربر را تشخیص می‌دهد",
          "سیستم داده‌های داشبورد را بر اساس نقش از API دریافت می‌کند",
          "KPI کارت‌ها نمایش داده می‌شوند",
          "نمودار روند بهره‌وری نمایش داده می‌شود",
          "لیست پروژه‌های فعال نمایش داده می‌شود",
          "وظایف محول‌شده به کاربر نمایش داده می‌شود",
          "فعالیت‌های اخیر نمایش داده می‌شود",
        ],
        alternativeFlows: [
          "اگر کاربر مدیر ارشد باشد، KPI سازمانی نمایش داده می‌شود",
          "اگر کاربر مدیر پروژه باشد، KPI پروژه‌های او نمایش داده می‌شود",
          "اگر کاربر کارشناس باشد، KPI شخصی نمایش داده می‌شود",
        ],
        postconditions: [
          "کاربر نمای کامل داشبورد را می‌بیند",
          "داده‌ها در cache ذخیره می‌شوند برای refresh سریع",
        ],
      },
      {
        id: "UC-DASH-002",
        title: "شخصی‌سازی چیدمان داشبورد",
        actor: "کاربر وارد شده",
        preconditions: ["کاربر وارد سامانه شده است"],
        mainFlow: [
          "کاربر روی دکمه «شخصی‌سازی» کلیک می‌کند",
          "حالت ویرایش چیدمان فعال می‌شود",
          "کاربر می‌تواند widget‌ها را drag-and-drop کند",
          "کاربر می‌تواند widget‌ها را show/hide کند",
          "کاربر روی «ذخیره» کلیک می‌کند",
          "چیدمان جدید در پایگاه داده ذخیره می‌شود",
        ],
        alternativeFlows: [
          "کاربر می‌تواند با کلیک روی «بازنشانی» به چیدمان پیش‌فرض برگردد",
        ],
        postconditions: ["چیدمان جدید در جلسات بعدی کاربر نمایش داده می‌شود"],
      },
      {
        id: "UC-DASH-003",
        title: "دسترسی سریع به جزئیات از داشبورد",
        actor: "کاربر وارد شده",
        preconditions: ["داشبورد نمایش داده شده است"],
        mainFlow: [
          "کاربر روی یک پروژه در لیست پروژه‌های فعال کلیک می‌کند",
          "سیستم به صفحه جزئیات پروژه هدایت می‌کند",
          "یا کاربر روی یک وظیفه در «وظایف من» کلیک می‌کند",
          "سیستم به صفحه جزئیات وظیفه هدایت می‌کند",
        ],
        alternativeFlows: [],
        postconditions: ["کاربر به صفحه جزئیات مورد نظر هدایت می‌شود"],
      },
    ],
  },

  sequenceDiagrams: [
    {
      id: "SD-DASH-001",
      title: "بارگذاری اولیه داشبورد",
      description: "توالی بارگذاری داشبورد هنگام ورود کاربر به صفحه اصلی",
      participants: [
        "User (Browser)",
        "Next.js Frontend",
        "Backend API",
        "Database",
        "Redis Cache",
      ],
      flow: [
        "User صفحه اصلی را باز می‌کند",
        "Next.js Frontend درخواست GET /api/v1/dashboard می‌فرستد",
        "Backend API توکن را اعتبارسنجی می‌کند",
        "Backend API نقش کاربر را از Keycloak دریافت می‌کند",
        "Backend API در Redis Cache برای داده‌های داشبورد جستجو می‌کند",
        "اگر cache miss باشد، Backend از Database داده‌ها را aggregate می‌کند",
        "Backend داده‌های تجمیعی را در Redis cache می‌کند (TTL: 5 دقیقه)",
        "Backend داده‌ها را به Frontend برمی‌گرداند",
        "Frontend widget‌ها را با داده‌ها render می‌کند",
        "Frontend داده‌ها را در React Query cache می‌کند (staleTime: 1 دقیقه)",
      ],
    },
  ],

  security: {
    overview: "امنیت ماژول داشبورد بر اساس نقش کاربر است. داده‌های نمایش داده شده در داشبورد بر اساس scope دسترسی کاربر فیلتر می‌شوند. به عنوان مثال، یک کارشناس فقط KPI شخصی خود را می‌بیند، در حالی که مدیر ارشد KPI کل سازمان را مشاهده می‌کند.",
    roles: [
      ["مدیر ارشد", "مشاهده همه KPI‌ها و داشبورد سازمانی"],
      ["مدیر میانی", "مشاهده KPI دپارتمان و پروژه‌های تحت مدیریت"],
      ["مدیر پروژه", "مشاهده KPI پروژه‌های خود + عملکرد تیم"],
      ["کارشناس", "مشاهده KPI شخصی + وظایف محول‌شده"],
    ],
    requirements: [
      "اعتبارسنجی توکن در هر درخواست",
      "فیلتر داده‌ها بر اساس scope سازمانی کاربر",
      "Cache به کلید user_id + role + scope تخصیص داده می‌شود",
      "نمایش داده‌های حساس (مثل بودجه) فقط برای نقش‌های مجاز",
    ],
    auditTrail: "تمام بازدیدهای داشبورد در Audit Trail ثبت می‌شوند. این شامل: کاربر، timestamp، timeframe مورد مشاهده و widget‌های نمایش داده شده است. این اطلاعات برای تحلیل استفاده و بهبود UX استفاده می‌شود.",
  },

  businessRules: [
    {
      id: "BR-DASH-001",
      title: "نقش‌محور بودن KPI‌ها",
      description: "KPI‌های نمایش داده شده در داشبورد باید بر اساس نقش کاربر متفاوت باشند. مدیر ارشد KPI سازمانی، مدیر پروژه KPI پروژه و کارشناس KPI شخصی می‌بیند. این rule در سمت Backend اعمال می‌شود تا امنیت داده تضمین شود.",
      validation: `if (user.role === 'senior_manager') {
  return getOrganizationKPIs();
} else if (user.role === 'project_manager') {
  return getProjectKPIs(user.id);
} else {
  return getPersonalKPIs(user.id);
}`,
    },
    {
      id: "BR-DASH-002",
      title: "Cache TTL برای داده‌های داشبورد",
      description: "داده‌های داشبورد برای ۵ دقیقه در Redis cache می‌شوند. این زمان بهینه است - کوتاه‌تر از آن باعث افزایش درخواست به database می‌شود و طولانی‌تر از آن باعث نمایش داده‌های قدیمی می‌گردد. کاربر می‌تواند با کلیک روی «به‌روزرسانی» cache را دور بزند.",
      validation: `cache_ttl = 300 // 5 minutes in seconds
if (user_clicked_refresh) {
  cache.invalidate(dashboard_cache_key)
}`,
    },
    {
      id: "BR-DASH-003",
      title: "نمایش پروژه‌های فعال فقط",
      description: "در لیست پروژه‌های فعال داشبورد، فقط پروژه‌هایی نمایش داده می‌شوند که وضعیت «فعال» یا «متوقف» دارند و کاربر به آن‌ها دسترسی دارد. پروژه‌های «تکمیل شده» و «لغو شده» نمایش داده نمی‌شوند.",
      validation: `query = projects
  .where(status.in(['active', 'on_hold']))
  .where(user.hasAccess(project.id))
  .orderBy(updatedAt.desc())
  .limit(5)`,
    },
  ],

  quality: {
    performance: [
      ["زمان بارگذاری داشبورد (P95)", "< ۱.۵ ثانیه", "Application Insights"],
      ["زمان پاسخ API داشبورد", "< ۳۰۰ms", "Prometheus"],
      ["Cache Hit Ratio", "> ۸۵٪", "Redis metrics"],
      ["زمان render widget", "< ۲۰۰ms", "React Profiler"],
    ],
    availability: [
      "داشبورد در دسترس باشد ۹۹.۵٪ زمان",
      "اگر یک ماژول (مثل گزارش‌ها) down باشد، داشبورد همچنان کار کند با widget‌های دیگر",
      "Graceful degradation: اگر داده‌ای در دسترس نباشد، widget پیام خطا نمایش دهد",
    ],
    scalability: [
      "Cache در Redis مقیاس‌پذیر است",
      "API داشبورد Stateless است و می‌تواند افقی مقیاس شود",
      "Aggregation در سمت database با materialized view قابل بهینه‌سازی",
    ],
  },

  implementation: {
    patterns: [
      ["Composite Pattern", "ساخت داشبورد از widget‌های مستقل"],
      ["Strategy Pattern", "محتوای متفاوت بر اساس نقش کاربر"],
      ["Observer Pattern", "به‌روزرسانی خودکار widget‌ها هنگام تغییر داده"],
      ["Cache-Aside Pattern", "cache در Redis با fallback به database"],
      ["BFF Pattern", "API مخصوص داشبورد به جای چندین درخواست جداگانه"],
    ],
    notes: [
      "از React Query برای cache سمت کلاینت استفاده شود (staleTime: 60s)",
      "Widget‌ها باید lazy load شوند برای بهبود زمان بارگذاری اولیه",
      "از Suspense boundary برای جلوگیری از layout shift استفاده شود",
      "نمودارها با Recharts و SSR support پیاده‌سازی شوند",
      "تقویم شمسی در KPI‌های زمان‌محور استفاده شود",
    ],
    testing: "Unit test برای هر widget، integration test برای API داشبورد، E2E test برای سناریوهای نقش‌محور. Cache behavior با mock Redis تست شود. Performance test با k6 برای اطمینان از P95 < 1.5s.",
    relatedDocs: [
      "سند معماری کلی سامانه (SAD)",
      "مستندات API داشبورد (Swagger)",
      "راهنمای طراحی UI/UX داشبورد",
    ],
    changelog: [
      ["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه - داشبورد با KPI، نمودارها، فعالیت‌ها"],
    ],
  },
};
