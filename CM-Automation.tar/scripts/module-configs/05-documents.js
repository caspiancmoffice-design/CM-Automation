// 05-documents.js — Module config for Documents module
module.exports = {
  meta: {
    title: "معماری ماژول اسناد",
    subtitle: "Documents Module Architecture",
    version: "نسخه ۱.۰",
    date: "۱۴۰۳/۱۰/۰۱",
    code: "MOD-DOC-005",
    fileName: "05-معماری-ماژول-اسناد.docx",
    description: "Architecture document for Documents module",
  },

  introduction: {
    purpose: "ماژول اسناد مدیریت کامل چرخه حیات اسناد در سامانه CM Automation را بر عهده دارد. این ماژول شامل بارگذاری، نسخه‌بندی، دسته‌بندی، جستجو، اشتراک‌گذاری و کنترل دسترسی اسناد است. هر سند می‌تواند چندین نسخه داشته باشد و هر نسخه تاریخچه کامل تغییرات را حفظ می‌کند. اسناد در MinIO Object Storage ذخیره می‌شوند و متادیتای آن‌ها در PostgreSQL نگهداری می‌گردد.",
    goals: [
      "مدیریت اسناد با نسخه‌بندی کامل",
      "پشتیبانی از دسته‌بندی و تگ‌گذاری",
      "کنترل دسترسی فنی (RBAC + document-level)",
      "جستجوی full-text در محتوای اسناد",
      "اشتراک‌گذاری اسناد با کاربران و گروه‌ها",
      "پیش‌نمایش اسناد (PDF، تصاویر، Office)",
    ],
    audience: ["توسعه‌دهندگان", "معماران نرم‌افزار", "مدیران محصول"],
    scope: "این ماژول شامل فهرست اسناد، جزئیات سند با تاریخچه نسخه‌ها، بارگذاری سند، پوشه‌بندی، جستجو و پیش‌نمایش است.",
    glossary: [
      ["Document", "سند - فایل با متادیتا و نسخه‌بندی"],
      ["Version", "نسخه سند (v1.0, v1.1, v2.0)"],
      ["Category", "دسته سند: نقشه، مشخصه فنی، قرارداد، گزارش، مجوز، فاکتور"],
      ["Object Storage", "ذخیره‌سازی اشیاء (MinIO)"],
    ],
  },

  logical: {
    overview: "ماژول اسناد از دو بخش منطقی تشکیل شده: متادیتا در PostgreSQL و فایل فیزیکی در MinIO. هر سند می‌تواند چندین نسخه داشته باشد و هر نسخه به یک فایل در MinIO اشاره می‌کند. جستجوی full-text با OpenSearch انجام می‌شود.",
    components: [
      ["DocumentsListView", "فهرست اسناد با فیلتر و جستجو", "Next.js + React"],
      ["DocumentDetailsDialog", "دیالوگ جزئیات سند با تاریخچه نسخه‌ها", "React"],
      ["UploadModal", "مودال بارگذاری سند با drag-and-drop", "React"],
      ["DocumentPreview", "پیش‌نمایش PDF و تصاویر", "React + PDF.js"],
      ["VersionHistory", "تاریخچه نسخه‌های سند", "React"],
      ["DocumentAPI", "سرویس ارتباط با API اسناد", "Axios + React Query"],
      ["FileStorageService", "سرویس ارتباط با MinIO", "ASP.NET Core + MinIO SDK"],
    ],
    dependencies: [
      ["پروژه‌ها", "متعلق به", "اسناد به پروژه متصل می‌شوند"],
      ["کاربران", "اشتراک", "اسناد با کاربران به اشتراک گذاشته می‌شوند"],
      ["جستجو", "ایندکس", "محتوای اسناد در OpenSearch ایندکس می‌شود"],
      ["اعلان‌ها", "ارسال رویداد", "بارگذاری/اشتراک سند اعلان تولید می‌کند"],
    ],
    interfaces: [
      { name: "DocumentCRUDAPI", description: "ایجاد، خواندن، ویرایش، حذف سند" },
      { name: "DocumentVersionAPI", description: "مدیریت نسخه‌های سند" },
      { name: "DocumentUploadAPI", description: "بارگذاری فایل با multipart" },
      { name: "DocumentShareAPI", description: "اشتراک‌گذاری با کاربران" },
      { name: "DocumentSearchAPI", description: "جستجوی full-text" },
    ],
  },

  dataModel: {
    overview: "موجودیت‌های اصلی: Document (متادیتا)، DocumentVersion (نسخه‌ها)، DocumentShare (اشتراک‌ها)، DocumentFolder (پوشه‌ها).",
    entities: [
      {
        name: "Document",
        tableName: "documents",
        description: "متادیتای سند - فایل فیزیکی در MinIO ذخیره می‌شود",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["name", "VARCHAR(255)", "بله", "نام فایل"],
          ["category", "ENUM", "بله", "drawing, specification, contract, report, permit, invoice, other"],
          ["project_id", "UUID", "خیر", "پروژه مربوطه (FK)"],
          ["mime_type", "VARCHAR(100)", "بله", "نوع MIME فایل"],
          ["size", "BIGINT", "بله", "اندازه فایل به بایت"],
          ["current_version", "VARCHAR(20)", "بله", "نسخه فعلی (مثال: v2.0)"],
          ["folder_id", "UUID", "خیر", "پوشه والد (FK)"],
          ["uploaded_by", "UUID", "بله", "بارگذارنده (FK)"],
          ["uploaded_at", "TIMESTAMP", "بله", "تاریخ بارگذاری"],
          ["status", "ENUM", "بله", "draft, in_review, approved, rejected"],
          ["tags", "JSONB", "خیر", "تگ‌های سند"],
          ["description", "TEXT", "خیر", "توضیحات سند"],
        ],
      },
      {
        name: "DocumentVersion",
        tableName: "document_versions",
        description: "نسخه‌های یک سند - هر نسخه به یک فایل در MinIO اشاره می‌کند",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["document_id", "UUID", "بله", "سند (FK)"],
          ["version", "VARCHAR(20)", "بله", "شماره نسخه (v1.0, v1.1)"],
          ["file_path", "VARCHAR(500)", "بله", "مسیر فایل در MinIO"],
          ["size", "BIGINT", "بله", "اندازه این نسخه"],
          ["uploaded_by", "UUID", "بله", "بارگذارنده نسخه (FK)"],
          ["uploaded_at", "TIMESTAMP", "بله", "تاریخ بارگذاری"],
          ["comment", "TEXT", "خیر", "توضیحات تغییرات"],
          ["checksum", "VARCHAR(64)", "بله", "SHA-256 برای یکتایی"],
        ],
      },
      {
        name: "DocumentShare",
        tableName: "document_shares",
        description: "اشتراک‌گذاری سند با کاربران",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["document_id", "UUID", "بله", "سند (FK)"],
          ["user_id", "UUID", "بله", "کاربر (FK)"],
          ["permission", "ENUM", "بله", "view, comment, edit"],
          ["shared_by", "UUID", "بله", "اشتراک‌گذار (FK)"],
          ["shared_at", "TIMESTAMP", "بله", "تاریخ اشتراک"],
        ],
      },
    ],
    relationships: [
      "Document ↔ Project (یک به چند)",
      "Document ↔ DocumentVersion (یک به چند)",
      "Document ↔ User (چند به چند از طریق DocumentShare)",
      "Document ↔ DocumentFolder (چند به یک)",
    ],
    indexes: [
      ["idx_docs_project", "project_id", "B-Tree", "اسناد یک پروژه"],
      ["idx_docs_category", "category", "B-Tree", "فیلتر دسته"],
      ["idx_docs_uploaded_by", "uploaded_by", "B-Tree", "اسناد یک کاربر"],
      ["idx_docs_tags", "tags", "GIN", "جستجو در تگ‌ها"],
      ["idx_doc_versions_doc", "document_id, version", "Composite", "نسخه‌های یک سند"],
    ],
  },

  api: {
    overview: "API ماژول اسناد شامل endpoint‌های CRUD، بارگذاری، دانلود، اشتراک و جستجو است. بارگذاری با multipart/form-data انجام می‌شود.",
    endpoints: [
      {
        id: "۱",
        method: "GET",
        path: "/api/v1/documents",
        description: "دریافت فهرست اسناد با فیلتر",
        request: `GET /api/v1/documents?category=drawing&project_id={id}&search=نقشه
Authorization: Bearer {token}`,
        response: `{ "data": [{ "id": "uuid", "name": "...", "current_version": "v2.0" }] }`,
        statusCodes: [["200", "موفق"]],
      },
      {
        id: "۲",
        method: "POST",
        path: "/api/v1/documents/upload",
        description: "بارگذاری سند جدید با multipart",
        request: `POST /api/v1/documents/upload
Content-Type: multipart/form-data

file: [binary]
name: نقشه‌های فاز ۲.pdf
category: drawing
project_id: uuid`,
        response: `{ "id": "uuid", "current_version": "v1.0", "size": 24580000 }`,
        statusCodes: [["201", "بارگذاری شد"], ["413", "فایل بیش از حد بزرگ"], ["415", "نوع فایل غیرمجاز"]],
      },
      {
        id: "۳",
        method: "POST",
        path: "/api/v1/documents/{id}/versions",
        description: "بارگذاری نسخه جدید سند موجود",
        request: `POST /api/v1/documents/{id}/versions
Content-Type: multipart/form-data

file: [binary]
comment: اصلاحات نهایی اتصالات`,
        response: `{ "version": "v3.0", "uploaded_at": "..." }`,
        statusCodes: [["201", "نسخه جدید ثبت شد"]],
      },
      {
        id: "۴",
        method: "GET",
        path: "/api/v1/documents/{id}/download",
        description: "دانلود فایل سند (نسخه فعلی یا خاص)",
        request: `GET /api/v1/documents/{id}/download?version=v2.0
Authorization: Bearer {token}`,
        response: `Binary file (application/octet-stream)`,
        statusCodes: [["200", "دانلود"], ["404", "نسخه یافت نشد"]],
      },
      {
        id: "۵",
        method: "POST",
        path: "/api/v1/documents/{id}/share",
        description: "اشتراک‌گذاری سند با کاربران",
        request: `POST /api/v1/documents/{id}/share
{ "user_ids": ["uuid1", "uuid2"], "permission": "view" }`,
        response: `{ "shared_with": 2 }`,
        statusCodes: [["200", "اشتراک گذاشته شد"]],
      },
    ],
  },

  useCases: {
    overview: "موارد استفاده شامل بارگذاری، نسخه‌بندی، اشتراک و جستجوی اسناد است.",
    cases: [
      {
        id: "UC-DOC-001",
        title: "بارگذاری سند جدید",
        actor: "کاربر با دسترسی بارگذاری",
        preconditions: ["کاربر دسترسی دارد"],
        mainFlow: [
          "کاربر روی «بارگذاری سند» کلیک می‌کند",
          "مودال بارگذاری باز می‌شود",
          "کاربر فایل را drag-and-drop یا انتخاب می‌کند",
          "متادیتا (نام، دسته، پروژه) وارد می‌شود",
          "سیستم فایل را اعتبارسنجی می‌کند (نوع، اندازه)",
          "فایل در MinIO ذخیره می‌شود",
          "متادیتا در PostgreSQL ثبت می‌شود",
          "نسخه v1.0 ایجاد می‌شود",
          "محتوای قابل ایندکس در OpenSearch ذخیره می‌شود",
        ],
        alternativeFlows: ["اگر فایل تکراری باشد (checksum)، هشدار نمایش داده می‌شود"],
        postconditions: ["سند در سیستم ثبت می‌شود", "نسخه اولیه ایجاد می‌شود"],
      },
      {
        id: "UC-DOC-002",
        title: "بارگذاری نسخه جدید سند",
        actor: "کاربر با دسترسی ویرایش",
        preconditions: ["سند وجود دارد"],
        mainFlow: [
          "از جزئیات سند، کاربر روی «نسخه جدید» کلیک می‌کند",
          "فایل جدید را انتخاب می‌کند",
          "توضیحات تغییرات را وارد می‌کند",
          "نسخه جدید با شماره خودکار (مثلا v2.0) ثبت می‌شود",
          "نسخه قبلی حفظ می‌شود",
        ],
        alternativeFlows: [],
        postconditions: ["نسخه جدید ایجاد می‌شود", "نسخه قبلی قابل دسترسی باقی می‌ماند"],
      },
    ],
  },

  sequenceDiagrams: [
    {
      id: "SD-DOC-001",
      title: "بارگذاری سند با نسخه‌بندی",
      description: "توالی بارگذاری سند و ذخیره در MinIO و PostgreSQL",
      participants: ["User", "Frontend", "Backend API", "MinIO", "PostgreSQL", "OpenSearch"],
      flow: [
        "User فایل را drag-and-drop می‌کند",
        "Frontend اعتبارسنجی اولیه (نوع، اندازه)",
        "Frontend POST /api/v1/documents/upload می‌فرستد (multipart)",
        "Backend checksum فایل را محاسبه می‌کند",
        "Backend فایل را در MinIO ذخیره می‌کند",
        "Backend متادیتا را در PostgreSQL ثبت می‌کند",
        "Backend نسخه v1.0 را ایجاد می‌کند",
        "Backend محتوای قابل استخراج را در OpenSearch ایندکس می‌کند",
        "Backend پاسخ 201 برمی‌گرداند",
        "Frontend سند را در فهرست نمایش می‌دهد",
      ],
    },
  ],

  security: {
    overview: "امنیت اسناد چندلایه است: RBAC برای دسترسی ماژول، document-level permissions برای اسناد حساس، و signed URLs برای دانلود. اسناد مستقیم از MinIO قابل دسترسی نیستند - فقط از طریق Backend API با اعتبارسنجی.",
    roles: [
      ["مدیر پروژه", "دسترسی کامل به اسناد پروژه"],
      ["کارشناس", "بارگذاری و مشاهده اسناد پروژه"],
      ["کاربر اشتراک‌داده‌شده", "دسترسی طبق permission (view, comment, edit)"],
      ["مدیر سیستم", "دسترسی کامل + مدیریت تنظیمات"],
    ],
    requirements: [
      "Signed URL با انقضای ۱ ساعت برای دانلود",
      "اعتبارسنجی دسترسی قبل از هر دانلود",
      "عدم دسترسی مستقیم به MinIO از خارج",
      "رمزنگاری at-rest در MinIO (SSE)",
      "Audit trail برای مشاهده، دانلود، اشتراک",
    ],
    auditTrail: "تمام عملیات اسناد (بارگذاری، دانلود، اشتراک، حذف، تغییر نسخه) در Audit Trail ثبت می‌شوند.",
  },

  businessRules: [
    {
      id: "BR-DOC-001",
      title: "حداکثر اندازه فایل ۵۰ مگابایت",
      description: "هر فایل نمی‌تواند بیش از ۵۰ مگابایت باشد. فایل‌های بزرگ‌تر باید split شوند یا از روش بارگذاری chunked استفاده کنند.",
      validation: `if (file.size > 50 * 1024 * 1024) {
  throw new Error('حداکثر اندازه فایل ۵۰ مگابایت است');
}`,
    },
    {
      id: "BR-DOC-002",
      title: "نوع فایل‌های مجاز",
      description: "فقط نوع فایل‌های مجاز قابل بارگذاری هستند: PDF، تصاویر (JPG, PNG, GIF)، Office (DOCX, XLSX, PPTX)، CAD (DWG, DXF) و ZIP.",
      validation: `const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', ...];
if (!allowedTypes.includes(file.mimetype)) {
  throw new Error('نوع فایل مجاز نیست');
}`,
    },
    {
      id: "BR-DOC-003",
      title: "Checksum برای جلوگیری از فایل تکراری",
      description: "هر نسخه سند باید checksum یکتا داشته باشد. اگر فایل با checksum مشابه قبلاً بارگذاری شده باشد، هشدار نمایش داده می‌شود (اما اجازه بارگذاری داده می‌شود).",
      validation: `const existing = await db.document_versions
  .where({ checksum: fileChecksum })
  .first();
if (existing) {
  warn('فایل مشابه قبلاً بارگذاری شده است');
}`,
    },
    {
      id: "BR-DOC-004",
      title: "افزایش خودکار شماره نسخه",
      description: "شماره نسخه به‌صورت خودکار افزایش می‌یابد: v1.0 → v1.1 → v1.2 یا v1.0 → v2.0 (major). کاربر می‌تواند major یا minor را انتخاب کند.",
      validation: `const lastVersion = await getLastVersion(document_id);
const newVersion = incrementVersion(lastVersion, type); // type: major | minor`,
    },
  ],

  quality: {
    performance: [
      ["زمان بارگذاری فایل ۱۰MB", "< ۵ ثانیه", "Custom metric"],
      ["زمان دانلود فایل ۱۰MB", "< ۳ ثانیه", "Custom metric"],
      ["زمان جستجوی full-text", "< ۵۰۰ms", "OpenSearch slowlog"],
      ["پیش‌نمایش PDF", "< ۲ ثانیه", "PDF.js render time"],
    ],
    availability: [
      "MinIO با replication برای high availability",
      "OpenSearch cluster با حداقل ۲ node",
      "Backup هفتگی از MinIO",
    ],
    scalability: [
      "MinIO با افزایش disk مقیاس می‌شود",
      "OpenSearch با shard و replica مقیاس می‌شود",
      "Background worker برای پردازش فایل (OCR، thumbnail)",
    ],
  },

  implementation: {
    patterns: [
      ["Repository Pattern", "DocumentRepository برای دسترسی داده"],
      ["Strategy Pattern", "پردازشگران مختلف برای انواع فایل (PDF، Image، Office)"],
      ["Decorator Pattern", "افزودن watermark، thumbnail به فایل"],
      ["Background Job", "پردازش OCR و ایندکس در background"],
      ["Signed URL Pattern", "دسترسی موقت به فایل‌های MinIO"],
    ],
    notes: [
      "از MinIO SDK برای ارتباط با Object Storage",
      "PDF.js برای پیش‌نمایش PDF در مرورگر",
      "Apache Tika برای استخراج متن از فایل‌های Office",
      "Tesseract OCR برای اسکن‌ها (در background)",
    ],
    testing: "Unit test برای validation، integration test با MinIO mock، E2E test برای بارگذاری و دانلود.",
    relatedDocs: ["سند معماری کلی سامانه", "مستندات API اسناد", "راهنمای MinIO"],
    changelog: [["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه"]],
  },
};
