// 08-procurement.js
module.exports = {
  meta: {
    title: "معماری ماژول تدارکات",
    subtitle: "Procurement Module Architecture",
    version: "نسخه ۱.۰",
    date: "۱۴۰۳/۱۰/۰۱",
    code: "MOD-PROC-008",
    fileName: "08-معماری-ماژول-تدارکات.docx",
    description: "Architecture document for Procurement module",
  },

  introduction: {
    purpose: "ماژول تدارکات مدیریت درخواست‌های خرید با گردش کار ۷ مرحله‌ای را بر عهده دارد. این ماژول شامل ایجاد درخواست خرید با فیلدهای دقیق (شرح مصالح، مقدار، محل مصرف، مشخصات فنی، وندور، درصد سفارش)، گردش کار تأیید مرحله‌ای، و پیگیری وضعیت تحویل است. هر درخواست می‌تواند چندین قلم داشته باشد و هر قلم به وندور و درصد سفارش متصل است.",
    goals: [
      "مدیریت درخواست‌های خرید با گردش کار ۷ مرحله‌ای",
      "ثبت دقیق اقلام: شرح، مقدار، محل مصرف، مشخصات فنی، وندور، درصد سفارش",
      "گردش کار قابل تنظیم با مراحل تأیید",
      "پیگیری وضعیت سفارش و تحویل",
      "ارتباط با ماژول وندورها و پروژه‌ها",
      "تاریخچه کامل تغییرات و نظرات",
    ],
    audience: ["توسعه‌دهندگان", "معماران نرم‌افزار", "مدیران محصول", "کارشناسان خرید"],
    scope: "این ماژول شامل فهرست درخواست‌های خرید، جزئیات با ۵ تب، فرم ایجاد درخواست، گردش کار، و تاریخچه است.",
    glossary: [
      ["PR", "Purchase Request - درخواست خرید"],
      ["Workflow", "گردش کار - ۷ مرحله تأیید"],
      ["WF Step", "مرحله گردش کار: submit, technical_review, manager_approval, financial_review, order, delivery, close"],
      ["Order Percent", "درصد سفارش - ۰ تا ۱۰۰"],
      ["Vendor", "وندور - تأمین‌کننده"],
    ],
  },

  logical: {
    overview: "ماژول تدارکات از سه بخش تشکیل شده: فهرست درخواست‌ها، جزئیات درخواست با ۵ تب، و فرم ایجاد. گردش کار ۷ مرحله‌ای با state machine مدیریت می‌شود و هر مرحله توسط مسئول مشخصی تأیید می‌شود.",
    components: [
      ["ProcurementListView", "فهرست درخواست‌ها با فیلتر و KPI", "Next.js + React"],
      ["ProcurementDetailsView", "جزئیات با ۵ تب (نمای کلی، اقلام، گردش کار، تاریخچه، وندورها)", "Next.js + React"],
      ["ProcurementNewView", "فرم ایجاد درخواست با اقلام پویا", "React"],
      ["WorkflowTimeline", "نمایش timeline گردش کار", "React"],
      ["ItemEditor", "ویرایشگر قلم با فیلدهای دقیق", "React"],
      ["ProcurementAPI", "سرویس ارتباط با API تدارکات", "Axios + React Query"],
    ],
    dependencies: [
      ["پروژه‌ها", "متعلق به", "درخواست‌ها به پروژه متصل هستند"],
      ["تأمین‌کنندگان", "مرتبط", "اقلام به وندور متصل می‌شوند"],
      ["کاربران", "تأییدکننده", "هر مرحله گردش کار توسط کاربر تأیید می‌شود"],
      ["اعلان‌ها", "ارسال رویداد", "تغییر مرحله اعلان تولید می‌کند"],
    ],
    interfaces: [
      { name: "PurchaseRequestCRUDAPI", description: "CRUD درخواست خرید" },
      { name: "WorkflowAPI", description: "مدیریت گردش کار و انتقال مرحله" },
      { name: "PurchaseRequestItemAPI", description: "مدیریت اقلام درخواست" },
    ],
  },

  dataModel: {
    overview: "موجودیت‌های اصلی: PurchaseRequest، PurchaseRequestItem، WorkflowStep، WorkflowHistory.",
    entities: [
      {
        name: "PurchaseRequest",
        tableName: "purchase_requests",
        description: "درخواست خرید اصلی",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["number", "VARCHAR(50)", "بله", "شماره درخواست (PR-1403-001)"],
          ["title", "VARCHAR(300)", "بله", "عنوان درخواست"],
          ["status", "ENUM", "بله", "draft, submitted, under_review, approved, rejected, in_order, partial_received, received, cancelled"],
          ["priority", "ENUM", "بله", "low, medium, high, critical, urgent"],
          ["project_id", "UUID", "بله", "پروژه (FK)"],
          ["requester_id", "UUID", "بله", "درخواست‌کننده (FK)"],
          ["needed_by_date", "DATE", "بله", "تاریخ نیاز"],
          ["total_estimate", "BIGINT", "بله", "تخمین کل (ریال)"],
          ["description", "TEXT", "خیر", "شرح درخواست"],
          ["justification", "TEXT", "خیر", "توجیه نیاز"],
          ["created_at", "TIMESTAMP", "بله", "تاریخ ایجاد"],
        ],
      },
      {
        name: "PurchaseRequestItem",
        tableName: "pr_items",
        description: "اقلام درخواست خرید - شامل شرح دقیق، مقدار، محل مصرف، مشخصات فنی، وندور، درصد سفارش",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["pr_id", "UUID", "بله", "درخواست خرید (FK)"],
          ["row", "INTEGER", "بله", "شماره ردیف"],
          ["name", "TEXT", "بله", "شرح دقیق مصالح/تجهیزات"],
          ["category", "ENUM", "بله", "material, equipment, tool, consumable, spare_part, service, other"],
          ["quantity", "DECIMAL", "بله", "مقدار"],
          ["unit", "VARCHAR(20)", "بله", "واحد"],
          ["unit_price_estimate", "BIGINT", "خیر", "تخمین بهای واحد"],
          ["total_price_estimate", "BIGINT", "خیر", "تخمین مبلغ کل"],
          ["consumption_location", "TEXT", "بله", "محل مصرف"],
          ["technical_spec", "TEXT", "بله", "مشخصات فنی"],
          ["vendor_id", "UUID", "خیر", "وندور پیشنهادی (FK)"],
          ["order_percent", "INTEGER", "بله", "درصد سفارش (0-100)"],
          ["ordered_quantity", "DECIMAL", "خیر", "مقدار سفارش داده شده"],
          ["received_quantity", "DECIMAL", "خیر", "مقدار دریافت شده"],
          ["notes", "TEXT", "خیر", "توضیحات تکمیلی"],
        ],
      },
      {
        name: "WorkflowStep",
        tableName: "workflow_steps",
        description: "مراحل گردش کار یک درخواست",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["pr_id", "UUID", "بله", "درخواست خرید (FK)"],
          ["type", "ENUM", "بله", "submit, technical_review, manager_approval, financial_review, order, delivery, close"],
          ["title", "VARCHAR(100)", "بله", "عنوان مرحله"],
          ["status", "ENUM", "بله", "done, current, pending, rejected, skipped"],
          ["assigned_to", "UUID", "خیر", "مسئول (FK)"],
          ["started_at", "TIMESTAMP", "خیر", "تاریخ شروع"],
          ["completed_at", "TIMESTAMP", "خیر", "تاریخ تکمیل"],
          ["comment", "TEXT", "خیر", "نظر مسئول"],
          ["order_percent", "INTEGER", "خیر", "درصد سفارش (برای مرحله order)"],
        ],
      },
      {
        name: "WorkflowHistory",
        tableName: "workflow_history",
        description: "تاریخچه تغییرات گردش کار",
        fields: [
          ["id", "UUID", "بله", "شناسه یکتا"],
          ["pr_id", "UUID", "بله", "درخواست (FK)"],
          ["step_type", "ENUM", "بله", "نوع مرحله"],
          ["step_title", "VARCHAR(100)", "بله", "عنوان مرحله"],
          ["from_status", "ENUM", "بله", "وضعیت قبلی"],
          ["to_status", "ENUM", "بله", "وضعیت جدید"],
          ["actor_id", "UUID", "بله", "انجام‌دهنده (FK)"],
          ["timestamp", "TIMESTAMP", "بله", "زمان"],
          ["comment", "TEXT", "خیر", "نظر"],
        ],
      },
    ],
    relationships: [
      "PurchaseRequest ↔ Project (چند به یک)",
      "PurchaseRequest ↔ PurchaseRequestItem (یک به چند)",
      "PurchaseRequest ↔ WorkflowStep (یک به چند)",
      "PurchaseRequest ↔ WorkflowHistory (یک به چند)",
      "PurchaseRequestItem ↔ Vendor (چند به یک)",
    ],
    indexes: [
      ["idx_pr_project", "project_id", "B-Tree", "درخواست‌های یک پروژه"],
      ["idx_pr_status", "status", "B-Tree", "فیلتر وضعیت"],
      ["idx_pr_requester", "requester_id", "B-Tree", "درخواست‌های یک کاربر"],
      ["idx_pr_items_pr", "pr_id", "B-Tree", "اقلام یک درخواست"],
      ["idx_wf_steps_pr", "pr_id", "B-Tree", "مراحل گردش کار"],
    ],
  },

  api: {
    overview: "API ماژول تدارکات شامل CRUD، گردش کار، و اقلام است.",
    endpoints: [
      {
        id: "۱",
        method: "GET",
        path: "/api/v1/purchase-requests",
        description: "دریافت فهرست درخواست‌های خرید",
        request: `GET /api/v1/purchase-requests?status=in_order&priority=high
Authorization: Bearer {token}`,
        response: `{ "data": [{ "id": "uuid", "number": "PR-1403-018", "status": "in_order" }] }`,
        statusCodes: [["200", "موفق"]],
      },
      {
        id: "۲",
        method: "POST",
        path: "/api/v1/purchase-requests",
        description: "ایجاد درخواست خرید جدید",
        request: `POST /api/v1/purchase-requests
{
  "title": "درخواست خرید بتن فاز ۲",
  "project_id": "uuid",
  "priority": "critical",
  "needed_by_date": "1403/10/10",
  "items": [
    {
      "name": "بتن آماده M30",
      "category": "material",
      "quantity": 300,
      "unit": "مترمکعب",
      "consumption_location": "طبقه ۱۸",
      "technical_spec": "عیار M30...",
      "vendor_id": "uuid",
      "order_percent": 100
    }
  ]
}`,
        response: `{ "id": "uuid", "number": "PR-1403-024", "status": "draft" }`,
        statusCodes: [["201", "ایجاد شد"], ["400", "داده نامعتبر"]],
      },
      {
        id: "۳",
        method: "POST",
        path: "/api/v1/purchase-requests/{id}/workflow/advance",
        description: " advance گردش کار به مرحله بعد",
        request: `POST /api/v1/purchase-requests/{id}/workflow/advance
{ "comment": "تأیید شد", "order_percent": 100 }`,
        response: `{ "current_step": "order", "status": "in_order" }`,
        statusCodes: [["200", "advance شد"], ["400", "انتقال مجاز نیست"]],
      },
    ],
  },

  useCases: {
    overview: "موارد استفاده شامل ایجاد درخواست، گردش کار، و پیگیری تحویل است.",
    cases: [
      {
        id: "UC-PROC-001",
        title: "ایجاد درخواست خرید با اقلام دقیق",
        actor: "کارشناس دفتر فنی",
        preconditions: ["کاربر دسترسی دارد"],
        mainFlow: [
          "کاربر روی «درخواست خرید جدید» کلیک می‌کند",
          "اطلاعات کلی (عنوان، پروژه، اولویت، تاریخ نیاز) وارد می‌شود",
          "برای هر قلم: شرح دقیق، مقدار، واحد، محل مصرف، مشخصات فنی، وندور، درصد سفارش",
          "اعتبارسنجی فیلدهای الزامی",
          "درخواست با وضعیت «پیش‌نویس» یا «ارسال شده» ذخیره می‌شود",
          "گردش کار ۷ مرحله‌ای شروع می‌شود",
        ],
        alternativeFlows: ["ذخیره به‌عنوان پیش‌نویس", "ارسال مستقیم برای بررسی"],
        postconditions: ["درخواست ایجاد می‌شود", "گردش کار شروع می‌شود"],
      },
      {
        id: "UC-PROC-002",
        title: "advance گردش کار",
        actor: "مسئول مرحله (مثلاً مدیر پروژه)",
        preconditions: ["درخواست در مرحله فعلی است", "کاربر مسئول مرحله است"],
        mainFlow: [
          "مسئول مرحله درخواست را بازبینی می‌کند",
          "روی «تأیید و ادامه» کلیک می‌کند",
          "نظر خود را وارد می‌کند",
          "مرحله فعلی به «done» و مرحله بعد به «current» تغییر می‌کند",
          "اعلان به مسئول مرحله بعد ارسال می‌شود",
        ],
        alternativeFlows: ["مسئول می‌تواند «رد» کند و درخواست به درخواست‌کننده برمی‌گردد"],
        postconditions: ["مرحله advance می‌شود", "تاریخچه ثبت می‌شود"],
      },
    ],
  },

  sequenceDiagrams: [
    {
      id: "SD-PROC-001",
      title: "گردش کار تأیید مرحله‌ای",
      description: "توالی advance گردش کار",
      participants: ["Approver", "Frontend", "Backend API", "Database", "Notification Service"],
      flow: [
        "Approver روی «تأیید و ادامه» کلیک می‌کند",
        "Frontend POST /workflow/advance می‌فرستد",
        "Backend اعتبارسنجی می‌کند که Approver مسئول مرحله فعلی است",
        "Backend مرحله فعلی را به «done» تغییر می‌دهد",
        "Backend مرحله بعد را به «current» تغییر می‌دهد",
        "Backend رویداد WorkflowAdvanced را publish می‌کند",
        "Notification Service به مسئول مرحله بعد اعلان می‌فرستد",
        "Backend پاسخ 200 برمی‌گرداند",
      ],
    },
  ],

  security: {
    overview: "امنیت تدارکات بر اساس مسئولیت مرحله است. هر مرحله فقط توسط مسئول مشخص قابل تأیید است.",
    roles: [
      ["درخواست‌کننده", "ایجاد، مشاهده درخواست‌های خود"],
      ["کارشناس فنی", "تأیید مرحله بازبینی فنی"],
      ["مدیر پروژه", "تأیید مرحله مدیر"],
      ["امور مالی", "تأیید مرحله مالی"],
      ["واحد خرید", "تأیید مرحله سفارش"],
      ["انبار", "تأیید مرحله تحویل"],
    ],
    requirements: ["اعتبارسنجی مسئولیت مرحله", "Audit trail کامل", "عدم امکان skip مرحله"],
    auditTrail: "تمام تغییرات گردش کار در WorkflowHistory ثبت می‌شوند.",
  },

  businessRules: [
    {
      id: "BR-PROC-001",
      title: "فیلدهای الزامی برای هر قلم",
      description: "هر قلم باید شامل: شرح دقیق، مقدار (>0)، محل مصرف، مشخصات فنی باشد. درصد سفارش بین ۰ تا ۱۰۰.",
      validation: `if (!item.name || item.quantity <= 0 || !item.consumption_location || !item.technical_spec) {
  throw new Error('فیلدهای الزامی ناقص است');
}
if (item.order_percent < 0 || item.order_percent > 100) {
  throw new Error('درصد سفارش باید بین ۰ تا ۱۰۰ باشد');
}`,
    },
    {
      id: "BR-PROC-002",
      title: "قوانین انتقال مرحله گردش کار",
      description: "advance گردش کار فقط توسط مسئول مرحله فعلی امکان‌پذیر است. هر مرحله فقط به مرحله بعد مجاز است (به جز «رد» که به درخواست‌کننده برمی‌گردد).",
      validation: `if (step.assigned_to !== currentUser.id) {
  throw new Error('شما مسئول این مرحله نیستید');
}
const nextStep = workflow[step.order + 1];
if (!nextStep) throw new Error('مرحله نهایی است');`,
    },
    {
      id: "BR-PROC-003",
      title: "درصد سفارش در مرحله order",
      description: "در مرحله «صدور سفارش»، درصد سفارش باید مشخص شود. این درصد نشان می‌دهد چه مقدار از درخواست سفارش داده شده است.",
      validation: `if (step.type === 'order' && order_percent === undefined) {
  throw new Error('درصد سفارش الزامی است');
}`,
    },
  ],

  quality: {
    performance: [["زمان پاسخ فهرست", "< ۲۰۰ms", "-"], ["زمان advance گردش کار", "< ۳۰۰ms", "-"]],
    availability: ["ماژول ۹۹.۵٪ در دسترس"],
    scalability: ["صفحه‌بندی", "Index روی status و project_id"],
  },

  implementation: {
    patterns: [
      ["State Machine", "مدیریت گردش کار ۷ مرحله‌ای"],
      ["Chain of Responsibility", "توالی مراحل تأیید"],
      ["Repository Pattern", "PurchaseRequestRepository"],
      ["Domain Events", "رویداد WorkflowAdvanced"],
    ],
    notes: ["از state machine برای گردش کار", "اعلان real-time با SignalR", "تاریخچه append-only"],
    testing: "Unit test برای state machine، integration test برای گردش کار کامل.",
    relatedDocs: ["سند معماری کلی سامانه", "مستندات API تدارکات"],
    changelog: [["۱.۰", "۱۴۰۳/۱۰/۰۱", "نسخه اولیه - گردش کار ۷ مرحله‌ای"]],
  },
};
