// generate-remaining-modules.js
// Generate remaining 6 module documents (vendors, reports, users, notifications, search, profile)

const fs = require("fs");
const path = require("path");
const H = require("./docx-helpers");
const {
  P, rtlRun, rtlParagraph, heading, bullet, numberedItem, codeBlock, makeTable,
  note, spacer, buildCover, Paragraph, TextRun, Document, Packer,
  AlignmentType, PageBreak, SectionType, Header, Footer, PageNumber,
  NumberFormat, TableOfContents, StyleLevel,
} = H;

const OUT_DIR = "/home/z/my-project/download/architecture-docs";
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

// ===== Common builders =====
function tocSection() {
  return [
    new Paragraph({
      bidirectional: true, alignment: AlignmentType.CENTER,
      spacing: { before: 480, after: 400, line: 480 },
      children: [new TextRun({
        text: "فهرست مطالب", rightToLeft: true, bold: true, size: 44, color: P.primary,
        font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
      })],
    }),
    new TableOfContents("Table of Contents", {
      hyperlink: true, headingStyleRange: "1-3",
      stylesWithLevels: [new StyleLevel("Heading1", 1), new StyleLevel("Heading2", 2), new StyleLevel("Heading3", 3)],
    }),
    new Paragraph({
      bidirectional: true, alignment: AlignmentType.CENTER, spacing: { before: 200 },
      children: [new TextRun({
        text: "(برای به‌روزرسانی فهرست، روی آن کلیک راست کرده و Update Field را انتخاب کنید)",
        rightToLeft: true, italics: true, size: 18, color: P.muted,
      })],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function buildDoc(meta, chapters) {
  return new Document({
    creator: "CM Automation Team",
    title: meta.title,
    description: meta.description,
    styles: {
      default: {
        document: {
          run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY }, size: 24, color: P.body },
          paragraph: { spacing: { line: 360 } },
        },
        heading1: {
          run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 36, bold: true, color: P.primary },
          paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 480, after: 200, line: 480 } },
        },
        heading2: {
          run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 30, bold: true, color: P.primary },
          paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 360, after: 160, line: 400 } },
        },
        heading3: {
          run: { font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING }, size: 26, bold: true, color: P.primaryDark },
          paragraph: { alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 240, after: 120, line: 360 } },
        },
      },
    },
    sections: [
      {
        properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 } } },
        children: buildCover(meta.title, meta.subtitle, meta.version, meta.date, meta.code),
      },
      {
        properties: {
          type: SectionType.NEXT_PAGE,
          page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 }, pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
        },
        headers: { default: new Header({ children: [new Paragraph({ bidirectional: true, alignment: AlignmentType.RIGHT, children: [new TextRun({ text: `${meta.title} - ${meta.version}`, rightToLeft: true, size: 18, color: P.muted, font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY } })] })] }) },
        footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "صفحه ", rightToLeft: true, size: 18, color: P.muted }), new TextRun({ children: [PageNumber.CURRENT], size: 18, color: P.muted })] })] }) },
        children: [...tocSection(), ...chapters],
      },
    ],
  });
}

// ===== Module 09: Vendors =====
function buildVendorsChapters() {
  return [
    heading("فصل اول: معرفی ماژول", 1),
    rtlParagraph("ماژول تأمین‌کنندگان (Vendors) مدیریت جامع وندورها و تأمین‌کنندگان مصالح و تجهیزات را بر عهده دارد. این ماژول شامل ثبت اطلاعات کامل وندور (نام، شناسه ملی، تلفن، شماره شبا، آدرس)، ارزیابی عملکرد با سیستم امتیازدهی، دسته‌بندی با تگ‌ها، و تاریخچه سفارش‌های قبلی است."),
    heading("۱.۱ اهداف", 2),
    bullet("مدیریت مرکزی اطلاعات تأمین‌کنندگان"),
    bullet("ارزیابی عملکرد وندورها با سیستم امتیازدهی ۵ ستاره"),
    bullet("دسته‌بندی وندورها با تگ (مثال: بتن، فولاد، تأسیسات)"),
    bullet("پیگیری تاریخچه سفارش‌های قبلی هر وندور"),
    bullet("انتخاب وندور هوشمند در درخواست‌های خرید"),
    spacer(),
    heading("۱.۲ کامپوننت‌ها", 2),
    makeTable(["کامپوننت", "مسئولیت"], [
      ["VendorsListView", "فهرست وندورها با جستجو و فیلتر تگ"],
      ["VendorCard", "کارت وندور با امتیاز و تگ‌ها"],
      ["VendorFormModal", "مودال ایجاد/ویرایش وندور"],
      ["VendorAPI", "سرویس ارتباط با API"],
    ], [30, 70]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل دوم: مدل داده", 1),
    heading("۲.۱ موجودیت Vendor", 2),
    makeTable(["فیلد", "نوع", "توضیح"], [
      ["id", "UUID", "شناسه یکتا"],
      ["name", "VARCHAR(200)", "نام وندور"],
      ["type", "ENUM", "person, company"],
      ["national_id", "VARCHAR(20)", "کدملی/شناسه ملی"],
      ["phone", "VARCHAR(20)", "تلفن"],
      ["email", "VARCHAR(100)", "ایمیل"],
      ["address", "TEXT", "نشانی"],
      ["contact_person", "VARCHAR(100)", "نماینده"],
      ["iban", "VARCHAR(26)", "شماره شبا"],
      ["rating", "INTEGER", "امتیاز ۱-۵"],
      ["tags", "JSONB", "تگ‌ها"],
      ["previous_orders", "INTEGER", "تعداد سفارش‌های قبلی"],
    ], [25, 25, 50]),
    spacer(),
    heading("۲.۲ روابط", 2),
    bullet("Vendor ↔ PurchaseRequest (یک به چند - از طریق items)"),
    bullet("Vendor ↔ Contract (یک به چند - به‌عنوان پیمانکار)"),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل سوم: API", 1),
    makeTable(["Method", "Path", "توضیح"], [
      ["GET", "/api/v1/vendors", "دریافت فهرست وندورها"],
      ["POST", "/api/v1/vendors", "ایجاد وندور جدید"],
      ["GET", "/api/v1/vendors/{id}", "دریافت جزئیات وندور"],
      ["PUT", "/api/v1/vendors/{id}", "ویرایش وندور"],
      ["GET", "/api/v1/vendors/{id}/orders", "سفارش‌های قبلی وندور"],
    ], [15, 40, 45]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل چهارم: امنیت و قوانین کسب‌وکار", 1),
    heading("۴.۱ نقش‌ها", 2),
    bullet("مدیر سیستم: دسترسی کامل"),
    bullet("واحد خرید: ایجاد، ویرایش، مشاهده"),
    bullet("کارشناس: فقط مشاهده"),
    spacer(),
    heading("۴.۲ قوانین کسب‌وکار", 2),
    numberedItem("۱", "اعتبارسنجی شناسه ملی/کدملی با check digit"),
    numberedItem("۲", "اعتبارسنجی شماره شبا با فرمت IR + 24 رقم"),
    numberedItem("۳", "امتیاز ۱ تا ۵ فقط قابل تنظیم توسط مدیر"),
    numberedItem("۴", "حذف وندور با سفارش فعال ممنوع"),
  ];
}

// ===== Module 10: Reports =====
function buildReportsChapters() {
  return [
    heading("فصل اول: معرفی ماژول", 1),
    rtlParagraph("ماژول گزارش‌ها، گزارش‌گیری تحلیلی و داشبورد مدیریت را بر عهده دارد. این ماژول شامل نمودارهای متنوع (Area، Line، Bar، Pie، Radar)، جدول رتبه‌بندی، و قابلیت Drill-down از سطح سازمان تا وظیفه فردی است. گزارش‌ها بر اساس نقش کاربر فیلتر می‌شوند."),
    heading("۱.۱ اهداف", 2),
    bullet("ارائه گزارش‌های تحلیلی با نمودارهای متنوع"),
    bullet("پشتیبانی از Drill-down چندسطحی"),
    bullet("گزارش بهره‌وری فردی، تیمی، پروژه و سازمانی"),
    bullet("خروجی Excel و PDF برای گزارش‌ها"),
    bullet("فیلتر بر اساس بازه زمانی، پروژه، کاربر"),
    spacer(),
    heading("۱.۲ انواع گزارش‌ها", 2),
    makeTable(["گزارش", "توضیح"], [
      ["روند بهره‌وری", "نمودار Area ۷ ماه گذشته"],
      ["پیشرفت برنامه‌ریزی‌شده vs واقعی", "نمودار Line مقایسه‌ای"],
      ["بودجه پروژه‌ها", "نمودار Bar مقایسه بودجه و هزینه"],
      ["توزیع وظایف", "نمودار Pie بر اساس وضعیت"],
      ["اولویت وظایف", "نمودار Bar افقی"],
      ["عملکرد تیم", "جدول رتبه‌بندی با نمودار"],
    ], [30, 70]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل دوم: معماری و کامپوننت‌ها", 1),
    heading("۲.۱ کامپوننت‌ها", 2),
    makeTable(["کامپوننت", "تکنولوژی"], [
      ["ReportsView", "Next.js + React"],
      ["ChartWidget", "Recharts (Area, Line, Bar, Pie, Radar)"],
      ["TeamPerformanceTable", "React Table"],
      ["ReportFilters", "React + Select"],
      ["ReportExportService", "ExcelJS + jsPDF"],
    ], [50, 50]),
    spacer(),
    heading("۲.۲ وابستگی‌ها", 2),
    bullet("پروژه‌ها: دریافت داده‌های پیشرفت و بودجه"),
    bullet("وظایف: دریافت آمار وظایف برای KPI"),
    bullet("کاربران: دریافت داده‌های بهره‌وری"),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل سوم: API و مدل داده", 1),
    makeTable(["Endpoint", "توضیح"], [
      ["GET /api/v1/reports/productivity-trend", "روند بهره‌وری"],
      ["GET /api/v1/reports/project-progress", "پیشرفت پروژه‌ها"],
      ["GET /api/v1/reports/budget-analysis", "تحلیل بودجه"],
      ["GET /api/v1/reports/team-performance", "عملکرد تیم"],
      ["GET /api/v1/reports/export?type=excel", "خروجی Excel"],
    ], [50, 50]),
    spacer(),
    rtlParagraph("مدل داده: ماژول گزارش‌ها موجودیت مستقل ندارد و از aggregation داده‌های سایر ماژول‌ها استفاده می‌کند. برای گزارش‌های سنگین، از materialized view در PostgreSQL استفاده می‌شود."),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل چهارم: امنیت و کیفیت", 1),
    heading("۴.۱ امنیت", 2),
    bullet("گزارش‌ها بر اساس نقش فیلتر می‌شوند (مدیر ارشد: سازمانی، مدیر پروژه: پروژه، کارشناس: شخصی)"),
    bullet("دسترسی به گزارش‌های مالی محدود به امور مالی"),
    spacer(),
    heading("۴.۲ ویژگی‌های کیفیت", 2),
    bullet("زمان پاسخ گزارش: < ۳ ثانیه"),
    bullet("Cache برای گزارش‌های پرتکرار با TTL ۱۵ دقیقه"),
    bullet("Materialized view برای aggregation سنگین"),
    bullet("پشتیبانی از خروجی Excel و PDF"),
  ];
}

// ===== Module 11: Users & Roles =====
function buildUsersChapters() {
  return [
    heading("فصل اول: معرفی ماژول", 1),
    rtlParagraph("ماژول کاربران و نقش‌ها، مدیریت هویت و دسترسی (IAM) را بر عهده دارد. این ماژول شامل مدیریت کاربران، نقش‌ها، دسترسی‌ها (RBAC + Scope)، و احراز هویت با Keycloak است. سامانه از ۶ نقش پیش‌فرض پروژه پشتیبانی می‌کند و امکان تعریف نقش‌های جدید وجود دارد."),
    heading("۱.۱ اهداف", 2),
    bullet("مدیریت کاربران با احراز هویت Keycloak"),
    bullet("RBAC + Scope برای کنترل دسترسی دقیق"),
    bullet("۶ نقش پیش‌فرض پروژه + نقش‌های سفارشی"),
    bullet("مدیریت دعوت‌نامه و فعال‌سازی کاربر"),
    bullet("پروفایل کاربر با تاریخچه فعالیت"),
    spacer(),
    heading("۱.۲ نقش‌های پیش‌فرض", 2),
    makeTable(["نقش", "دسترسی"], [
      ["مدیر پروژه", "دسترسی کامل به پروژه‌های خود"],
      ["سرپرست کارگاه", "مدیریت کارگاه، بازدیدها"],
      ["کارشناس دفتر فنی", "ایجاد و ویرایش وظایف، اسناد"],
      ["کارشناس اجرا", "ثبت گزارش روزانه، وظایف"],
      ["کارشناس برق", "تخصصی تأسیسات برق"],
      ["کارشناس مکانیک", "تخصصی تأسیسات مکانیک"],
    ], [30, 70]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل دوم: مدل داده", 1),
    heading("۲.۱ موجودیت‌ها", 2),
    makeTable(["موجودیت", "توضیح"], [
      ["User", "کاربر سامانه با اطلاعات پروفایل"],
      ["Role", "نقش با مجموعه دسترسی‌ها"],
      ["Permission", "دسترسی atomic (مثال: project.create)"],
      ["RolePermission", "ارتباط نقش و دسترسی"],
      ["UserRole", "ارتباط کاربر و نقش (با scope)"],
      ["Organization", "سازمان کاربر"],
    ], [25, 75]),
    spacer(),
    heading("۲.۲ موجودیت User", 2),
    makeTable(["فیلد", "نوع", "توضیح"], [
      ["id", "UUID", "شناسه یکتا"],
      ["name", "VARCHAR(100)", "نام و نام خانوادگی"],
      ["email", "VARCHAR(100)", "ایمیل (unique)"],
      ["phone", "VARCHAR(20)", "تلفن"],
      ["role", "ENUM", "نقش پیش‌فرض"],
      ["organization_id", "UUID", "سازمان (FK)"],
      ["department", "VARCHAR(100)", "دپارتمان"],
      ["status", "ENUM", "active, inactive, invited"],
      ["productivity_score", "INTEGER", "امتیاز بهره‌وری 0-100"],
      ["last_seen", "TIMESTAMP", "آخرین بازدید"],
    ], [25, 25, 50]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل سوم: API و امنیت", 1),
    makeTable(["Endpoint", "توضیح"], [
      ["GET /api/v1/users", "فهرست کاربران"],
      ["POST /api/v1/users", "ایجاد کاربر (دعوت‌نامه)"],
      ["PUT /api/v1/users/{id}", "ویرایش کاربر"],
      ["DELETE /api/v1/users/{id}", "غیرفعال‌سازی"],
      ["GET /api/v1/roles", "فهرست نقش‌ها"],
      ["POST /api/v1/roles", "تعریف نقش جدید"],
      ["POST /api/v1/auth/login", "ورود (Keycloak)"],
      ["POST /api/v1/auth/refresh", "refresh token"],
    ], [45, 55]),
    spacer(),
    heading("۳.۱ مدل امنیت RBAC + Scope", 2),
    rtlParagraph("هر کاربر یک یا چند نقش دارد. هر نقش دارای دسترسی‌های atomic است. علاوه بر این، scope دسترسی را به سازمان، پروژه و دپارتمان محدود می‌کند. به عنوان مثال، یک کارشناس دفتر فنی ممکن است به پروژه‌های دپارتمان خود دسترسی داشته باشد اما به پروژه‌های دپارتمان‌های دیگر دسترسی نداشته باشد."),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل چهارم: قوانین کسب‌وکار", 1),
    numberedItem("۱", "ایمیل یکتا - هر ایمیل فقط یک حساب کاربری دارد"),
    numberedItem("۲", "حداقل یک نقش الزامی - هر کاربر باید حداقل یک نقش داشته باشد"),
    numberedItem("۳", "غیرفعال‌سازی به‌جای حذف - کاربران soft delete می‌شوند"),
    numberedItem("۴", "محاسبه خودکار بهره‌وری - بر اساس داده‌های وظایف"),
    numberedItem("۵", "دعوت‌نامه با انقضای ۷ روز - کاربر دعوت‌شده باید در ۷ روز ثبت‌نام کند"),
  ];
}

// ===== Module 12: Notifications =====
function buildNotificationsChapters() {
  return [
    heading("فصل اول: معرفی ماژول", 1),
    rtlParagraph("ماژول اعلان‌ها، سیستم اعلان چندکاناله را بر عهده دارد. این ماژول شامل اعلان‌های in-app، ایمیل، SMS و push است. هر اعلان دارای نوع (تخصیص وظیفه، سررسید، مکاتبه، تأیید، سیستم)، اولویت و وضعیت خوانده‌شده/خوانده‌نشده است."),
    heading("۱.۱ اهداف", 2),
    bullet("سیستم اعلان چندکاناله (in-app, email, SMS, push)"),
    bullet("اعلان real-time با SignalR"),
    bullet("مدیریت وضعیت خوانده‌شده/خوانده‌نشده"),
    bullet("فیلتر بر اساس نوع و وضعیت"),
    bullet("تنظیمات اعلان توسط کاربر"),
    spacer(),
    heading("۱.۲ انواع اعلان", 2),
    makeTable(["نوع", "توضیح"], [
      ["task_assigned", "وظیفه جدید محول شد"],
      ["task_due", "سررسید نزدیک است"],
      ["doc_shared", "سند به اشتراک گذاشته شد"],
      ["correspondence", "مکاتبه جدید دریافت شد"],
      ["approval", "در انتظار تأیید شما"],
      ["mention", "اشاره به شما در نظر"],
      ["system", "اعلان سیستمی"],
    ], [25, 75]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل دوم: معماری", 1),
    heading("۲.۱ کامپوننت‌ها", 2),
    makeTable(["کامپوننت", "توضیح"], [
      ["NotificationsView", "مرکز اعلان‌ها با فیلتر"],
      ["NotificationBell", "آیکون زنگوله در header با badge"],
      ["NotificationPopover", "پاپ‌اور اعلان‌های اخیر"],
      ["NotificationService", "سرویس ارتباط با API + SignalR"],
      ["EmailSender", "ارسال ایمیل با SMTP"],
      ["SMSSender", "ارسال SMS با ارائه‌دهنده ایرانی"],
    ], [30, 70]),
    spacer(),
    heading("۲.۲ گردش کار اعلان", 2),
    rtlParagraph("رویدادهای سامانه (ایجاد وظیفه، تغییر وضعیت، مکاتبه جدید) در RabbitMQ publish می‌شوند. Notification Service این رویدادها را consume می‌کند و بر اساس تنظیمات کاربر، اعلان در کانال‌های مناسب ارسال می‌کند. اعلان in-app با SignalR به‌صورت real-time نمایش داده می‌شود."),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل سوم: مدل داده و API", 1),
    heading("۳.۱ موجودیت Notification", 2),
    makeTable(["فیلد", "نوع", "توضیح"], [
      ["id", "UUID", "شناسه یکتا"],
      ["user_id", "UUID", "کاربر دریافت‌کننده (FK)"],
      ["type", "ENUM", "نوع اعلان"],
      ["title", "VARCHAR(200)", "عنوان"],
      ["message", "TEXT", "متن اعلان"],
      ["read", "BOOLEAN", "خوانده‌شده"],
      ["link", "JSONB", "لینک به صفحه مرتبط"],
      ["created_at", "TIMESTAMP", "تاریخ ایجاد"],
    ], [25, 25, 50]),
    spacer(),
    heading("۳.۲ API", 2),
    makeTable(["Endpoint", "توضیح"], [
      ["GET /api/v1/notifications", "دریافت اعلان‌ها"],
      ["PUT /api/v1/notifications/{id}/read", "علامت‌گذاری خوانده‌شده"],
      ["PUT /api/v1/notifications/read-all", "خوانده‌شده همه"],
      ["WS /hub/notifications", "SignalR برای real-time"],
    ], [45, 55]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل چهارم: قوانین و کیفیت", 1),
    numberedItem("۱", "اعلان‌های مهم ( بحرانی) حتی اگر کاربر mute کرده باشد نمایش داده می‌شوند"),
    numberedItem("۲", "اعلان‌های خوانده‌نشده بعد از ۳۰ روز خودکار archive می‌شوند"),
    numberedItem("۳", "هر کاربر حداکثر ۵۰ اعلان خوانده‌نشده می‌تواند داشته باشد"),
    numberedItem("۴", "Real-time با SignalR - تأخیر کمتر از ۲ ثانیه"),
    numberedItem("۵", "Retry policy برای ارسال ایمیل و SMS (۳ بار با تأخیر تصاعدی)"),
  ];
}

// ===== Module 13: Search =====
function buildSearchChapters() {
  return [
    heading("فصل اول: معرفی ماژول", 1),
    rtlParagraph("ماژول جستجو، جستجوی سراسری در همه ماژول‌های سامانه را بر عهده دارد. این ماژول با OpenSearch پیاده‌سازی شده و از جستجوی فارسی با stemming، fuzzy search و highlight نتایج پشتیبانی می‌کند."),
    heading("۱.۱ اهداف", 2),
    bullet("جستجوی سراسری در همه ماژول‌ها"),
    bullet("پشتیبانی از زبان فارسی با stemming"),
    bullet("Fuzzy search برای تحمل اشتباه تایپی"),
    bullet("Highlight کلمات جستجو در نتایج"),
    bullet("جستجو با تأخیر کمتر از ۵۰۰ms"),
    spacer(),
    heading("۱.۲ دامنه جستجو", 2),
    makeTable(["ماژول", "فیلدهای قابل جستجو"], [
      ["پروژه‌ها", "نام، کد، توضیحات، کارفرما"],
      ["وظایف", "عنوان، شرح، تگ‌ها"],
      ["اسناد", "نام، توضیحات، محتوای فایل"],
      ["مکاتبات", "موضوع، شماره، متن"],
      ["قراردادها", "عنوان، شماره، موضوع"],
      ["تدارکات", "عنوان، شماره، اقلام"],
      ["کاربران", "نام، ایمیل"],
    ], [25, 75]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل دوم: معماری", 1),
    heading("۲.۱ کامپوننت‌ها", 2),
    makeTable(["کامپوننت", "توضیح"], [
      ["SearchView", "صفحه نتایج جستجو با تب‌بندی"],
      ["SearchBar", "نوار جستجو در header"],
      ["SearchAPI", "سرویس ارتباط با OpenSearch"],
      ["IndexerService", "ایندکس‌گذاری داده‌ها در OpenSearch"],
    ], [30, 70]),
    spacer(),
    heading("۲.۲ معماری ایندکس‌گذاری", 2),
    rtlParagraph("هنگام ایجاد، ویرایش یا حذف داده در ماژول‌ها، رویداد در RabbitMQ publish می‌شود. Indexer Service این رویدادها را consume می‌کند و ایندکس OpenSearch را به‌روزرسانی می‌کند. این رویکرد async از کند کردن عملیات اصلی جلوگیری می‌کند."),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل سوم: API و OpenSearch", 1),
    makeTable(["Endpoint", "توضیح"], [
      ["GET /api/v1/search?q=بتن", "جستجوی سراسری"],
      ["GET /api/v1/search/projects?q=برج", "جستجو در پروژه‌ها"],
      ["GET /api/v1/search/suggest?q=بت", "پیشنهاد خودکار"],
    ], [50, 50]),
    spacer(),
    heading("۳.۱ پیکربندی OpenSearch", 2),
    bullet("Analyzer: persian (با stemming فارسی)"),
    bullet("Fuzzy search: fuzziness=AUTO برای تحمل اشتباه تایپی"),
    bullet("Highlight: با tag <em> برای کلمات جستجو"),
    bullet("Index: هر ماژول یک index مجزا دارد"),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل چهارم: کیفیت و قوانین", 1),
    bullet("زمان پاسخ جستجو: < ۵۰۰ms"),
    bullet("پشتیبانی از pagination (۲۰ نتیجه در صفحه)"),
    bullet("Cache برای جستجوهای پرتکرار (TTL ۱ دقیقه)"),
    bullet("Index replication برای high availability"),
    bullet("Reindex کامل در صورت تغییر schema"),
  ];
}

// ===== Module 14: Profile & Settings =====
function buildProfileChapters() {
  return [
    heading("فصل اول: معرفی ماژول", 1),
    rtlParagraph("ماژول پروفایل و تنظیمات، مدیریت پروفایل کاربر و پیکربندی سامانه را بر عهده دارد. این ماژول شامل پروفایل کاربر با تاریخچه فعالیت، تنظیمات اعلان، تنظیمات ظاهر (تم، RTL)، و تنظیمات امنیتی (تغییر رمز، 2FA) است."),
    heading("۱.۱ اهداف", 2),
    bullet("مدیریت پروفایل کاربر با آواتار و اطلاعات تماس"),
    bullet("تنظیمات اعلان (in-app, email, SMS)"),
    bullet("تنظیمات ظاهر (light/dark، RTL)"),
    bullet("تنظیمات امنیتی (تغییر رمز، 2FA)"),
    bullet("نمایش تاریخچه فعالیت و دستاوردها"),
    spacer(),
    heading("۱.۲ بخش‌های ماژول", 2),
    makeTable(["بخش", "توضیح"], [
      ["اطلاعات شخصی", "نام، ایمیل، تلفن، دپارتمان"],
      ["عملکرد", "نمودار راداری مهارت‌ها، دستاوردها"],
      ["فعالیت‌ها", "وظایف اخیر، پروژه‌ها"],
      ["اعلان‌ها", "تنظیمات کانال‌های اعلان"],
      ["ظاهر", "تم، RTL، زبان"],
      ["امنیت", "تغییر رمز، 2FA، نشست‌های فعال"],
    ], [25, 75]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل دوم: مدل داده و API", 1),
    heading("۲.۱ موجودیت UserPreference", 2),
    makeTable(["فیلد", "نوع", "توضیح"], [
      ["user_id", "UUID", "کاربر (FK)"],
      ["theme", "ENUM", "light, dark, system"],
      ["language", "VARCHAR(10)", "fa, en"],
      ["notification_settings", "JSONB", "تنظیمات اعلان"],
      ["dashboard_layout", "JSONB", "چیدمان داشبورد"],
    ], [25, 25, 50]),
    spacer(),
    heading("۲.۲ API", 2),
    makeTable(["Endpoint", "توضیح"], [
      ["GET /api/v1/profile", "دریافت پروفایل"],
      ["PUT /api/v1/profile", "ویرایش پروفایل"],
      ["PUT /api/v1/profile/avatar", "تغییر آواتار"],
      ["PUT /api/v1/profile/password", "تغییر رمز"],
      ["GET /api/v1/profile/settings", "دریافت تنظیمات"],
      ["PUT /api/v1/profile/settings", "ذخیره تنظیمات"],
      ["POST /api/v1/profile/2fa/enable", "فعال‌سازی 2FA"],
    ], [45, 55]),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل سوم: امنیت", 1),
    heading("۳.۱ امنیت پروفایل", 2),
    bullet("هر کاربر فقط پروفایل خود را می‌تواند ویرایش کند"),
    bullet("تغییر رمز نیاز به رمز فعلی دارد"),
    bullet("2FA با TOTP (Google Authenticator)"),
    bullet("مدیریت نشست‌های فعال با امکان logout از دستگاه‌های دیگر"),
    bullet("Audit trail برای تغییرات حساس (رمز، 2FA)"),
    new Paragraph({ children: [new PageBreak()] }),

    heading("فصل چهارم: قوانین و کیفیت", 1),
    numberedItem("۱", "رمز عبور باید حداقل ۸ کاراکتر با حروف بزرگ، کوچک و عدد باشد"),
    numberedItem("۲", "آواتار باید حداقل 200x200 و حداکثر 2MB باشد"),
    numberedItem("۳", "تغییر ایمیل نیاز به تأیید ایمیل جدید دارد"),
    numberedItem("۴", "2FA بعد از فعال‌سازی غیرقابل غیرفعال‌سازی بدون کد backup نیست"),
    numberedItem("۵", "زمان پاسخ پروفایل: < ۲۰۰ms"),
  ];
}

// ===== Generate all 6 modules =====
const modules = [
  { meta: { title: "معماری ماژول تأمین‌کنندگان", subtitle: "Vendors Module Architecture", version: "نسخه ۱.۰", date: "۱۴۰۳/۱۰/۰۱", code: "MOD-VEND-009", fileName: "09-معماری-ماژول-تأمین‌کنندگان.docx", description: "Vendors module" }, build: buildVendorsChapters },
  { meta: { title: "معماری ماژول گزارش‌ها", subtitle: "Reports Module Architecture", version: "نسخه ۱.۰", date: "۱۴۰۳/۱۰/۰۱", code: "MOD-REP-010", fileName: "10-معماری-ماژول-گزارش‌ها.docx", description: "Reports module" }, build: buildReportsChapters },
  { meta: { title: "معماری ماژول کاربران و نقش‌ها", subtitle: "Users & Roles Module Architecture", version: "نسخه ۱.۰", date: "۱۴۰۳/۱۰/۰۱", code: "MOD-USER-011", fileName: "11-معماری-ماژول-کاربران-و-نقش‌ها.docx", description: "Users & Roles module" }, build: buildUsersChapters },
  { meta: { title: "معماری ماژول اعلان‌ها", subtitle: "Notifications Module Architecture", version: "نسخه ۱.۰", date: "۱۴۰۳/۱۰/۰۱", code: "MOD-NOTIF-012", fileName: "12-معماری-ماژول-اعلان‌ها.docx", description: "Notifications module" }, build: buildNotificationsChapters },
  { meta: { title: "معماری ماژول جستجو", subtitle: "Search Module Architecture", version: "نسخه ۱.۰", date: "۱۴۰۳/۱۰/۰۱", code: "MOD-SEARCH-013", fileName: "13-معماری-ماژول-جستجو.docx", description: "Search module" }, build: buildSearchChapters },
  { meta: { title: "معماری ماژول پروفایل و تنظیمات", subtitle: "Profile & Settings Module Architecture", version: "نسخه ۱.۰", date: "۱۴۰۳/۱۰/۰۱", code: "MOD-PROF-014", fileName: "14-معماری-ماژول-پروفایل-و-تنظیمات.docx", description: "Profile & Settings module" }, build: buildProfileChapters },
];

async function generateAll() {
  for (const mod of modules) {
    const doc = buildDoc(mod.meta, mod.build());
    const buffer = await Packer.toBuffer(doc);
    const outPath = path.join(OUT_DIR, mod.meta.fileName);
    fs.writeFileSync(outPath, buffer);
    console.log(`✓ Generated: ${outPath} (${(buffer.length / 1024).toFixed(1)} KB)`);
  }
}

generateAll().catch(err => { console.error(err); process.exit(1); });
