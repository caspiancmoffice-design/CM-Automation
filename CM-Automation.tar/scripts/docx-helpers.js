// generate-system-architecture.js — System Architecture Document (SAD)
// Based on IEEE 1471 + 4+1 View Model
// Persian language, RTL, technical document

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  Header, Footer, PageNumber, NumberFormat, SectionType, PageBreak,
  LevelFormat, convertInchesToTwip, TableOfContents, StyleLevel,
  TabStopType, TabStopPosition, Break, HorizontalPositionAlign,
  VerticalPositionAlign, VerticalAlign, ImageRun,
} = require("docx");
const fs = require("fs");
const path = require("path");

// ===== Palette (CM Automation industrial emerald/teal) =====
const P = {
  primary: "1A5F4A",       // Deep teal
  primaryLight: "2D8B6F",
  primaryDark: "0F3D30",
  accent: "D4A574",       // Warm amber
  body: "1F2937",
  muted: "6B7280",
  light: "F0FDF4",
  lightAccent: "FEF3C7",
  border: "E5E7EB",
  white: "FFFFFF",
  codeBg: "F9FAFB",
  codeText: "374151",
};

// ===== Font specifications =====
const FONT_BODY = "B Nazanin";  // Will fallback to system Persian font
const FONT_HEADING = "B Nazanin";
const FONT_CODE = "Consolas";
const FONT_EN = "Calibri";

// ===== Helper functions =====

function rtlRun(text, options = {}) {
  return new TextRun({
    text: String(text ?? ""),
    rightToLeft: true,
    font: { ascii: FONT_EN, eastAsia: FONT_BODY, hAnsi: FONT_EN, cs: FONT_BODY },
    size: options.size ?? 24,
    bold: options.bold ?? false,
    italics: options.italics ?? false,
    color: options.color ?? P.body,
    ...options,
  });
}

function ltrRun(text, options = {}) {
  return new TextRun({
    text: String(text ?? ""),
    font: { ascii: FONT_CODE, eastAsia: FONT_CODE, hAnsi: FONT_CODE },
    size: options.size ?? 20,
    color: options.color ?? P.codeText,
    ...options,
  });
}

function rtlParagraph(text, options = {}) {
  return new Paragraph({
    bidirectional: true,
    alignment: options.alignment ?? AlignmentType.JUSTIFIED,
    spacing: { line: 360, before: options.before ?? 0, after: options.after ?? 120 },
    indent: options.indent ?? { firstLine: 360 },
    children: [rtlRun(text, options)],
  });
}

function heading(text, level = 1, options = {}) {
  const sizes = { 1: 36, 2: 30, 3: 26, 4: 24 };
  const colors = { 1: P.primary, 2: P.primary, 3: P.primaryDark, 4: P.body };
  const headingLevels = {
    1: HeadingLevel.HEADING_1,
    2: HeadingLevel.HEADING_2,
    3: HeadingLevel.HEADING_3,
    4: HeadingLevel.HEADING_4,
  };
  return new Paragraph({
    heading: headingLevels[level],
    bidirectional: true,
    alignment: AlignmentType.RIGHT,
    spacing: {
      before: level === 1 ? 480 : level === 2 ? 360 : 240,
      after: level === 1 ? 200 : 160,
      line: 360,
    },
    children: [new TextRun({
      text,
      rightToLeft: true,
      bold: true,
      size: sizes[level],
      color: colors[level],
      font: { ascii: FONT_EN, eastAsia: FONT_HEADING, hAnsi: FONT_EN, cs: FONT_HEADING },
    })],
  });
}

function bullet(text, level = 0) {
  return new Paragraph({
    bidirectional: true,
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 340, after: 80 },
    indent: { right: 360 + level * 360, firstLine: 0, hanging: 0 },
    children: [
      rtlRun("• ", { bold: true, color: P.primary }),
      rtlRun(text),
    ],
  });
}

function numberedItem(num, text) {
  return new Paragraph({
    bidirectional: true,
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 340, after: 80 },
    indent: { right: 360, firstLine: 0 },
    children: [
      rtlRun(`${num}. `, { bold: true, color: P.primary }),
      rtlRun(text),
    ],
  });
}

function codeBlock(code) {
  const lines = code.split("\n");
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 1, color: P.border },
      bottom: { style: BorderStyle.SINGLE, size: 1, color: P.border },
      left: { style: BorderStyle.SINGLE, size: 1, color: P.border },
      right: { style: BorderStyle.SINGLE, size: 1, color: P.border },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
    },
    rows: [new TableRow({
      cantSplit: true,
      children: [new TableCell({
        width: { size: 100, type: WidthType.PERCENTAGE },
        shading: { type: ShadingType.CLEAR, fill: P.codeBg, color: "auto" },
        margins: { top: 200, bottom: 200, left: 200, right: 200 },
        children: lines.map(line => new Paragraph({
          bidirectional: false,
          alignment: AlignmentType.LEFT,
          spacing: { line: 280, after: 0 },
          children: [ltrRun(line || " ")],
        })),
      })],
    })],
  });
}

function tableCell(text, options = {}) {
  return new TableCell({
    width: options.width ? { size: options.width, type: WidthType.PERCENTAGE } : undefined,
    shading: options.shading ? { type: ShadingType.CLEAR, fill: options.shading, color: "auto" } : undefined,
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      bidirectional: true,
      alignment: options.alignment ?? AlignmentType.RIGHT,
      spacing: { line: 300, after: 0 },
      children: [rtlRun(text, { bold: options.bold, size: options.size ?? 22, color: options.color })],
    })],
  });
}

function makeTable(headers, rows, columnWidths) {
  const headerRow = new TableRow({
    tableHeader: true,
    cantSplit: true,
    children: headers.map((h, i) => tableCell(h, {
      width: columnWidths?.[i],
      shading: P.primary,
      bold: true,
      color: P.white,
      alignment: AlignmentType.CENTER,
    })),
  });
  const dataRows = rows.map(row => new TableRow({
    cantSplit: true,
    children: row.map((c, i) => tableCell(String(c), {
      width: columnWidths?.[i],
      alignment: i === 0 ? AlignmentType.RIGHT : AlignmentType.RIGHT,
    })),
  }));
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: P.primary },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: P.primary },
      left: { style: BorderStyle.SINGLE, size: 2, color: P.border },
      right: { style: BorderStyle.SINGLE, size: 2, color: P.border },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: P.border },
      insideVertical: { style: BorderStyle.SINGLE, size: 1, color: P.border },
    },
    rows: [headerRow, ...dataRows],
  });
}

function note(text, type = "info") {
  const colors = {
    info: { bg: P.light, border: P.primary, icon: "ℹ️", label: "نکته" },
    warning: { bg: P.lightAccent, border: P.accent, icon: "⚠️", label: "هشدار" },
    success: { bg: P.light, border: P.primary, icon: "✓", label: "مزیت" },
  };
  const c = colors[type] || colors.info;
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      right: { style: BorderStyle.SINGLE, size: 12, color: c.border },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
    },
    rows: [new TableRow({
      cantSplit: true,
      children: [new TableCell({
        width: { size: 100, type: WidthType.PERCENTAGE },
        shading: { type: ShadingType.CLEAR, fill: c.bg, color: "auto" },
        margins: { top: 160, bottom: 160, left: 200, right: 200 },
        children: [
          new Paragraph({
            bidirectional: true,
            alignment: AlignmentType.RIGHT,
            spacing: { line: 340, after: 60 },
            children: [
              rtlRun(`${c.label}: `, { bold: true, color: c.border, size: 22 }),
              rtlRun(text, { size: 22 }),
            ],
          }),
        ],
      })],
    })],
  });
}

function spacer() {
  return new Paragraph({ children: [new TextRun({ text: " " })], spacing: { after: 120 } });
}

// ===== Cover page =====
function buildCover(title, subtitle, version, date, docCode) {
  return [
    // Top spacer
    new Paragraph({ children: [new TextRun({ text: " " })], spacing: { before: 2000 } }),

    // Logo placeholder
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [
        new TextRun({
          text: "CM AUTOMATION",
          bold: true,
          size: 56,
          color: P.primary,
          font: { ascii: FONT_EN, hAnsi: FONT_EN },
        }),
      ],
    }),

    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 2000 },
      children: [
        new TextRun({
          text: "سامانه مدیریت هوشمند ساخت",
          rightToLeft: true,
          size: 28,
          color: P.muted,
          font: { ascii: FONT_EN, eastAsia: FONT_BODY, hAnsi: FONT_EN, cs: FONT_BODY },
        }),
      ],
    }),

    // Divider
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 600 },
      border: {
        bottom: { style: BorderStyle.SINGLE, size: 16, color: P.primary, space: 1 },
      },
      children: [new TextRun({ text: "" })],
    }),

    // Document title
    new Paragraph({
      alignment: AlignmentType.CENTER,
      bidirectional: true,
      spacing: { before: 600, after: 400, line: 480 },
      children: [
        new TextRun({
          text: title,
          rightToLeft: true,
          bold: true,
          size: 52,
          color: P.primaryDark,
          font: { ascii: FONT_EN, eastAsia: FONT_HEADING, hAnsi: FONT_EN, cs: FONT_HEADING },
        }),
      ],
    }),

    // Subtitle
    new Paragraph({
      alignment: AlignmentType.CENTER,
      bidirectional: true,
      spacing: { after: 1600 },
      children: [
        new TextRun({
          text: subtitle,
          rightToLeft: true,
          size: 28,
          color: P.muted,
          font: { ascii: FONT_EN, eastAsia: FONT_BODY, hAnsi: FONT_EN, cs: FONT_BODY },
        }),
      ],
    }),

    // Meta info table
    new Table({
      width: { size: 70, type: WidthType.PERCENTAGE },
      alignment: AlignmentType.CENTER,
      borders: {
        top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        insideVertical: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      },
      rows: [
        new TableRow({
          children: [
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              borders: {
                top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                bottom: { style: BorderStyle.SINGLE, size: 4, color: P.border },
                left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
              },
              children: [new Paragraph({
                bidirectional: true,
                alignment: AlignmentType.RIGHT,
                children: [rtlRun("نسخه سند", { color: P.muted, size: 20 })],
              })],
            }),
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              borders: {
                top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                bottom: { style: BorderStyle.SINGLE, size: 4, color: P.border },
                left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
              },
              children: [new Paragraph({
                bidirectional: true,
                alignment: AlignmentType.RIGHT,
                children: [rtlRun("کد سند", { color: P.muted, size: 20 })],
              })],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              borders: {
                top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
              },
              children: [new Paragraph({
                bidirectional: true,
                alignment: AlignmentType.RIGHT,
                children: [rtlRun(version, { bold: true, color: P.primary, size: 24 })],
              })],
            }),
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              borders: {
                top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
              },
              children: [new Paragraph({
                bidirectional: true,
                alignment: AlignmentType.RIGHT,
                children: [rtlRun(docCode, { bold: true, color: P.primary, size: 24 })],
              })],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              margins: { top: 200, bottom: 80, left: 100, right: 100 },
              borders: {
                top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                bottom: { style: BorderStyle.SINGLE, size: 4, color: P.border },
                left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
              },
              children: [new Paragraph({
                bidirectional: true,
                alignment: AlignmentType.RIGHT,
                children: [rtlRun("تاریخ تدوین", { color: P.muted, size: 20 })],
              })],
            }),
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              margins: { top: 200, bottom: 80, left: 100, right: 100 },
              borders: {
                top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                bottom: { style: BorderStyle.SINGLE, size: 4, color: P.border },
                left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
              },
              children: [new Paragraph({
                bidirectional: true,
                alignment: AlignmentType.RIGHT,
                children: [rtlRun("سطح طبقه‌بندی", { color: P.muted, size: 20 })],
              })],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              borders: {
                top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
              },
              children: [new Paragraph({
                bidirectional: true,
                alignment: AlignmentType.RIGHT,
                children: [rtlRun(date, { bold: true, color: P.primary, size: 24 })],
              })],
            }),
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              borders: {
                top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
                right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
              },
              children: [new Paragraph({
                bidirectional: true,
                alignment: AlignmentType.RIGHT,
                children: [rtlRun("عمومی", { bold: true, color: P.primary, size: 24 })],
              })],
            }),
          ],
        }),
      ],
    }),

    // Footer
    new Paragraph({ children: [new TextRun({ text: " " })], spacing: { before: 3000 } }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      bidirectional: true,
      border: {
        top: { style: BorderStyle.SINGLE, size: 4, color: P.border, space: 4 },
      },
      children: [
        new TextRun({
          text: "این سند مطابق با استانداردهای IEEE 1471 و مدل 4+1 Kruchten تدوین شده است",
          rightToLeft: true,
          size: 18,
          color: P.muted,
          font: { ascii: FONT_EN, eastAsia: FONT_BODY, hAnsi: FONT_EN, cs: FONT_BODY },
        }),
      ],
    }),
  ];
}

// ===== Module export for shared utilities =====
module.exports = {
  P, FONT_BODY, FONT_HEADING, FONT_CODE, FONT_EN,
  rtlRun, ltrRun, rtlParagraph, heading, bullet, numberedItem,
  codeBlock, tableCell, makeTable, note, spacer, buildCover,
  Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  Header, Footer, PageNumber, NumberFormat, SectionType, PageBreak,
  Document, Packer, VerticalAlign, TableOfContents, StyleLevel,
};
