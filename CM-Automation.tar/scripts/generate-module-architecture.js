// generate-module-architecture.js
// Generic script for generating module architecture documents
// Usage: bun run generate-module-architecture.js <module-config.js>

const fs = require("fs");
const path = require("path");
const H = require("./docx-helpers");
const {
  P, rtlRun, rtlParagraph, heading, bullet, numberedItem, codeBlock, makeTable,
  note, spacer, buildCover, Paragraph, TextRun, Document, Packer,
  AlignmentType, PageBreak, SectionType, Header, Footer, PageNumber,
  NumberFormat, TableOfContents, StyleLevel,
} = H;

const OUT_DIR = "/home/z/my-project/download/architecture-docs";
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

// Load module config from command line argument
const configPath = process.argv[2];
if (!configPath) {
  console.error("Usage: bun run generate-module-architecture.js <module-config.js>");
  process.exit(1);
}

const moduleConfig = require(path.resolve(configPath));

// ===== TOC =====
function tocSection() {
  return [
    new Paragraph({
      bidirectional: true,
      alignment: AlignmentType.CENTER,
      spacing: { before: 480, after: 400, line: 480 },
      children: [new TextRun({
        text: "فهرست مطالب",
        rightToLeft: true,
        bold: true,
        size: 44,
        color: P.primary,
        font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
      })],
    }),
    new TableOfContents("Table of Contents", {
      hyperlink: true,
      headingStyleRange: "1-3",
      stylesWithLevels: [
        new StyleLevel("Heading1", 1),
        new StyleLevel("Heading2", 2),
        new StyleLevel("Heading3", 3),
      ],
    }),
    new Paragraph({
      bidirectional: true,
      alignment: AlignmentType.CENTER,
      spacing: { before: 200, after: 0 },
      children: [new TextRun({
        text: "(برای به‌روزرسانی فهرست، روی آن کلیک راست کرده و Update Field را انتخاب کنید)",
        rightToLeft: true,
        italics: true,
        size: 18,
        color: P.muted,
      })],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

// ===== Build all chapter content from config =====
function buildChapters(cfg) {
  const chapters = [];

  // Chapter 1: Introduction
  chapters.push(
    heading("فصل اول: معرفی ماژول", 1),
    rtlParagraph(cfg.introduction.purpose),
    spacer(),

    heading("۱.۱ اهداف ماژول", 2),
    ...cfg.introduction.goals.map((g, i) => numberedItem(String(i + 1), g)),
    spacer(),

    heading("۱.۲ مخاطبان سند", 2),
    rtlParagraph("این سند برای گروه‌های زیر تهیه شده است:"),
    ...cfg.introduction.audience.map(a => bullet(a)),
    spacer(),

    heading("۱.۳ دامنه ماژول", 2),
    rtlParagraph(cfg.introduction.scope),
    spacer(),

    heading("۱.۴ تعاریف و اصطلاحات ماژول", 2),
    makeTable(
      ["اصطلاح", "تعریف"],
      cfg.introduction.glossary,
      [30, 70]
    ),
    new Paragraph({ children: [new PageBreak()] }),
  );

  // Chapter 2: Logical Architecture
  chapters.push(
    heading("فصل دوم: معماری منطقی ماژول", 1),
    rtlParagraph(cfg.logical.overview),
    spacer(),

    heading("۲.۱ کامپوننت‌های ماژول", 2),
    makeTable(
      ["کامپوننت", "مسئولیت", "تکنولوژی"],
      cfg.logical.components,
      [25, 50, 25]
    ),
    spacer(),

    heading("۲.۲ وابستگی‌های ماژول", 2),
    rtlParagraph("این ماژول با ماژول‌های زیر در تعامل است:"),
    makeTable(
      ["ماژول وابسته", "نوع وابستگی", "توضیح"],
      cfg.logical.dependencies,
      [25, 20, 55]
    ),
    spacer(),

    heading("۲.۳ رابط‌های ماژول (Interfaces)", 2),
    ...cfg.logical.interfaces.map(iface => (
      new Paragraph({
        bidirectional: true,
        alignment: AlignmentType.JUSTIFIED,
        spacing: { line: 360, after: 100 },
        indent: { firstLine: 360 },
        children: [
          rtlRun(`${iface.name}: `, { bold: true, color: P.primary }),
          rtlRun(iface.description),
        ],
      })
    )),
    new Paragraph({ children: [new PageBreak()] }),
  );

  // Chapter 3: Data Model
  chapters.push(
    heading("فصل سوم: مدل داده (Data Model)", 1),
    rtlParagraph(cfg.dataModel.overview),
    spacer(),

    heading("۳.۱ موجودیت‌های اصلی", 2),
    ...cfg.dataModel.entities.map(entity => {
      const result = [
        heading(`${entity.name} (${entity.tableName})`, 3),
        rtlParagraph(entity.description),
        makeTable(
          ["فیلد", "نوع", "الزامی", "توضیح"],
          entity.fields,
          [20, 18, 12, 50]
        ),
        spacer(),
      ];
      return result;
    }).flat(),

    heading("۳.۲ روابط موجودیت‌ها (Relationships)", 2),
    ...cfg.dataModel.relationships.map(rel => bullet(rel)),
    spacer(),

    heading("۳.۳ ایندکس‌های پیشنهادی", 2),
    makeTable(
      ["نام ایندکس", "فیلدها", "نوع", "دلیل"],
      cfg.dataModel.indexes,
      [25, 25, 15, 35]
    ),
    new Paragraph({ children: [new PageBreak()] }),
  );

  // Chapter 4: API Specification
  chapters.push(
    heading("فصل چهارم: مشخصات API", 1),
    rtlParagraph(cfg.api.overview),
    spacer(),
  );

  for (const endpoint of cfg.api.endpoints) {
    chapters.push(
      heading(`۴.${endpoint.id} ${endpoint.method} ${endpoint.path}`, 2),
      rtlParagraph(endpoint.description),
      spacer(),

      endpoint.request && heading("Request", 3),
      endpoint.request && codeBlock(endpoint.request),
      endpoint.request && spacer(),

      endpoint.response && heading("Response", 3),
      endpoint.response && codeBlock(endpoint.response),
      endpoint.response && spacer(),

      endpoint.statusCodes && heading("Status Codes", 3),
      endpoint.statusCodes && makeTable(
        ["کد", "توضیح"],
        endpoint.statusCodes,
        [20, 80]
      ),
      endpoint.statusCodes && spacer(),
    );
  }

  chapters.push(new Paragraph({ children: [new PageBreak()] }));

  // Chapter 5: Use Cases
  chapters.push(
    heading("فصل پنجم: موارد استفاده (Use Cases)", 1),
    rtlParagraph(cfg.useCases.overview),
    spacer(),
  );

  for (const uc of cfg.useCases.cases) {
    chapters.push(
      heading(`${uc.id} - ${uc.title}`, 2),
      heading("Actor", 3),
      bullet(uc.actor),
      heading("Pre-conditions", 3),
      ...uc.preconditions.map(p => bullet(p)),
      heading("Main Flow", 3),
      ...uc.mainFlow.map((step, i) => numberedItem(String(i + 1), step)),
      heading("Alternative Flows", 3),
      ...uc.alternativeFlows.map(af => bullet(af)),
      heading("Post-conditions", 3),
      ...uc.postconditions.map(p => bullet(p)),
      spacer(),
    );
  }

  chapters.push(new Paragraph({ children: [new PageBreak()] }));

  // Chapter 6: Sequence Diagrams (textual)
  chapters.push(
    heading("فصل ششم: نمودارهای توالی (Sequence Diagrams)", 1),
    rtlParagraph("در این فصل، نمودارهای توالی برای فرآیندهای کلیدی ماژول به صورت متنی توصیف می‌شوند. این نمودارها برای درک تعامل بین کامپوننت‌ها در زمان اجرا ضروری هستند."),
    spacer(),
  );

  for (const sd of cfg.sequenceDiagrams) {
    chapters.push(
      heading(`${sd.id} - ${sd.title}`, 2),
      rtlParagraph(sd.description),
      heading("Participants", 3),
      ...sd.participants.map(p => bullet(p)),
      heading("Flow", 3),
      ...sd.flow.map((step, i) => numberedItem(String(i + 1), step)),
      spacer(),
    );
  }

  chapters.push(new Paragraph({ children: [new PageBreak()] }));

  // Chapter 7: Security
  chapters.push(
    heading("فصل هفتم: معماری امنیت ماژول", 1),
    rtlParagraph(cfg.security.overview),
    spacer(),

    heading("۷.۱ نقش‌ها و دسترسی‌ها", 2),
    makeTable(
      ["نقش", "دسترسی در این ماژول"],
      cfg.security.roles,
      [30, 70]
    ),
    spacer(),

    heading("۷.۲ الزامات امنیتی", 2),
    ...cfg.security.requirements.map(r => bullet(r)),
    spacer(),

    heading("۷.۳ Audit Trail", 2),
    rtlParagraph(cfg.security.auditTrail),
    new Paragraph({ children: [new PageBreak()] }),
  );

  // Chapter 8: Business Rules
  chapters.push(
    heading("فصل هشتم: قوانین کسب‌وکار (Business Rules)", 1),
    rtlParagraph("قوانین کسب‌وکار، قواعدی هستند که منطق کسب‌وکار ماژول را تعریف می‌کنند و باید در همه شرایط رعایت شوند. این قوانین در لایه Domain پیاده‌سازی می‌شوند و توسط unit test‌ها پوشش داده می‌شوند."),
    spacer(),
  );

  for (const rule of cfg.businessRules) {
    chapters.push(
      heading(`${rule.id} - ${rule.title}`, 2),
      rtlParagraph(rule.description),
      rule.validation && heading("Validation", 3),
      rule.validation && codeBlock(rule.validation),
      spacer(),
    );
  }

  chapters.push(new Paragraph({ children: [new PageBreak()] }));

  // Chapter 9: Quality Attributes
  chapters.push(
    heading("فصل نهم: ویژگی‌های کیفیت ماژول", 1),
    rtlParagraph("ویژگی‌های کیفیت اختصاصی این ماژول در ادامه آمده است. این ویژگی‌ها در طول توسعه و استقرار پایش می‌شوند."),
    spacer(),

    heading("۹.۱ عملکرد", 2),
    makeTable(
      ["معیار", "هدف", "ابزار پایش"],
      cfg.quality.performance,
      [35, 30, 35]
    ),
    spacer(),

    heading("۹.۲ قابلیت دسترسی", 2),
    ...cfg.quality.availability.map(a => bullet(a)),
    spacer(),

    heading("۹.۳ مقیاس‌پذیری", 2),
    ...cfg.quality.scalability.map(s => bullet(s)),
    new Paragraph({ children: [new PageBreak()] }),
  );

  // Chapter 10: Implementation Notes
  chapters.push(
    heading("فصل دهم: نکات پیاده‌سازی", 1),
    rtlParagraph("در این فصل، نکات کلیدی پیاده‌سازی، الگوهای طراحی به‌کاررفته و توصیه‌های فنی برای توسعه‌دهندگان ارائه می‌شود."),
    spacer(),

    heading("۱۰.۱ الگوهای طراحی به‌کاررفته", 2),
    makeTable(
      ["الگو", "کاربرد در این ماژول"],
      cfg.implementation.patterns,
      [25, 75]
    ),
    spacer(),

    heading("۱۰.۲ نکات فنی", 2),
    ...cfg.implementation.notes.map(n => bullet(n)),
    spacer(),

    heading("۱۰.۳ تست‌پذیری", 2),
    rtlParagraph(cfg.implementation.testing),
    spacer(),

    heading("۱۰.۴ مستندات مرتبط", 2),
    ...cfg.implementation.relatedDocs.map(d => numberedItem("", d)),
    spacer(),

    heading("۱۰.۵ تاریخچه تغییرات", 2),
    makeTable(
      ["نسخه", "تاریخ", "توضیح"],
      cfg.implementation.changelog,
      [15, 25, 60]
    ),
  );

  return chapters;
}

// ===== Assemble document =====
const doc = new Document({
  creator: "CM Automation Team",
  title: moduleConfig.meta.title,
  description: moduleConfig.meta.description,
  styles: {
    default: {
      document: {
        run: {
          font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY },
          size: 24,
          color: P.body,
        },
        paragraph: { spacing: { line: 360 } },
      },
      heading1: {
        run: {
          font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
          size: 36, bold: true, color: P.primary,
        },
        paragraph: {
          alignment: AlignmentType.RIGHT,
          bidirectional: true,
          spacing: { before: 480, after: 200, line: 480 },
        },
      },
      heading2: {
        run: {
          font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
          size: 30, bold: true, color: P.primary,
        },
        paragraph: {
          alignment: AlignmentType.RIGHT,
          bidirectional: true,
          spacing: { before: 360, after: 160, line: 400 },
        },
      },
      heading3: {
        run: {
          font: { ascii: H.FONT_EN, eastAsia: H.FONT_HEADING, hAnsi: H.FONT_EN, cs: H.FONT_HEADING },
          size: 26, bold: true, color: P.primaryDark,
        },
        paragraph: {
          alignment: AlignmentType.RIGHT,
          bidirectional: true,
          spacing: { before: 240, after: 120, line: 360 },
        },
      },
    },
  },
  sections: [
    // Cover
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
        },
      },
      children: buildCover(
        moduleConfig.meta.title,
        moduleConfig.meta.subtitle,
        moduleConfig.meta.version,
        moduleConfig.meta.date,
        moduleConfig.meta.code
      ),
    },
    // TOC + Body
    {
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            bidirectional: true,
            alignment: AlignmentType.RIGHT,
            children: [new TextRun({
              text: `${moduleConfig.meta.title} - ${moduleConfig.meta.version}`,
              rightToLeft: true,
              size: 18,
              color: P.muted,
              font: { ascii: H.FONT_EN, eastAsia: H.FONT_BODY, hAnsi: H.FONT_EN, cs: H.FONT_BODY },
            })],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: "صفحه ",
                rightToLeft: true,
                size: 18,
                color: P.muted,
              }),
              new TextRun({
                children: [PageNumber.CURRENT],
                size: 18,
                color: P.muted,
              }),
            ],
          })],
        }),
      },
      children: [
        ...tocSection(),
        ...buildChapters(moduleConfig),
      ],
    },
  ],
});

// ===== Generate =====
Packer.toBuffer(doc).then(buffer => {
  const outPath = path.join(OUT_DIR, moduleConfig.meta.fileName);
  fs.writeFileSync(outPath, buffer);
  console.log(`✓ Generated: ${outPath} (${(buffer.length / 1024).toFixed(1)} KB)`);
}).catch(err => {
  console.error("Error:", err);
  process.exit(1);
});
